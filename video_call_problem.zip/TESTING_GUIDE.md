# Testing Guide - Video Calls & Notifications

Complete guide to test video calls and notifications before deployment.

---

## Video Call Testing

### Prerequisites
- 2 browser windows/tabs (or 2 devices)
- Both users logged in
- Microphone & camera permissions granted
- Good internet connection

### Test Steps

#### 1. **Setup Two Users**
```
Browser 1: Log in as User A (buyer)
Browser 2: Log in as User B (seller)
```

#### 2. **Navigate to Messages**
- Both users go to Dashboard → Messages tab
- User A should see User B in conversation list
- User B should see User A in conversation list

#### 3. **Initiate Video Call (User A)**
- Click on User B's conversation
- Look for video call button in message header
- Click the video call button
- Should see "Calling..." status

#### 4. **Receive Call (User B)**
- User B should see incoming call modal
- Modal shows: "User A is calling..."
- Two buttons: "Accept" and "Decline"

#### 5. **Accept Call (User B)**
- Click "Accept" button
- Both users should see video call window
- Should see:
  - Local video (your camera)
  - Remote video (other person's camera)
  - Mic toggle button
  - Camera toggle button
  - Screen share button
  - End call button

#### 6. **Test Call Features**
- **Mute/Unmute**: Click mic button, should toggle
- **Camera On/Off**: Click camera button, should toggle
- **Screen Share**: Click screen share button (if supported)
- **Call Duration**: Should show elapsed time

#### 7. **End Call**
- Click end call button
- Both users should return to chat
- Call window should close

### Expected Results
- [ ] Call initiates successfully
- [ ] Incoming call modal appears
- [ ] Video streams display
- [ ] Audio works both ways
- [ ] Mic/camera toggles work
- [ ] Call duration displays
- [ ] End call works cleanly

### Troubleshooting

**No incoming call modal appears:**
- Check browser console for errors
- Verify both users are in same conversation
- Check internet connection
- Verify PeerJS library loaded

**No video/audio:**
- Check camera/mic permissions
- Try allowing permissions in browser settings
- Test camera/mic in browser settings
- Check firewall/network settings

**Call drops:**
- Check internet connection
- Try again with better connection
- Check browser console for errors

---

## Notification Testing

### Prerequisites
- 2 browser windows/tabs (or 2 devices)
- Both users logged in
- Notifications enabled in browser

### Test Steps

#### 1. **Check Notification Center**
- Look for bell icon in top navigation
- Click to open notification panel
- Should show "No notifications" initially

#### 2. **Trigger Order Notification (Seller)**
- User B (seller) creates a new product listing
- User A (buyer) should receive notification:
  - "New product available"
  - Shows product name
  - Shows timestamp

#### 3. **Trigger Message Notification**
- User B sends message to User A
- User A should see:
  - Notification badge on bell icon
  - Toast notification at bottom
  - Message in notification center

#### 4. **Trigger Order Notification (Buyer)**
- User A places an order
- User B (seller) should receive notification:
  - "New order received"
  - Shows order details
  - Shows timestamp

#### 5. **Test Notification Actions**
- Click notification in center
- Should navigate to relevant page
- Mark as read (click notification)
- Delete notification (click X)

#### 6. **Test Notification Badge**
- Unread notifications should show count
- Badge should update in real-time
- Clicking "Mark all as read" should clear badge

### Expected Results
- [ ] Notifications appear in real-time
- [ ] Toast notifications show
- [ ] Notification center updates
- [ ] Badge count is accurate
- [ ] Clicking notification navigates correctly
- [ ] Mark as read works
- [ ] Delete notification works

### Troubleshooting

**Notifications not appearing:**
- Check browser console for errors
- Verify Supabase real-time subscriptions
- Check notification permissions
- Verify both users are logged in

**Badge not updating:**
- Refresh page
- Check browser console
- Verify database has notification records

**Notifications not real-time:**
- Check internet connection
- Verify WebSocket connection in DevTools
- Check Supabase real-time status

---

## 🧪 Automated Testing Checklist

### Video Calls
- [ ] Call initiates from both buyer and seller
- [ ] Incoming call modal appears
- [ ] Video/audio streams work
- [ ] Mic toggle works
- [ ] Camera toggle works
- [ ] Screen share works (if supported)
- [ ] Call duration displays correctly
- [ ] End call works cleanly
- [ ] Call history is saved
- [ ] Multiple calls can be made sequentially

### Notifications
- [ ] Order notifications appear
- [ ] Message notifications appear
- [ ] Notification badge updates
- [ ] Toast notifications show
- [ ] Notification center displays all
- [ ] Mark as read works
- [ ] Delete notification works
- [ ] Real-time updates work
- [ ] Notifications persist after refresh
- [ ] Notification sounds work (if enabled)

---

## 📊 Performance Testing

### Video Call Performance
- **Latency**: Should be < 500ms
- **Frame rate**: Should be 24+ fps
- **Audio quality**: Should be clear
- **CPU usage**: Should be < 50%
- **Memory usage**: Should be < 200MB

### Notification Performance
- **Delivery time**: Should be < 1 second
- **UI update**: Should be instant
- **Database queries**: Should be < 100ms
- **Real-time latency**: Should be < 500ms

---

## 🔐 Security Testing

### Video Calls
- [ ] Only authenticated users can call
- [ ] Users can only call people in their conversations
- [ ] Call data is encrypted
- [ ] No unauthorized access to streams

### Notifications
- [ ] Only relevant notifications shown to user
- [ ] Users can't see others' notifications
- [ ] Notification data is secure
- [ ] No data leakage

---

## 📝 Test Report Template

```
Date: [Date]
Tester: [Name]
Environment: [Local/Staging/Production]

VIDEO CALLS
-----------
Status: [PASS/FAIL]
Issues: [List any issues]
Notes: [Additional notes]

NOTIFICATIONS
-------------
Status: [PASS/FAIL]
Issues: [List any issues]
Notes: [Additional notes]

OVERALL
-------
Ready for Deployment: [YES/NO]
Blockers: [List any blockers]
```

---

## 🚀 Deployment Decision

### Deploy if:
- All video call tests pass
- All notification tests pass
- No critical issues found
- Performance is acceptable
- Security checks pass

### Don't Deploy if:
- Video calls don't work
- Notifications don't appear
- Critical bugs found
- Performance issues
- Security vulnerabilities

---

## Support

If you encounter issues:
1. Check browser console for errors
2. Check Supabase logs
3. Verify network connection
4. Try in incognito mode
5. Clear browser cache
6. Try different browser

---

## 📚 Related Documentation

- [README.md](./README.md) - Main guide
- [DEPLOYMENT.md](./DEPLOYMENT.md) - Deployment guide
- [DEPLOYMENT_READY.md](./DEPLOYMENT_READY.md) - Pre-deployment checklist
