# Font Awesome Icon Reference Guide

## Quick Reference for Developers

This guide shows all Font Awesome icons used in the REWEAR application and their usage.

## Communication Icons

| Icon | Class | Usage | Location |
|------|-------|-------|----------|
| 💬 | `fas fa-comment` | Messages, Chat | Notifications, Shop, Dashboard |
| 📞 | `fas fa-phone` | Phone calls, End call | Video Call, Notifications |
| 📹 | `fas fa-video` | Video calls | Video Call, Dashboard, Notifications |

## User & Profile Icons

| Icon | Class | Usage | Location |
|------|-------|-------|----------|
| 👤 | `fas fa-user` | User avatar, Profile | Video Call, Incoming Call |
| 🏢 | `fas fa-building` | Business seller | Seller Verification |

## Status & Action Icons

| Icon | Class | Usage | Location |
|------|-------|-------|----------|
| ✅ | `fas fa-check` | Success, Confirm, In Stock | Modals, Product, Orders |
| ❌ | `fas fa-times` | Close, Delete, Out of Stock | Video Call, Modals, Products |
| ✓ | `fas fa-check-circle` | Approved, Success | Notifications, Orders |
| ✗ | `fas fa-times-circle` | Rejected, Error | Notifications, Orders |

## Media & Device Icons

| Icon | Class | Usage | Location |
|------|-------|-------|----------|
| 🎤 | `fas fa-microphone` | Microphone on | Video Call, Dashboard |
| 🔇 | `fas fa-microphone-slash` | Microphone muted | Video Call, Dashboard |
| 📷 | `fas fa-video` | Camera on | Video Call, Dashboard |
| 📕 | `fas fa-video-slash` | Camera off | Video Call, Dashboard |
| 🖥️ | `fas fa-desktop` | Screen share | Video Call |
| 📱 | `fas fa-mobile-alt` | Mobile device | PWA Install |
| 💻 | `fas fa-laptop` | Desktop/Laptop | PWA Install |

## Navigation & Control Icons

| Icon | Class | Usage | Location |
|------|-------|-------|----------|
| ➖ | `fas fa-minus` | Minimize | Video Call |
| ⬆️ | `fas fa-arrow-up` | Maximize, Restore | Video Call |
| 🔍 | `fas fa-search` | Search | Shop |
| ✕ | `fas fa-times` | Close button | Modals, Notifications |

## Commerce & Order Icons

| Icon | Class | Usage | Location |
|------|-------|-------|----------|
| 🛒 | `fas fa-shopping-cart` | Order placed | Order Tracking |
| 📦 | `fas fa-box` | Package, Order | Notifications, Orders |
| 🚚 | `fas fa-truck` | Shipping, Delivery | Order Tracking, Notifications |
| 💰 | `fas fa-money-bill` | Payment received | Notifications |
| 💳 | `fas fa-credit-card` | Payment card | Notifications |
| ⏳ | `fas fa-hourglass` | Pending, Awaiting | Order Tracking, Notifications |

## Feedback & Rating Icons

| Icon | Class | Usage | Location |
|------|-------|-------|----------|
| ⭐ | `fas fa-star` | Review, Rating | Order Tracking, Notifications |
| ♡ | `fas fa-heart` | Wishlist, Favorite | Shop |

## Notification & Alert Icons

| Icon | Class | Usage | Location |
|------|-------|-------|----------|
| 🔔 | `fas fa-bell` | Notification bell | Notification Center |
| 📭 | `fas fa-inbox` | Empty inbox | Notification Center |
| 🏷️ | `fas fa-tag` | Listing, Tag | Notifications |

## Usage Examples

### In HTML
```html
<!-- Simple icon -->
<i class="fas fa-video"></i>

<!-- Icon with text -->
<button>
  <i class="fas fa-phone"></i>
  End Call
</button>

<!-- Icon with styling -->
<i class="fas fa-star" style="color: #c8a96e; font-size: 20px;"></i>
```

### In JavaScript
```javascript
// Set icon dynamically
element.innerHTML = '<i class="fas fa-check"></i>';

// Change icon class
element.className = 'fas fa-times';

// Toggle icon
element.classList.toggle('fa-microphone', !isMuted);
element.classList.toggle('fa-microphone-slash', isMuted);
```

### In CSS
```css
/* Style icons */
.icon {
  color: #c8a96e;
  font-size: 16px;
  margin-right: 8px;
}

/* Animated icon */
.loading-icon {
  animation: spin 1s linear infinite;
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
```

## Icon Sizing

Font Awesome provides size modifiers:

```html
<!-- Default size -->
<i class="fas fa-video"></i>

<!-- Larger sizes -->
<i class="fas fa-video fa-lg"></i>      <!-- 1.33x -->
<i class="fas fa-video fa-2x"></i>      <!-- 2x -->
<i class="fas fa-video fa-3x"></i>      <!-- 3x -->
<i class="fas fa-video fa-5x"></i>      <!-- 5x -->
<i class="fas fa-video fa-7x"></i>      <!-- 7x -->
<i class="fas fa-video fa-10x"></i>     <!-- 10x -->
```

## Icon Rotation

```html
<!-- Rotate 90 degrees -->
<i class="fas fa-arrow-up fa-rotate-90"></i>

<!-- Rotate 180 degrees -->
<i class="fas fa-arrow-up fa-rotate-180"></i>

<!-- Rotate 270 degrees -->
<i class="fas fa-arrow-up fa-rotate-270"></i>

<!-- Flip horizontally -->
<i class="fas fa-arrow-up fa-flip-horizontal"></i>

<!-- Flip vertically -->
<i class="fas fa-arrow-up fa-flip-vertical"></i>
```

## Icon Animation

```html
<!-- Spinning animation -->
<i class="fas fa-spinner fa-spin"></i>

<!-- Pulsing animation -->
<i class="fas fa-circle fa-pulse"></i>
```

## Color Customization

```html
<!-- Using inline styles -->
<i class="fas fa-heart" style="color: #c8a96e;"></i>

<!-- Using CSS classes -->
<i class="fas fa-heart text-primary"></i>
```

```css
/* CSS color classes */
.text-primary { color: #c8a96e; }
.text-success { color: #27ae60; }
.text-error { color: #e74c3c; }
.text-warning { color: #f39c12; }
.text-info { color: #3498db; }
```

## Accessibility

### Always provide context
```html
<!-- Good: Icon with text -->
<button>
  <i class="fas fa-phone"></i>
  Call Seller
</button>

<!-- Good: Icon with aria-label -->
<button aria-label="End call">
  <i class="fas fa-phone"></i>
</button>

<!-- Avoid: Icon alone without context -->
<button>
  <i class="fas fa-phone"></i>
</button>
```

### Screen Reader Support
```html
<!-- Hide icon from screen readers if text is present -->
<button>
  <i class="fas fa-check" aria-hidden="true"></i>
  Confirm
</button>

<!-- Provide label for icon-only buttons -->
<button aria-label="Confirm receipt">
  <i class="fas fa-check"></i>
</button>
```

## Common Patterns

### Icon Button
```html
<button class="icon-btn">
  <i class="fas fa-video"></i>
</button>

<style>
  .icon-btn {
    background: #c8a96e;
    color: white;
    border: none;
    padding: 10px 16px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
  }
  
  .icon-btn:hover {
    background: #a68a52;
  }
</style>
```

### Icon with Badge
```html
<div class="icon-badge">
  <i class="fas fa-bell"></i>
  <span class="badge">5</span>
</div>

<style>
  .icon-badge {
    position: relative;
    display: inline-block;
  }
  
  .badge {
    position: absolute;
    top: -8px;
    right: -8px;
    background: #e74c3c;
    color: white;
    border-radius: 50%;
    width: 20px;
    height: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    font-weight: bold;
  }
</style>
```

### Icon List
```html
<ul class="icon-list">
  <li><i class="fas fa-check"></i> Feature 1</li>
  <li><i class="fas fa-check"></i> Feature 2</li>
  <li><i class="fas fa-check"></i> Feature 3</li>
</ul>

<style>
  .icon-list {
    list-style: none;
    padding: 0;
  }
  
  .icon-list li {
    padding: 8px 0;
    padding-left: 28px;
    position: relative;
  }
  
  .icon-list i {
    position: absolute;
    left: 0;
    color: #27ae60;
  }
</style>
```

## Performance Tips

1. **Use CDN** - Font Awesome CDN is optimized and cached
2. **Lazy load** - Load icons only when needed
3. **Minimize** - Use only the icons you need
4. **Cache** - Browser caches Font Awesome files
5. **Compress** - Icons are already optimized

## Browser Support

Font Awesome 6.4.0 supports:
- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Resources

- **Font Awesome Official**: https://fontawesome.com
- **Icon Search**: https://fontawesome.com/icons
- **Documentation**: https://fontawesome.com/docs
- **CDN**: https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css

---

**Last Updated**: May 4, 2026
**Font Awesome Version**: 6.4.0
**Status**: Production Ready
