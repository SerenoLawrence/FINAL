# Quick Setup Guide - Seller Ratings (Verified Buyers)

## ✅ What Was Implemented

### **Option B: Integrated with Order Reviews**
- Only **verified buyers** (completed orders) can rate sellers
- Rating happens **at the same time** as product review
- Prevents fake ratings - must have purchased to rate

---

## 🚀 Setup (3 Steps)

### **Step 1: Run SQL Migration**

1. Open **Supabase SQL Editor**
2. Copy and paste this file: `yoww-main/sql/add_seller_ratings_to_reviews.sql`
3. Click **Run**
4. Verify success:
   ```sql
   SELECT * FROM seller_ratings LIMIT 1;
   ```

### **Step 2: Test the Feature**

1. **Complete an order** (as a buyer)
2. Go to **Order Tracking** page
3. Click **"Leave a Review"** button
4. You'll see:
   - ⭐ Product rating (1-5 stars)
   - 👍👎 Seller rating (Trustworthy / Not Responsive)
   - 💬 Comment box
5. Fill everything and click **Submit**

### **Step 3: Check Seller Profile**

1. Visit the **seller's profile page**
2. Look at the **rating percentage** (e.g., "85%")
3. Hover over it to see: "X trustworthy, Y not responsive (from verified buyers)"

---

## 📊 How It Works

### **Review Modal (After Order Completion)**

```
┌──────────────────────────────────────┐
│ Leave a Review                       │
│ Product Name                         │
├──────────────────────────────────────┤
│ Product Rating                       │
│ ★ ★ ★ ★ ★                            │
├──────────────────────────────────────┤
│ Rate the Seller                      │
│ Was the seller trustworthy and       │
│ responsive?                          │
│                                      │
│ [👍 Trustworthy] [👎 Not Responsive] │
├──────────────────────────────────────┤
│ Your Experience (optional)           │
│ ┌────────────────────────────────┐  │
│ │ Share details about product... │  │
│ └────────────────────────────────┘  │
├──────────────────────────────────────┤
│ [Submit Review]  [Cancel]            │
└──────────────────────────────────────┘
```

### **What Gets Saved**

1. **Product Review** → `reviews` table
   - Star rating (1-5)
   - Comment
   - Buyer email

2. **Seller Rating** → `seller_ratings` table
   - Like or Dislike
   - Linked to order (verified purchase)
   - User ID

### **Trust Score Formula**

```
Trust Score = (Likes / Total Ratings) × 100

Example:
- 17 buyers: 👍 Trustworthy
- 3 buyers: 👎 Not Responsive
- Trust Score = (17 / 20) × 100 = 85%
```

---

## 🎯 Key Features

### ✅ **Verified Purchases Only**
- Must complete order to rate
- No fake reviews possible
- Linked to actual purchase

### ✅ **Fair System**
- One rating per order
- Can rate same seller multiple times (different orders)
- Both positive and negative feedback counted

### ✅ **Easy to Understand**
- Simple percentage (85% = trustworthy)
- Tooltip shows breakdown
- Visual thumbs up/down

### ✅ **Integrated Flow**
- Rate product AND seller together
- One modal, one submission
- Smooth user experience

---

## 📁 Files Changed

### Modified:
- ✅ `yoww-main/js/order-tracking.js`
  - Updated review modal UI
  - Added seller rating buttons
  - Updated submit function

- ✅ `yoww-main/js/seller-profile.js`
  - Added `loadSellerRatings()` function
  - Displays trust score percentage

### Created:
- ✅ `yoww-main/sql/add_seller_ratings_to_reviews.sql`
  - Database schema
  - RLS policies
  - Helper view

- ✅ `yoww-main/SELLER_RATING_VERIFIED_BUYERS.md`
  - Full documentation

- ✅ `yoww-main/SETUP_SELLER_RATINGS.md`
  - This quick guide

---

## 🔍 Testing Checklist

- [ ] SQL migration ran successfully
- [ ] `seller_ratings` table exists
- [ ] Complete a test order
- [ ] Click "Leave a Review" button
- [ ] See seller rating buttons (👍👎)
- [ ] Select product rating (stars)
- [ ] Select seller rating (thumbs)
- [ ] Submit review
- [ ] Check seller profile shows trust score
- [ ] Verify data in database:
  ```sql
  SELECT * FROM seller_ratings;
  SELECT * FROM seller_trust_scores;
  ```

---

## 💡 Example Usage

### **Good Seller Experience:**
```
Buyer completes order
→ Rates product: ★★★★★
→ Rates seller: 👍 Trustworthy
→ Comment: "Fast shipping, great communication!"
→ Seller's trust score increases
```

### **Bad Seller Experience:**
```
Buyer completes order (after delays)
→ Rates product: ★★☆☆☆
→ Rates seller: 👎 Not Responsive
→ Comment: "Took 5 days to reply to messages"
→ Seller's trust score decreases
```

---

## ❓ FAQ

**Q: Can buyers rate without purchasing?**  
A: No. Must complete an order first.

**Q: Can buyers rate the same seller multiple times?**  
A: Yes, but only once per order. If they buy again, they can rate again.

**Q: What if seller has no ratings?**  
A: Shows "—" until first rating is received.

**Q: Can sellers see who rated them?**  
A: No. Ratings are anonymous (only email is stored, not shown to seller).

**Q: Can buyers change their rating?**  
A: Currently no. They would need to contact support.

---

## 🎉 You're Done!

The seller rating system is now integrated with your order review process. Buyers will automatically rate sellers when they review products after order completion.

**Next Steps:**
1. Run the SQL migration
2. Test with a real order
3. Monitor seller trust scores
4. Encourage buyers to leave reviews

---

**Need Help?**
- Check `SELLER_RATING_VERIFIED_BUYERS.md` for detailed docs
- Verify SQL migration ran successfully
- Check browser console for errors
- Test with completed order (status = 'completed')
