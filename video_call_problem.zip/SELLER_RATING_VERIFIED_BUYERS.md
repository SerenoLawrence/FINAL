# Seller Rating System - Verified Buyers Only

## Overview
This seller rating system is **integrated with the order review process**. Only buyers who have completed orders can rate sellers, ensuring all ratings come from verified purchases.

## How It Works

### 1. **When Can Buyers Rate Sellers?**
- ✅ **After order is COMPLETED** (status = 'completed')
- ✅ **At the same time as product review**
- ✅ **One rating per order** (can't rate same seller multiple times for same order)
- ✅ **Verified purchases only** - no fake ratings

### 2. **Review Modal - What Buyers See**

When a buyer clicks "Leave a Review" after order completion, they see:

```
┌─────────────────────────────────────┐
│  Leave a Review                     │
│  Product Name                       │
├─────────────────────────────────────┤
│  Product Rating                     │
│  ★ ★ ★ ★ ★  (1-5 stars)            │
├─────────────────────────────────────┤
│  Rate the Seller                    │
│  Was the seller trustworthy and     │
│  responsive?                        │
│                                     │
│  [👍 Trustworthy] [👎 Not Responsive]│
├─────────────────────────────────────┤
│  Your Experience (optional)         │
│  [Text area for comments]           │
├─────────────────────────────────────┤
│  [Submit Review]  [Cancel]          │
└─────────────────────────────────────┘
```

### 3. **What Gets Saved**

**Product Review** (existing `reviews` table):
```javascript
{
  order_id: "...",
  product_id: "...",
  seller_id: "...",
  buyer_email: "...",
  rating: 1-5,        // Product rating
  comment: "..."      // Optional comment
}
```

**Seller Rating** (new `seller_ratings` table):
```javascript
{
  seller_id: "...",
  user_id: "...",
  order_id: "...",
  vote_type: "like" or "dislike",
  verified_purchase: true
}
```

### 4. **Trust Score Calculation**

```
Trust Score = (Total Likes / Total Ratings) × 100

Example:
- 8 buyers rated "Trustworthy" (👍)
- 2 buyers rated "Not Responsive" (👎)
- Trust Score = (8 / 10) × 100 = 80%
```

### 5. **Where Ratings Are Displayed**

**Seller Profile Page:**
- Shows trust score percentage (e.g., "85%")
- Tooltip shows breakdown: "8 trustworthy, 2 not responsive (from verified buyers)"
- Only counts ratings from completed orders

## Database Schema

### New Table: `seller_ratings`

```sql
CREATE TABLE seller_ratings (
  id UUID PRIMARY KEY,
  seller_id UUID REFERENCES sellers(id),
  user_id UUID REFERENCES auth.users(id),
  order_id UUID REFERENCES orders(id),
  vote_type TEXT CHECK (vote_type IN ('like', 'dislike')),
  verified_purchase BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ,
  
  UNIQUE(seller_id, user_id, order_id)
);
```

**Key Features:**
- `order_id` links rating to specific order (proof of purchase)
- `verified_purchase` always true (comes from completed order)
- `UNIQUE` constraint prevents duplicate ratings per order
- User can rate same seller multiple times (different orders)

### Helper View: `seller_trust_scores`

```sql
CREATE VIEW seller_trust_scores AS
SELECT 
  seller_id,
  COUNT(*) as total_ratings,
  COUNT(*) FILTER (WHERE vote_type = 'like') as likes,
  COUNT(*) FILTER (WHERE vote_type = 'dislike') as dislikes,
  ROUND((likes / total) * 100) as trust_score_percentage
FROM seller_ratings
GROUP BY seller_id;
```

## Setup Instructions

### Step 1: Run SQL Migration

1. Open Supabase SQL Editor
2. Copy contents of `yoww-main/sql/add_seller_ratings_to_reviews.sql`
3. Execute the SQL script
4. Verify table was created:

```sql
SELECT * FROM seller_ratings LIMIT 1;
SELECT * FROM seller_trust_scores;
```

### Step 2: Test the Feature

1. **Create a test order:**
   - Login as a buyer
   - Purchase a product
   - Mark order as completed (or have seller mark it)

2. **Leave a review:**
   - Go to Order Tracking page
   - Click "Leave a Review" button
   - Rate the product (1-5 stars)
   - Rate the seller (👍 Trustworthy or 👎 Not Responsive)
   - Add optional comment
   - Submit

3. **Verify on seller profile:**
   - Visit the seller's profile page
   - Check the trust score percentage
   - Hover over percentage to see breakdown

### Step 3: Verify Data

```sql
-- View all seller ratings
SELECT 
  sr.*,
  s.business_name as seller,
  o.reference_number as order_ref
FROM seller_ratings sr
JOIN sellers s ON s.id = sr.seller_id
JOIN orders o ON o.id = sr.order_id
ORDER BY sr.created_at DESC;

-- View trust scores
SELECT 
  s.business_name,
  ts.*
FROM seller_trust_scores ts
JOIN sellers s ON s.id = ts.seller_id
ORDER BY ts.trust_score_percentage DESC;
```

## UI Components

### Review Modal (order-tracking.js)

**Product Rating Section:**
- 5-star rating picker
- Required field

**Seller Rating Section:**
- Two buttons: "👍 Trustworthy" and "👎 Not Responsive"
- Visual feedback (green for like, red for dislike)
- Required field
- Can toggle selection

**Comment Section:**
- Optional textarea
- Placeholder suggests what to write
- Saved with product review

### Seller Profile Display (seller-profile.js)

**Trust Score:**
- Displayed as percentage (e.g., "85%")
- Tooltip shows: "X trustworthy, Y not responsive (from verified buyers)"
- Only visible if seller has ratings
- Shows "—" if no ratings yet

## Security Features

### 1. **Verified Purchases Only**
- Rating requires completed order
- `order_id` links to actual purchase
- Can't rate without buying

### 2. **Row Level Security (RLS)**
- **Read**: Anyone can view ratings (public trust scores)
- **Insert**: Only authenticated users can rate
- **Update/Delete**: Users can only modify their own ratings

### 3. **Validation**
- Vote type must be 'like' or 'dislike'
- One rating per user per seller per order
- User can rate same seller multiple times (different orders)

### 4. **Prevents Abuse**
- Can't rate without completing order
- Can't rate same order twice
- Can't fake verified purchase status

## Benefits

### For Buyers:
✅ See seller reputation before purchasing  
✅ Trust scores from real buyers only  
✅ No fake or paid reviews  
✅ Easy to understand (percentage)

### For Sellers:
✅ Build reputation through good service  
✅ Incentive to be responsive and trustworthy  
✅ Fair system (only verified buyers)  
✅ Multiple orders = multiple ratings (fair representation)

### For Platform:
✅ Increases trust in marketplace  
✅ Encourages quality service  
✅ Reduces disputes  
✅ Authentic feedback only

## Example Scenarios

### Scenario 1: First-Time Buyer
```
1. Buyer completes order
2. Clicks "Leave a Review"
3. Rates product: ★★★★★ (5 stars)
4. Rates seller: 👍 Trustworthy
5. Comment: "Fast shipping, great communication!"
6. Submits review
7. Seller's trust score increases
```

### Scenario 2: Unresponsive Seller
```
1. Buyer completes order (after delays)
2. Clicks "Leave a Review"
3. Rates product: ★★★☆☆ (3 stars)
4. Rates seller: 👎 Not Responsive
5. Comment: "Product is okay but seller took 3 days to reply"
6. Submits review
7. Seller's trust score decreases
```

### Scenario 3: Repeat Customer
```
1. Buyer orders from same seller (2nd time)
2. Completes order
3. Leaves another review
4. Can rate seller again (different order)
5. Both ratings count toward trust score
6. Fair representation of seller's service
```

## Troubleshooting

### Issue: "Please rate the seller" alert
**Cause**: Seller rating not selected  
**Solution**: Click either 👍 Trustworthy or 👎 Not Responsive

### Issue: Can't submit review
**Cause**: Missing required fields  
**Solution**: Must select both product rating (stars) AND seller rating (thumbs)

### Issue: Trust score shows "—"
**Cause**: Seller has no ratings yet  
**Solution**: Normal for new sellers, will show percentage after first rating

### Issue: Rating not appearing on seller profile
**Cause**: Order might not be completed, or database error  
**Solution**: Check order status is 'completed', verify SQL migration ran

## Future Enhancements

### Phase 2 (Optional):
1. **Response Rate Tracking**
   - Track seller message response times
   - Show average response time on profile

2. **Seller Badges**
   - "Top Rated" badge for 90%+ trust score
   - "Fast Responder" badge for quick replies
   - "Verified Seller" badge (already exists)

3. **Rating Breakdown**
   - Show chart: X% trustworthy, Y% not responsive
   - Filter reviews by seller rating

4. **Seller Response to Ratings**
   - Allow sellers to respond to negative ratings
   - Show seller's side of the story

## Technical Details

### Files Modified:
- ✅ `yoww-main/js/order-tracking.js` - Updated review modal
- ✅ `yoww-main/js/seller-profile.js` - Display trust scores

### Files Created:
- ✅ `yoww-main/sql/add_seller_ratings_to_reviews.sql` - Database schema
- ✅ `yoww-main/SELLER_RATING_VERIFIED_BUYERS.md` - This documentation

### Database Tables:
- ✅ `seller_ratings` - Stores verified buyer ratings
- ✅ `seller_trust_scores` - View for aggregated scores

### API Calls:

**Submit Rating:**
```javascript
await db.from('seller_ratings').upsert({
  seller_id: sellerId,
  user_id: userId,
  order_id: orderId,
  vote_type: 'like', // or 'dislike'
  verified_purchase: true
}, {
  onConflict: 'seller_id,user_id,order_id'
});
```

**Get Trust Score:**
```javascript
const { data } = await db
  .from('seller_ratings')
  .select('vote_type')
  .eq('seller_id', sellerId);

const likes = data.filter(r => r.vote_type === 'like').length;
const total = data.length;
const trustScore = Math.round((likes / total) * 100);
```

---

**Status**: ✅ Complete and Ready to Use  
**Version**: 1.0.0  
**Date**: May 5, 2026  
**Type**: Verified Buyer Ratings (Integrated with Order Reviews)
