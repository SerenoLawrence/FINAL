# Quick Test - Video Calls & Notifications (5 minutes)

Fast way to test both features before deployment.

---

## 🎬 Video Call - Quick Test (3 minutes)

### Setup
```
Open 2 browser windows:
- Window 1: Log in as User A
- Window 2: Log in as User B
```

### Test
1. **User A**: Go to Dashboard → Messages
2. **User A**: Click on User B's conversation
3. **User A**: Click video call button
4. **User B**: Should see incoming call modal
5. **User B**: Click "Accept"
6. **Both**: Should see video window with:
   - Your camera feed
   - Other person's camera feed
   - Mic/Camera/End Call buttons
7. **Both**: Click End Call button

### Result
- PASS: Video call works, both see video/audio
- FAIL: No video, no audio, or call doesn't connect

---

## Notification - Quick Test (2 minutes)

### Setup
```
Same 2 browser windows as above
```

### Test
1. **User B**: Go to Dashboard → Create New Listing
2. **User B**: Add a product and save
3. **User A**: Check notification bell
4. **User A**: Should see notification about new product
5. **User B**: Send message to User A
6. **User A**: Should see notification badge update

### Result
- PASS: Notifications appear in real-time
- FAIL: No notifications or delayed

---

## ⚡ What to Check

### Video Call
```
✓ Call initiates
✓ Incoming modal appears
✓ Video displays
✓ Audio works
✓ Can end call
```

### Notifications
```
✓ Notifications appear
✓ Badge updates
✓ Real-time delivery
✓ Can mark as read
```

---

## 🚨 If Something Fails

### Video Call Issues
1. Check browser console (F12)
2. Look for red errors
3. Check microphone/camera permissions
4. Try different browser
5. Check internet connection

### Notification Issues
1. Check browser console (F12)
2. Refresh page
3. Check Supabase connection
4. Try different browser
5. Clear browser cache

---

## ✅ Ready to Deploy?

**YES if:**
- Video calls work both ways
- Notifications appear in real-time
- No console errors
- Both features are responsive

**NO if:**
- Video calls don't work
- Notifications don't appear
- Console shows errors
- Features are slow/laggy

---

## 📝 Test Result

```
Date: ___________
Tester: ___________

Video Calls: [ ] PASS  [ ] FAIL
Notifications: [ ] PASS  [ ] FAIL

Overall: [ ] READY  [ ] NOT READY

Issues: _________________________________
```

---

## 🎯 Next Steps

1. Run this quick test
2. If PASS → Ready for deployment
3. If FAIL → Check TESTING_GUIDE.md for detailed troubleshooting
4. Fix issues and retest
5. Deploy when all tests pass
