# Admin Security Setup - Quick Checklist

## ✅ Step-by-Step Setup

### **Step 1: Update SQL File** ⚠️ REQUIRED

Open `yoww-main/sql/secure_admin_system.sql` and find this section (around line 120):

```sql
INSERT INTO admin_users (email, full_name, notes) VALUES
  ('admin1@gmail.com', 'Admin 1', 'Primary administrator - CHANGE THIS EMAIL'),
  ('admin2@gmail.com', 'Admin 2', 'Secondary administrator - CHANGE THIS EMAIL'),
  ('admin3@gmail.com', 'Admin 3', 'Tertiary administrator - CHANGE THIS EMAIL')
ON CONFLICT (email) DO NOTHING;
```

**Replace with YOUR actual Gmail addresses:**

```sql
INSERT INTO admin_users (email, full_name, notes) VALUES
  ('your-email@gmail.com', 'Your Name', 'Primary administrator'),
  ('partner-email@gmail.com', 'Partner Name', 'Secondary administrator'),
  ('developer-email@gmail.com', 'Developer Name', 'Technical administrator')
ON CONFLICT (email) DO NOTHING;
```

---

### **Step 2: Run SQL in Supabase**

1. Open **Supabase Dashboard**
2. Go to **SQL Editor**
3. Copy the ENTIRE contents of `secure_admin_system.sql`
4. Paste into SQL Editor
5. Click **Run** (or press Ctrl+Enter)
6. Wait for "Success" message

---

### **Step 3: Verify Tables Created**

Run this query in Supabase SQL Editor:

```sql
-- Check admin_users table
SELECT * FROM admin_users;

-- Check admin_audit_log table
SELECT * FROM admin_audit_log;
```

**Expected result:**
- `admin_users` shows your 3 admin emails
- `admin_audit_log` is empty (no actions yet)

---

### **Step 4: Test Admin Access**

1. **Logout** from current account
2. **Login** with one of your admin Gmail accounts
3. **Navigate** to: `http://localhost/pages/admin.html` (or your domain)
4. **Should see:** Admin dashboard loads immediately
5. **Check console:** Should see `[Admin] ✅ Admin access granted`

---

### **Step 5: Test Non-Admin Access**

1. **Logout**
2. **Login** with a regular user account (NOT in admin_users)
3. **Try to access:** `/pages/admin.html`
4. **Should see:** "Access Denied" alert
5. **Redirected to:** Home page

---

### **Step 6: Test Audit Logging**

1. **Login as admin**
2. **Access admin panel**
3. **Perform an action** (e.g., delete a seller rating)
4. **Check audit log:**

```sql
SELECT * FROM admin_audit_log 
ORDER BY created_at DESC 
LIMIT 5;
```

**Should see:**
- LOGIN event
- Any actions you performed
- Your admin email
- Timestamps

---

## 🔒 Security Verification

### **Test 1: Cannot View Admin List (Non-Admin)**

Login as regular user, open browser console, run:

```javascript
const { data, error } = await db.from('admin_users').select('*');
console.log(data, error);
```

**Expected:** Error (RLS policy violation)  
**If you see data:** ❌ Security issue - contact support

---

### **Test 2: Cannot Add Self as Admin**

Login as regular user, open browser console, run:

```javascript
const { data, error } = await db.from('admin_users').insert({
  email: 'hacker@test.com',
  is_active: true
});
console.log(error);
```

**Expected:** Error (RLS policy violation)  
**If successful:** ❌ Security issue - contact support

---

### **Test 3: Admin Can View Admin List**

Login as admin, open browser console, run:

```javascript
const { data, error } = await db.from('admin_users').select('*');
console.log(data);
```

**Expected:** Array of admin users  
**If error:** ❌ Check if you're logged in as admin

---

## 📋 Post-Setup Checklist

- [ ] SQL migration ran successfully
- [ ] `admin_users` table exists with your emails
- [ ] `admin_audit_log` table exists
- [ ] Admin login works
- [ ] Non-admin access is denied
- [ ] Audit logging is working
- [ ] Tested seller ratings deletion
- [ ] Verified RLS policies are active

---

## 🚨 If Something Goes Wrong

### **Problem: "Access Denied" for your admin email**

**Solution:**
```sql
-- Check if your email is in the table
SELECT * FROM admin_users WHERE email = 'your-email@gmail.com';

-- If not found, add it manually
INSERT INTO admin_users (email, full_name, is_active) 
VALUES ('your-email@gmail.com', 'Your Name', true);
```

---

### **Problem: Tables don't exist**

**Solution:**
- SQL migration didn't run successfully
- Check Supabase SQL Editor for error messages
- Make sure you copied the ENTIRE SQL file
- Try running it again

---

### **Problem: RLS policies not working**

**Solution:**
```sql
-- Check if RLS is enabled
SELECT tablename, rowsecurity 
FROM pg_tables 
WHERE tablename IN ('admin_users', 'admin_audit_log');

-- Should show rowsecurity = true for both
```

---

### **Problem: Audit logs not recording**

**Solution:**
```sql
-- Test the log function manually
SELECT log_admin_action(
  'test@gmail.com',
  'TEST_ACTION',
  'test_type',
  NULL,
  '{"test": true}'::jsonb
);

-- Check if it was inserted
SELECT * FROM admin_audit_log WHERE action = 'TEST_ACTION';
```

---

## 🎯 Quick Reference

### **Add New Admin**
```sql
INSERT INTO admin_users (email, full_name) 
VALUES ('newemail@gmail.com', 'New Admin');
```

### **Remove Admin**
```sql
UPDATE admin_users 
SET is_active = false 
WHERE email = 'email@gmail.com';
```

### **View Audit Log**
```sql
SELECT * FROM admin_audit_log 
ORDER BY created_at DESC 
LIMIT 20;
```

### **Check Who's Admin**
```sql
SELECT email, full_name, is_active, last_login 
FROM admin_users 
ORDER BY last_login DESC;
```

---

## 📞 Need Help?

1. Check `SECURE_ADMIN_SYSTEM.md` for detailed documentation
2. Review Supabase logs for errors
3. Verify SQL migration completed successfully
4. Check browser console for JavaScript errors

---

**Status:** Ready to Deploy  
**Security Level:** Enterprise-Grade  
**Setup Time:** ~10 minutes  
**Difficulty:** Easy (just run SQL)
