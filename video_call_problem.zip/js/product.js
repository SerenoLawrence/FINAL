// ============================================================
// product.js — Product detail page logic
// Used on: product.html
// ============================================================

// TABLES, COLUMNS, dbToJs, and jsToDb are now available globally
// from db-constants.js and data-mapper.js loaded via script tags

const productDetailContent = document.getElementById('productDetailContent');
if (!productDetailContent) throw new Error('product.js loaded on wrong page');

const params = new URLSearchParams(window.location.search);
const productId = params.get('id');

// ---- WISHLIST ----
let wishlist = JSON.parse(localStorage.getItem('wearix-wishlist') || '[]');
function saveWishlist() { localStorage.setItem('wearix-wishlist', JSON.stringify(wishlist)); }

function initWishlistBtn(btn, productName) {
  if (wishlist.includes(productName)) { 
    btn.classList.add('wishlisted');
    btn.style.color = '#8e1f1f';
  }
  btn.addEventListener('click', e => {
    e.preventDefault();
    e.stopPropagation();
    if (btn.classList.contains('wishlisted')) {
      btn.classList.remove('wishlisted');
      btn.style.color = '';
      wishlist = wishlist.filter(i => i !== productName);
    } else {
      btn.classList.add('wishlisted');
      btn.style.color = '#8e1f1f';
      if (!wishlist.includes(productName)) wishlist.push(productName);
      showSuccess('Added to Wishlist', `${productName} saved to your wishlist.`, 'Got it');
    }
    saveWishlist();
  });
}

// ---- RENDER DETAIL ----
async function renderDetail(p) {
  const sizes = p.sizes || ['S', 'M', 'L'];
  document.title = `${p.name} - REWEAR`;
  const breadcrumb = document.getElementById('breadcrumbName');
  if (breadcrumb) breadcrumb.textContent = p.name;

  // Load seller info if available
  let sellerHTML = '';
  let sellerData = null;
  console.log('[product] seller_id on product:', p.seller_id);
  if (p.seller_id) {
    try {
      const { data: sd, error: sellerErr } = await db
        .from('sellers')
        .select('id, business_name, verified, rating, description')
        .eq('id', p.seller_id)
        .single();

      console.log('[product] seller query result:', sd, 'error:', sellerErr?.message);

      if (!sellerErr && sd) {
        sellerData = sd; // use raw snake_case — no dbToJs needed
        const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
        sellerHTML = `
          <div class="sp-mini-card">
            <div class="sp-mini-left">
              <div class="sp-mini-avatar">
                ${sd.business_name.charAt(0).toUpperCase()}
              </div>
              <div>
                <div class="sp-mini-name">${sd.business_name}</div>
                ${sd.verified
                  ? `<div class="sp-mini-verified">
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="11" height="11" style="display:inline;vertical-align:middle;margin-right:3px;"><polyline points="20 6 9 17 4 12"/></svg>
                      Verified Seller
                     </div>`
                  : ''}
                ${sd.rating ? `<div class="sp-mini-rating">${starsFromRating(sd.rating)} (${sd.rating})</div>` : ''}
              </div>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              <a href="${prefix}seller-profile.html?id=${sd.id}" class="sp-mini-btn">View Profile</a>
              <button onclick="openInquiryModal('${sd.id}', '${sd.business_name.replace(/'/g, "\\'")}', '${p.id}')"
                style="padding:8px 16px;background:#fff;border:1.5px solid #c8a96e;color:#c8a96e;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;">
                Message
              </button>
            </div>
          </div>`;
      } else {
        console.warn('[product] Seller not found or error:', sellerErr?.message);
      }
    } catch(e) {
      console.warn('[product] Could not load seller:', e.message);
    }
  }

  // Load product reviews (optional - table may not exist yet)
  let reviews = [];
  try {
    const { data: reviewsDbData, error } = await db
      .from(TABLES.REVIEWS)
      .select('*')
      .eq('product_id', p.id)
      .order(COLUMNS.REVIEWS.CREATED_AT, { ascending: false })
      .limit(5);
    
    if (!error && reviewsDbData) {
      reviews = dbToJs(reviewsDbData);
    }
  } catch (error) {
    console.log('[product] Reviews not available:', error.message);
  }

  const avgRating = reviews?.length
    ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1)
    : p.rating;
  const reviewCount = reviews?.length || 0;

  const reviewsHTML = reviews?.length ? `
    <div class="pd-reviews" style="margin-top:24px;">
      <h4 style="margin:0 0 12px;font-size:16px;">Buyer Reviews (${reviewCount})</h4>
      ${reviews.map(r => `
        <div style="padding:12px 0;border-bottom:1px solid #eee;">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
            <span>${starsFromRating(r.rating)}</span>
            <span style="font-size:12px;color:#888;">${r.buyerEmail.replace(/(.{2}).*(@.*)/, '$1***$2')}</span>
            <span style="font-size:12px;color:#bbb;">${new Date(r.createdAt).toLocaleDateString()}</span>
          </div>
          ${r.comment ? `<p style="margin:0;font-size:14px;color:#444;">${r.comment}</p>` : ''}
        </div>
      `).join('')}
    </div>` : '';

  productDetailContent.innerHTML = `
    <div class="pd-image-wrap">
      <img src="${p.image_url}" alt="${p.name}" class="pd-image">
      <button class="wishlist-btn pd-wishlist" aria-label="Wishlist"><i class="fas fa-heart"></i></button>
    </div>
    <div class="pd-info">
      <span class="pd-category">${p.category}</span>
      <h1 class="pd-name">${p.name}</h1>
      <div class="pd-rating">${starsFromRating(avgRating)} <span class="pd-rating-num">(${avgRating}${reviewCount ? ` · ${reviewCount} reviews` : ''})</span></div>
      <div class="pd-price-row">
        <span class="pd-price">${formatPrice(p.price)}</span>
        ${p.suggested_price ? `<span class="pd-suggested">Suggested: ${formatPrice(p.suggested_price)}</span>` : ''}
      </div>
      ${p.description ? `<p class="pd-description">${p.description}</p>` : ''}
      ${sellerHTML}
      <div class="pd-size-section">
        <p class="pd-size-label">Select Size</p>
        <div class="pd-sizes">
          ${sizes.map((s, i) => `<button class="pd-size-btn${i === 0 ? ' active' : ''}" data-size="${s}">${s}</button>`).join('')}
        </div>
      </div>
      <div class="pd-actions">
        <button class="btn-primary-large pd-buy-btn" id="pdBuyBtn" ${!p.in_stock ? 'disabled style="opacity:0.5;cursor:not-allowed;"' : ''}>Buy Now</button>
        <button class="btn-secondary-large pd-cart-btn" id="pdCartBtn" ${!p.in_stock ? 'disabled style="opacity:0.5;cursor:not-allowed;"' : ''}>Add to Cart</button>
      </div>
      ${sellerData ? `
      <div style="margin-top:16px;">
        <button onclick="openQuickChatModal('${sellerData.id}', '${sellerData.business_name.replace(/'/g, "\\'")}', '${p.id}', '${p.name.replace(/'/g, "\\'")}')"
          style="width:100%;padding:14px;background:#fff;border:2px solid #c8a96e;color:#c8a96e;border-radius:10px;font-size:15px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:all 0.2s;"
          onmouseover="this.style.background='#c8a96e';this.style.color='#fff';"
          onmouseout="this.style.background='#fff';this.style.color='#c8a96e';">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          Chat with Seller
        </button>
      </div>` : ''}
      <div class="pd-meta">
        <span class="${p.in_stock ? 'pd-instock' : 'pd-outstock'}">${p.in_stock ? '<i class="fas fa-check"></i> In Stock' : '<i class="fas fa-times"></i> Out of Stock'}</span>
      </div>
      ${reviewsHTML}
    </div>`;

  // Size selector
  let selectedSize = sizes[0];
  productDetailContent.querySelectorAll('.pd-size-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      productDetailContent.querySelectorAll('.pd-size-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedSize = btn.dataset.size;
    });
  });

  // Wishlist
  initWishlistBtn(productDetailContent.querySelector('.pd-wishlist'), p.name);

  const goToCheckout = () => {
    const pid = new URLSearchParams(window.location.search).get('id');
    if (!pid) { showError('Error', 'Product information not found'); return; }
    const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
    window.location.href = prefix + `checkout.html?productId=${pid}&size=${selectedSize}`;
  };

  document.getElementById('pdBuyBtn')?.addEventListener('click', goToCheckout);
  document.getElementById('pdCartBtn')?.addEventListener('click', goToCheckout);
}

// ---- RELATED PRODUCTS ----
async function loadRelated(category, excludeId) {
  const relatedGrid = document.getElementById('relatedGrid');
  if (!relatedGrid) return;
  const { data, error } = await db.from('products').select('*').eq('category', category).eq('status', 'approved').eq('in_stock', true).neq('id', excludeId).limit(4);
  if (error || !data.length) { relatedGrid.innerHTML = '<p class="dash-empty">No related products.</p>'; return; }
  relatedGrid.innerHTML = data.map(p => `
    <div class="product-card" data-id="${p.id}">
      <div class="product-image"><img src="${p.image_url}" alt="${p.name}" loading="lazy"><button class="wishlist-btn"><i class="fas fa-heart"></i></button></div>
      <div class="product-info">
        <h3 class="product-name">${p.name}</h3>
        <p class="product-price">${formatPrice(p.price)}</p>
        <div class="product-sizes">${(p.sizes || []).map(s => `<span class="size-tag">${s}</span>`).join('')}</div>
        <div class="product-rating">${starsFromRating(p.rating)}</div>
      </div>
    </div>`).join('');
  relatedGrid.querySelectorAll('.product-card').forEach(card => {
    initWishlistBtn(card.querySelector('.wishlist-btn'), card.querySelector('.product-name').textContent.trim());
    card.addEventListener('click', e => {
      // Check if the clicked element is the wishlist button or inside it
      if (e.target.classList.contains('wishlist-btn') || 
          e.target.closest('.wishlist-btn')) {
        return;
      }
      const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
      window.location.href = prefix + `product.html?id=${card.dataset.id}`;
    });
  });
}

// ---- LOAD ----
async function loadProductDetail() {
  if (!productId) { productDetailContent.innerHTML = '<p class="dash-empty">Product not found.</p>'; return; }
  const { data: p, error } = await db.from('products').select('*').eq('id', productId).single();
  if (error || !p) {
    productDetailContent.innerHTML = '<p class="dash-empty">Product not found.</p>';
    console.error('[product.js] loadProductDetail:', error?.message);
    return;
  }
  await renderDetail(p);
  loadRelated(p.category, p.id);
}

// Inquiry modal (inline, reused from seller-profile.js pattern)
// Inquiry modal - Consolidated in core.js
// Uses window.openInquiryModal() and window.submitInquiry() from core.js
// These functions are now shared across all pages

// Quick chat modal - Consolidated in core.js
// Uses window.openQuickChatModal() and window.submitQuickChat() from core.js

// submitInquiry - Consolidated in core.js
// Uses window.submitInquiry() from core.js for all pages

loadProductDetail();
