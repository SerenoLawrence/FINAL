/**
 * ============================================================
 * CHAT ROUTER - Centralized Message Routing System
 * ============================================================
 * 
 * This module ensures ALL buyer messages are routed to the correct seller
 * regardless of where the chat is initiated (shop, profile, review, etc.)
 * 
 * Key Features:
 * - Single entry point for all buyer messages
 * - Automatic seller identification
 * - Conversation deduplication (prevents duplicate chats with same seller)
 * - Unified message threading
 * - Real-time synchronization
 */

// ============================================================
// CHAT ROUTER - Core Routing Logic
// ============================================================

const ChatRouter = {
  /**
   * Send a message from buyer to seller
   * CENTRALIZED: Routes to existing conversation with this seller or creates new one
   * 
   * KEY BEHAVIOR:
   * - If buyer has ALREADY chatted with this seller, message goes to SAME thread
   * - If buyer is NEW to this seller, creates ONE conversation
   * - Prevents duplicate conversations between same buyer-seller pair
   * - Works from ANY source (shop, profile, review, dashboard, etc.)
   * 
   * @param {Object} options
   *   - sellerId: Seller's ID (required)
   *   - sellerEmail: Seller's email (optional, for lookup)
   *   - buyerEmail: Buyer's email (auto-detected if not provided)
   *   - buyerName: Buyer's name (optional)
   *   - message: Message text (required)
   *   - productId: Product ID (optional, for context)
   *   - source: Where message came from (shop, profile, review, dashboard, etc.)
   * 
   * @returns {Promise<Object>} { success, messageId, conversationId, isNewConversation, error }
   */
  async sendMessage(options) {
    try {
      const {
        sellerId,
        sellerEmail,
        buyerEmail,
        buyerName,
        message,
        productId,
        source = 'unknown'
      } = options;

      // Validation
      if (!sellerId) throw new Error('sellerId is required');
      if (!message || !message.trim()) throw new Error('Message cannot be empty');

      // Get current user if not provided
      const currentUser = window.authManager?.getCurrentUser();
      const finalBuyerEmail = buyerEmail || currentUser?.email;
      const finalBuyerName = buyerName || currentUser?.user_metadata?.name || 'Buyer';

      if (!finalBuyerEmail) {
        throw new Error('Buyer email could not be determined. Please log in.');
      }

      // Check if messagesDb is available
      if (typeof messagesDb === 'undefined' || !messagesDb) {
        throw new Error('Message database not initialized');
      }

      console.log('[ChatRouter] CENTRALIZED routing - buyer to seller:', {
        buyer: finalBuyerEmail,
        seller: sellerId,
        source,
        productId
      });

      // CRITICAL: Check if conversation already exists with this seller
      // This ensures ONE conversation per buyer-seller pair
      const existingConversation = await this.findExistingConversation(
        finalBuyerEmail,
        sellerId
      );

      let conversationId;
      let isNewConversation = false;

      if (existingConversation) {
        // REUSE existing conversation - add to thread
        conversationId = existingConversation.id;
        console.log('[ChatRouter] ✓ REUSING existing conversation:', conversationId);
        console.log('[ChatRouter] Message from', source, 'added to existing thread');

        // Get current thread
        const thread = Array.isArray(existingConversation.thread)
          ? existingConversation.thread
          : [];

        // Add new message to thread
        thread.push({
          role: 'buyer',
          text: message,
          ts: new Date().toISOString(),
          source, // Track where message came from
          read: false
        });

        // Update conversation with new thread
        const { error: updateError } = await messagesDb
          .from('messages')
          .update({
            thread,
            message // Update preview message
          })
          .eq('id', conversationId);

        if (updateError) throw updateError;

        console.log('[ChatRouter] ✓ Message added to thread. Total messages:', thread.length);
      } else {
        // CREATE new conversation (first time buyer contacts this seller)
        isNewConversation = true;
        console.log('[ChatRouter] ✓ NEW conversation - first contact with seller:', sellerId);

        const payload = {
          seller_id: sellerId,
          buyer_email: finalBuyerEmail,
          buyer_name: finalBuyerName,
          message: message, // Preview message
          product_id: productId || null,
          thread: [
            {
              role: 'buyer',
              text: message,
              ts: new Date().toISOString(),
              source,
              read: false
            }
          ],
          accepted: false,
          rejected: false
        };

        const { data, error: insertError } = await messagesDb
          .from('messages')
          .insert([payload])
          .select();

        if (insertError) throw insertError;
        if (!data || data.length === 0) throw new Error('Failed to create conversation');

        conversationId = data[0].id;
        console.log('[ChatRouter] ✓ New conversation created:', conversationId);
      }

      console.log('[ChatRouter] ✓ Message routed successfully:', {
        conversationId,
        isNewConversation,
        source
      });

      return {
        success: true,
        messageId: conversationId,
        conversationId,
        isNewConversation,
        source
      };
    } catch (error) {
      console.error('[ChatRouter] ✗ Error routing message:', error);
      return {
        success: false,
        error: error.message
      };
    }
  },

  /**
   * Find existing conversation between buyer and seller
   * CRITICAL: Ensures ONE conversation per buyer-seller pair
   * 
   * Search logic:
   * 1. Look for active (not rejected) conversation
   * 2. Match by buyer_email AND seller_id
   * 3. Return first match (should only be one)
   * 
   * @param {string} buyerEmail - Buyer's email
   * @param {string} sellerId - Seller's ID
   * @returns {Promise<Object|null>} Existing conversation or null
   */
  async findExistingConversation(buyerEmail, sellerId) {
    try {
      if (typeof messagesDb === 'undefined' || !messagesDb) {
        console.warn('[ChatRouter] messagesDb not available');
        return null;
      }

      console.log('[ChatRouter] Searching for existing conversation:', {
        buyer: buyerEmail,
        seller: sellerId
      });

      // Query: Find conversation with this buyer-seller pair that is NOT rejected
      const { data, error } = await messagesDb
        .from('messages')
        .select('*')
        .eq('buyer_email', buyerEmail)
        .eq('seller_id', sellerId)
        .eq('rejected', false)
        .limit(1);

      if (error) {
        console.warn('[ChatRouter] Error querying conversation:', error);
        return null;
      }

      if (data && data.length > 0) {
        console.log('[ChatRouter] ✓ Found existing conversation:', data[0].id);
        return data[0];
      }

      console.log('[ChatRouter] No existing conversation found (first contact)');
      return null;

      return null;
    } catch (error) {
      console.warn('[ChatRouter] Exception finding conversation:', error);
      return null;
    }
  },

  /**
   * Get all conversations for a buyer
   * Groups by seller to show unified view
   * 
   * @param {string} buyerEmail
   * @returns {Promise<Array>}
   */
  async getBuyerConversations(buyerEmail) {
    try {
      if (typeof messagesDb === 'undefined' || !messagesDb) {
        return [];
      }

      const { data, error } = await messagesDb
        .from('messages')
        .select('*')
        .eq('buyer_email', buyerEmail)
        .eq('rejected', false)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('[ChatRouter] Error getting buyer conversations:', error);
      return [];
    }
  },

  /**
   * Get all conversations for a seller
   * Groups by buyer
   * 
   * @param {string} sellerId
   * @returns {Promise<Array>}
   */
  async getSellerConversations(sellerId) {
    try {
      if (typeof messagesDb === 'undefined' || !messagesDb) {
        return [];
      }

      const { data, error } = await messagesDb
        .from('messages')
        .select('*')
        .eq('seller_id', sellerId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('[ChatRouter] Error getting seller conversations:', error);
      return [];
    }
  },

  /**
   * Add message to existing conversation thread
   * 
   * @param {string} conversationId
   * @param {string} role - 'buyer' or 'seller'
   * @param {string} text - Message text
   * @param {string} source - Where message came from
   * @returns {Promise<Object>}
   */
  async addMessageToThread(conversationId, role, text, source = 'unknown') {
    try {
      if (typeof messagesDb === 'undefined' || !messagesDb) {
        throw new Error('Message database not initialized');
      }

      // Fetch current conversation
      const { data: conversation, error: fetchError } = await messagesDb
        .from('messages')
        .select('thread')
        .eq('id', conversationId)
        .single();

      if (fetchError) throw fetchError;

      // Add message to thread
      const thread = Array.isArray(conversation?.thread) ? conversation.thread : [];
      thread.push({
        role,
        text,
        ts: new Date().toISOString(),
        source,
        read: false
      });

      // Update conversation
      const { error: updateError } = await messagesDb
        .from('messages')
        .update({
          thread
        })
        .eq('id', conversationId);

      if (updateError) throw updateError;

      return { success: true, threadLength: thread.length };
    } catch (error) {
      console.error('[ChatRouter] Error adding message to thread:', error);
      return { success: false, error: error.message };
    }
  },

  /**
   * Mark conversation as read
   * 
   * @param {string} conversationId
   * @returns {Promise<Object>}
   */
  async markAsRead(conversationId) {
    try {
      if (typeof messagesDb === 'undefined' || !messagesDb) {
        throw new Error('Message database not initialized');
      }

      const { error } = await messagesDb
        .from('messages')
        .update({ is_read: true })
        .eq('id', conversationId);

      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('[ChatRouter] Error marking as read:', error);
      return { success: false, error: error.message };
    }
  },

  /**
   * Accept conversation (seller action)
   * 
   * @param {string} conversationId
   * @returns {Promise<Object>}
   */
  async acceptConversation(conversationId) {
    try {
      if (typeof messagesDb === 'undefined' || !messagesDb) {
        throw new Error('Message database not initialized');
      }

      const { error } = await messagesDb
        .from('messages')
        .update({
          accepted: true,
          accepted_at: new Date().toISOString()
        })
        .eq('id', conversationId);

      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('[ChatRouter] Error accepting conversation:', error);
      return { success: false, error: error.message };
    }
  },

  /**
   * Reject conversation (seller action)
   * 
   * @param {string} conversationId
   * @param {string} reason - Optional rejection reason
   * @returns {Promise<Object>}
   */
  async rejectConversation(conversationId, reason = '') {
    try {
      if (typeof messagesDb === 'undefined' || !messagesDb) {
        throw new Error('Message database not initialized');
      }

      const { error } = await messagesDb
        .from('messages')
        .update({
          rejected: true,
          rejected_reason: reason,
          rejected_at: new Date().toISOString()
        })
        .eq('id', conversationId);

      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('[ChatRouter] Error rejecting conversation:', error);
      return { success: false, error: error.message };
    }
  }
};

// ============================================================
// GLOBAL EXPORTS
// ============================================================

window.ChatRouter = ChatRouter;

console.log('[ChatRouter] Centralized chat routing system loaded');
