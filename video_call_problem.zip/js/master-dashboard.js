
/* ==== MASTER DASHBOARD - Unified Dashboard Engine ==== */

// ============================================================
// dashboard.js — Unified Dashboard Logic
// Mode toggle, tab switching, auth check, video call engine
// ============================================================

let currentMode = 'buyer';
let sellerIsVerified = false;
let userIsSeller = false;

// ---- DOM REFS ----
const modeToggle    = document.getElementById('modeToggle');
const buyerLabel    = document.getElementById('buyerLabel');
const sellerLabel   = document.getElementById('sellerLabel');
const buyerNav      = document.getElementById('buyerNav');
const sellerNav     = document.getElementById('sellerNav');
const buyerContent  = document.getElementById('buyerContent');
const sellerContent = document.getElementById('sellerContent');
const modeBadge     = document.getElementById('modeBadge');
const verifyGate    = document.getElementById('verifyGate');
const becomeGate    = document.getElementById('becomeSellerGate');
const pendingGate   = document.getElementById('pendingGate');

// ---- MODE SWITCH ----
function switchMode(mode) {
    // Guard against multiple retries during mode switching
    if (window._switchModeRetrying) return;
    
    if (mode === 'seller') {
        // Always update toggle UI first
        modeToggle.classList.add('seller-mode');
        buyerLabel.classList.remove('active');
        sellerLabel.classList.add('active');
        buyerNav.style.display = 'none';
        sellerNav.style.display = 'block';
        modeBadge.textContent = 'Seller';
        modeBadge.style.background = '#c8a96e';
        document.getElementById('pageTitle').textContent = 'Seller Dashboard';

        // If auth hasn't resolved yet, show a loading state and retry
        if (!window.authManager?.isInitialized) {
            window._switchModeRetrying = true;
            currentMode = 'seller';
            buyerContent.style.display = 'none';
            sellerContent.style.display = 'none';
            verifyGate.style.display = 'none';
            becomeGate.style.display = 'none';
            document.getElementById('pageSubtitle').textContent = 'Loading…';
            // Retry once auth is ready
            const retryPoll = setInterval(() => {
                if (window.authManager?.isInitialized) {
                    clearInterval(retryPoll);
                    window._switchModeRetrying = false;
                    switchMode('seller');
                }
            }, 200);
            return;
        }

        if (!userIsSeller) {
            currentMode = 'seller';
            buyerContent.style.display = 'none';
            sellerContent.style.display = 'none';
            verifyGate.style.display = 'none';
            pendingGate.style.display = 'none';
            becomeGate.style.display = 'block';
            document.getElementById('pageSubtitle').textContent = 'Open your shop on REWEAR';
            return;
        }
        if (!sellerIsVerified) {
            currentMode = 'seller';
            buyerContent.style.display = 'none';
            sellerContent.style.display = 'none';
            becomeGate.style.display = 'none';
            // Check if verification is pending or not submitted
            if (window._verificationPending) {
                verifyGate.style.display = 'none';
                pendingGate.style.display = 'block';
                document.getElementById('pageSubtitle').textContent = 'Verification under review';
            } else {
                pendingGate.style.display = 'none';
                verifyGate.style.display = 'block';
                document.getElementById('pageSubtitle').textContent = 'Verify your identity to start selling';
            }
            return;
        }
        // Verified seller
        currentMode = 'seller';
        buyerContent.style.display = 'none';
        sellerContent.style.display = 'block';
        verifyGate.style.display = 'none';
        becomeGate.style.display = 'none';
        document.getElementById('pageSubtitle').textContent = 'Manage your listings and sales';

        // Force overview tab visible — strip active from all, re-add to overview
        sellerContent.querySelectorAll('.tab-content').forEach(t => {
            t.classList.remove('active');
            t.style.display = 'none';
        });
        const overviewTab = document.getElementById('tab-seller-overview');
        if (overviewTab) {
            overviewTab.classList.add('active');
            overviewTab.style.display = 'block';
        }

        // Update sidebar nav active state
        sellerNav.querySelectorAll('.nav-item').forEach(l => l.classList.remove('active'));
        const overviewNavItem = sellerNav.querySelector('[data-tab="seller-overview"]');
        if (overviewNavItem) overviewNavItem.classList.add('active');

        if (typeof loadOverviewStats === 'function') loadOverviewStats();
        if (typeof loadSellerMessages === 'function') loadSellerMessages();
    } else {
        // Buyer mode
        currentMode = 'buyer';
        modeToggle.classList.remove('seller-mode');
        buyerLabel.classList.add('active');
        sellerLabel.classList.remove('active');
        buyerNav.style.display = 'block';
        sellerNav.style.display = 'none';
        buyerContent.style.display = 'block';
        sellerContent.style.display = 'none';
        verifyGate.style.display = 'none';
        pendingGate.style.display = 'none';
        becomeGate.style.display = 'none';
        modeBadge.textContent = 'Buyer';
        modeBadge.style.background = '#4CAF50';
        document.getElementById('pageTitle').textContent = 'My Account';
        document.getElementById('pageSubtitle').textContent = 'Manage your orders and profile';

        // Ensure buyer overview tab is visible
        buyerContent.querySelectorAll('.tab-content').forEach(t => {
            t.classList.remove('active');
            t.style.display = 'none';
        });
        const buyerOverview = document.getElementById('tab-buyer-overview');
        if (buyerOverview) {
            buyerOverview.classList.add('active');
            buyerOverview.style.display = 'block';
        }
        buyerNav.querySelectorAll('.nav-item').forEach(l => l.classList.remove('active'));
        const buyerOverviewNav = buyerNav.querySelector('[data-tab="buyer-overview"]');
        if (buyerOverviewNav) buyerOverviewNav.classList.add('active');
    }
}

// ---- TAB SWITCHING ----
document.querySelectorAll('.nav-item[data-tab]').forEach(link => {
    link.addEventListener('click', e => {
        e.preventDefault();
        const tab     = link.dataset.tab;
        const section = link.dataset.section;
        const navEl   = section === 'seller' ? sellerNav : buyerNav;

        navEl.querySelectorAll('.nav-item').forEach(l => l.classList.remove('active'));
        link.classList.add('active');

        const contentEl = section === 'seller' ? sellerContent : buyerContent;

        // Remove active + hide all tabs in this section
        contentEl.querySelectorAll('.tab-content').forEach(t => {
            t.classList.remove('active');
            t.style.display = 'none';
        });

        // Show the target tab
        const tabEl = document.getElementById('tab-' + tab);
        if (tabEl) {
            tabEl.classList.add('active');
            tabEl.style.display = 'block';
        }

        // Lazy-load data per tab
        const loaders = {
            'seller-listings': () => typeof loadSellerListings === 'function' && loadSellerListings(),
            'seller-orders':   () => typeof loadSellerOrders   === 'function' && loadSellerOrders(),
            'seller-fees':     () => typeof loadFeesTab        === 'function' && loadFeesTab(),
            'seller-earnings': () => typeof loadEarningsTab    === 'function' && loadEarningsTab(),
            'seller-messages': () => typeof loadSellerMessages === 'function' && loadSellerMessages(),
            'seller-profile':  () => { typeof loadSellerProfile  === 'function' && loadSellerProfile(); loadSellerAccountSettings(); },
            'seller-overview': () => typeof loadOverviewStats  === 'function' && loadOverviewStats(),
            'seller-reviews':  () => loadSellerReviews(),
            'buyer-orders':    () => typeof loadBuyerOrders    === 'function' && loadBuyerOrders(),
            'buyer-messages':  () => typeof loadBuyerMessages  === 'function' && loadBuyerMessages(),
            'buyer-profile':   () => typeof loadBuyerProfile   === 'function' && loadBuyerProfile(),
        };
        if (loaders[tab]) loaders[tab]();
    });
});

// ---- AUTH CHECK + INIT ----
document.addEventListener('DOMContentLoaded', async () => {
    console.log('[Dashboard] DOMContentLoaded - Loading dashboard...');
    
    // Load dashboard content immediately without waiting for auth
    loadMostAffordable();
    loadMostPopular();
    
    // Wait for auth to be ready, then initialize dashboard
    async function initDashboard() {
        if (!window.authManager?.isInitialized || !authManager.isAuthenticated?.()) {
            console.log('[Dashboard] Auth not ready or user not authenticated');
            return;
        }

        const user = authManager.getCurrentUser();
        console.log('[Dashboard] Auth ready, user:', user?.email, 'roles:', user?.roles);

        // --- Resolve seller status from DB (source of truth) ---
        // Check by user.id first, then fall back to email
        let sellerRecord = null;
        try {
            const { data: byIdArr } = await db
                .from('sellers')
                .select('id, verified, user_id')
                .eq('id', user.id)
                .limit(1);

            if (byIdArr && byIdArr.length > 0) {
                sellerRecord = byIdArr[0];
            } else {
                // Fallback: look up by email
                const { data: byEmailArr } = await db
                    .from('sellers')
                    .select('id, verified, user_id')
                    .eq('email', user.email)
                    .limit(1);
                sellerRecord = (byEmailArr && byEmailArr.length > 0) ? byEmailArr[0] : null;
            }
        } catch(e) {
            console.warn('[Dashboard] Could not query sellers table:', e.message);
        }

        // A user is a seller if: their metadata says so OR a sellers record exists for them
        userIsSeller = authManager.isSeller() || !!sellerRecord;
        sellerIsVerified = sellerRecord?.verified === true;

        // Check if verification is pending (submitted but not yet approved)
        window._verificationPending = false;
        if (userIsSeller && !sellerIsVerified) {
            try {
                const { data: verArr } = await db
                    .from('seller_verifications')
                    .select('status')
                    .eq('user_id', user.id)
                    .in('status', ['pending', 'approved'])
                    .limit(1);
                if (verArr && verArr.length > 0) {
                    window._verificationPending = verArr[0].status === 'pending';
                    // If somehow approved in verifications but not in sellers, sync it
                    if (verArr[0].status === 'approved') {
                        sellerIsVerified = true;
                    }
                }
            } catch(e) {
                console.warn('[Dashboard] Could not check verification status:', e.message);
            }
        }

        // If seller record exists but user_metadata doesn't have 'seller' role yet, sync it
        if (sellerRecord && !authManager.isSeller()) {
            console.log('[Dashboard] Seller record found but role not in metadata — syncing...');
            try {
                await authManager.addSellerRole();
                userIsSeller = true;
            } catch(e) {
                console.warn('[Dashboard] Could not sync seller role:', e.message);
                userIsSeller = true;
            }
        }

        console.log('[Dashboard] Seller status resolved:', { userIsSeller, sellerIsVerified, verificationPending: window._verificationPending });

        // Load buyer data
        if (typeof loadBuyerProfile === 'function') loadBuyerProfile();
        if (typeof loadBuyerOrders  === 'function') loadBuyerOrders();
        if (typeof loadBuyerOverviewStats === 'function') loadBuyerOverviewStats();
        if (typeof loadOverviewStats === 'function' && currentMode === 'buyer') {
            // loadOverviewStats in buyer context = buyer stats
            // (seller overview stats are loaded when switching to seller mode)
        }

        // Auto-open tab from URL hash
        const hash = window.location.hash.replace('#', '');
        if (hash === 'seller') {
            // Auto-switch to seller mode (handles redirect from verification page)
            switchMode('seller');
        } else if (hash) {
            const link = document.querySelector(`.nav-item[data-tab="${hash}"]`);
            if (link) link.click();
        }

        // Check for incoming video call from global notification system
        const incomingCallData = sessionStorage.getItem('incomingVideoCall');
        if (incomingCallData) {
            try {
                const callInfo = JSON.parse(incomingCallData);
                console.log('[Dashboard] Incoming video call detected:', callInfo);
                
                // Clear the flag immediately to prevent loops
                sessionStorage.removeItem('incomingVideoCall');
                
                // Switch to buyer messages tab
                const messagesLink = document.querySelector('.nav-item[data-tab="buyer-messages"]');
                if (messagesLink) {
                    messagesLink.click();
                }
                
                // Wait for messages to load, then accept the call
                setTimeout(() => {
                    console.log('[Dashboard] Auto-accepting incoming call...');
                    window._vcPendingRoomId = callInfo.roomId;
                    window._vcPendingCallerName = callInfo.callerName;
                    
                    // Trigger the accept call function
                    if (typeof window.vcAccept === 'function') {
                        window.vcAccept();
                    }
                }, 1500);
            } catch (e) {
                console.error('[Dashboard] Error processing incoming call:', e);
                sessionStorage.removeItem('incomingVideoCall');
            }
        }
    }

    // Poll for auth readiness — check every 200ms up to 5s
    let authWaitMs = 0;
    const authPoll = setInterval(async () => {
        authWaitMs += 200;
        if (window.authManager?.isInitialized) {
            clearInterval(authPoll);
            await initDashboard();
        } else if (authWaitMs >= 5000) {
            clearInterval(authPoll);
            console.warn('[Dashboard] Auth timed out after 5s');
            await initDashboard(); // Try anyway
        }
    }, 200);
});

// ---- CHECK VERIFICATION STATUS (called from pendingGate button) ----
window.checkVerificationStatus = async function() {
    const user = window.authManager?.getCurrentUser();
    if (!user) return;

    try {
        const { data: verArr } = await db
            .from('seller_verifications')
            .select('status')
            .eq('user_id', user.id)
            .order('submitted_at', { ascending: false })
            .limit(1);

        if (verArr && verArr.length > 0) {
            const status = verArr[0].status;
            if (status === 'approved') {
                // Re-check sellers table
                const { data: sellerArr } = await db
                    .from('sellers')
                    .select('id, verified')
                    .eq('user_id', user.id)
                    .limit(1);
                if (sellerArr && sellerArr.length > 0 && sellerArr[0].verified) {
                    sellerIsVerified = true;
                    window._verificationPending = false;
                    switchMode('seller');
                    return;
                }
            } else if (status === 'rejected') {
                window._verificationPending = false;
                alert('Your verification was rejected. Please resubmit with correct documents.');
                location.href = 'seller-verification.html';
                return;
            }
        }
        // Still pending
        showSuccess('Still Under Review', 'Your verification is still being reviewed. Please check back later.', 'OK');
    } catch(e) {
        console.warn('[Dashboard] checkVerificationStatus error:', e.message);
    }
};

// ---- MOST AFFORDABLE ----
async function loadMostAffordable() {
    const el = document.getElementById('mostCheapList');
    if (!el) return;
    try {
        const { data, error } = await db
            .from('products')
            .select('id, name, price, image_url')
            .eq('status', 'approved')
            .eq('in_stock', true)
            .order('price', { ascending: true })
            .limit(6);
        if (error || !data?.length) { el.innerHTML = '<p style="color:#aaa;font-size:13px;">No products found.</p>'; return; }
        el.innerHTML = data.map(p => `
            <a href="product.html?id=${p.id}" style="text-decoration:none;display:block;">
                <div style="border-radius:10px;overflow:hidden;background:#f5f5f5;border:1px solid #eee;transition:transform .2s;" onmouseover="this.style.transform='translateY(-3px)'" onmouseout="this.style.transform='none'">
                    <img src="${p.image_url || 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%22100%22%3E%3Crect fill=%22%23f0f0f0%22 width=%22100%22 height=%22100%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2214%22 fill=%22%23999%22 text-anchor=%22middle%22 dy=%22.3em%22%3ENo Image%3C/text%3E%3C/svg%3E'}" alt="${p.name}" style="width:100%;aspect-ratio:1;object-fit:cover;">
                    <div style="padding:8px;">
                        <p style="margin:0;font-size:12px;font-weight:600;color:#1a1a2e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${p.name}</p>
                        <p style="margin:3px 0 0;font-size:13px;font-weight:700;color:#c8a96e;">₱${parseFloat(p.price).toFixed(2)}</p>
                    </div>
                </div>
            </a>`).join('');
    } catch(e) { el.innerHTML = '<p style="color:#aaa;font-size:13px;">Could not load.</p>'; }
}

// ---- MOST POPULAR (most orders) ----
async function loadMostPopular() {
    const el = document.getElementById('mostPopularList');
    if (!el) return;
    try {
        // Get products ordered by number of orders (most purchased)
        const { data: orders } = await db
            .from('orders')
            .select('product_id')
            .not('product_id', 'is', null);

        if (!orders?.length) {
            // Fallback: just show newest approved products
            const { data } = await db.from('products').select('id, name, price, image_url').eq('status', 'approved').eq('in_stock', true).order('created_at', { ascending: false }).limit(6);
            renderPopular(el, data || []);
            return;
        }

        // Count orders per product
        const counts = {};
        orders.forEach(o => { counts[o.product_id] = (counts[o.product_id] || 0) + 1; });
        const topIds = Object.entries(counts).sort((a,b) => b[1]-a[1]).slice(0,6).map(e => e[0]);

        const { data } = await db.from('products').select('id, name, price, image_url').eq('status', 'approved').eq('in_stock', true).in('id', topIds);
        // Sort by order count
        const sorted = (data || []).sort((a,b) => (counts[b.id]||0) - (counts[a.id]||0));
        renderPopular(el, sorted);
    } catch(e) { el.innerHTML = '<p style="color:#aaa;font-size:13px;">Could not load.</p>'; }
}

function renderPopular(el, products) {
    if (!products.length) { el.innerHTML = '<p style="color:#aaa;font-size:13px;">No products found.</p>'; return; }
    el.innerHTML = products.map(p => `
        <a href="product.html?id=${p.id}" style="text-decoration:none;display:block;">
            <div style="border-radius:10px;overflow:hidden;background:#f5f5f5;border:1px solid #eee;transition:transform .2s;" onmouseover="this.style.transform='translateY(-3px)'" onmouseout="this.style.transform='none'">
                <img src="${p.image_url || 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%22100%22%3E%3Crect fill=%22%23f0f0f0%22 width=%22100%22 height=%22100%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2214%22 fill=%22%23999%22 text-anchor=%22middle%22 dy=%22.3em%22%3ENo Image%3C/text%3E%3C/svg%3E'}" alt="${p.name}" style="width:100%;aspect-ratio:1;object-fit:cover;">
                <div style="padding:8px;">
                    <p style="margin:0;font-size:12px;font-weight:600;color:#1a1a2e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${p.name}</p>
                    <p style="margin:3px 0 0;font-size:13px;font-weight:700;color:#c8a96e;">₱${parseFloat(p.price).toFixed(2)}</p>
                </div>
            </div>
        </a>`).join('');
}

// ---- TOGGLE EVENTS ----
// Use the visual state of the toggle (not currentMode) to determine direction
modeToggle.addEventListener('click', () => {
    const goingToSeller = !modeToggle.classList.contains('seller-mode');
    switchMode(goingToSeller ? 'seller' : 'buyer');
});
buyerLabel.addEventListener('click',  () => switchMode('buyer'));
sellerLabel.addEventListener('click', () => switchMode('seller'));

// ---- SELLER STUBS (overridden by dashboard-seller.js) ----
window.selectFeeTier   = window.selectFeeTier   || function(tier) { console.log('[dashboard] selectFeeTier stub:', tier); };
window.submitFeePayment = window.submitFeePayment || function() { console.log('[dashboard] submitFeePayment stub'); };

// ---- VIDEO CALL ENGINE ----
window.vcPeer = null;
window.vcLocalStream = null;
window.vcCurrentCall = null;
window.vcMuted = false;
window.vcCamOff = false;
window.vcPollingInterval = null;

function vcGenerateRoomId() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let id = '';
    for (let i = 0; i < 6; i++) id += chars[Math.floor(Math.random() * chars.length)];
    return id;
}

async function vcGetLocalStream() {
    window.vcLocalStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    document.getElementById('vcLocalVideo').srcObject = window.vcLocalStream;
    return window.vcLocalStream;
}

function vcSetStatus(connected, text) {
    const dot    = document.getElementById('vcDot');
    const status = document.getElementById('vcTopStatus');
    if (dot)    dot.className = 'vc-dot' + (connected ? ' connected' : '');
    if (status) status.textContent = text;
}

function vcShowOverlay(name) {
    document.getElementById('vcWaitingAvatar').textContent = name.charAt(0).toUpperCase();
    document.getElementById('vcWaitingName').textContent   = name;
    document.getElementById('vcTopName').textContent       = name;
    document.getElementById('vcOverlay').classList.add('active');
    document.getElementById('vcWaiting').style.display     = 'flex';
    document.getElementById('vcRemoteVideo').style.display = 'none';
}

function vcOnRemoteStream(stream) {
    const v = document.getElementById('vcRemoteVideo');
    v.srcObject = stream;
    v.style.display = 'block';
    document.getElementById('vcWaiting').style.display = 'none';
    vcSetStatus(true, 'Connected');
}

async function vcHangUp() {
    if (window.vcCurrentCall) { window.vcCurrentCall.close(); window.vcCurrentCall = null; }
    if (window.vcLocalStream) { window.vcLocalStream.getTracks().forEach(t => t.stop()); window.vcLocalStream = null; }
    if (window.vcPeer)        { window.vcPeer.destroy(); window.vcPeer = null; }
    if (window.vcPollingInterval) { clearInterval(window.vcPollingInterval); window.vcPollingInterval = null; }
    document.getElementById('vcOverlay').classList.remove('active');
    document.getElementById('vcIncoming').classList.remove('active');
    document.getElementById('vcLocalVideo').srcObject  = null;
    document.getElementById('vcRemoteVideo').srcObject = null;
    window.vcMuted = false; window.vcCamOff = false;
    document.getElementById('vcMicBtn').innerHTML = '<i class="fas fa-microphone"></i>';
    document.getElementById('vcCamBtn').innerHTML = '<i class="fas fa-video"></i>';
}
window.vcHangUp = vcHangUp;

window.vcToggleMic = function() {
    if (!window.vcLocalStream) return;
    window.vcMuted = !window.vcMuted;
    window.vcLocalStream.getAudioTracks().forEach(t => t.enabled = !window.vcMuted);
    document.getElementById('vcMicBtn').innerHTML  = window.vcMuted ? '<i class="fas fa-microphone-slash"></i>' : '<i class="fas fa-microphone"></i>';
    document.getElementById('vcMicBtn').className    = 'vc-btn' + (window.vcMuted ? ' off' : '');
};

window.vcToggleCam = function() {
    if (!window.vcLocalStream) return;
    window.vcCamOff = !window.vcCamOff;
    window.vcLocalStream.getVideoTracks().forEach(t => t.enabled = !window.vcCamOff);
    document.getElementById('vcCamBtn').innerHTML = window.vcCamOff ? '<i class="fas fa-video-slash"></i>' : '<i class="fas fa-video"></i>';
    document.getElementById('vcCamBtn').className   = 'vc-btn' + (window.vcCamOff ? ' off' : '');
};

// Buyer starts video call
window.buyerStartVideoCall = async function() {
    const chatId = window.activeChatId;
    if (!chatId) { alert('Open a conversation first'); return; }
    const name   = document.getElementById('buyerChatName')?.textContent || 'Seller';
    const roomId = vcGenerateRoomId();
    try {
        const { data: msg } = await messagesDb.from('messages').select('thread').eq('id', chatId).single();
        const thread = Array.isArray(msg?.thread) ? msg.thread : [];
        thread.push({ role: 'buyer', text: '📹 Video call invite', ts: new Date().toISOString(), type: 'video_call', roomId });
        await messagesDb.from('messages').update({ thread }).eq('id', chatId);
    } catch(e) { console.error('[vc] invite error:', e); }
    vcShowOverlay(name);
    vcSetStatus(false, 'Waiting for ' + name + ' to join…');
    try {
        await vcGetLocalStream();
        window.vcPeer = new Peer(roomId, { debug: 1 });
        window.vcPeer.on('open', () => vcSetStatus(false, 'Waiting for ' + name + '…'));
        window.vcPeer.on('call', call => {
            window.vcCurrentCall = call;
            call.answer(window.vcLocalStream);
            call.on('stream', vcOnRemoteStream);
            call.on('close', vcHangUp);
        });
        window.vcPeer.on('error', e => { console.error('[vc]', e); vcHangUp(); });
    } catch(e) { console.error('[vc]', e); vcHangUp(); }
};

window.buyerStartVoiceCall = function() {
    alert('Voice call — coming soon!');
};

// Incoming call
window.vcShowIncoming = function(roomId, callerName) {
    document.getElementById('vcIncomingAvatar').textContent = callerName.charAt(0).toUpperCase();
    document.getElementById('vcIncomingName').textContent   = callerName;
    document.getElementById('vcIncoming').classList.add('active');
    window._vcPendingRoomId     = roomId;
    window._vcPendingCallerName = callerName;
};

window.vcAccept = async function() {
    const roomId = window._vcPendingRoomId;
    const name   = window._vcPendingCallerName || 'Caller';
    document.getElementById('vcIncoming').classList.remove('active');
    vcShowOverlay(name);
    vcSetStatus(false, 'Connecting…');
    try {
        await vcGetLocalStream();
        const joinerId = roomId + '-' + Math.random().toString(36).substring(2, 7);
        window.vcPeer = new Peer(joinerId, { debug: 1 });
        window.vcPeer.on('open', () => {
            const call = window.vcPeer.call(roomId, window.vcLocalStream);
            window.vcCurrentCall = call;
            call.on('stream', vcOnRemoteStream);
            call.on('close', vcHangUp);
        });
        window.vcPeer.on('error', e => { console.error('[vc]', e); vcHangUp(); });
    } catch(e) { vcHangUp(); }
};

window.vcDecline = function() {
    document.getElementById('vcIncoming').classList.remove('active');
};

// Poll for incoming video call invites
function vcStartPolling() {
    if (window.vcPollingInterval) {
        console.log('[vc-polling] Already running');
        return;
    }
    
    console.log('[vc-polling] ✅ Started - checking for incoming calls every 3 seconds');
    let lastSeenTs = null;
    
    window.vcPollingInterval = setInterval(async () => {
        if (!window.activeChatId || !window.messagesDb) {
            console.log('[vc-polling] Skipping - no active chat or messagesDb');
            return;
        }
        
        try {
            const { data: msg } = await messagesDb.from('messages').select('thread').eq('id', window.activeChatId).single();
            const thread = Array.isArray(msg?.thread) ? msg.thread : [];
            
            // Look for video call invites from seller (most recent first)
            const invite = thread.slice().reverse().find(e =>
                e.type === 'video_call' && e.role === 'seller' && e.ts !== lastSeenTs
            );
            
            if (invite) {
                console.log('[vc-polling] 🎥 INCOMING CALL DETECTED!', invite);
                lastSeenTs = invite.ts;
                const sellerName = document.getElementById('buyerChatName')?.textContent || 'Seller';
                console.log('[vc-polling] Showing incoming call from:', sellerName);
                window.vcShowIncoming(invite.roomId, sellerName);
            }
        } catch(e) {
            console.error('[vc-polling] Error checking for calls:', e);
        }
    }, 3000);
}

// Start polling when messages tab opens
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.nav-item[data-tab]').forEach(link => {
        link.addEventListener('click', () => {
            if (link.dataset.tab === 'buyer-messages') {
                vcStartPolling();
            } else {
                // Stop polling when leaving messages tab
                if (window.vcPollingInterval) {
                    clearInterval(window.vcPollingInterval);
                    window.vcPollingInterval = null;
                }
            }
        });
    });
});

// Seller video call
window.startVideoCallFromChat = async function() {
    const name   = document.getElementById('sellerChatName')?.textContent || 'Buyer';
    const chatId = window.activeSellerChatId;
    const chars  = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let roomId   = '';
    for (let i = 0; i < 6; i++) roomId += chars[Math.floor(Math.random() * chars.length)];
    if (chatId && window.messagesDb) {
        try {
            const { data: msg } = await messagesDb.from('messages').select('thread').eq('id', chatId).single();
            const thread = Array.isArray(msg?.thread) ? msg.thread : [];
            thread.push({ role: 'seller', text: '📹 Video call invite', ts: new Date().toISOString(), type: 'video_call', roomId });
            await messagesDb.from('messages').update({ thread, reply: '📹 Video call invite', replied_at: new Date().toISOString() }).eq('id', chatId);
            if (window.openSellerChat) openSellerChat(chatId);
        } catch(e) { console.error('[vc] invite error:', e); }
    }
    sellerVcShowOverlay(name);
    sellerVcSetStatus(false, chatId ? ('Waiting for ' + name + '…') : ('Room: ' + roomId));
    try {
        await sellerVcGetLocalStream();
        window.sellerVcPeer = new Peer(roomId, { debug: 1 });
        window.sellerVcPeer.on('open', () => sellerVcSetStatus(false, 'Room: ' + roomId));
        window.sellerVcPeer.on('call', call => {
            window.sellerVcCurrentCall = call;
            call.answer(window.sellerVcLocalStream);
            call.on('stream', sellerVcOnRemoteStream);
            call.on('close', sellerVcHangUp);
        });
        window.sellerVcPeer.on('error', e => { console.error('[vc]', e); sellerVcHangUp(); });
    } catch(e) { console.error('[vc]', e); sellerVcHangUp(); }
};

window.startVoiceCall = function() { alert('Voice call — coming soon!'); };

// Seller VC engine
window.sellerVcPeer = null;
window.sellerVcLocalStream = null;
window.sellerVcCurrentCall = null;

async function sellerVcGetLocalStream() {
    window.sellerVcLocalStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    document.getElementById('sellerVcLocalVideo').srcObject = window.sellerVcLocalStream;
    return window.sellerVcLocalStream;
}
function sellerVcSetStatus(connected, text) {
    const dot    = document.getElementById('sellerVcDot');
    const status = document.getElementById('sellerVcTopStatus');
    if (dot)    dot.className = 'vc-dot' + (connected ? ' connected' : '');
    if (status) status.textContent = text;
}
function sellerVcShowOverlay(name) {
    document.getElementById('sellerVcWaitingAvatar').textContent = name.charAt(0).toUpperCase();
    document.getElementById('sellerVcWaitingName').textContent   = name;
    document.getElementById('sellerVcTopName').textContent       = name;
    document.getElementById('sellerVcOverlay').classList.add('active');
    document.getElementById('sellerVcWaiting').style.display     = 'flex';
    document.getElementById('sellerVcRemoteVideo').style.display = 'none';
}
function sellerVcOnRemoteStream(stream) {
    const v = document.getElementById('sellerVcRemoteVideo');
    v.srcObject = stream;
    v.style.display = 'block';
    document.getElementById('sellerVcWaiting').style.display = 'none';
    sellerVcSetStatus(true, 'Connected');
}
async function sellerVcHangUp() {
    if (window.sellerVcCurrentCall) { window.sellerVcCurrentCall.close(); window.sellerVcCurrentCall = null; }
    if (window.sellerVcLocalStream) { window.sellerVcLocalStream.getTracks().forEach(t => t.stop()); window.sellerVcLocalStream = null; }
    if (window.sellerVcPeer)        { window.sellerVcPeer.destroy(); window.sellerVcPeer = null; }
    document.getElementById('sellerVcOverlay').classList.remove('active');
    document.getElementById('sellerVcLocalVideo').srcObject  = null;
    document.getElementById('sellerVcRemoteVideo').srcObject = null;
    document.getElementById('sellerVcMicBtn').textContent = '🎤';
    document.getElementById('sellerVcCamBtn').textContent = '📷';
}
window.sellerVcHangUp = sellerVcHangUp;
window.sellerVcToggleMic = function() {
    if (!window.sellerVcLocalStream) return;
    const on = window.sellerVcLocalStream.getAudioTracks()[0]?.enabled;
    window.sellerVcLocalStream.getAudioTracks().forEach(t => t.enabled = !t.enabled);
    document.getElementById('sellerVcMicBtn').textContent = on ? '🔇' : '🎤';
    document.getElementById('sellerVcMicBtn').className   = 'vc-btn' + (on ? ' off' : '');
};
window.sellerVcToggleCam = function() {
    if (!window.sellerVcLocalStream) return;
    const on = window.sellerVcLocalStream.getVideoTracks()[0]?.enabled;
    window.sellerVcLocalStream.getVideoTracks().forEach(t => t.enabled = !t.enabled);
    document.getElementById('sellerVcCamBtn').textContent = on ? '📕' : '📷';
    document.getElementById('sellerVcCamBtn').className   = 'vc-btn' + (on ? ' off' : '');
};

console.log('[dashboard] Unified dashboard JS loaded');

// ---- MOBILE SIDEBAR TOGGLE ----
// NOTE: On mobile, hamburger now opens the nav drawer (mobileNavDrawer)
// The sidebar (.modern-sidebar) is only used on desktop
(function() {
    const menuBtn = document.getElementById('mobileMenuBtn');
    const sidebar = document.querySelector('.modern-sidebar');
    const overlay = document.getElementById('sidebarOverlay');

    // On desktop: show sidebar normally, hide hamburger
    // On mobile: hamburger opens the nav drawer (handled in inline script)
    function checkMobile() {
        if (window.innerWidth <= 767) {
            // Hide old sidebar on mobile (drawer handles navigation)
            if (sidebar) {
                sidebar.classList.remove('open');
            }
        } else {
            // Desktop: close drawer if open
            const drawer = document.getElementById('mobileNavDrawer');
            if (drawer) drawer.classList.remove('open');
            if (overlay) overlay.classList.remove('show');
        }
    }
    checkMobile();
    window.addEventListener('resize', checkMobile);

    // Close sidebar when a nav item is clicked on mobile
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', () => {
            if (window.innerWidth <= 767) {
                if (sidebar) sidebar.classList.remove('open');
                if (overlay) overlay.classList.remove('show');
            }
        });
    });

    // Close sidebar/drawer when clicking on overlay (blurred background)
    if (overlay) {
        overlay.addEventListener('click', () => {
            const drawer = document.getElementById('mobileNavDrawer');
            if (drawer) drawer.classList.remove('open');
            if (sidebar) sidebar.classList.remove('open');
            overlay.classList.remove('show');
        });
    }
})();


// ============================================================
// MOBILE HEADER FUNCTIONALITY
// ============================================================

function initMobileHeader() {
    const mobileMessagesBtn = document.getElementById('mobileMessagesBtn');
    const mobileNotificationsBtn = document.getElementById('mobileNotificationsBtn');
    const mobileProfileBtn = document.getElementById('mobileProfileBtn');
    const messagesBadge = document.getElementById('messagesBadge');
    const notificationsBadge = document.getElementById('notificationsBadge');
    const mobileProfileAvatar = document.getElementById('mobileProfileAvatar');
    
    // Messages button click
    if (mobileMessagesBtn) {
        mobileMessagesBtn.addEventListener('click', () => {
            // Switch to messages tab
            const messagesTab = document.querySelector('[data-tab="buyer-messages"]') || 
                               document.querySelector('[data-tab="seller-messages"]');
            if (messagesTab) {
                messagesTab.click();
            }
            
            // Add active state
            mobileMessagesBtn.classList.add('active');
            setTimeout(() => mobileMessagesBtn.classList.remove('active'), 300);
        });
    }
    
    // Notifications button click
    if (mobileNotificationsBtn) {
        mobileNotificationsBtn.addEventListener('click', () => {
            // Show notifications panel - navigate to notifications tab if available
            const notificationsTab = document.querySelector('[data-tab="buyer-notifications"]') || 
                                    document.querySelector('[data-tab="seller-notifications"]');
            if (notificationsTab) {
                notificationsTab.click();
            } else {
                // Fallback: show message
                showError('Notifications', 'Notifications panel is not available on this page.');
            }
            
            // Add active state
            mobileNotificationsBtn.classList.add('active');
            setTimeout(() => mobileNotificationsBtn.classList.remove('active'), 300);
        });
    }
    
    // Profile button click
    if (mobileProfileBtn) {
        mobileProfileBtn.addEventListener('click', () => {
            // Switch to profile tab
            const profileTab = document.querySelector('[data-tab="buyer-profile"]') || 
                              document.querySelector('[data-tab="seller-profile"]');
            if (profileTab) {
                profileTab.click();
            }
            
            // Add active state
            mobileProfileBtn.classList.add('active');
            setTimeout(() => mobileProfileBtn.classList.remove('active'), 300);
        });
    }
    
    // Update notification badges
    async function updateNotificationBadges() {
        if (!window.authManager) return;
        
        const user = window.authManager.getCurrentUser();
        if (!user) return;
        
        try {
            // Get unread messages count
            const { data: messages, error: msgErr } = await window.db
                .from('messages')
                .select('id')
                .eq('seller_id', user.id)
                .eq('read', false);
            
            const unreadMessages = msgErr ? 0 : (messages?.length || 0);
            if (messagesBadge && unreadMessages > 0) {
                messagesBadge.textContent = unreadMessages > 99 ? '99+' : unreadMessages;
                messagesBadge.style.display = 'block';
            } else if (messagesBadge) {
                messagesBadge.style.display = 'none';
            }
            
            // Get unread notifications count
            const { data: notifs, error: notifErr } = await window.db
                .from('notifications')
                .select('id')
                .eq('user_id', user.id)
                .eq('read', false);
            
            const unreadNotifications = notifErr ? 0 : (notifs?.length || 0);
            if (notificationsBadge && unreadNotifications > 0) {
                notificationsBadge.textContent = unreadNotifications > 99 ? '99+' : unreadNotifications;
                notificationsBadge.style.display = 'block';
            } else if (notificationsBadge) {
                notificationsBadge.style.display = 'none';
            }
        } catch (err) {
            console.error('[updateNotificationBadges]', err);
        }
    }
    
    // Update profile avatar
    function updateProfileAvatar() {
        if (!window.authManager || !mobileProfileAvatar) return;
        
        const user = window.authManager.getCurrentUser();
        if (user && user.avatar_url) {
            mobileProfileAvatar.innerHTML = `<img src="${user.avatar_url}" alt="Profile">`;
        } else if (user && user.name) {
            // Show initials
            const initials = user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
            mobileProfileAvatar.innerHTML = `<span style="font-size:14px;font-weight:700;">${initials}</span>`;
        }
    }
    
    // Initialize
    updateNotificationBadges();
    updateProfileAvatar();
    
    // Update periodically
    setInterval(updateNotificationBadges, 30000); // Every 30 seconds
}

// Initialize mobile header when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initMobileHeader);
} else {
    initMobileHeader();
}

// ---- GCash QR Code Uploader ----
class QRCodeUploader {
  constructor() {
    this.qrImage = null;
    this.init();
  }

  init() {
    const dropzone  = document.getElementById('qrDropzone');
    const input     = document.getElementById('qrInput');
    const removeBtn = document.getElementById('qrRemove');

    if (!dropzone || !input) return;

    dropzone.addEventListener('click', () => input.click());

    input.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) this.handleFile(file);
    });

    dropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropzone.classList.add('drag-over');
    });

    dropzone.addEventListener('dragleave', () => {
      dropzone.classList.remove('drag-over');
    });

    dropzone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropzone.classList.remove('drag-over');
      const file = e.dataTransfer.files[0];
      if (file) this.handleFile(file);
    });

    if (removeBtn) {
      removeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.removeQR();
      });
    }
  }

  handleFile(file) {
    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file');
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      alert('File size must be less than 2MB');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      this.qrImage = { file, url: e.target.result };
      this.showPreview();
    };
    reader.readAsDataURL(file);
  }

  showPreview() {
    const dropzone = document.getElementById('qrDropzone');
    const preview  = document.getElementById('qrPreview');
    const img      = document.getElementById('qrImage');
    if (dropzone && preview && img) {
      dropzone.style.display = 'none';
      preview.style.display  = 'block';
      img.src = this.qrImage.url;
    }
  }

  removeQR() {
    const dropzone = document.getElementById('qrDropzone');
    const preview  = document.getElementById('qrPreview');
    const input    = document.getElementById('qrInput');
    if (dropzone && preview) {
      dropzone.style.display = 'block';
      preview.style.display  = 'none';
    }
    if (input) input.value = '';
    this.qrImage = null;
  }

  getQRImage() { return this.qrImage; }
}

// Init QR uploader + description char counter on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  window.qrUploader = new QRCodeUploader();

  const descTextarea = document.getElementById('newDescription');
  const charCount    = document.getElementById('descCharCount');
  if (descTextarea && charCount) {
    descTextarea.addEventListener('input', () => {
      const count = descTextarea.value.length;
      charCount.textContent = count;
      charCount.style.color = count > 500 ? '#EF4444' : '';
    });
  }
});

// ============================================================
// PRODUCT PREVIEW MODAL (buyer orders)
// ============================================================
window.openOrderProductPreview = function(orderId, productName, productImage, price, size, status) {
  document.getElementById('orderProductOverlay')?.remove();

  const overlay = document.createElement('div');
  overlay.id = 'orderProductOverlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;';

  const canReview = status === 'received';

  overlay.innerHTML = `
    <div style="background:#fff;border-radius:20px;max-width:460px;width:100%;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.3);animation:rwPopIn .22s ease;">
      ${productImage
        ? `<img src="${productImage}" alt="${productName}" style="width:100%;height:220px;object-fit:cover;">`
        : `<div style="width:100%;height:180px;background:linear-gradient(135deg,#1a1a2e,#2d2520);display:flex;align-items:center;justify-content:center;font-size:64px;">👕</div>`}
      <div style="padding:22px;">
        <h2 style="margin:0 0 6px;font-size:20px;font-weight:800;">${productName}</h2>
        <p style="font-size:22px;font-weight:800;color:#c8a96e;margin:0 0 10px;">${price}</p>
        ${size ? `<span style="background:#f5f5f5;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">Size: ${size}</span>` : ''}
        <div style="display:flex;gap:10px;margin-top:18px;">
          <button onclick="document.getElementById('orderProductOverlay').remove()"
            style="flex:1;padding:12px;background:#f5f5f5;color:#333;border:none;border-radius:10px;font-size:14px;font-weight:600;cursor:pointer;">
            Close
          </button>
          ${canReview ? `
          <button onclick="document.getElementById('orderProductOverlay').remove(); openBuyerReviewModal('${orderId}','${productName.replace(/'/g,"\\'")}','','${productImage.replace(/'/g,"\\'")}');"
            style="flex:1;padding:12px;background:linear-gradient(135deg,#c8a96e,#e0c080);color:#fff;border:none;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(200,169,110,.4);">
            ⭐ Write a Review
          </button>` : ''}
        </div>
      </div>
    </div>`;

  document.body.appendChild(overlay);
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
};

// ============================================================
// BUYER REVIEW MODAL — promo style with photo upload
// ============================================================
window.openBuyerReviewModal = function(orderId, productName, productId, productImage) {
  document.getElementById('buyerReviewOverlay')?.remove();

  const overlay = document.createElement('div');
  overlay.id = 'buyerReviewOverlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;';

  overlay.innerHTML = `
    <div style="background:#fff;border-radius:20px;max-width:440px;width:100%;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.35);animation:rwPopIn .22s ease;">
      <!-- Hero -->
      <div style="background:linear-gradient(135deg,#1a1a2e,#2d2520);padding:24px;text-align:center;">
        ${productImage
          ? `<img src="${productImage}" alt="${productName}" style="width:90px;height:90px;border-radius:12px;object-fit:cover;border:3px solid #c8a96e;margin-bottom:12px;">`
          : `<div style="width:90px;height:90px;border-radius:12px;background:#c8a96e;display:inline-flex;align-items:center;justify-content:center;font-size:36px;margin-bottom:12px;">👕</div>`}
        <h2 style="color:#fff;font-size:20px;margin:0 0 4px;">Share your experience!</h2>
        <p style="color:rgba(255,255,255,.6);font-size:13px;margin:0;">${productName} · Help other buyers decide</p>
      </div>
      <!-- Body -->
      <div style="padding:24px;">
        <!-- Stars -->
        <div style="text-align:center;margin-bottom:16px;">
          <div id="rwStarRow" style="display:inline-flex;gap:6px;font-size:38px;cursor:pointer;">
            <span data-v="1" style="color:#ddd;transition:color .1s;user-select:none;">★</span>
            <span data-v="2" style="color:#ddd;transition:color .1s;user-select:none;">★</span>
            <span data-v="3" style="color:#ddd;transition:color .1s;user-select:none;">★</span>
            <span data-v="4" style="color:#ddd;transition:color .1s;user-select:none;">★</span>
            <span data-v="5" style="color:#ddd;transition:color .1s;user-select:none;">★</span>
          </div>
          <input type="hidden" id="rwSelectedRating" value="0">
        </div>
        <!-- Comment -->
        <textarea id="rwComment" rows="3" placeholder="What did you think? (optional)"
          style="width:100%;padding:12px;border:1px solid #ddd;border-radius:10px;font-size:14px;resize:vertical;font-family:inherit;box-sizing:border-box;margin-bottom:14px;"></textarea>
        <!-- Photo upload -->
        <label for="rwPhotoInput" style="display:flex;align-items:center;gap:8px;padding:10px 14px;border:2px dashed #ddd;border-radius:10px;cursor:pointer;font-size:13px;color:#888;margin-bottom:14px;transition:border-color .2s;"
          onmouseover="this.style.borderColor='#c8a96e';this.style.color='#c8a96e';"
          onmouseout="this.style.borderColor='#ddd';this.style.color='#888';">
          📷 Add a photo <span style="font-size:11px;margin-left:4px;">(optional)</span>
        </label>
        <input type="file" id="rwPhotoInput" accept="image/*" style="display:none;" onchange="rwPreviewPhoto(this)">
        <img id="rwPhotoPreview" src="" alt="Preview" style="display:none;width:90px;height:90px;border-radius:10px;object-fit:cover;border:2px solid #c8a96e;margin-bottom:14px;">
        <!-- Submit -->
        <button onclick="submitBuyerReview('${orderId}','${productId}')"
          style="width:100%;padding:14px;background:linear-gradient(135deg,#c8a96e,#e0c080);color:#fff;border:none;border-radius:10px;font-size:16px;font-weight:700;cursor:pointer;margin-bottom:10px;box-shadow:0 4px 14px rgba(200,169,110,.4);">
          Submit Review ⭐
        </button>
        <div style="text-align:center;">
          <span onclick="document.getElementById('buyerReviewOverlay').remove()"
            style="color:#aaa;font-size:13px;cursor:pointer;text-decoration:underline;">Maybe Later</span>
        </div>
      </div>
    </div>`;

  document.body.appendChild(overlay);
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });

  // Star picker
  let rwSelected = 0;
  const stars = overlay.querySelectorAll('#rwStarRow span');
  stars.forEach(s => {
    s.addEventListener('mouseover', () => {
      const v = +s.dataset.v;
      stars.forEach((x, i) => x.style.color = i < v ? '#c8a96e' : '#ddd');
    });
    s.addEventListener('click', () => {
      rwSelected = +s.dataset.v;
      document.getElementById('rwSelectedRating').value = rwSelected;
      stars.forEach((x, i) => x.style.color = i < rwSelected ? '#c8a96e' : '#ddd');
    });
  });
  overlay.querySelector('#rwStarRow').addEventListener('mouseleave', () => {
    stars.forEach((x, i) => x.style.color = i < rwSelected ? '#c8a96e' : '#ddd');
  });
};

window.rwPreviewPhoto = function(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    const img = document.getElementById('rwPhotoPreview');
    img.src = e.target.result;
    img.style.display = 'block';
  };
  reader.readAsDataURL(file);
};

window.submitBuyerReview = async function(orderId, productId) {
  const rating  = parseInt(document.getElementById('rwSelectedRating')?.value || '0');
  const comment = document.getElementById('rwComment')?.value.trim();
  const photoInput = document.getElementById('rwPhotoInput');
  const user = window.authManager?.getCurrentUser();

  if (!rating) { alert('Please select a star rating.'); return; }
  if (!user)   { alert('Please log in to leave a review.'); return; }

  // Verify order is eligible
  const { data: order, error: orderErr } = await window.db
    .from('orders')
    .select('id, status, seller_id, buyer_email')
    .eq('id', orderId)
    .eq('buyer_email', user.email)
    .eq('status', 'received')
    .single();

  if (orderErr || !order) {
    alert('This order is not eligible for a review.');
    return;
  }

  // Check not already reviewed
  const { data: existing } = await window.db
    .from('reviews').select('id').eq('order_id', orderId).single();
  if (existing) {
    alert('You have already reviewed this order.');
    document.getElementById('buyerReviewOverlay')?.remove();
    return;
  }

  // Upload photo if provided
  let photoUrl = null;
  const photoFile = photoInput?.files[0];
  if (photoFile && window.uploadToCloudinary) {
    try {
      photoUrl = await window.uploadToCloudinary(photoFile);
    } catch(e) {
      console.warn('[review] photo upload failed:', e.message);
    }
  }

  try {
    const { error } = await window.db.from('reviews').insert({
      order_id:    orderId,
      product_id:  productId || null,
      seller_id:   order.seller_id || null,
      buyer_email: user.email,
      rating,
      comment:     comment || null,
      photo_url:   photoUrl
    });
    if (error) throw error;

    document.getElementById('buyerReviewOverlay')?.remove();

    // Show promo-style success toast
    const toast = document.createElement('div');
    toast.style.cssText = 'position:fixed;bottom:30px;left:50%;transform:translateX(-50%);background:#1a1a2e;color:#fff;padding:16px 28px;border-radius:14px;font-size:14px;font-weight:600;z-index:99999;box-shadow:0 8px 24px rgba(0,0,0,.3);display:flex;align-items:center;gap:10px;';
    toast.innerHTML = '<span style="font-size:22px;">⭐</span> Review submitted! Thank you for helping other buyers.';
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);

    // Refresh pending reviews if on profile tab
    if (typeof loadPendingReviews === 'function') loadPendingReviews();
    if (typeof loadFeedback === 'function') loadFeedback();
  } catch(err) {
    console.error('[review]', err);
    alert('Could not submit review. Please try again.');
  }
};

// ============================================================
// SELLER REVIEWS TAB
// ============================================================
window.filterSellerReviews = function(type, btn) {
  document.querySelectorAll('.fb-filter-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  document.querySelectorAll('.seller-review-card').forEach(card => {
    card.style.display = (type === 'all' || card.dataset.type === type) ? 'block' : 'none';
  });
};

async function loadSellerReviews() {
  const list  = document.getElementById('sellerReviewsList');
  const empty = document.getElementById('sellerReviewsEmpty');
  if (!list) return;

  const sellerId = await getSellerIdForCurrentUser();
  if (!sellerId) return;

  list.querySelectorAll('.seller-review-card').forEach(c => c.remove());

  try {
    const { data: reviews, error } = await window.db
      .from('reviews')
      .select('id, rating, comment, photo_url, created_at, buyer_email, products(name, image_url)')
      .eq('seller_id', sellerId)
      .order('created_at', { ascending: false });

    if (error) throw error;

    if (!reviews || reviews.length === 0) {
      if (empty) empty.style.display = 'block';
      // Update badge
      const badge = document.getElementById('sellerReviewsCount');
      if (badge) badge.style.display = 'none';
      return;
    }

    if (empty) empty.style.display = 'none';

    // Update badge
    const badge = document.getElementById('sellerReviewsCount');
    if (badge) { badge.textContent = reviews.length; badge.style.display = 'inline-block'; }

    reviews.forEach(r => {
      const stars = '★'.repeat(r.rating) + '☆'.repeat(5 - r.rating);
      const type  = r.rating >= 3 ? 'positive' : 'negative';
      const maskedEmail = r.buyer_email.replace(/(.{2}).*(@.*)/, '$1***$2');
      const initial = r.buyer_email[0].toUpperCase();
      const avatarBg = type === 'positive' ? '#c8a96e' : '#e74c3c';
      const productName = r.products?.name || '—';
      const date = new Date(r.created_at).toLocaleDateString('en-PH', { year:'numeric', month:'short', day:'numeric' });

      const card = document.createElement('div');
      card.className = 'seller-review-card';
      card.dataset.type = type;
      card.style.cssText = 'background:#fff;border-radius:14px;box-shadow:0 2px 12px rgba(0,0,0,.07);padding:18px;margin-bottom:14px;border:1px solid #f0f0f0;';
      card.innerHTML = `
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">
          <div style="width:42px;height:42px;border-radius:50%;background:${avatarBg};color:#fff;font-size:16px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0;">${initial}</div>
          <div style="flex:1;">
            <div style="font-weight:700;font-size:14px;">${maskedEmail}</div>
            <div style="font-size:12px;color:#888;">on: ${productName}</div>
          </div>
          <div style="font-size:12px;color:#bbb;">${date}</div>
        </div>
        <div style="display:inline-block;background:#fdf8f0;color:#c8a96e;border:1px solid #e8d5b0;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:600;margin-bottom:8px;">${productName}</div>
        <div style="color:#c8a96e;font-size:20px;margin-bottom:8px;letter-spacing:2px;">${stars}</div>
        ${r.comment ? `<p style="margin:0 0 10px;font-size:14px;color:#444;line-height:1.5;">"${r.comment}"</p>` : ''}
        ${r.photo_url ? `<img src="${r.photo_url}" alt="Review photo" style="width:100px;height:100px;border-radius:10px;object-fit:cover;border:2px solid #eee;cursor:pointer;" onclick="window.open('${r.photo_url}','_blank')">` : ''}`;
      list.appendChild(card);
    });

  } catch(e) {
    console.warn('[sellerReviews] Could not load:', e.message);
    if (empty) { empty.style.display = 'block'; empty.querySelector('p').textContent = 'Could not load reviews.'; }
  }
}

// ============================================================
// SELLER ACCOUNT SETTINGS (profile pic + name/email/phone)
// ============================================================
window.previewSellerProfilePic = function(input) {
  if (!input.files || !input.files[0]) return;
  const file = input.files[0];
  if (file.size > 10 * 1024 * 1024) { alert('File too large. Max 10MB.'); return; }
  const reader = new FileReader();
  reader.onload = e => {
    const preview = document.getElementById('sellerProfilePicPreview');
    const placeholder = document.getElementById('sellerProfilePicPlaceholder');
    if (preview) { preview.src = e.target.result; preview.style.display = 'block'; }
    if (placeholder) placeholder.style.display = 'none';
  };
  reader.readAsDataURL(file);
};

window.toggleSellerField = function(fieldId) {
  const input = document.getElementById(fieldId);
  if (!input) return;
  if (input.hasAttribute('readonly')) {
    input.removeAttribute('readonly');
    input.focus();
    input.style.borderColor = '#c8a96e';
    const saveRow = document.getElementById('sellerAcctSaveRow');
    if (saveRow) saveRow.style.display = 'flex';
  } else {
    input.setAttribute('readonly', true);
    input.style.borderColor = '';
  }
};

window.saveSellerAccountSettings = async function() {
  const name  = document.getElementById('sellerAcctName')?.value.trim();
  const phone = document.getElementById('sellerAcctPhone')?.value.trim();
  if (!name) { alert('Business name cannot be empty.'); return; }

  const sellerId = await getSellerIdForCurrentUser();
  if (sellerId && window.db) {
    try {
      await window.db.from('sellers').update({ business_name: name, phone }).eq('id', sellerId);
    } catch(e) { console.warn('[sellerAcct] save failed:', e.message); }
  }

  ['sellerAcctName','sellerAcctPhone'].forEach(id => {
    const el = document.getElementById(id);
    if (el) { el.setAttribute('readonly', true); el.style.borderColor = ''; }
  });
  const saveRow = document.getElementById('sellerAcctSaveRow');
  if (saveRow) saveRow.style.display = 'none';
  showSuccess('Saved!', 'Account settings updated.', 'Got it');
};

window.cancelSellerAccountEdit = function() {
  ['sellerAcctName','sellerAcctEmail','sellerAcctPhone'].forEach(id => {
    const el = document.getElementById(id);
    if (el) { el.setAttribute('readonly', true); el.style.borderColor = ''; }
  });
  const saveRow = document.getElementById('sellerAcctSaveRow');
  if (saveRow) saveRow.style.display = 'none';
};

// Populate seller account settings fields when profile tab opens
async function loadSellerAccountSettings() {
  const user = window.authManager?.getCurrentUser();
  if (!user) return;
  const sellerId = await getSellerIdForCurrentUser();

  const nameEl  = document.getElementById('sellerAcctName');
  const emailEl = document.getElementById('sellerAcctEmail');
  const phoneEl = document.getElementById('sellerAcctPhone');

  if (emailEl) emailEl.value = user.email || '';

  if (sellerId && window.db) {
    try {
      const { data } = await window.db
        .from('sellers').select('business_name, phone').eq('id', sellerId).single();
      if (data) {
        if (nameEl)  nameEl.value  = data.business_name || user.name || '';
        if (phoneEl) phoneEl.value = data.phone || '';
      }
    } catch(e) { /* fallback to user data */
      if (nameEl) nameEl.value = user.name || '';
    }
  } else {
    if (nameEl) nameEl.value = user.name || '';
  }
}

// Add pop-in animation keyframe once
(function() {
  if (!document.getElementById('rwAnimStyle')) {
    const s = document.createElement('style');
    s.id = 'rwAnimStyle';
    s.textContent = '@keyframes rwPopIn{from{transform:scale(.9);opacity:0}to{transform:scale(1);opacity:1}}';
    document.head.appendChild(s);
  }
})();


// ============================================================
// UPDATE BUYER ORDERS BADGE
// ============================================================

async function updateBuyerOrdersBadge() {
  const currentUser = authManager?.getCurrentUser();
  if (!currentUser) return;

  try {
    // Count total orders for this buyer
    const { count: totalOrders } = await db
      .from('orders')
      .select('*', { count: 'exact', head: true })
      .eq('buyer_email', currentUser.email);

    // Update badge
    const badge = document.getElementById('buyerOrdersCount');
    if (badge) {
      if (totalOrders > 0) {
        badge.textContent = totalOrders > 99 ? '99+' : totalOrders;
        badge.style.display = 'inline-block';
      } else {
        badge.style.display = 'none';
      }
    }

    console.log('[dashboard] Buyer orders badge updated:', totalOrders);
  } catch (error) {
    console.error('[dashboard] updateBuyerOrdersBadge:', error);
  }
}

// Call this after loading buyer orders
document.addEventListener('DOMContentLoaded', () => {
  // Update badge when page loads
  setTimeout(() => {
    if (typeof updateBuyerOrdersBadge === 'function') {
      updateBuyerOrdersBadge();
    }
  }, 500);
});

// Also update badge when orders tab is clicked
document.addEventListener('click', (e) => {
  if (e.target?.closest('[data-tab="buyer-orders"]')) {
    setTimeout(() => {
      if (typeof updateBuyerOrdersBadge === 'function') {
        updateBuyerOrdersBadge();
      }
    }, 100);
  }
});


// ============================================================
// ORDER DETAILS MODAL FUNCTION - ADDED TO DASHBOARD.JS
// ============================================================

async function openOrderDetailsModal(orderId) {
  console.log('[orderDetailsModal] ✅ FUNCTION CALLED from dashboard.js with orderId:', orderId);
  
  const modal = document.getElementById('orderDetailsModal');
  const content = document.getElementById('orderDetailsContent');
  
  if (!modal || !content) {
    console.error('[orderDetailsModal] ❌ Modal or content element not found');
    return;
  }
  
  content.innerHTML = '<p style="text-align:center;color:#999;">Loading order details...</p>';
  modal.style.display = 'block';
  
  try {
    const { data: order, error } = await db
      .from('orders')
      .select('*, products(id, name, image_url)')
      .eq('id', orderId)
      .single();
    
    if (error || !order) {
      console.error('[orderDetailsModal] Error loading order:', error);
      content.innerHTML = '<p style="color:#e74c3c;">Could not load order details.</p>';
      return;
    }
    
    console.log('[orderDetailsModal] Order data:', order);
    
    // Get current user to determine view (buyer or seller)
    const currentUser = window.authManager?.getCurrentUser();
    const isBuyer = currentUser?.email === order.buyer_email;
    const isSeller = currentUser?.id === order.seller_id;
    
    const product = order.products;
    const lsTracking = JSON.parse(localStorage.getItem(`rewear_tracking_${order.id}`) || '{}');
    const courierName = order.courier_name || lsTracking.courier_name || null;
    const trackingNumber = order.tracking_number || lsTracking.tracking_number || null;
    
    const paymentBadge = {
      pending:   '<span style="background:#fff3cd;color:#856404;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">⏳ Awaiting Payment</span>',
      submitted: '<span style="background:#cce5ff;color:#004085;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">📤 Payment Submitted</span>',
      verified:  '<span style="background:#d4edda;color:#155724;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">✅ Payment Verified</span>',
      rejected:  '<span style="background:#f8d7da;color:#721c24;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">❌ Payment Rejected</span>'
    }[order.payment_status || 'pending'] || '';
    
    const acceptedBadge = order.accepted 
      ? '<span style="background:#d4edda;color:#155724;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">✅ Accepted</span>'
      : '<span style="background:#fff3cd;color:#856404;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">⏳ Pending</span>';
    
    let html = `
      <div style="margin-bottom:20px;">
        <h3 style="margin:0 0 12px;font-size:16px;font-weight:700;">Order ${order.id.slice(0, 8).toUpperCase()}</h3>
        <p style="margin:0;color:#999;font-size:13px;">Placed on ${new Date(order.created_at).toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' })}</p>
      </div>
      
      <div style="background:#f9f9f9;border-radius:12px;padding:16px;margin-bottom:16px;">
        <div style="display:flex;gap:12px;margin-bottom:12px;">
          ${product?.image_url ? `<img src="${product.image_url}" alt="${product?.name}" style="width:80px;height:80px;object-fit:cover;border-radius:8px;">` : '<div style="width:80px;height:80px;background:#eee;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:24px;">📦</div>'}
          <div style="flex:1;">
            <h4 style="margin:0 0 4px;font-size:15px;font-weight:700;">${product?.name || 'Product'}</h4>
            <p style="margin:0 0 4px;color:#666;font-size:13px;">Size: ${order.size_selected || '—'}</p>
            <p style="margin:0;color:#666;font-size:13px;">Quantity: ${order.quantity || 1}</p>
          </div>
        </div>
        <div style="border-top:1px solid #e0e0e0;padding-top:12px;text-align:right;">
          <p style="margin:0;font-size:14px;font-weight:700;color:#1a1a2e;">Total: ₱${parseFloat(order.total_price || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
        </div>
      </div>
      
      <div style="background:#f9f9f9;border-radius:12px;padding:16px;margin-bottom:16px;">
        <h4 style="margin:0 0 12px;font-size:14px;font-weight:700;">Order Information</h4>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:13px;">
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Status</p>
            <p style="margin:0;color:#1a1a2e;font-weight:600;">${order.status.replace(/_/g, ' ').toUpperCase()}</p>
          </div>
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Payment</p>
            <p style="margin:0;">${paymentBadge}</p>
          </div>
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Buyer Name</p>
            <p style="margin:0;color:#1a1a2e;">${order.buyer_name || '—'}</p>
          </div>
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Buyer Email</p>
            <p style="margin:0;color:#1a1a2e;font-size:12px;">${order.buyer_email || '—'}</p>
          </div>
          ${order.seller_name || order.seller_email ? `
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Seller Name</p>
            <p style="margin:0;color:#1a1a2e;">${order.seller_name || order.seller_email?.split('@')[0] || '—'}</p>
          </div>
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Seller Email</p>
            <p style="margin:0;color:#1a1a2e;font-size:12px;">${order.seller_email || '—'}</p>
          </div>
          ` : ''}
        </div>
        
        ${order.delivery_address ? `
        <div style="margin-top:12px;padding-top:12px;border-top:1px solid #e0e0e0;">
          <p style="margin:0 0 4px;color:#999;font-weight:600;font-size:13px;">Delivery Address</p>
          <p style="margin:0;color:#1a1a2e;font-size:13px;">${order.delivery_address}</p>
        </div>` : ''}
        
        ${order.payment_reference ? `
        <div style="margin-top:12px;padding-top:12px;border-top:1px solid #e0e0e0;">
          <p style="margin:0 0 4px;color:#999;font-weight:600;font-size:13px;">Payment Reference</p>
          <p style="margin:0;color:#c8a96e;font-weight:700;font-size:13px;">${order.payment_reference}</p>
        </div>` : ''}
      </div>
      
      ${order.payment_proof_url ? `
      <div style="background:#f0f8ff;border-radius:12px;padding:16px;margin-bottom:16px;">
        <h4 style="margin:0 0 12px;font-size:14px;font-weight:700;">💳 Payment Proof</h4>
        <div style="font-size:13px;">
          <p style="margin:0 0 8px;color:#666;">Payment proof uploaded by buyer</p>
          <img src="${order.payment_proof_url}" alt="Payment Proof" style="max-width:100%;max-height:300px;border-radius:8px;border:1px solid #ddd;cursor:pointer;" onclick="window.open('${order.payment_proof_url}', '_blank')">
          <p style="margin:8px 0 0;font-size:12px;color:#999;">Click to view full size</p>
          
          ${isSeller && order.payment_status === 'submitted' ? `
          <div style="margin-top:12px;display:flex;gap:8px;">
            <button onclick="confirmPayment('${order.id}')" style="flex:1;padding:10px;background:#27ae60;color:#fff;border:none;border-radius:6px;font-size:13px;font-weight:600;cursor:pointer;">
              ✅ Confirm Payment
            </button>
            <button onclick="rejectPayment('${order.id}')" style="flex:1;padding:10px;background:#e74c3c;color:#fff;border:none;border-radius:6px;font-size:13px;font-weight:600;cursor:pointer;">
              ❌ Reject Payment
            </button>
          </div>` : ''}
        </div>
      </div>` : `
      ${isSeller && order.payment_status === 'pending' ? `
      <div style="background:#fff3cd;border-radius:12px;padding:16px;margin-bottom:16px;">
        <h4 style="margin:0 0 12px;font-size:14px;font-weight:700;">💳 Payment Proof</h4>
        <p style="margin:0 0 12px;color:#856404;font-size:13px;">No payment proof uploaded yet. You can upload proof on behalf of the buyer if needed.</p>
        <button onclick="sellerUploadPaymentProof('${order.id}')" style="padding:10px 16px;background:#c8a96e;color:#fff;border:none;border-radius:6px;font-size:13px;font-weight:600;cursor:pointer;">
          📸 Upload Payment Proof
        </button>
      </div>` : ''}`}
      
      ${isSeller ? `
      <div style="background:#fffbf0;border-radius:12px;padding:16px;margin-bottom:16px;">
        <h4 style="margin:0 0 12px;font-size:14px;font-weight:700;">✅ Order Acceptance</h4>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:13px;">
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Seller Status</p>
            <p style="margin:0;">${acceptedBadge}</p>
          </div>
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Rejected</p>
            <p style="margin:0;color:#1a1a2e;font-weight:600;">${order.rejected ? '❌ Yes' : '✅ No'}</p>
          </div>
        </div>
        ${order.rejection_reason ? `
        <div style="margin-top:12px;padding-top:12px;border-top:1px solid #e0e0e0;">
          <p style="margin:0 0 4px;color:#999;font-weight:600;font-size:13px;">Rejection Reason</p>
          <p style="margin:0;color:#c0392b;font-size:13px;">${order.rejection_reason}</p>
        </div>` : ''}
      </div>` : ''}
      
      ${courierName || trackingNumber ? `
      <div style="background:#f0f9f0;border-radius:12px;padding:16px;margin-bottom:16px;">
        <h4 style="margin:0 0 12px;font-size:14px;font-weight:700;">📦 Tracking Information</h4>
        <div style="font-size:13px;">
          ${courierName ? `<p style="margin:0 0 8px;"><strong>Courier:</strong> ${courierName}</p>` : ''}
          ${trackingNumber ? `<p style="margin:0;"><strong>Tracking #:</strong> <span style="color:#c8a96e;font-weight:700;">${trackingNumber}</span></p>` : ''}
        </div>
      </div>` : ''}
      
      <div style="display:flex;gap:12px;margin-top:20px;">
        <button onclick="closeOrderDetailsModal()" style="flex:1;padding:12px;background:#f5f5f5;color:#333;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;">
          Close
        </button>
        ${isBuyer ? `
        <button onclick="openOrderChat('${order.id}', '${order.seller_id}', '${order.buyer_email}')" style="flex:1;padding:12px;background:#c8a96e;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;">
          💬 Chat
        </button>
        <button onclick="window.location.href='pages/order-tracking.html?id=${order.id}'" style="flex:1;padding:12px;background:#3498db;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;">
          📍 Track
        </button>` : ''}
      </div>
    `;
    
    content.innerHTML = html;
    console.log('[orderDetailsModal] ✅ Modal content updated successfully');
    
  } catch (error) {
    console.error('[orderDetailsModal] ❌ Error:', error);
    content.innerHTML = '<p style="color:#e74c3c;">Error loading order details. Please try again.</p>';
  }
}

function closeOrderDetailsModal() {
  console.log('[orderDetailsModal] Closing modal');
  const modal = document.getElementById('orderDetailsModal');
  if (modal) modal.style.display = 'none';
}

/**
 * Confirm payment - Seller action
 */
window.confirmPayment = async (orderId) => {
  if (!confirm('Confirm this payment? The order status will be updated to CONFIRMED.')) return;
  
  try {
    showLoadingModal('Confirming Payment', 'Please wait...');
    
    const { error } = await db.from('orders').update({
      payment_status: 'verified',
      status: 'confirmed',
      accepted: true
    }).eq('id', orderId);
    
    if (error) throw error;
    
    hideLoadingModal();
    showSuccess('Payment Confirmed!', 'Order status updated to CONFIRMED.', 'Got it');
    
    // Refresh modal
    setTimeout(() => {
      openOrderDetailsModal(orderId);
    }, 1000);
  } catch (err) {
    hideLoadingModal();
    console.error('[confirmPayment] Error:', err);
    showError('Error', 'Could not confirm payment. Please try again.');
  }
};

/**
 * Reject payment - Seller action
 */
window.rejectPayment = async (orderId) => {
  const reason = prompt('Enter reason for rejection:');
  if (!reason) return;
  
  try {
    showLoadingModal('Rejecting Payment', 'Please wait...');
    
    const { error } = await db.from('orders').update({
      payment_status: 'rejected',
      payment_rejected_reason: reason,
      rejected: true
    }).eq('id', orderId);
    
    if (error) throw error;
    
    hideLoadingModal();
    showSuccess('Payment Rejected', 'Buyer has been notified.', 'Got it');
    
    // Refresh modal
    setTimeout(() => {
      openOrderDetailsModal(orderId);
    }, 1000);
  } catch (err) {
    hideLoadingModal();
    console.error('[rejectPayment] Error:', err);
    showError('Error', 'Could not reject payment. Please try again.');
  }
};


/* ==== SELLER LOGIC ==== */
// ============================================================
// dashboard-seller.js — Seller dashboard logic
// Used on: dashboard-seller.html
// ============================================================

// ============================================================
// ORDER DETAILS MODAL FUNCTION
// ============================================================


// ---- SELLER ID RESOLVER ----
// Single source of truth for the current seller's ID.
// Checks DB by user.id first, then by email as fallback.
// Caches the result so subsequent calls are instant.
let _resolvedSellerId = null;

async function getSellerIdForCurrentUser() {
  if (_resolvedSellerId) return _resolvedSellerId;

  const user = authManager?.getCurrentUser();
  if (!user) return null;

  // 1. Try sellers.id = user.id (standard flow)
  try {
    const { data: byIdArr } = await db
      .from('sellers')
      .select('id')
      .eq('id', user.id)
      .limit(1);
    if (byIdArr && byIdArr.length > 0) {
      _resolvedSellerId = byIdArr[0].id;
      return _resolvedSellerId;
    }
  } catch(e) { /* continue */ }

  // 2. Fallback: sellers.email = user.email (verification flow / admin-created)
  try {
    const { data: byEmailArr } = await db
      .from('sellers')
      .select('id')
      .eq('email', user.email)
      .limit(1);
    if (byEmailArr && byEmailArr.length > 0) {
      _resolvedSellerId = byEmailArr[0].id;
      return _resolvedSellerId;
    }
  } catch(e) { /* continue */ }

  // 3. Last resort: use user.id directly (may be a new seller)
  _resolvedSellerId = user.id;
  return _resolvedSellerId;
}

// Reset cache on auth change
document.addEventListener('authStateChanged', () => { _resolvedSellerId = null; });

// ---- TAB SWITCHING ----
document.querySelectorAll('.dash-nav-link').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const tab = link.dataset.tab;
    document.querySelectorAll('.dash-nav-link').forEach(l => l.classList.remove('active'));
    document.querySelectorAll('.dash-tab').forEach(t => t.classList.remove('active'));
    link.classList.add('active');
    const tabEl = document.getElementById(`tab-${tab}`);
    if (tabEl) tabEl.classList.add('active');
    const titleEl = document.getElementById('dashPageTitle');
    if (titleEl) titleEl.textContent = link.textContent.trim();
    if (tab === 'listings') loadSellerListings();
    if (tab === 'orders')   loadSellerOrders();
    if (tab === 'fees')     loadFeesTab();
    if (tab === 'earnings') loadEarningsTab();
    if (tab === 'payouts')  loadPayoutsTab();
    if (tab === 'profile')  loadSellerProfile();
    if (tab === 'messages') loadSellerMessages();
  });
});

// Shortcut: Add Listing button
document.getElementById('addProductBtn')?.addEventListener('click', () => {
  document.querySelector('[data-tab="add"]')?.click();
});

// ---- OVERVIEW STATS ----
async function loadOverviewStats() {
  try {
    const currentSellerId = await getSellerIdForCurrentUser();
    
    console.log('[seller] loadOverviewStats: Resolved seller ID:', currentSellerId);
    
    if (!currentSellerId) {
      const el = id => document.getElementById(id);
      if (el('statListings')) el('statListings').textContent = 0;
      if (el('statOrders'))   el('statOrders').textContent   = 0;
      if (el('statPending'))  el('statPending').textContent  = 0;
      const list = document.getElementById('sellerRecentOrdersList');
      if (list) list.innerHTML = '<p class="dash-empty">No orders yet.</p>';
      return;
    }

    console.log('[seller] loadOverviewStats: Querying database...');

    // Query 1: Count listings by seller
    let listingCount = 0;
    try {
      const { count, error: listingError } = await db
        .from('products')
        .select('*', { count: 'exact', head: true })
        .eq('seller_id', currentSellerId);
      
      if (listingError) {
        console.error('[seller] loadOverviewStats: Listing count error:', listingError);
        listingCount = 0;
      } else {
        listingCount = count ?? 0;
      }
    } catch (err) {
      console.error('[seller] loadOverviewStats: Listing query exception:', err);
      listingCount = 0;
    }

    // Query 2: Get orders for this seller
    // First, get all products by this seller
    let orderCount = 0;
    let pendingCount = 0;
    let recentOrders = [];
    
    try {
      const { data: sellerProducts, error: productsError } = await db
        .from('products')
        .select('id')
        .eq('seller_id', currentSellerId);
      
      if (productsError) {
        console.error('[seller] loadOverviewStats: Products query error:', productsError);
      } else if (sellerProducts && sellerProducts.length > 0) {
        const productIds = sellerProducts.map(p => p.id);
        console.log('[seller] loadOverviewStats: Found', productIds.length, 'products');
        
        // Now get orders for these products
        const { data: orders, error: ordersError } = await db
          .from('orders')
          .select('*')
          .in('product_id', productIds)
          .order('created_at', { ascending: false })
          .limit(20);
        
        if (ordersError) {
          console.error('[seller] loadOverviewStats: Orders query error:', ordersError);
        } else if (orders) {
          orderCount = orders.length;
          pendingCount = orders.filter(o => o.status === 'pending').length;
          recentOrders = orders.slice(0, 5);
          console.log('[seller] loadOverviewStats: Found', orderCount, 'orders');
        }
      } else {
        console.log('[seller] loadOverviewStats: No products found for seller');
      }
    } catch (err) {
      console.error('[seller] loadOverviewStats: Orders query exception:', err);
    }

    console.log('[seller] loadOverviewStats: Final results:', {
      listingCount,
      orderCount,
      pendingCount
    });

    // Update stats display
    const el = id => document.getElementById(id);
    if (el('statListings')) el('statListings').textContent = listingCount;
    if (el('statOrders'))   el('statOrders').textContent   = orderCount;
    if (el('statPending'))  el('statPending').textContent  = pendingCount;

    // Update recent orders list
    const list = document.getElementById('sellerRecentOrdersList');
    if (list) {
      if (recentOrders.length > 0) {
        list.innerHTML = recentOrders.map(o => {
          return `
            <div class="order-row" style="padding:12px;border-bottom:1px solid #eee;">
              <div style="display:flex;justify-content:space-between;align-items:center;">
                <div>
                  <p style="margin:0;font-weight:600;font-size:14px;">Order #${o.id.substring(0, 8)}</p>
                  <p style="margin:4px 0 0;font-size:13px;color:#666;">${o.buyer_name || 'Customer'}</p>
                </div>
                <div style="text-align:right;">
                  <p style="margin:0;font-weight:600;font-size:14px;">₱${parseFloat(o.total_price || 0).toFixed(2)}</p>
                  <span style="display:inline-block;margin-top:4px;padding:4px 8px;background:${
                    o.status === 'pending' ? '#fff8e1' : 
                    o.status === 'confirmed' ? '#e8f5e9' : 
                    o.status === 'shipped' ? '#e3f2fd' : '#f5f5f5'
                  };color:${
                    o.status === 'pending' ? '#856404' : 
                    o.status === 'confirmed' ? '#155724' : 
                    o.status === 'shipped' ? '#0d47a1' : '#666'
                  };border-radius:4px;font-size:11px;font-weight:600;">${o.status || 'pending'}</span>
                </div>
              </div>
            </div>`;
        }).join('');
      } else {
        list.innerHTML = '<p class="dash-empty">No orders yet.</p>';
      }
    }

    // Update sidebar nav badges
    updateListingBadges();

  } catch (error) {
    console.error('[seller] loadOverviewStats: Exception:', error);
    // Show zeros instead of "Error" for better UX
    const el = id => document.getElementById(id);
    if (el('statListings')) el('statListings').textContent = '0';
    if (el('statOrders'))   el('statOrders').textContent   = '0';
    if (el('statPending'))  el('statPending').textContent  = '0';
    
    const list = document.getElementById('sellerRecentOrdersList');
    if (list) {
      list.innerHTML = '<p class="dash-empty" style="color:#e74c3c;">Could not load stats. Please refresh the page.</p>';
    }
  }
}

// ---- UPDATE LISTING BADGES (sidebar nav counters) ----
async function updateListingBadges() {
  const sellerId = await getSellerIdForCurrentUser();
  if (!sellerId) return;
  try {
    const { data: listings } = await db
      .from('products')
      .select('id, status')
      .eq('seller_id', sellerId);

    const total   = listings?.length || 0;
    const pending = listings?.filter(p => p.status === 'pending').length || 0;

    const totalBadge   = document.getElementById('listingsCount');
    const pendingBadge = document.getElementById('pendingListingsCount');
    if (totalBadge)   { totalBadge.textContent   = total;   totalBadge.style.display   = total   > 0 ? 'inline-block' : 'none'; }
    if (pendingBadge) { pendingBadge.textContent  = pending; pendingBadge.style.display = pending > 0 ? 'inline-block' : 'none'; }
  } catch(e) { console.warn('[seller] updateListingBadges:', e.message); }
}

// ---- LISTINGS TAB ----
async function loadSellerListings() {
  const grid = document.getElementById('sellerListingsGrid');
  if (!grid) return;

  try {
    const currentSellerId = await getSellerIdForCurrentUser();
    
    console.log('[seller] loadSellerListings: Resolved seller ID:', currentSellerId);
    
    if (!currentSellerId) {
      grid.innerHTML = '<p class="dash-empty">Seller session not found. Please log in.</p>';
      return;
    }

    // Only show loading if we expect there might be data
    const hasSearch = document.getElementById('listingSearch')?.value.trim();
    if (hasSearch) {
      grid.innerHTML = '<p class="dash-empty">Searching…</p>';
    } else {
      // For initial load, show loading briefly
      grid.innerHTML = '<p class="dash-empty">Loading…</p>';
    }

    const sort = document.getElementById('listingSort')?.value || 'newest';
    
    console.log('[seller] loadSellerListings: Building query with sort:', sort);
    
    let query = db.from('products').select('*').eq('seller_id', currentSellerId); // Filter by seller ID
    if (sort === 'price_asc')  query = query.order('price', { ascending: true });
    if (sort === 'price_desc') query = query.order('price', { ascending: false });
    if (sort === 'newest')     query = query.order('created_at', { ascending: false });

    console.log('[seller] loadSellerListings: Executing query...');
    const { data, error } = await query;
    
    if (error) { 
      console.error('[seller] loadSellerListings: Database error:', error);
      grid.innerHTML = '<p class="dash-empty">Could not load listings. Error: ' + error.message + '</p>'; 
      return; 
    }

    console.log('[seller] loadSellerListings: Query successful, found', data?.length || 0, 'products');

    // Handle empty data case immediately
    if (!data || data.length === 0) {
      grid.innerHTML = '<p class="dash-empty">No listings yet. <a href="#" onclick="document.querySelector(\'[data-tab=&quot;add&quot;]\').click()" style="color:#c8a96e;text-decoration:underline;">Add your first product</a></p>';
      return;
    }

    const search = document.getElementById('listingSearch')?.value.toLowerCase() || '';
    const filtered = search ? data.filter(p => p.name.toLowerCase().includes(search)) : data;

    console.log('[seller] loadSellerListings: After filtering:', filtered.length, 'products');

    grid.innerHTML = filtered.length
      ? filtered.map(p => {
          const statusColor = p.status==='approved'?'#27ae60':p.status==='rejected'?'#e74c3c':'#c8a96e';
          const statusLabel = p.status==='approved'?'<i class="fas fa-check-circle"></i> Live':p.status==='rejected'?'<i class="fas fa-times-circle"></i> Rejected':'<i class="fas fa-hourglass"></i> Pending Approval';
          return `
          <div class="product-card" style="cursor:default;position:relative;">
            <div class="product-image"><img src="${p.image_url}" alt="${p.name}" loading="lazy"></div>
            <div class="product-info">
              <h3 class="product-name">${p.name}</h3>
              <p class="product-price">₱${parseFloat(p.price).toFixed(2)}</p>
              <div class="product-sizes">${(p.sizes||[]).map(s=>`<span class="size-tag">${s}</span>`).join('')}</div>
              <div style="margin-top:6px;">
                <span style="font-size:12px;font-weight:600;color:${statusColor};">${statusLabel}</span>
                ${p.rejection_reason ? `<p style="font-size:11px;color:#e74c3c;margin:2px 0 0;">Reason: ${p.rejection_reason}</p>` : ''}
              </div>
              ${p.status==='approved' && p.in_stock ? `
              <button onclick="markAsSold('${p.id}')"
                style="margin-top:8px;width:100%;padding:7px;background:#e74c3c;color:#fff;border:none;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;">
                Mark as Sold
              </button>` : ''}
              ${!p.in_stock ? `<p style="margin-top:6px;font-size:12px;color:#888;font-weight:600;">✕ Sold / Out of Stock</p>` : ''}
            </div>
          </div>`}).join('')
      : '<p class="dash-empty">No listings match your search. <button onclick="document.getElementById(\'listingSearch\').value=\'\'; loadSellerListings();" style="background:none;border:none;color:#c8a96e;text-decoration:underline;cursor:pointer;">Clear search</button></p>';

  } catch (error) {
    console.error('[seller] loadSellerListings: Exception:', error);
    grid.innerHTML = '<p class="dash-empty">Error loading listings: ' + error.message + '</p>';
  }
}

document.getElementById('listingSearch')?.addEventListener('input', loadSellerListings);
document.getElementById('listingSort')?.addEventListener('change', loadSellerListings);

// ---- ORDERS TAB ----
function orderRowHTML(o) {
  const orderId = o.id || o.order_id || o.uuid;
  return `
    <div class="dash-order-row" data-order-id="${orderId}" style="cursor: pointer;" onclick="openOrderDetailsModal('${orderId}')">
      <div>
        <p class="dash-order-name">${o.buyer_name}</p>
        <p class="dash-order-meta">${o.buyer_email} · Size: ${o.size_selected || '—'} · $${parseFloat(o.total_price||0).toFixed(2)}</p>
        <p class="dash-order-meta">${new Date(o.created_at).toLocaleDateString()}</p>
      </div>
      <span class="dash-order-status status-${o.status}">${o.status}</span>
    </div>`;
}

async function loadSellerOrders() {
  const list = document.getElementById('sellerOrdersList');
  if (!list) return;
  list.innerHTML = '<p class="dash-empty">Loading…</p>';

  const currentSellerId = await getSellerIdForCurrentUser();
  
  console.log('[seller] loadSellerOrders: Resolved seller ID:', currentSellerId);
  
  if (!currentSellerId) {
    list.innerHTML = '<p class="dash-empty">Seller session not found. Please log in.</p>';
    return;
  }

  const statusFilter = document.getElementById('orderStatusFilter')?.value || 'all';
  
  try {
    // Step 1: Get all products by this seller
    const { data: sellerProducts, error: productsError } = await db
      .from('products')
      .select('id, name, image_url')
      .eq('seller_id', currentSellerId);
    
    if (productsError) {
      console.error('[seller] loadSellerOrders: Products query error:', productsError);
      list.innerHTML = '<p class="dash-empty">Could not load products.</p>';
      return;
    }
    
    if (!sellerProducts || sellerProducts.length === 0) {
      console.log('[seller] loadSellerOrders: No products found for seller');
      list.innerHTML = '<p class="dash-empty">No products found. Add products to receive orders.</p>';
      return;
    }
    
    const productIds = sellerProducts.map(p => p.id);
    const productMap = {};
    sellerProducts.forEach(p => productMap[p.id] = p);
    
    console.log('[seller] loadSellerOrders: Found', productIds.length, 'products');
    
    // Step 2: Get orders for those products
    let query = db
      .from('orders')
      .select('*')
      .in('product_id', productIds)
      .order('created_at', { ascending: false });
    
    if (statusFilter !== 'all') {
      query = query.eq('status', statusFilter);
    }
    
    const { data: orders, error: ordersError } = await query;
    
    if (ordersError) {
      console.error('[seller] loadSellerOrders: Orders query error:', ordersError);
      list.innerHTML = '<p class="dash-empty">Could not load orders.</p>';
      return;
    }
    
    console.log('[seller] loadSellerOrders: Found', orders?.length || 0, 'orders');
    
    // Attach product info to each order
    const ordersWithProducts = orders?.map(o => ({
      ...o,
      products: productMap[o.product_id] || { name: 'Unknown Product', image_url: '' }
    })) || [];
    
    list.innerHTML = ordersWithProducts.length 
      ? ordersWithProducts.map(o => enhancedOrderRowHTML(o)).join('') 
      : '<p class="dash-empty">No orders found for your products.</p>';
      
  } catch (error) {
    console.error('[seller] loadSellerOrders: Exception:', error);
    list.innerHTML = '<p class="dash-empty">Error loading orders. Please refresh the page.</p>';
  }
}

document.getElementById('orderStatusFilter')?.addEventListener('change', loadSellerOrders);

// ---- ORDER MANAGEMENT FUNCTIONS ----
function getStatusLabel(status) {
  const statusLabels = {
    'pending':   'Pending',
    'confirmed': 'Confirmed',
    'shipped':   'Shipped',
    'delivered': 'Delivered',
    'received':  'Receipt Confirmed',
    'cancelled': 'Cancelled'
  };
  return statusLabels[status] || status.replace(/_/g, ' ').toUpperCase();
}

// Enhanced order row HTML with management controls
function enhancedOrderRowHTML(o) {
  const productName = o.products?.name || 'Unknown Product';
  const showTracking = ['confirmed', 'shipped', 'delivered'].includes(o.status);
  // Prefer DB columns; fall back to localStorage
  const lsTracking = JSON.parse(localStorage.getItem(`rewear_tracking_${o.id}`) || '{}');
  const trackingNumber = o.tracking_number || lsTracking.tracking_number || '';
  const courierName    = o.courier_name    || lsTracking.courier_name    || '';

  const paymentBadge = {
    pending:   '<span style="background:#fff3cd;color:#856404;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600;">⏳ Awaiting Payment</span>',
    submitted: '<span style="background:#cce5ff;color:#004085;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600;">📤 Proof Submitted</span>',
    verified:  '<span style="background:#d4edda;color:#155724;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600;">✅ Payment Verified</span>',
    rejected:  '<span style="background:#f8d7da;color:#721c24;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600;">❌ Payment Rejected</span>'
  }[o.payment_status || 'pending'] || '';

  return `
    <div class="dash-order-row" data-order-id="${o.id}" data-status="${o.status}">
      <div class="order-main-info">
        <div class="order-buyer-info">
          <p class="dash-order-name">${o.buyer_name}</p>
          <p class="dash-order-meta"><strong>Product:</strong> ${productName}</p>
          <p class="dash-order-meta">${o.buyer_email}${o.buyer_phone ? ' · ' + o.buyer_phone : ''}</p>
          ${(() => {
            const pref = o.shipping_info?.delivery_preference;
            const addr = o.delivery_address || o.shipping_info?.delivery_address;
            const labels = { meetup: '🤝 Meet Up', courier: '📦 Ship via Courier', seller_delivers: '🛵 Seller Delivers' };
            const label = labels[pref] || '';
            return label ? `<p class="dash-order-meta" style="color:#c8a96e;font-weight:600;">${label}${addr ? ' · ' + addr : ''}</p>` : (addr ? `<p class="dash-order-meta">📍 ${addr}</p>` : '');
          })()}
          <p class="dash-order-meta">Size: ${o.size_selected || '—'} · Qty: ${o.quantity || 1} · ₱${parseFloat(o.total_price||0).toFixed(2)}</p>
          <p class="dash-order-meta">Ref: ${o.payment_reference || o.id.slice(0,8).toUpperCase()} · ${new Date(o.created_at).toLocaleDateString()}</p>
          <div style="margin-top:4px;">${paymentBadge}</div>
          ${o.payment_status === 'submitted' ? `
          <div style="margin-top:6px;padding:8px;background:#fff8e1;border-radius:6px;font-size:13px;color:#856404;">
            📤 Payment proof submitted — awaiting admin verification
          </div>` : ''}
          ${o.payment_status === 'pending' ? `
          <div style="margin-top:6px;padding:8px;background:#fff3cd;border-radius:6px;font-size:13px;color:#856404;">
            ⏳ Awaiting payment proof from buyer
            <button onclick="sellerUploadPaymentProof('${o.id}')" style="margin-left:8px;padding:4px 12px;background:#c8a96e;color:#fff;border:none;border-radius:4px;font-size:12px;font-weight:600;cursor:pointer;">
              📸 Upload Proof
            </button>
          </div>` : ''}
          ${o.payment_proof_url ? `
          <div style="margin-top:6px;padding:8px;background:#e3f2fd;border-radius:6px;font-size:13px;color:#004085;">
            💳 Payment proof uploaded
            <button onclick="window.open('${o.payment_proof_url}', '_blank')" style="margin-left:8px;padding:4px 12px;background:#2196F3;color:#fff;border:none;border-radius:4px;font-size:12px;font-weight:600;cursor:pointer;">
              👁️ View
            </button>
          </div>` : ''}
          ${o.status === 'confirmed' ? `
          <div style="margin-top:6px;padding:8px;background:#e8f5e9;border-radius:6px;font-size:13px;color:#155724;">
            ✅ Payment verified — please prepare this item for shipping
          </div>` : ''}
          ${o.status === 'received' ? `
          <div style="margin-top:6px;padding:12px;background:#e8f5e9;border-radius:8px;border:1px solid #a5d6a7;">
            <p style="font-weight:700;margin:0 0 6px;color:#155724;">🎉 Buyer Confirmed Receipt!</p>
            <p style="margin:0 0 10px;font-size:13px;color:#555;">The transaction is complete. Mark the item as sold to close this order.</p>
            <button onclick="sellerMarkItemSold('${o.id}', '${o.products?.id || ''}')"
              style="padding:8px 18px;background:#27ae60;color:#fff;border:none;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;">
              ✓ Mark Item as Sold — Transaction Complete
            </button>
          </div>` : ''}
        </div>
        
        <div class="order-status-section">
          <div class="current-status">
            <span class="dash-order-status status-${o.status.replace(/_/g, '-')}">${getStatusLabel(o.status)}</span>
          </div>
          
          <div class="order-actions">
            ${o.status === 'confirmed' ? `
            <button onclick="acceptOrder('${o.id}')" style="display:none;"></button>` : ''}
            <select class="status-update-select" data-order-id="${o.id}" data-current-status="${o.status}">
              <option value="pending"   ${o.status === 'pending'   ? 'selected' : ''}>Pending</option>
              <option value="confirmed" ${o.status === 'confirmed' ? 'selected' : ''}>Confirmed</option>
              <option value="shipped"   ${o.status === 'shipped'   ? 'selected' : ''}>Shipped</option>
              <option value="delivered" ${o.status === 'delivered' ? 'selected' : ''}>Delivered</option>
              <option value="cancelled" ${o.status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
            </select>

            ${showTracking ? `
            <div class="tracking-info" style="margin-top:8px;">
              <input type="text" class="tracking-number-input dash-search" 
                     placeholder="Tracking Number" 
                     value="${trackingNumber}"
                     data-order-id="${o.id}"
                     style="margin-bottom:6px;">
              <input type="text" class="courier-name-input dash-search" 
                     placeholder="Courier (e.g. LBC, J&T, Grab)" 
                     value="${courierName}"
                     data-order-id="${o.id}">
            </div>` : ''}
            
            <button class="btn-update-order" data-order-id="${o.id}" style="margin-top:8px;">Update Order</button>
          </div>
        </div>
      </div>
    </div>`;
}

async function updateOrderStatus(orderId, newStatus) {
  try {
    console.log('[seller] updateOrderStatus called:', { orderId, newStatus });

    const orderRow = document.querySelector(`.dash-order-row[data-order-id="${orderId}"]`);
    const trackingNumber = orderRow?.querySelector('.tracking-number-input')?.value.trim() || null;
    const courierName    = orderRow?.querySelector('.courier-name-input')?.value.trim() || null;

    // Base update — always works
    const baseUpdate = { status: newStatus };
    const { error: baseErr } = await db.from('orders').update(baseUpdate).eq('id', orderId);
    if (baseErr) throw baseErr;

    // Extended update — only if 06_buyer_flow.sql has been run
    if (trackingNumber || courierName || newStatus === 'delivered' || newStatus === 'confirmed') {
      const extUpdate = {};
      if (trackingNumber) extUpdate.tracking_number = trackingNumber;
      if (courierName)    extUpdate.courier_name    = courierName;
      if (newStatus === 'delivered') extUpdate.delivered_at = new Date().toISOString();
      if (newStatus === 'confirmed') extUpdate.confirmed_at = new Date().toISOString();

      const { error: extErr } = await db.from('orders').update(extUpdate).eq('id', orderId);
      if (extErr) {
        // Columns not yet available — save tracking to localStorage as fallback
        console.warn('[seller] Extended columns not available, using localStorage:', extErr.message);
        if (trackingNumber || courierName) {
          localStorage.setItem(`rewear_tracking_${orderId}`, JSON.stringify({
            tracking_number: trackingNumber || '',
            courier_name:    courierName || '',
            updated_at:      new Date().toISOString()
          }));
        }
      }
    }

    // Update badge in-place immediately
    if (orderRow) {
      orderRow.dataset.status = newStatus;
      const badge = orderRow.querySelector('.dash-order-status');
      if (badge) {
        badge.className = `dash-order-status status-${newStatus.replace(/_/g, '-')}`;
        badge.textContent = getStatusLabel(newStatus);
      }
    }

    showSuccess('Order Updated', `Status updated to ${getStatusLabel(newStatus)}`);
    loadSellerOrders();
    
  } catch (error) {
    showError('Update Failed', 'Could not update order status: ' + (error.message || error));
    console.error('[seller] updateOrderStatus full error:', error);
  }
}

// ---- PAYMENT VERIFICATION — ADMIN ONLY ----
// Payment verification is handled exclusively by the admin panel.
// Sellers can see payment status badges but cannot verify or reject payments.

// Event delegation for order management buttons
document.addEventListener('click', async (e) => {
  if (e.target.classList.contains('btn-update-order')) {
    const orderId = e.target.dataset.orderId;
    const orderRow = e.target.closest('.dash-order-row');
    const statusSelect = orderRow.querySelector('.status-update-select');
    const newStatus = statusSelect.value;
    
    await updateOrderStatus(orderId, newStatus);
  }
});

// Show/hide tracking inputs based on status selection - removed (tracking not supported)

// ============================================================
// LISTING FEE FUNCTIONS
// ============================================================

// ---- CHECK LISTING FEE AVAILABILITY ----
// Returns { available: true, fee } or { available: false, fee: null, reason: '...' }
async function checkListingFeeAvailability(seller_id) {
  // Query for an active fee that still has slots remaining
  const { data: fees, error } = await db
    .from('listing_fees')
    .select('*')
    .eq('seller_id', seller_id)
    .eq('status', 'active')
    .order('expires_at', { ascending: true });

  if (error) {
    console.error('[seller] checkListingFeeAvailability:', error.message);
    return { available: false, fee: null, reason: 'Could not check listing fee availability.' };
  }

  if (!fees || fees.length === 0) {
    return { available: false, fee: null, reason: 'No active listing fee found. Please purchase a listing tier.' };
  }

  const now = new Date();

  for (const fee of fees) {
    // Check expiry first
    if (fee.expires_at && new Date(fee.expires_at) < now) {
      // Mark as expired in DB
      await db.from('listing_fees').update({ status: 'expired' }).eq('id', fee.id);
      continue; // try next fee
    }

    // Check slots remaining
    if (fee.listings_used >= fee.max_listings) {
      continue; // exhausted, try next
    }

    // This fee is valid and has slots
    return { available: true, fee };
  }

  // All fees were either expired or exhausted
  return {
    available: false,
    fee: null,
    reason: 'Your listing fee has expired or all listing slots are exhausted. Please purchase a new tier.'
  };
}

// ---- RECORD LISTING FEE ----
// Records a listing fee payment for the given seller and tier.
// Returns { data: fee, error } matching the Supabase response pattern.
async function recordListingFee(seller_id, tier) {
  const tierConfig = {
    basic:    { amount_paid: 99,  max_listings: 3,  days: 30 },
    standard: { amount_paid: 249, max_listings: 10, days: 60 },
    premium:  { amount_paid: 499, max_listings: 25, days: 90 }
  };

  const config = tierConfig[tier];
  if (!config) {
    return { data: null, error: new Error(`Invalid tier: ${tier}. Must be basic, standard, or premium.`) };
  }

  // Step 1: Ensure seller record exists
  const { data: existingSeller, error: sellerCheckError } = await db
    .from('sellers')
    .select('id')
    .eq('id', seller_id)
    .single();

  if (sellerCheckError && sellerCheckError.code !== 'PGRST116') {
    // PGRST116 is "not found" error, which is expected if seller doesn't exist
    console.error('[seller] recordListingFee (seller check):', sellerCheckError.message);
    return { data: null, error: sellerCheckError };
  }

  if (!existingSeller) {
    // Seller doesn't exist, create a basic seller record
    console.log('[seller] recordListingFee: Creating seller record for ID:', seller_id);
    
    // Get user info from auth system for seller creation
    const currentUser = authManager.getCurrentUser();
    const userEmail = currentUser?.email || `user_${seller_id}@rewear.com`;
    
    const { data: newSeller, error: createSellerError } = await db
      .from('sellers')
      .insert({
        id: seller_id,
        business_name: `Seller ${seller_id.slice(0, 8)}`,
        email: userEmail,
        verified: true, // Auto-verify for listing fee purchases
        verified_at: new Date().toISOString(),
        description: 'Auto-created seller account'
      })
      .select()
      .single();

    if (createSellerError) {
      console.error('[seller] recordListingFee (create seller):', createSellerError.message);
      return { data: null, error: new Error('Could not create seller account. Please contact support.') };
    }

    console.log('[seller] recordListingFee: Seller record created:', newSeller);
  }

  const expires_at = new Date();
  expires_at.setDate(expires_at.getDate() + config.days);

  // Step 2: INSERT into listing_fees
  const { data: feeRows, error: feeError } = await db
    .from('listing_fees')
    .insert({
      seller_id,
      tier,
      amount_paid:   config.amount_paid,
      max_listings:  config.max_listings,
      listings_used: 0,
      status:        'active',
      expires_at:    expires_at.toISOString()
    })
    .select()
    .single();

  if (feeError) {
    console.error('[seller] recordListingFee (insert fee):', feeError.message);
    return { data: null, error: feeError };
  }

  const fee = feeRows;

  // Step 3: INSERT into earnings
  const { error: earningsError } = await db
    .from('earnings')
    .insert({
      source:       'listing_fee',
      reference_id: fee.id,
      amount:       config.amount_paid
    });

  if (earningsError) {
    // Non-fatal: fee was recorded, earnings entry failed — log and continue
    console.error('[seller] recordListingFee (insert earnings):', earningsError.message);
  }

  return { data: fee, error: null };
}

// ---- SUBMIT LISTING ----
// Verifies seller and fee availability, then inserts the product.
// Returns { data: product, error } matching the Supabase response pattern.
async function submitListing(seller_id, productPayload) {
  try {
    console.log('[seller] submitListing called with:', { seller_id, productPayload });

    // Step 1: Ensure seller record exists
    const { data: existingSeller, error: sellerCheckError } = await db
      .from('sellers')
      .select('id')
      .eq('id', seller_id)
      .single();

    if (sellerCheckError && sellerCheckError.code !== 'PGRST116') {
      // PGRST116 is "not found" error, which is expected if seller doesn't exist
      console.error('[seller] submitListing (seller check):', sellerCheckError.message);
      return { data: null, error: sellerCheckError };
    }

    if (!existingSeller) {
      // Seller doesn't exist, create a basic seller record
      console.log('[seller] submitListing: Creating seller record for ID:', seller_id);
      
      // Get user info from auth system for seller creation
      const currentUser = authManager.getCurrentUser();
      const userEmail = currentUser?.email || `user_${seller_id}@rewear.com`;
      
      const { data: newSeller, error: createSellerError } = await db
        .from('sellers')
        .insert({
          id: seller_id,
          business_name: `Seller ${seller_id.slice(0, 8)}`,
          email: userEmail,
          verified: true, // Auto-verify for product submissions
          verified_at: new Date().toISOString(),
          description: 'Auto-created seller account'
        })
        .select()
        .single();

      if (createSellerError) {
        console.error('[seller] submitListing (create seller):', createSellerError.message);
        return { data: null, error: new Error('Could not create seller account. Please contact support.') };
      }

      console.log('[seller] submitListing: Seller record created:', newSeller);
    }

    // Step 2: Check seller is verified — use sellers.verified only
    const { data: sellerRecord } = await db
      .from('sellers')
      .select('verified, rejection_reason')
      .eq('id', seller_id)
      .single();

    const isVerified = sellerRecord?.verified === true;
    const rejectionReason = sellerRecord?.rejection_reason;

    if (!isVerified) {
      if (rejectionReason) {
        return { data: null, error: new Error(`Application rejected: ${rejectionReason}`) };
      } else {
        return { data: null, error: new Error('Your seller account is pending admin approval. Please wait for verification.') };
      }
    }

    // Step 3: Check listing fee availability
    const { available, fee, reason: feeReason } = await checkListingFeeAvailability(seller_id);
    if (!available) {
      return { data: null, error: new Error(feeReason || 'No active listing fee. Please pay a listing fee first.') };
    }

    // Step 4: Insert the product with 'pending' status for admin approval
    const { data: product, error: insertError } = await db
      .from('products')
      .insert({
        seller_id:       seller_id,
        listing_fee_id:  fee.id,
        name:            productPayload.name,
        price:           productPayload.price,
        category:        productPayload.category,
        image_url:       productPayload.image_url,
        description:     productPayload.description || '',
        sizes:           productPayload.sizes,
        suggested_price: productPayload.suggested_price,
        in_stock:        false,   // set to true when admin approves
        status:          'pending' // requires admin approval
      })
      .select()
      .single();

    if (insertError) {
      console.error('[seller] submitListing (insert):', insertError.message);
      return { data: null, error: insertError };
    }

    console.log('[seller] submitListing: Product created successfully:', product);

    // Increment listing fee usage count
    await db.from('listing_fees')
      .update({ listings_used: fee.listings_used + 1 })
      .eq('id', fee.id);

    return { data: product, error: null };
    
  } catch (error) {
    console.error('[seller] submitListing (catch):', error.message);
    return { data: null, error };
  }
}

// ---- LOAD SELLER EARNINGS ----
// Returns aggregated earnings data for the seller's transactions.
// { totalGross, totalCommission, totalPayout, orders: Transaction[] }
async function loadSellerEarnings(seller_id) {
  const { data: orders, error } = await db
    .from('transactions')
    .select('gross_amount, commission_amount, seller_payout, status, created_at')
    .eq('seller_id', seller_id)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('[seller] loadSellerEarnings:', error.message);
    return { totalGross: 0, totalCommission: 0, totalPayout: 0, orders: [] };
  }

  const rows = orders || [];

  const totalGross      = rows.reduce((sum, t) => sum + parseFloat(t.gross_amount      || 0), 0);
  const totalCommission = rows.reduce((sum, t) => sum + parseFloat(t.commission_amount || 0), 0);
  const totalPayout     = rows
    .filter(t => t.status === 'released')
    .reduce((sum, t) => sum + parseFloat(t.seller_payout || 0), 0);

  return { totalGross, totalCommission, totalPayout, orders: rows };
}

// ============================================================
// FEES / EARNINGS / PAYOUTS TAB HANDLERS
// ============================================================

// ---- FEES TAB ----
async function loadFeesTab() {
  const currentSellerId = await getSellerIdForCurrentUser();
  const statusEl  = document.getElementById('currentFeeStatus');
  const historyEl = document.getElementById('feeHistoryList');
  if (!statusEl) return;

  if (!currentSellerId) {
    statusEl.innerHTML = '<p class="dash-empty">Please log in.</p>';
    return;
  }

  statusEl.innerHTML = '<p style="color:#888;font-size:14px;">Loading…</p>';

  // Load all fees for this seller
  const { data: fees, error } = await db
    .from('listing_fees')
    .select('*')
    .eq('seller_id', currentSellerId)
    .order('created_at', { ascending: false });

  if (error) {
    statusEl.innerHTML = '<p class="dash-empty">Could not load fee status.</p>';
    return;
  }

  const activeFee = fees?.find(f => f.status === 'active' && f.listings_used < f.max_listings);
  const pendingFee = fees?.find(f => f.status === 'proof_submitted' || f.status === 'pending_payment');

  if (activeFee) {
    const remaining = activeFee.max_listings - activeFee.listings_used;
    statusEl.innerHTML = `
      <div style="padding:16px;background:#e8f5e9;border-radius:10px;display:flex;align-items:center;gap:12px;">
        <span style="font-size:28px;">✅</span>
        <div>
          <p style="font-weight:700;margin:0;font-size:15px;">Active — ${activeFee.tier.charAt(0).toUpperCase()+activeFee.tier.slice(1)} Tier</p>
          <p style="margin:4px 0 0;font-size:13px;color:#555;">${activeFee.listings_used}/${activeFee.max_listings} listings used · ${remaining} slot${remaining!==1?'s':''} remaining</p>
          ${activeFee.expires_at ? `<p style="margin:2px 0 0;font-size:12px;color:#888;">Expires: ${new Date(activeFee.expires_at).toLocaleDateString()}</p>` : ''}
        </div>
      </div>`;
  } else if (pendingFee) {
    statusEl.innerHTML = `
      <div style="padding:16px;background:#fff8e1;border-radius:10px;display:flex;align-items:center;gap:12px;">
        <span style="font-size:28px;">⏳</span>
        <div>
          <p style="font-weight:700;margin:0;font-size:15px;">Payment Proof Submitted</p>
          <p style="margin:4px 0 0;font-size:13px;color:#555;">Awaiting admin verification. Your listings will activate once approved.</p>
        </div>
      </div>`;
  } else {
    statusEl.innerHTML = `
      <div style="padding:16px;background:#fce4ec;border-radius:10px;display:flex;align-items:center;gap:12px;">
        <span style="font-size:28px;">⚠️</span>
        <div>
          <p style="font-weight:700;margin:0;font-size:15px;">No Active Listing Fee</p>
          <p style="margin:4px 0 0;font-size:13px;color:#555;">Choose a tier below and pay via GCash to start listing products.</p>
        </div>
      </div>`;
  }

  // Fee history
  if (historyEl) {
    if (!fees?.length) {
      historyEl.innerHTML = '<p style="color:#888;font-size:14px;">No fee payments yet.</p>';
    } else {
      historyEl.innerHTML = fees.map(f => `
        <div style="padding:12px;border:1px solid #eee;border-radius:8px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
          <div>
            <span style="font-weight:600;font-size:14px;">${f.tier.charAt(0).toUpperCase()+f.tier.slice(1)} Tier</span>
            <span style="font-size:13px;color:#888;margin-left:8px;">₱${parseFloat(f.amount_paid).toFixed(2)}</span>
            <p style="margin:2px 0 0;font-size:12px;color:#aaa;">${new Date(f.created_at).toLocaleDateString()}</p>
            ${f.rejection_reason ? `<p style="margin:2px 0 0;font-size:12px;color:#e74c3c;">Rejected: ${f.rejection_reason}</p>` : ''}
          </div>
          <span style="padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;background:${
            f.status==='active'?'#d4edda':f.status==='proof_submitted'?'#cce5ff':f.status==='rejected'?'#f8d7da':f.status==='verified'?'#d4edda':'#fff3cd'
          };color:${
            f.status==='active'?'#155724':f.status==='proof_submitted'?'#004085':f.status==='rejected'?'#721c24':f.status==='verified'?'#155724':'#856404'
          };">${f.status==='active'?'✅ Active':f.status==='proof_submitted'?'📤 Pending Verification':f.status==='rejected'?'❌ Rejected':f.status==='verified'?'✅ Verified':'⏳ Pending'}</span>
        </div>`).join('');
    }
  }
}

// ---- SELECT FEE TIER ----
let _selectedTier = null;
const _tierPrices = { basic: 99, standard: 249, premium: 499 };

window.selectFeeTier = function(tier) {
  _selectedTier = tier;
  document.querySelectorAll('.fee-tier-card').forEach(card => {
    const isSelected = card.dataset.tier === tier;
    card.style.borderColor = isSelected ? '#c8a96e' : '#eee';
    card.style.background  = isSelected ? '#fdf8f0' : '#fff';
    card.style.transform   = isSelected ? 'scale(1.02)' : 'scale(1)';
  });

  const section = document.getElementById('feePaymentSection');
  const amountEl = document.getElementById('feePaymentAmount');
  const refEl    = document.getElementById('feePaymentRef');
  if (section) section.style.display = 'block';
  if (amountEl) amountEl.textContent = `₱${_tierPrices[tier]}`;
  if (refEl)    refEl.textContent    = `FEE-${Date.now().toString().slice(-6)}-${tier.toUpperCase()}`;
};

window.submitFeePayment = async function() {
  const currentSellerId = await getSellerIdForCurrentUser();
  if (!currentSellerId) { showError('Not Logged In', 'Please log in again.'); return; }
  if (!_selectedTier)   { showError('No Tier', 'Please select a tier first.'); return; }

  const proofInput = document.getElementById('feeProofInput');
  const file = proofInput?.files[0];
  if (!file) { showError('No Proof', 'Please upload your GCash payment screenshot.'); return; }
  if (!file.type.startsWith('image/')) { showError('Invalid File', 'Please upload an image file.'); return; }
  if (file.size > 5 * 1024 * 1024) { showError('File Too Large', 'Max 5MB.'); return; }

  showLoadingModal('Submitting…', 'Recording your fee payment request.');

  try {
    const config = { basic:{amount:99,max:3,days:30}, standard:{amount:249,max:10,days:60}, premium:{amount:499,max:25,days:90} };
    const c = config[_selectedTier];
    const ref = document.getElementById('feePaymentRef')?.textContent || `FEE-${Date.now()}`;

    // Ensure seller record exists
    const currentUser = authManager.getCurrentUser();
    await db.from('sellers').upsert({
      id: currentSellerId,
      business_name: currentUser?.name || currentUser?.email || 'Seller',
      email: currentUser?.email || '',
      verified: false
    }, { onConflict: 'id' });

    const expires_at = new Date();
    expires_at.setDate(expires_at.getDate() + c.days);

    // Try with 'pending' status first (more compatible)
    const feeData = {
      seller_id:    currentSellerId,
      tier:         _selectedTier,
      amount_paid:  c.amount,
      max_listings: c.max,
      listings_used: 0,
      status:       'pending', // Use 'pending' status for better compatibility
      payment_method: 'gcash',
      payment_ref:  ref,
      expires_at:   expires_at.toISOString()
    };

    console.log('[seller] submitFeePayment: Inserting fee data:', feeData);

    // Insert fee record
    let { error } = await db.from('listing_fees').insert(feeData);
    
    if (error) {
      console.error('[seller] submitFeePayment: Insert error:', error);
      
      // If status constraint error, try with 'active' status
      if (error.message?.includes('status_check') || error.message?.includes('constraint')) {
        console.log('[seller] submitFeePayment: Retrying with active status...');
        feeData.status = 'active';
        ({ error } = await db.from('listing_fees').insert(feeData));
      }
      
      if (error) throw error;
    }
    
    // Store proof metadata only (not the full image to avoid quota issues)
    // Admin will verify payment through their GCash account
    try {
      // Upload proof to Cloudinary if available
      let proofUrl = null;
      if (window.uploadPaymentReceipt) {
        try {
          proofUrl = await window.uploadPaymentReceipt(file, ref);
          console.log('[seller] submitFeePayment: Proof uploaded to Cloudinary:', proofUrl);
        } catch (uploadErr) {
          console.warn('[seller] submitFeePayment: Cloudinary upload failed, using localStorage fallback:', uploadErr.message);
        }
      }

      // If Cloudinary upload succeeded, update the fee record with proof_url
      if (proofUrl) {
        await db.from('listing_fees').update({
          proof_url: proofUrl,
          status: 'proof_submitted'
        }).eq('payment_ref', ref).eq('seller_id', currentSellerId);
        console.log('[seller] submitFeePayment: proof_url saved to database');
      }

      // Always store metadata in localStorage as fallback
      const proofMetadata = {
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type,
        uploadedAt: new Date().toISOString(),
        reference: ref,
        tier: _selectedTier,
        proofUrl: proofUrl
      };
      localStorage.setItem(`rewear_fee_proof_meta_${currentSellerId}_${ref}`, JSON.stringify(proofMetadata));
      if (proofUrl) {
        localStorage.setItem(`rewear_fee_proof_${currentSellerId}_${ref}`, proofUrl);
      }
      console.log('[seller] submitFeePayment: Proof metadata stored');
    } catch (storageErr) {
      console.warn('[seller] submitFeePayment: Could not store proof metadata:', storageErr);
    }
    
    console.log('[seller] submitFeePayment: Fee submitted successfully');

    hideLoadingModal();
    showSuccess('Payment Submitted!', 'Your listing fee payment has been recorded. Admin will verify your GCash payment and activate your listing slots within 24 hours.', 'Got it');
    document.getElementById('feePaymentSection').style.display = 'none';
    proofInput.value = '';
    _selectedTier = null;
    document.querySelectorAll('.fee-tier-card').forEach(c => { c.style.borderColor='#eee'; c.style.background='#fff'; });
    loadFeesTab();
  } catch (err) {
    hideLoadingModal();
    console.error('[seller] submitFeePayment: Exception:', err);
    showError('Submission Failed', err.message || 'Could not submit fee payment. Please try again or contact support.');
  }
};

// ---- PURCHASE TIER BUTTON (legacy) ----
document.getElementById('purchaseTierBtn')?.addEventListener('click', async () => {
  const tier = document.querySelector('input[name="feeTier"]:checked')?.value;
  if (!tier) { showError('No Tier Selected', 'Please select a listing tier.'); return; }
  const currentSellerId = await getSellerIdForCurrentUser();
  if (!currentSellerId) { showError('Not Logged In', 'Please log in again.'); return; }
  showLoadingModal('Processing…', 'Recording your listing fee purchase.');
  const { data: fee, error } = await recordListingFee(currentSellerId, tier);
  hideLoadingModal();
  if (error) { showError('Purchase Failed', error.message); return; }
  showSuccess('Tier Purchased!', `You can now list up to ${fee.max_listings} products.`, 'Got it');
  await loadFeesTab();
});

// ---- EARNINGS TAB ----
async function loadEarningsTab() {
  const currentSellerId = await getSellerIdForCurrentUser();
  const listEl      = document.getElementById('sellerEarningsList');
  const grossEl     = document.getElementById('earningsTotalGross');
  const commissionEl = document.getElementById('earningsTotalCommission');
  const payoutEl    = document.getElementById('earningsTotalPayout');

  if (!listEl) return;
  if (!currentSellerId) { listEl.innerHTML = '<p class="dash-empty">Please log in.</p>'; return; }

  listEl.innerHTML = '<p class="dash-empty">Loading earnings…</p>';

  try {
    // Get seller's product IDs first, then query orders for those products
    const { data: sellerProducts } = await db
      .from('products')
      .select('id, name')
      .eq('seller_id', currentSellerId);

    const productIds = (sellerProducts || []).map(p => p.id);
    const productMap = {};
    (sellerProducts || []).forEach(p => { productMap[p.id] = p; });

    let sellerOrders = [];
    if (productIds.length > 0) {
      const { data: orders } = await db
        .from('orders')
        .select('id, total_price, status, created_at, product_id')
        .in('product_id', productIds)
        .in('status', ['confirmed', 'shipped', 'delivered', 'received'])
        .order('created_at', { ascending: false });
      sellerOrders = (orders || []).map(o => ({
        ...o,
        products: productMap[o.product_id] || { name: '—' }
      }));
    }

    const COMMISSION_RATE = 0.10; // 10% platform commission
    const totalGross      = sellerOrders.reduce((s, o) => s + parseFloat(o.total_price || 0), 0);
    const totalCommission = totalGross * COMMISSION_RATE;
    const totalPayout     = totalGross - totalCommission;

    if (grossEl)      grossEl.textContent      = formatPHP(totalGross);
    if (commissionEl) commissionEl.textContent = formatPHP(totalCommission);
    if (payoutEl)     payoutEl.textContent     = formatPHP(totalPayout);

    if (sellerOrders.length === 0) {
      listEl.innerHTML = '<p class="dash-empty">No earnings yet. Earnings appear once orders are confirmed.</p>';
      return;
    }

    listEl.innerHTML = `
      <table style="width:100%;border-collapse:collapse;font-size:0.9rem;">
        <thead>
          <tr style="border-bottom:2px solid #e8d5b0;text-align:left;">
            <th style="padding:8px 12px;">Date & Time</th>
            <th style="padding:8px 12px;">Product</th>
            <th style="padding:8px 12px;">Gross</th>
            <th style="padding:8px 12px;">Commission (10%)</th>
            <th style="padding:8px 12px;">Net Payout</th>
            <th style="padding:8px 12px;">Status</th>
          </tr>
        </thead>
        <tbody>
          ${sellerOrders.map(o => {
            const gross      = parseFloat(o.total_price || 0);
            const commission = gross * COMMISSION_RATE;
            const payout     = gross - commission;
            const date       = new Date(o.created_at);
            const dateStr    = `${date.toLocaleDateString()} ${date.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}`;
            return `
              <tr style="border-bottom:1px solid #f0e6d3;">
                <td style="padding:8px 12px;">${dateStr}</td>
                <td style="padding:8px 12px;">${o.products?.name || '—'}</td>
                <td style="padding:8px 12px;">${formatPHP(gross)}</td>
                <td style="padding:8px 12px;color:#e74c3c;">-${formatPHP(commission)}</td>
                <td style="padding:8px 12px;color:#27ae60;font-weight:600;">${formatPHP(payout)}</td>
                <td style="padding:8px 12px;"><span class="dash-order-status status-${o.status}">${getStatusLabel(o.status)}</span></td>
              </tr>`;
          }).join('')}
        </tbody>
      </table>`;

  } catch (error) {
    listEl.innerHTML = '<p class="dash-empty">Could not load earnings.</p>';
    console.error('[seller] loadEarningsTab:', error);
  }
}

// ---- PAYOUTS TAB ----
async function loadPayoutsTab() {
  const currentSellerId = await getSellerIdForCurrentUser();
  const balanceEl = document.getElementById('pendingPayoutBalance');
  const historyEl = document.getElementById('payoutHistoryList');

  if (!balanceEl || !historyEl) return;

  if (!currentSellerId) {
    balanceEl.innerHTML = '<p class="dash-empty">Seller session not found. Please log in.</p>';
    historyEl.innerHTML = '';
    authManager.redirectToLogin();
    return;
  }

  balanceEl.innerHTML = '<p class="dash-empty">Loading…</p>';
  historyEl.innerHTML = '<p class="dash-empty">Loading…</p>';

  // Query released transactions (payout history)
  const { data: released, error: releasedError } = await db
    .from('transactions')
    .select('*')
    .eq('seller_id', currentSellerId)
    .eq('status', 'released')
    .order('released_at', { ascending: false });

  if (releasedError) {
    console.error('[seller] loadPayoutsTab (released):', releasedError.message);
    historyEl.innerHTML = '<p class="dash-empty">Could not load payout history.</p>';
  }

  // Query pending transactions to compute pending balance
  const { data: pending, error: pendingError } = await db
    .from('transactions')
    .select('seller_payout')
    .eq('seller_id', currentSellerId)
    .eq('status', 'pending');

  if (pendingError) {
    console.error('[seller] loadPayoutsTab (pending):', pendingError.message);
  }

  // Compute pending balance
  const pendingBalance = (pending || []).reduce((sum, t) => sum + parseFloat(t.seller_payout || 0), 0);

  // Render pending balance
  if (pendingBalance > 0) {
    balanceEl.innerHTML = `
      <div class="dash-verify-info">
        <div>
          <p class="dash-verify-title" style="font-size:1.5rem;">${formatPHP(pendingBalance)}</p>
          <p class="dash-verify-text">Awaiting release by admin after order delivery.</p>
        </div>
      </div>`;
  } else {
    balanceEl.innerHTML = '<p class="dash-empty">No pending payouts.</p>';
  }

  // Render payout history
  const releasedRows = released || [];
  if (releasedRows.length === 0) {
    historyEl.innerHTML = '<p class="dash-empty">No payout history yet.</p>';
    return;
  }

  historyEl.innerHTML = releasedRows.map(t => `
    <div class="dash-order-row">
      <div>
        <p class="dash-order-name">${formatPHP(t.seller_payout)} released</p>
        <p class="dash-order-meta">Gross: ${formatPHP(t.gross_amount)} &nbsp;·&nbsp; Commission: ${formatPHP(t.commission_amount)}</p>
        <p class="dash-order-meta">Released: ${t.released_at ? formatDate(t.released_at) : '—'}</p>
      </div>
      <span class="dash-order-status status-released">released</span>
    </div>`).join('');
}

// ---- ADD PRODUCT FORM ----
document.getElementById('addProductForm')?.addEventListener('submit', async e => {
  e.preventDefault();

  const currentSellerId = await getSellerIdForCurrentUser();
  if (!currentSellerId) {
    showError('Not Logged In', 'Could not find your seller session. Please log in again.');
    authManager.redirectToLogin();
    return;
  }

  const sizes = [...document.querySelectorAll('.size-selector input:checked')].map(cb => cb.value);

  // Get image URL from the modern image uploader (data URL or empty)
  const uploader = window.imageUploader || imageUploader;
  const uploadedImages = uploader?.getImages?.() || [];
  const uploadedImageUrl = uploadedImages.length > 0 ? uploadedImages[0].url : '';

  const payload = {
    name:             document.getElementById('newName').value.trim(),
    price:            parseFloat(document.getElementById('newPrice').value),
    category:         document.getElementById('newCategory').value,
    suggested_price:  parseFloat(document.getElementById('newSuggestedPrice').value) || null,
    image_url:        uploadedImageUrl,
    description:      document.getElementById('newDescription').value.trim(),
    sizes:            sizes.length ? sizes : ['S', 'M', 'L'],
    in_stock:         true
  };

  // Validate image URL is not a local file path
  if (payload.image_url) {
    const isLocalPath = payload.image_url.startsWith('file://') || 
                       payload.image_url.includes(':\\') || 
                       payload.image_url.includes('C:/') || 
                       payload.image_url.includes('Users/');
    
    if (isLocalPath) {
      showError('Invalid Image', 'Image must be uploaded through the form, not a local file path. Please use the image upload area above.');
      return;
    }
    
    // Check if it's a valid format (data URL, http/https, or relative path)
    const isValidFormat = payload.image_url.startsWith('data:image/') ||
                         payload.image_url.startsWith('http://') ||
                         payload.image_url.startsWith('https://') ||
                         payload.image_url.startsWith('/') ||
                         payload.image_url.startsWith('./') ||
                         payload.image_url.startsWith('../');
    
    if (!isValidFormat) {
      showError('Invalid Image Format', 'Please upload an image using the upload area above. Direct file paths are not supported.');
      return;
    }
  }

  // ✅ VALIDATION
  const { valid, errors } = validateObject(payload, {
    name: 'productName',
    price: 'price',
    category: 'category',
    image_url: 'imageUrl',
    sizes: 'sizes'
  });

  if (!valid) {
    showValidationErrors(errors);
    return;
  }

  // Validate optional suggested_price if provided
  if (payload.suggested_price && !validators.price(payload.suggested_price)) {
    showError('Validation Error', 'Suggested price must be a valid amount');
    return;
  }

  // Sanitize description
  if (payload.description) {
    const sanitized = validators.description(payload.description);
    if (sanitized === null) {
      showError('Validation Error', 'Description is too long (max 2000 characters)');
      return;
    }
    payload.description = sanitized;
  }

  showLoadingModal('Submitting…', 'Sending your listing for admin review.');
  const { data: product, error } = await submitListing(currentSellerId, payload);
  hideLoadingModal();

  if (error) {
    const msg = error.message || '';
    console.error('[seller] addProduct:', msg);

    if (msg.toLowerCase().includes('pending admin approval') || msg.toLowerCase().includes('not yet verified') || msg.toLowerCase().includes('rejected')) {
      showError('Account Not Verified', msg);
    } else if (msg.toLowerCase().includes('listing fee') || msg.toLowerCase().includes('no active')) {
      showError('Listing Fee Required', msg);
      document.querySelector('[data-tab="fees"]')?.click();
    } else {
      showError('Failed to Submit', msg);
    }
  } else {
    showSuccess('Listing Submitted!', 'Your listing has been submitted for admin review. It will appear in the shop once approved.', 'Got it');
    document.getElementById('addProductForm').reset();
    window.imageUploader?.reset?.();
  }
});

// ---- SELLER PROFILE LOAD ----
async function loadSellerProfile() {
  const currentSellerId = await getSellerIdForCurrentUser();
  const currentUser = authManager.getCurrentUser();
  if (!currentSellerId) return;

  // Also populate account settings fields
  if (typeof loadSellerAccountSettings === 'function') loadSellerAccountSettings();

  try {
    const { data: seller, error } = await db
      .from('sellers')
      .select('business_name, email, phone, description, gcash_number, gcash_name')
      .eq('id', currentSellerId)
      .single();

    const set = (id, val) => { const el = document.getElementById(id); if (el) el.value = val || ''; };

    if (seller) {
      set('bizName',  seller.business_name);
      set('bizEmail', seller.email);
      set('bizPhone', seller.phone);
      set('bizDesc',  seller.description);
      // Load GCash from DB first, fall back to localStorage
      const lsGcash = JSON.parse(localStorage.getItem(`rewear_gcash_${currentSellerId}`) || '{}');
      set('bizGcashNumber', seller.gcash_number || lsGcash.gcash_number);
      set('bizGcashName',   seller.gcash_name   || lsGcash.gcash_name);
    } else {
      set('bizName',  currentUser?.name || '');
      set('bizEmail', currentUser?.email || '');
      const lsGcash = JSON.parse(localStorage.getItem(`rewear_gcash_${currentSellerId}`) || '{}');
      set('bizGcashNumber', lsGcash.gcash_number);
      set('bizGcashName',   lsGcash.gcash_name);
    }

  } catch (error) {
    console.error('[seller] loadSellerProfile:', error.message);
  }
}

// ---- SELLER PROFILE FORM ----
document.getElementById('sellerProfileForm')?.addEventListener('submit', async e => {
  e.preventDefault();
  
  const currentSellerId = await getSellerIdForCurrentUser();
  if (!currentSellerId) return;

  const payload = {
    business_name: document.getElementById('bizName').value.trim(),
    email:         document.getElementById('bizEmail').value.trim(),
    phone:         document.getElementById('bizPhone').value.trim(),
    description:   document.getElementById('bizDesc').value.trim()
  };

  const gcashNumber = document.getElementById('bizGcashNumber')?.value.trim();
  const gcashName   = document.getElementById('bizGcashName')?.value.trim();

  // Always save GCash to localStorage as fallback
  localStorage.setItem(`rewear_gcash_${currentSellerId}`, JSON.stringify({
    gcash_number: gcashNumber || '',
    gcash_name:   gcashName || ''
  }));

  // Try to save GCash to DB (requires 06_buyer_flow.sql)
  if (gcashNumber) {
    payload.gcash_number = gcashNumber;
    payload.gcash_name   = gcashName || '';
  }

  // ✅ VALIDATION
  const { valid, errors } = validateObject(payload, {
    business_name: 'businessName',
    email: 'email'
  });

  if (!valid) {
    showValidationErrors(errors);
    return;
  }

  if (payload.phone && !validators.phone(payload.phone)) {
    showError('Validation Error', validationMessages.phone);
    return;
  }

  if (payload.description) {
    const sanitized = validators.description(payload.description);
    if (sanitized === null) {
      showError('Validation Error', 'Description is too long (max 2000 characters)');
      return;
    }
    payload.description = sanitized;
  }

  showLoadingModal('Saving…', 'Updating your seller profile.');
  let { error } = await db.from('sellers').upsert({ id: currentSellerId, ...payload });

  // If gcash columns don't exist yet, retry without them
  if (error?.message?.includes('gcash')) {
    delete payload.gcash_number;
    delete payload.gcash_name;
    ({ error } = await db.from('sellers').upsert({ id: currentSellerId, ...payload }));
  }
  hideLoadingModal();
  
  if (error) {
    if (error.code === '23505') showError('Email Taken', 'This email is already registered as a seller.');
    else showError('Save Failed', error.message);
    console.error('[seller] saveProfile:', error.message);
  } else {
    showSuccess('Profile Saved!', 'Your seller profile has been updated.', 'Got it');
  }
});

// ---- MESSAGES TAB ----
let activeSellerChatId = null;

function formatChatTime(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  const now = new Date();
  const diffDays = Math.floor((now - d) / 86400000);
  if (diffDays === 0) return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7)  return d.toLocaleDateString([], { weekday: 'short' });
  return d.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

async function loadSellerMessages() {
  const currentSellerId = await getSellerIdForCurrentUser();
  if (!currentSellerId) return;

  const pendingList  = document.getElementById('sellerPendingList');
  const activeList   = document.getElementById('sellerActiveList');
  if (!pendingList || !activeList) return;
  
  // Show skeleton loaders while loading
  const skeletonHTML = `
    ${Array(2).fill(0).map(() => `
      <div class="chat-skeleton-item">
        <div class="chat-skeleton-avatar skeleton"></div>
        <div class="chat-skeleton-info">
          <div class="chat-skeleton-name skeleton"></div>
          <div class="chat-skeleton-preview skeleton"></div>
        </div>
        <div class="chat-skeleton-time skeleton"></div>
      </div>
    `).join('')}
  `;
  
  pendingList.innerHTML = skeletonHTML;
  activeList.innerHTML = skeletonHTML;

  try {
    const { data, error } = await messagesDb
      .from('messages').select('*')
      .eq('seller_id', currentSellerId)
      .order('created_at', { ascending: false });

    if (error) throw error;

    const pending  = (data || []).filter(m => !m.accepted && !m.rejected);
    const accepted = (data || []).filter(m => m.accepted);

    // Render pending list
    pendingList.innerHTML = pending.length ? pending.map(m => `
      <div class="chat-conv-item ${activeSellerChatId === m.id ? 'active' : ''}"
           onclick="openSellerChat('${m.id}')" data-msg-id="${m.id}">
        <div class="chat-conv-avatar">${m.buyer_name.charAt(0).toUpperCase()}</div>
        <div class="chat-conv-info">
          <div class="chat-conv-name">${m.buyer_name}</div>
          <div class="chat-conv-preview">${m.message.length > 35 ? m.message.slice(0,35)+'…' : m.message}</div>
        </div>
        <div class="chat-conv-time">${formatChatTime(m.created_at)}</div>
      </div>`).join('')
    : '<p style="padding:12px 16px;font-size:13px;color:#aaa;">No pending messages</p>';

    // Render active list
    activeList.innerHTML = accepted.length ? accepted.map(m => {
      const thread = Array.isArray(m.thread) ? m.thread : [];
      const last = thread.length ? thread[thread.length-1] : null;
      const preview = last ? last.text : (m.reply || m.message);
      const hasUnread = thread.some(t => t.role === 'buyer' && !t.read);
      return `
        <div class="chat-conv-item ${activeSellerChatId === m.id ? 'active' : ''} ${hasUnread ? 'unread' : ''}"
             onclick="openSellerChat('${m.id}')" data-msg-id="${m.id}">
          <div class="chat-conv-avatar">${m.buyer_name.charAt(0).toUpperCase()}</div>
          <div class="chat-conv-info">
            <div class="chat-conv-name">${m.buyer_name}</div>
            <div class="chat-conv-preview">${preview.length > 35 ? preview.slice(0,35)+'…' : preview}</div>
          </div>
          <div class="chat-conv-time">${formatChatTime(m.updated_at || m.created_at)}</div>
          ${hasUnread ? '<div class="chat-unread-dot"></div>' : ''}
        </div>`;
    }).join('')
    : '<p style="padding:12px 16px;font-size:13px;color:#aaa;">No active conversations</p>';

    // Check if we need to auto-open a specific conversation (from order tracking chat button)
    const openChatWithData = sessionStorage.getItem('openChatWith');
    if (openChatWithData) {
      try {
        const chatInfo = JSON.parse(openChatWithData);
        console.log('[seller] Auto-opening chat with:', chatInfo);
        
        if (chatInfo.type === 'seller-to-buyer' && chatInfo.buyerEmail) {
          // Find the message with this buyer
          const matchingMsg = data.find(m => m.buyer_email === chatInfo.buyerEmail);
          if (matchingMsg) {
            console.log('[seller] Found matching conversation:', matchingMsg.id);
            openSellerChat(matchingMsg.id);
            // Clear the flag so it doesn't auto-open again
            sessionStorage.removeItem('openChatWith');
          } else {
            console.log('[seller] No existing conversation found with buyer:', chatInfo.buyerEmail);
          }
        }
      } catch (e) {
        console.error('[seller] Error parsing openChatWith data:', e);
        sessionStorage.removeItem('openChatWith');
      }
    }
    // Re-open active chat if one was selected (and no auto-open happened)
    else if (activeSellerChatId) {
      openSellerChat(activeSellerChatId);
    }

  } catch (err) {
    console.error('[seller] loadSellerMessages:', err);
  }
}

window.openSellerChat = async function(msgId) {
  activeSellerChatId = msgId;

  // Update active state in lists
  document.querySelectorAll('#sellerPendingList .chat-conv-item, #sellerActiveList .chat-conv-item').forEach(el => {
    el.classList.toggle('active', el.dataset.msgId === msgId);
  });

  // Show chat window
  document.getElementById('sellerChatEmptyState').style.display = 'none';
  document.getElementById('sellerChatActive').style.display = 'flex';

  // Fetch message
  const { data: msg } = await messagesDb.from('messages').select('*').eq('id', msgId).single();
  if (!msg) return;

  // Header — Messenger style with PC + VC buttons
  document.getElementById('sellerChatHeader').className = 'messenger-header';
  document.getElementById('sellerChatHeader').innerHTML = `
    <div class="messenger-header-left">
      <div class="messenger-avatar">${msg.buyer_name.charAt(0).toUpperCase()}</div>
      <div class="messenger-info">
        <span class="messenger-name" id="sellerChatName">${msg.buyer_name}</span>
        <span class="messenger-status">${msg.buyer_email}</span>
      </div>
    </div>
    <div class="messenger-header-actions">
      <button class="messenger-action-btn" title="Phone Call" onclick="startVoiceCall()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" width="16" height="16">
          <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.4 2 2 0 0 1 3.6 1.22h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.82a16 16 0 0 0 6.29 6.29l.96-.96a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z" stroke-width="2"/>
        </svg>
        <span style="font-size:11px;font-weight:700;">PC</span>
      </button>
      <button class="messenger-action-btn messenger-video-btn" title="Video Call" onclick="startVideoCallFromChat()">
        <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16">
          <path d="M15 10l4.553-2.276A1 1 0 0 1 21 8.723v6.554a1 1 0 0 1-1.447.894L15 14v-4zM3 8a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8z"/>
        </svg>
        <span style="font-size:11px;font-weight:700;">VC</span>
      </button>
    </div>`;

  // Build chat bubbles
  const messagesEl = document.getElementById('sellerChatMessages');
  const thread = Array.isArray(msg.thread) ? msg.thread : [];
  const bubbles = [];

  // Buyer's first message
  bubbles.push(`
    <div class="chat-bubble-wrap from-seller" style="align-items:flex-start;">
      <div class="chat-bubble" style="background:#f0f0f0;color:#333;">${msg.message}</div>
      <div class="chat-bubble-meta">${msg.buyer_name} · ${formatChatTime(msg.created_at)}</div>
    </div>`);

  // Old-style single reply (backwards compat)
  if (thread.length === 0 && msg.reply) {
    bubbles.push(`
      <div class="chat-bubble-wrap from-buyer">
        <div class="chat-bubble">You: ${msg.reply}</div>
        <div class="chat-bubble-meta">${formatChatTime(msg.replied_at)}</div>
      </div>`);
  }

  // Thread messages
  thread.forEach(entry => {
    const isSeller = entry.role === 'seller';
    bubbles.push(`
      <div class="chat-bubble-wrap ${isSeller ? 'from-buyer' : 'from-seller'}" style="align-items:${isSeller ? 'flex-end' : 'flex-start'};">
        <div class="chat-bubble" style="${isSeller ? '' : 'background:#f0f0f0;color:#333;'}">${entry.text}</div>
        <div class="chat-bubble-meta">${isSeller ? 'You' : msg.buyer_name} · ${formatChatTime(entry.ts)}</div>
      </div>`);
  });

  messagesEl.innerHTML = bubbles.join('');
  messagesEl.scrollTop = messagesEl.scrollHeight;

  // Show accept/reject or reply bar
  const acceptBar = document.getElementById('sellerAcceptBar');
  const replyBar  = document.getElementById('sellerReplyBar');
  if (msg.accepted) {
    if (acceptBar) acceptBar.style.display = 'none';
    if (replyBar)  replyBar.style.display  = 'flex';
  } else {
    if (acceptBar) acceptBar.style.display = 'flex';
    if (replyBar)  replyBar.style.display  = 'none';
  }
};

window.sellerAcceptCurrentChat = async function() {
  if (!activeSellerChatId) return;
  const { error } = await messagesDb.from('messages')
    .update({ accepted: true, accepted_at: new Date().toISOString() })
    .eq('id', activeSellerChatId);
  if (error) { showError('Error', error.message); return; }
  showSuccess('Chat Accepted!', 'You can now reply to this buyer.', 'Got it');
  loadSellerMessages();
};

window.sellerRejectCurrentChat = async function() {
  if (!activeSellerChatId) return;
  const reason = prompt('Reason for rejecting? (optional)') || '';
  const { error } = await messagesDb.from('messages')
    .update({ rejected: true, rejected_reason: reason })
    .eq('id', activeSellerChatId);
  if (error) { showError('Error', error.message); return; }
  activeSellerChatId = null;
  document.getElementById('sellerChatEmptyState').style.display = 'flex';
  document.getElementById('sellerChatActive').style.display = 'none';
  loadSellerMessages();
};

window.sendSellerReply = async function() {
  const input = document.getElementById('sellerReplyInput');
  const text  = input?.value.trim();
  if (!text || !activeSellerChatId) return;

  try {
    const { data: msg } = await messagesDb.from('messages').select('thread').eq('id', activeSellerChatId).single();
    const thread = Array.isArray(msg?.thread) ? msg.thread : [];
    thread.push({ role: 'seller', text, ts: new Date().toISOString() });

    const { error } = await messagesDb.from('messages')
      .update({ thread, reply: text, replied_at: new Date().toISOString() })
      .eq('id', activeSellerChatId);

    if (error) throw error;
    input.value = '';
    openSellerChat(activeSellerChatId);
    loadSellerMessages();
  } catch (err) {
    showError('Error', 'Could not send reply: ' + err.message);
  }
};

// Keep old sendReply for backwards compat
window.sendReply = window.sendSellerReply;

// ---- VERIFICATION STATUS ----
async function loadVerificationStatus() {
  const currentUser = authManager.getCurrentUser();
  const currentSellerId = await getSellerIdForCurrentUser();
  const el = document.getElementById('verificationStatusContent');
  
  if (!el) return;

  try {
    let seller = null;

    // Try by ID first
    if (currentSellerId) {
      const { data } = await db
        .from('sellers')
        .select('verified, rejection_reason')
        .eq('id', currentSellerId)
        .single();
      seller = data;
    }

    // Fallback: try by email
    if (!seller && currentUser?.email) {
      const { data } = await db
        .from('sellers')
        .select('verified, rejection_reason')
        .eq('email', currentUser.email)
        .single();
      seller = data;
    }

    console.log('[seller] Verification status:', seller);

    if (seller?.verified === true) {
      el.innerHTML = `
        <div style="padding:16px;background:#e8f5e9;border-radius:10px;display:flex;gap:12px;align-items:center;">
          <span style="font-size:28px;">✅</span>
          <div>
            <p style="font-weight:700;margin:0;color:#155724;">Account Verified</p>
            <p style="margin:4px 0 0;font-size:13px;color:#555;">You are a verified seller. You can now list products and receive orders.</p>
          </div>
        </div>`;
    } else if (seller?.rejection_reason) {
      el.innerHTML = `
        <div style="padding:16px;background:#fce4ec;border-radius:10px;display:flex;gap:12px;align-items:flex-start;">
          <span style="font-size:28px;">❌</span>
          <div>
            <p style="font-weight:700;margin:0;color:#880e4f;">Application Rejected</p>
            <p style="margin:4px 0 0;font-size:13px;color:#555;">Reason: ${seller.rejection_reason}</p>
          </div>
        </div>`;
    } else {
      el.innerHTML = `
        <div style="padding:16px;background:#fff8e1;border-radius:10px;display:flex;gap:12px;align-items:center;">
          <span style="font-size:28px;">⏳</span>
          <div>
            <p style="font-weight:700;margin:0;">Pending Review</p>
            <p style="margin:4px 0 0;font-size:13px;color:#555;">Your seller application is being reviewed by our team.</p>
          </div>
        </div>`;
    }
  } catch (error) {
    console.error('[seller] loadVerificationStatus error:', error);
    el.innerHTML = `
      <div style="padding:16px;background:#f8d7da;border-radius:10px;display:flex;gap:12px;align-items:center;">
        <span style="font-size:28px;">⚠️</span>
        <div>
          <p style="font-weight:700;margin:0;color:#721c24;">Could not load status</p>
          <p style="margin:4px 0 0;font-size:13px;color:#555;">${error.message}</p>
        </div>
      </div>`;
  }
}

// ---- MARK AS SOLD ----
window.markAsSold = async function(productId) {
  if (!confirm('Mark this item as sold? It will be removed from the shop.')) return;
  try {
    const { error } = await db.from('products').update({ in_stock: false, status: 'approved' }).eq('id', productId);
    if (error) throw error;
    showSuccess('Marked as Sold', 'The item has been removed from the shop.', 'Got it');
    loadSellerListings();
  } catch (err) {
    showError('Error', 'Could not mark as sold: ' + err.message);
  }
};

// ---- SELLER MARKS ITEM SOLD (Transaction Complete) ----
window.sellerMarkItemSold = async function(orderId, productId) {
  if (!confirm('Confirm transaction is complete and mark item as sold?')) return;
  try {
    showLoadingModal('Completing Transaction…', 'Marking item as sold.');

    // Mark product as sold (out of stock)
    if (productId) {
      await db.from('products').update({ in_stock: false }).eq('id', productId);
    }

    // Update order status to 'sold' (use 'received' as final state)
    await db.from('orders').update({ status: 'received' }).eq('id', orderId);

    hideLoadingModal();
    showSuccess('Transaction Complete! 🎉', 'The item has been marked as sold. The transaction is now complete.', 'Done');
    loadSellerOrders();
    loadOverviewStats();
  } catch (err) {
    hideLoadingModal();
    showError('Error', 'Could not complete transaction: ' + err.message);
  }
};

// ---- ACCEPT ORDER ----
window.acceptOrder = async function(orderId) {
  if (!confirm('Accept this order? This confirms you will prepare the item.')) return;
  try {
    const { error } = await db.from('orders').update({ status: 'confirmed' }).eq('id', orderId);
    if (error) throw error;
    showSuccess('Order Accepted!', 'The buyer has been notified. Please prepare the item.', 'Got it');
    loadSellerOrders();
    loadOverviewStats();
  } catch (err) {
    showError('Error', 'Could not accept order: ' + err.message);
  }
};

// ---- INIT ----
// Poll for authManager to be ready before initializing seller dashboard
(function initSellerDashboard() {
  let waited = 0;
  const poll = setInterval(async () => {
    waited += 200;
    if (window.authManager?.isInitialized && authManager.isAuthenticated?.()) {
      clearInterval(poll);
      console.log('[seller] Auth ready, initializing seller dashboard');
      await loadOverviewStats();
      await loadVerificationStatus();
    } else if (waited >= 5000) {
      clearInterval(poll);
      console.warn('[seller] Auth timed out — attempting init anyway');
      await loadOverviewStats();
      await loadVerificationStatus();
    }
  }, 200);
})();

// ---- REAL-TIME SUBSCRIPTIONS ----
async function startSellerRealtimeUpdates() {
  const currentSellerId = await getSellerIdForCurrentUser();
  if (!currentSellerId) return;

  // Real-time: new buyer messages coming in
  messagesDb
    .channel('seller-messages-realtime')
    .on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'messages',
      filter: `seller_id=eq.${currentSellerId}`
    }, (payload) => {
      console.log('[realtime] Seller: message update:', payload);
      loadSellerMessages();
      if (activeSellerChatId === payload.new?.id) {
        openSellerChat(activeSellerChatId);
      }
    })
    .subscribe();

  // Real-time: order status changes
  db
    .channel('seller-orders-realtime')
    .on('postgres_changes', {
      event: 'UPDATE',
      schema: 'public',
      table: 'orders',
      filter: `seller_id=eq.${currentSellerId}`
    }, (payload) => {
      console.log('[realtime] Seller: order updated:', payload);
      loadSellerOrders();
      loadOverviewStats();
    })
    .subscribe();

  console.log('[realtime] Seller real-time subscriptions started for:', currentSellerId);
}

// Start real-time after auth is ready
setTimeout(async () => {
  if (window.authManager?.getCurrentUser()) {
    await startSellerRealtimeUpdates();
  }
}, 2000);

// ---- DEVELOPMENT HELPER FUNCTIONS ----
// These functions can be called from browser console for testing

// Clear all data for current seller (for testing purposes)
window.clearSellerData = async function() {
  const currentSellerId = await getSellerIdForCurrentUser();
  if (!currentSellerId) {
    console.log('No seller logged in');
    return;
  }
  
  console.log('Clearing data for seller:', currentSellerId);
  
  try {
    // Delete seller's products
    const { error: productsError } = await db.from('products').delete().eq('seller_id', currentSellerId);
    if (productsError) console.error('Error deleting products:', productsError);
    
    // Delete seller's orders (get all orders and delete those for seller's products)
    const { data: allOrdersToCheck } = await db
      .from('orders')
      .select(`
        id,
        products (
          seller_id
        )
      `);
      
    const sellerOrderIds = allOrdersToCheck?.filter(order => 
      order.products?.seller_id === currentSellerId
    ).map(order => order.id) || [];
      
    if (sellerOrderIds.length > 0) {
      const { error: ordersError } = await db.from('orders').delete().in('id', sellerOrderIds);
      if (ordersError) console.error('Error deleting orders:', ordersError);
    }
    
    // Delete seller's listing fees
    const { error: feesError } = await db.from('listing_fees').delete().eq('seller_id', currentSellerId);
    if (feesError) console.error('Error deleting listing fees:', feesError);
    
    console.log('Seller data cleared successfully');
    
    // Refresh the dashboard
    loadOverviewStats();
    loadSellerListings();
    loadSellerOrders();
    
  } catch (error) {
    console.error('Error clearing seller data:', error);
  }
};

// Check current seller's data count
window.checkSellerData = async function() {
  const currentSellerId = await getSellerIdForCurrentUser();
  if (!currentSellerId) {
    console.log('No seller logged in');
    return;
  }
  
  console.log('Checking data for seller:', currentSellerId);
  
  try {
    const { count: productCount } = await db.from('products').select('*', { count: 'exact', head: true }).eq('seller_id', currentSellerId);
    
    // Count orders through products relationship (client-side filtering)
    const { data: allOrdersToCount } = await db
      .from('orders')
      .select(`
        id,
        products (
          seller_id
        )
      `);
      
    const orderCount = allOrdersToCount?.filter(order => 
      order.products?.seller_id === currentSellerId
    ).length || 0;
    
    const { count: feeCount } = await db.from('listing_fees').select('*', { count: 'exact', head: true }).eq('seller_id', currentSellerId);
    
    console.log('Products:', productCount);
    console.log('Orders:', orderCount);
    console.log('Listing Fees:', feeCount);
    
  } catch (error) {
    console.error('Error checking seller data:', error);
  }
};

/* ==== BUYER LOGIC ==== */
// ============================================================
// dashboard-buyer.js — Buyer dashboard logic
// Used on: dashboard-buyer.html
// ============================================================

// ============================================================
// ORDER DETAILS MODAL FUNCTION
// ============================================================


// ---- TAB SWITCHING ----
document.querySelectorAll('.dash-nav-link').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const tab = link.dataset.tab;
    console.log('[buyer] Tab clicked:', tab);
    document.querySelectorAll('.dash-nav-link').forEach(l => l.classList.remove('active'));
    document.querySelectorAll('.dash-tab').forEach(t => t.classList.remove('active'));
    link.classList.add('active');
    const tabEl = document.getElementById(`tab-${tab}`);
    if (tabEl) tabEl.classList.add('active');
    const titleEl = document.getElementById('dashPageTitle');
    if (titleEl) titleEl.textContent = link.textContent.trim();
    
    if (tab === 'orders')   loadBuyerOrders();
    if (tab === 'addresses') loadBuyerAddresses();
    if (tab === 'messages') {
      console.log('[buyer] Messages tab activated, calling loadBuyerMessages()');
      // Small delay to ensure DOM is ready
      setTimeout(() => {
        loadBuyerMessages();
      }, 100);
    }
  });
});

// ---- OVERVIEW STATS ----

// ---- RECENT ORDERS PREVIEW GRID ----
function recentOrderItemHTML(o) {
  const orderId = o.id || o.order_id || o.uuid || o.product_id;
  const productName = o.products?.name || 'Product';
  const productImage = o.products?.image_url || '';
  const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';

  const statusBadgeClass = {
    pending: 'pending',
    confirmed: 'confirmed',
    shipped: 'shipped',
    delivered: 'delivered',
    cancelled: 'cancelled'
  }[o.status] || 'pending';

  return `
    <div class="recent-order-item" data-order-id="${orderId}">
      <div class="recent-order-image-container">
        <img src="${productImage || 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22200%22 height=%22200%22%3E%3Crect fill=%22%23f5f5f5%22 width=%22200%22 height=%22200%22/%3E%3C/svg%3E'}" 
             alt="${productName}" 
             class="recent-order-image"
             onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22200%22 height=%22200%22%3E%3Crect fill=%22%23f5f5f5%22 width=%22200%22 height=%22200%22/%3E%3C/svg%3E'">
        <span class="recent-order-status-badge ${statusBadgeClass}">${o.status.replace(/_/g, ' ')}</span>
      </div>
      <div class="recent-order-content">
        <div class="recent-order-name">${productName}</div>
        <div class="recent-order-price">₱${parseFloat(o.total_price || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
        <div class="recent-order-date">${formatDate(o.created_at)}</div>
        <div class="recent-order-actions">
          <button class="recent-order-btn recent-order-btn-receipt" onclick="openReceipt('${orderId}'); event.stopPropagation();" title="View Receipt">
            📄
          </button>
          <button class="recent-order-btn recent-order-btn-track" onclick="location.href='${prefix}order-tracking.html?id=${orderId}'; event.stopPropagation();" title="Track Order">
            🔍
          </button>
        </div>
      </div>
    </div>
  `;
}

// ---- ORDERS TAB ----

async function confirmReceipt(orderId) {
  if (!confirm('Confirm that you have received this order?')) return;
  
  try {
    // Try with received_at first (requires 06_buyer_flow.sql)
    let error;
    ({ error } = await db.from('orders').update({
      status: 'received',
      received_at: new Date().toISOString()
    }).eq('id', orderId));

    if (error?.message?.includes('received_at')) {
      ({ error } = await db.from('orders').update({ status: 'received' }).eq('id', orderId));
    }
    if (error) throw error;
      
    showSuccess('Receipt Confirmed!', 'Thank you for confirming your order receipt.', 'Got it');
    loadBuyerOrders();
    loadOverviewStats();
  } catch (error) {
    showError('Error', 'Could not confirm receipt. Please try again.');
    console.error('[buyer] confirmReceipt:', error);
  }
}

async function cancelOrder(orderId) {
  if (!confirm('Are you sure you want to cancel this order? This action cannot be undone.')) return;
  
  try {
    const { error } = await db.from('orders').update({
      status: 'cancelled',
      cancelled_at: new Date().toISOString()
    }).eq('id', orderId);
    
    if (error) throw error;
    
    showSuccess('Order Cancelled', 'Your order has been cancelled successfully.', 'Got it');
    loadBuyerOrders();
    loadOverviewStats();
  } catch (error) {
    showError('Error', 'Could not cancel order. Please try again.');
    console.error('[buyer] cancelOrder:', error);
  }
}

function openOrderChat(orderId, productName) {
  console.log('[buyer] Opening chat for order:', orderId, 'Product:', productName);
  
  // Switch to messages tab
  const messagesTab = document.querySelector('[data-tab="buyer-messages"]');
  if (messagesTab) {
    messagesTab.click();
    
    // Store the order context for the chat
    sessionStorage.setItem('orderChatContext', JSON.stringify({
      orderId: orderId,
      productName: productName,
      timestamp: new Date().toISOString()
    }));
    
    showSuccess('Chat Opened', `You can now discuss "${productName}" with the seller.`, 'Got it');
  } else {
    showError('Error', 'Could not open messages. Please try again.');
  }
}

// Load buyer overview stats
async function loadBuyerOverviewStats() {
  const currentUser = authManager.getCurrentUser();
  if (!currentUser) return;

  try {
    // Load buyer order statistics
    const { data: orders } = await db
      .from('orders')
      .select('id, status, total_price, created_at')
      .eq('buyer_id', currentUser.id);

    if (orders && orders.length > 0) {
      // Calculate stats
      const totalOrders = orders.length;
      const totalSpent = orders.reduce((sum, o) => sum + (parseFloat(o.total_price) || 0), 0);
      const completedOrders = orders.filter(o => o.status === 'completed').length;

      // Update overview stats display if elements exist
      const totalOrdersEl = document.getElementById('buyerTotalOrders');
      const totalSpentEl = document.getElementById('buyerTotalSpent');
      const completedEl = document.getElementById('buyerCompletedOrders');

      if (totalOrdersEl) totalOrdersEl.textContent = totalOrders;
      if (totalSpentEl) totalSpentEl.textContent = '₱' + totalSpent.toFixed(2);
      if (completedEl) completedEl.textContent = completedOrders;
    }
  } catch (error) {
    console.warn('[buyer] Could not load overview stats:', error.message);
  }
}

async function loadBuyerOrders() {
  const currentUser = authManager.getCurrentUser();
  if (!currentUser) return;

  const list = document.getElementById('buyerOrdersList');
  if (!list) return;
  list.innerHTML = '<p class="dash-empty">Loading…</p>';

  const statusFilter = document.getElementById('orderStatusFilter')?.value || 'all';
  let query = db
    .from('orders')
    .select('*,products(id,name,image_url)')
    .eq('buyer_email', currentUser.email)
    .order('created_at', { ascending: false });

  if (statusFilter !== 'all') {
    query = query.eq('status', statusFilter);
  }

  try {
    const { data, error } = await query;
    if (error) throw error;

    console.log('[buyer] Orders loaded:', data?.length || 0, 'orders');
    console.log('[buyer] First order object:', data?.[0]);
    console.log('[buyer] First order keys:', Object.keys(data?.[0] || {}));

    list.innerHTML = data?.length 
      ? data.map(o => orderRowHTML(o)).join('') 
      : '<p class="dash-empty">No orders found.</p>';

    // Add event listeners to order rows
    document.querySelectorAll('.dash-order-row').forEach(row => {
      const orderId = row.getAttribute('data-order-id');
      console.log('[buyer] Setting up click listener for order:', orderId);
      row.addEventListener('click', function(e) {
        // Don't trigger if clicking on buttons or links
        if (e.target.closest('button, a')) {
          console.log('[buyer] Click on button/link, ignoring');
          return;
        }
        const orderId = this.getAttribute('data-order-id');
        console.log('[buyer] Order row clicked - orderId:', orderId, 'Type:', typeof orderId);
        if (orderId && orderId !== 'null' && orderId !== '') {
          console.log('[buyer] Opening modal for order:', orderId);
          openOrderDetailsModal(orderId);
        } else {
          console.error('[buyer] Invalid orderId:', orderId);
        }
      });
    });

    // Update badge in sidebar
    const badge = document.getElementById('buyerOrdersCount');
    if (badge && data?.length > 0) {
      badge.textContent = data.length > 99 ? '99+' : data.length;
      badge.style.display = 'inline-block';
    } else if (badge) {
      badge.style.display = 'none';
    }

    // Also call the dashboard badge update function if it exists
    if (typeof updateBuyerOrdersBadge === 'function') {
      updateBuyerOrdersBadge();
    }
    
    // Check if we need to auto-open a specific order (from order confirmation page)
    const openOrderId = sessionStorage.getItem('openOrderDetails');
    if (openOrderId && data && data.length > 0) {
      console.log('[buyer] Auto-opening order from confirmation:', openOrderId);
      // Clear the flag
      sessionStorage.removeItem('openOrderDetails');
      // Wait a bit for the DOM to be ready, then open the modal
      setTimeout(() => {
        openOrderDetailsModal(openOrderId);
      }, 500);
    }

  } catch (error) {
    list.innerHTML = '<p class="dash-empty">Could not load orders.</p>';
    console.error('[buyer] loadBuyerOrders:', error.message);
    console.error('[buyer] Full error:', error);
  }
}

document.getElementById('orderStatusFilter')?.addEventListener('change', loadBuyerOrders);

// ---- PROFILE MANAGEMENT ----
async function loadBuyerProfile() {
  const currentUser = authManager.getCurrentUser();
  if (!currentUser) return;

  try {
    console.log('[buyer] Loading profile for user:', currentUser.email);

    // Populate form fields with current user data
    const nameField = document.getElementById('buyerName');
    const emailField = document.getElementById('buyerEmail');
    const phoneField = document.getElementById('buyerPhone');

    if (nameField) nameField.value = currentUser.name || '';
    if (emailField) emailField.value = currentUser.email || '';
    if (phoneField) phoneField.value = ''; // Phone not stored in local auth

    console.log('[buyer] Profile loaded successfully');

  } catch (error) {
    console.error('[buyer] loadBuyerProfile:', error.message);
  }
}

// ---- PROFILE FORM ----
document.getElementById('buyerProfileForm')?.addEventListener('submit', async e => {
  e.preventDefault();
  
  const currentUser = authManager.getCurrentUser();
  if (!currentUser) return;

  const payload = {
    name: document.getElementById('buyerName').value.trim(),
    phone: document.getElementById('buyerPhone').value.trim()
  };

  // Validation
  if (!payload.name || payload.name.length < 2) {
    showError('Validation Error', 'Name must be at least 2 characters');
    return;
  }

  if (payload.phone && !validators.phone(payload.phone)) {
    showError('Validation Error', validationMessages.phone);
    return;
  }

  showLoadingModal('Saving…', 'Updating your profile.');

  try {
    // Update local auth user data
    const users = JSON.parse(localStorage.getItem('rewear_users') || '[]');
    const userIndex = users.findIndex(u => u.id === currentUser.id);
    
    if (userIndex !== -1) {
      users[userIndex].name = payload.name;
      localStorage.setItem('rewear_users', JSON.stringify(users));
      
      // Update current user session
      currentUser.name = payload.name;
      localStorage.setItem('rewear_current_user', JSON.stringify(currentUser));
    }

    hideLoadingModal();
    showSuccess('Profile Updated!', 'Your profile has been saved successfully.', 'Got it');

    console.log('[buyer] Profile updated successfully');

  } catch (error) {
    hideLoadingModal();
    showError('Save Failed', error.message);
    console.error('[buyer] saveProfile:', error.message);
  }
});

// ---- ADDRESSES MANAGEMENT ----
async function loadBuyerAddresses() {
  const currentUser = authManager.getCurrentUser();
  if (!currentUser) return;

  const list = document.getElementById('addressesList');
  if (!list) return;

  list.innerHTML = '<p class="dash-empty">Address management coming soon...</p>';

  // Note: Address functionality is not implemented in the current database schema
  console.log('[buyer] Address management not implemented yet');
}

// ---- ADDRESS ACTIONS ----
async function editAddress(addressId) {
  // Open address editing modal
  const currentUser = window.authManager?.getCurrentUser();
  if (!currentUser) return;
  
  try {
    // Fetch the address
    const { data: address, error } = await window.db
      .from('buyer_addresses')
      .select('*')
      .eq('id', addressId)
      .eq('buyer_email', currentUser.email)
      .single();
    
    if (error || !address) {
      showError('Not Found', 'Address not found.');
      return;
    }
    
    // Create edit modal
    const overlay = document.createElement('div');
    overlay.id = 'editAddressOverlay';
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;';
    
    overlay.innerHTML = `
      <div style="background:#fff;border-radius:16px;padding:28px;max-width:440px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,0.3);">
        <h3 style="margin:0 0 4px;font-size:18px;">Edit Address</h3>
        <p style="color:#888;font-size:13px;margin:0 0 20px;">Update your delivery address</p>
        
        <div style="margin-bottom:12px;">
          <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Full Name</label>
          <input id="editAddrName" type="text" value="${address.full_name || ''}" placeholder="Full name"
            style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
        </div>
        
        <div style="margin-bottom:12px;">
          <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Phone</label>
          <input id="editAddrPhone" type="tel" value="${address.phone || ''}" placeholder="+63 XXX XXX XXXX"
            style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
        </div>
        
        <div style="margin-bottom:12px;">
          <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Street Address</label>
          <input id="editAddrStreet" type="text" value="${address.street || ''}" placeholder="Street address"
            style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
        </div>
        
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
          <div>
            <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">City</label>
            <input id="editAddrCity" type="text" value="${address.city || ''}" placeholder="City"
              style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
          </div>
          <div>
            <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Postal Code</label>
            <input id="editAddrZip" type="text" value="${address.postal_code || ''}" placeholder="Postal code"
              style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
          </div>
        </div>
        
        <div style="display:flex;gap:10px;">
          <button onclick="saveEditedAddress('${addressId}')"
            style="flex:1;padding:12px;background:#1a1a2e;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:700;cursor:pointer;">
            Save Changes
          </button>
          <button onclick="document.getElementById('editAddressOverlay').remove()"
            style="padding:12px 18px;background:#f5f5f5;color:#333;border:none;border-radius:8px;font-size:14px;cursor:pointer;">
            Cancel
          </button>
        </div>
      </div>`;
    
    document.body.appendChild(overlay);
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
    
  } catch (err) {
    console.error('[editAddress]', err);
    showError('Error', 'Could not load address.');
  }
}

async function saveEditedAddress(addressId) {
  const name = document.getElementById('editAddrName')?.value.trim();
  const phone = document.getElementById('editAddrPhone')?.value.trim();
  const street = document.getElementById('editAddrStreet')?.value.trim();
  const city = document.getElementById('editAddrCity')?.value.trim();
  const zip = document.getElementById('editAddrZip')?.value.trim();
  
  if (!name || !phone || !street || !city || !zip) {
    showError('Missing Fields', 'Please fill in all address fields.');
    return;
  }
  
  try {
    showLoadingModal('Saving…', 'Updating your address.');
    
    const { error } = await window.db
      .from('buyer_addresses')
      .update({
        full_name: name,
        phone,
        street,
        city,
        postal_code: zip,
        updated_at: new Date().toISOString()
      })
      .eq('id', addressId);
    
    if (error) throw error;
    
    hideLoadingModal();
    document.getElementById('editAddressOverlay')?.remove();
    showSuccess('Address Updated', 'Your address has been saved.', 'Got it');
    loadBuyerAddresses();
    
  } catch (err) {
    hideLoadingModal();
    console.error('[saveEditedAddress]', err);
    showError('Save Failed', 'Could not save address.');
  }
}

async function deleteAddress(addressId) {
  if (!confirm('Are you sure you want to delete this address?')) return;

  showLoadingModal('Deleting…', 'Removing address.');

  try {
    const { error } = await db
      .from('buyer_addresses')
      .delete()
      .eq('id', addressId);

    if (error) throw error;

    hideLoadingModal();
    showSuccess('Address Deleted', 'The address has been removed.', 'Got it');
    loadBuyerAddresses();

  } catch (error) {
    hideLoadingModal();
    showError('Delete Failed', error.message);
    console.error('[buyer] deleteAddress:', error.message);
  }
}

document.getElementById('addAddressBtn')?.addEventListener('click', () => {
  // Open add address modal
  const currentUser = window.authManager?.getCurrentUser();
  if (!currentUser) return;
  
  const overlay = document.createElement('div');
  overlay.id = 'addAddressOverlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;';
  
  overlay.innerHTML = `
    <div style="background:#fff;border-radius:16px;padding:28px;max-width:440px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,0.3);">
      <h3 style="margin:0 0 4px;font-size:18px;">Add New Address</h3>
      <p style="color:#888;font-size:13px;margin:0 0 20px;">Add a new delivery address</p>
      
      <div style="margin-bottom:12px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Full Name</label>
        <input id="newAddrName" type="text" placeholder="Full name"
          style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
      </div>
      
      <div style="margin-bottom:12px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Phone</label>
        <input id="newAddrPhone" type="tel" placeholder="+63 XXX XXX XXXX"
          style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
      </div>
      
      <div style="margin-bottom:12px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Street Address</label>
        <input id="newAddrStreet" type="text" placeholder="Street address"
          style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
      </div>
      
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
        <div>
          <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">City</label>
          <input id="newAddrCity" type="text" placeholder="City"
            style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
        </div>
        <div>
          <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Postal Code</label>
          <input id="newAddrZip" type="text" placeholder="Postal code"
            style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
        </div>
      </div>
      
      <div style="display:flex;gap:10px;">
        <button onclick="saveNewAddress()"
          style="flex:1;padding:12px;background:#1a1a2e;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:700;cursor:pointer;">
          Add Address
        </button>
        <button onclick="document.getElementById('addAddressOverlay').remove()"
          style="padding:12px 18px;background:#f5f5f5;color:#333;border:none;border-radius:8px;font-size:14px;cursor:pointer;">
          Cancel
        </button>
      </div>
    </div>`;
  
  document.body.appendChild(overlay);
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
});

async function saveNewAddress() {
  const currentUser = window.authManager?.getCurrentUser();
  if (!currentUser) return;
  
  const name = document.getElementById('newAddrName')?.value.trim();
  const phone = document.getElementById('newAddrPhone')?.value.trim();
  const street = document.getElementById('newAddrStreet')?.value.trim();
  const city = document.getElementById('newAddrCity')?.value.trim();
  const zip = document.getElementById('newAddrZip')?.value.trim();
  
  if (!name || !phone || !street || !city || !zip) {
    showError('Missing Fields', 'Please fill in all address fields.');
    return;
  }
  
  try {
    showLoadingModal('Adding…', 'Creating new address.');
    
    const { error } = await window.db
      .from('buyer_addresses')
      .insert({
        buyer_email: currentUser.email,
        full_name: name,
        phone,
        street,
        city,
        postal_code: zip,
        is_default: false,
        created_at: new Date().toISOString()
      });
    
    if (error) throw error;
    
    hideLoadingModal();
    document.getElementById('addAddressOverlay')?.remove();
    showSuccess('Address Added', 'Your new address has been saved.', 'Got it');
    loadBuyerAddresses();
    
  } catch (err) {
    hideLoadingModal();
    console.error('[saveNewAddress]', err);
    showError('Add Failed', 'Could not add address.');
  }
}

// ---- MESSAGES / CHAT TAB ----
let activeChatId = null; // currently open message thread id

/**
 * Create initial message to seller when clicking chat for the first time
 */
async function createInitialMessage(chatInfo) {
  try {
    const currentUser = authManager.getCurrentUser();
    if (!currentUser) {
      console.error('[createInitialMessage] No current user');
      return;
    }

    console.log('[createInitialMessage] Creating initial message for:', chatInfo);

    // Get order details to include in message
    let orderRef = chatInfo.orderId ? chatInfo.orderId.substring(0, 8).toUpperCase() : 'N/A';
    
    // Create initial message
    const initialMessage = `Hi! I have a question about my order ${orderRef}. Looking forward to hearing from you!`;

    const messageData = {
      seller_id: chatInfo.sellerId,
      buyer_email: currentUser.email,
      buyer_name: currentUser.name || currentUser.email.split('@')[0],
      message: initialMessage,
      accepted: false,
      rejected: false,
      is_read: false,
      thread: []
    };

    console.log('[createInitialMessage] Inserting message:', messageData);

    const { data: newMessage, error } = await messagesDb
      .from('messages')
      .insert([messageData])
      .select()
      .single();

    if (error) {
      console.error('[createInitialMessage] Error creating message:', error);
      showError('Chat Error', 'Could not create conversation. Please try again.');
      return;
    }

    console.log('[createInitialMessage] ✅ Message created successfully:', newMessage.id);
    
    // Show success notification
    showSuccess('Chat Started!', 'Your conversation with the seller has been created. You can now send messages.', 'Got it');

    return newMessage;

  } catch (error) {
    console.error('[createInitialMessage] Exception:', error);
    showError('Chat Error', 'Could not create conversation. Please try again.');
  }
}

async function loadBuyerMessages() {
  const currentUser = authManager.getCurrentUser();
  console.log('[buyer] loadBuyerMessages: Current user:', currentUser);
  
  if (!currentUser) {
    console.error('[buyer] loadBuyerMessages: No current user found');
    return;
  }

  const convList = document.getElementById('chatConvList');
  if (!convList) {
    console.error('[buyer] loadBuyerMessages: chatConvList element not found');
    return;
  }
  
  // Show skeleton loaders while loading
  convList.innerHTML = `
    ${Array(3).fill(0).map(() => `
      <div class="chat-skeleton-item">
        <div class="chat-skeleton-avatar skeleton"></div>
        <div class="chat-skeleton-info">
          <div class="chat-skeleton-name skeleton"></div>
          <div class="chat-skeleton-preview skeleton"></div>
        </div>
        <div class="chat-skeleton-time skeleton"></div>
      </div>
    `).join('')}
  `;

  // Check if messagesDb is available
  if (typeof messagesDb === 'undefined' || !messagesDb) {
    console.error('[buyer] loadBuyerMessages: messagesDb is not defined!');
    convList.innerHTML = '<p class="dash-empty" style="padding:20px;color:#e74c3c;">Message system not initialized. Please refresh the page.</p>';
    return;
  }

  try {
    console.log('[buyer] loadBuyerMessages: Querying messages for email:', currentUser.email);
    
    // Use messagesDb for messages (separate Supabase project)
    // Note: products and sellers tables don't exist in messages DB, so we can't join
    const { data, error } = await messagesDb
      .from('messages')
      .select('*')
      .eq('buyer_email', currentUser.email)
      .order('created_at', { ascending: false });

    console.log('[buyer] loadBuyerMessages: Query result -', data?.length || 0, 'messages found');

    if (error) {
      console.error('[buyer] loadBuyerMessages: Database error:', error);
      throw error;
    }

    if (!data?.length) {
      console.log('[buyer] loadBuyerMessages: No messages found');
      convList.innerHTML = '<p class="dash-empty" style="padding:20px;font-size:13px;">No conversations yet.<br>Click <strong>+ New</strong> to message a seller.</p>';
      return;
    }

    console.log('[buyer] loadBuyerMessages: Found', data.length, 'messages');

    convList.innerHTML = data.map(m => {
      // Use seller_id directly since we can't join with sellers table
      const sellerName  = m.seller_id ? `Seller ${m.seller_id.substring(0, 8)}` : 'Seller';
      const lastMsg     = m.reply || m.message;
      const isUnread    = m.reply && !m.is_read;
      const initial     = 'S'; // S for Seller
      const time        = formatChatTime(m.reply ? m.replied_at : m.created_at);
      
      // Status indicator
      let statusBadge = '';
      if (m.rejected) {
        statusBadge = '<span style="font-size:11px;color:#e74c3c;font-weight:600;">✕ Rejected</span>';
      } else if (m.reply) {
        statusBadge = '<span style="font-size:11px;color:#27ae60;font-weight:600;">✓ Replied</span>';
      } else if (m.accepted) {
        statusBadge = '<span style="font-size:11px;color:#3498db;font-weight:600;">✓ Accepted</span>';
      } else {
        statusBadge = '<span style="font-size:11px;color:#c8a96e;font-weight:600;">⏳ Pending</span>';
      }

      return `
        <div class="chat-conv-item ${isUnread ? 'unread' : ''} ${activeChatId === m.id ? 'active' : ''}"
             onclick="openChat('${m.id}')" data-msg-id="${m.id}">
          <div class="chat-conv-avatar">${initial}</div>
          <div class="chat-conv-info">
            <div class="chat-conv-name">${sellerName}</div>
            <div class="chat-conv-preview">${lastMsg.length > 40 ? lastMsg.slice(0,40)+'…' : lastMsg}</div>
            <div style="margin-top:4px;">${statusBadge}</div>
          </div>
          <div class="chat-conv-time">${time}</div>
          ${isUnread ? '<div class="chat-unread-dot"></div>' : ''}
        </div>`;
    }).join('');

    console.log('[buyer] loadBuyerMessages: Messages rendered successfully');

    // Check if we need to auto-open a specific conversation (from order tracking chat button)
    const openChatWithData = sessionStorage.getItem('openChatWith');
    if (openChatWithData) {
      try {
        const chatInfo = JSON.parse(openChatWithData);
        console.log('[buyer] Auto-opening chat with:', chatInfo);
        
        if (chatInfo.type === 'buyer-to-seller' && chatInfo.sellerId) {
          // Find the message with this seller
          const matchingMsg = data.find(m => m.seller_id === chatInfo.sellerId);
          if (matchingMsg) {
            console.log('[buyer] Found matching conversation:', matchingMsg.id);
            console.log('[buyer] Calling openChat with message ID:', matchingMsg.id);
            
            // Clear the flag BEFORE opening to prevent loops
            sessionStorage.removeItem('openChatWith');
            
            // Wait a bit for DOM to be ready, then open the chat
            setTimeout(() => {
              console.log('[buyer] Opening chat after delay...');
              openChat(matchingMsg.id, data);
            }, 300);
          } else {
            console.log('[buyer] No existing conversation found with seller:', chatInfo.sellerId);
            console.log('[buyer] Creating initial message automatically...');
            
            // Clear the flag BEFORE creating to prevent loops
            sessionStorage.removeItem('openChatWith');
            
            // Auto-create initial message
            const newMessage = await createInitialMessage(chatInfo);
            
            if (newMessage) {
              // Reload messages to show the new conversation
              console.log('[buyer] Reloading messages after creating initial message...');
              setTimeout(() => {
                loadBuyerMessages();
              }, 1000);
            }
          }
        }
      } catch (e) {
        console.error('[buyer] Error parsing openChatWith data:', e);
        sessionStorage.removeItem('openChatWith');
      }
    }
    // Re-open active chat if one was selected (and no auto-open happened)
    else if (activeChatId) {
      openChat(activeChatId, data);
    }
    
    // Start video call polling to detect incoming calls
    console.log('[buyer] Starting video call polling for incoming calls');
    vcStartPolling();

  } catch (err) {
    convList.innerHTML = '<p class="dash-empty" style="padding:20px;">Could not load messages.</p>';
    console.error('[buyer] loadBuyerMessages: Exception:', err);
  }
}


async function openChat(msgId, cachedData) {
  console.log('[buyer] openChat called with msgId:', msgId);
  activeChatId = msgId;

  document.querySelectorAll('.chat-conv-item').forEach(el => {
    el.classList.toggle('active', el.dataset.msgId === msgId);
  });

  const emptyState = document.getElementById('chatEmptyState');
  const chatActive = document.getElementById('chatActive');
  
  console.log('[buyer] openChat - emptyState:', emptyState);
  console.log('[buyer] openChat - chatActive:', chatActive);
  
  if (emptyState) emptyState.style.display = 'none';
  if (chatActive) chatActive.style.display = 'flex';
  
  // Start video call polling when chat is opened
  console.log('[buyer] Starting video call polling for incoming calls');
  vcStartPolling();

  // Always fetch fresh data
  console.log('[buyer] openChat - Fetching message:', msgId);
  const { data: msg, error } = await messagesDb
    .from('messages')
    .select('*')
    .eq('id', msgId)
    .single();

  if (error) {
    console.error('[buyer] openChat - Error fetching message:', error);
    return;
  }

  if (!msg) {
    console.error('[buyer] openChat - No message found for ID:', msgId);
    return;
  }

  console.log('[buyer] openChat - Message loaded:', msg);

  const currentUser = authManager.getCurrentUser();
  const sellerName = msg.seller_id ? `Seller ${msg.seller_id.substring(0, 8)}` : 'Seller';

// Expose openChat globally so onclick handlers can access it
window.openChat = openChat;

  // Header — Messenger style with PC + VC buttons
  const header = document.getElementById('chatWindowHeader');
  if (header) {
    header.className = 'messenger-header';
    header.innerHTML = `
      <div class="messenger-header-left">
        <div class="messenger-avatar">${sellerName.charAt(0).toUpperCase()}</div>
        <div class="messenger-info">
          <span class="messenger-name" id="buyerChatName">${sellerName}</span>
          <span class="messenger-status">Active now</span>
        </div>
      </div>
      <div class="messenger-header-actions">
        <button class="messenger-action-btn" title="Phone Call" onclick="buyerStartVoiceCall()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" width="16" height="16">
            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.4 2 2 0 0 1 3.6 1.22h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.82a16 16 0 0 0 6.29 6.29l.96-.96a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z" stroke-width="2"/>
          </svg>
          <span style="font-size:11px;font-weight:700;">PC</span>
        </button>
        <button class="messenger-action-btn messenger-video-btn" title="Video Call" onclick="buyerStartVideoCall()">
          <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16">
            <path d="M15 10l4.553-2.276A1 1 0 0 1 21 8.723v6.554a1 1 0 0 1-1.447.894L15 14v-4zM3 8a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8z"/>
          </svg>
          <span style="font-size:11px;font-weight:700;">VC</span>
        </button>
      </div>`;
  }

  // Build thread from: original message + thread array
  const messagesEl = document.getElementById('chatMessages');
  if (messagesEl) {
    const bubbles = [];

    // First message (buyer's original)
    bubbles.push(`
      <div class="chat-bubble-wrap from-buyer">
        <div class="chat-bubble">${msg.message}</div>
        <div class="chat-bubble-meta">${formatChatTime(msg.created_at)}</div>
      </div>`);

    // Thread messages (subsequent back-and-forth)
    const thread = Array.isArray(msg.thread) ? msg.thread : [];
    thread.forEach(entry => {
      const isBuyer = entry.role === 'buyer';
      
      // Special: video call invite from seller
      if (entry.type === 'video_call' && entry.roomId) {
        const buyerName = encodeURIComponent(authManager.getCurrentUser()?.name || authManager.getCurrentUser()?.email || 'Buyer');
        bubbles.push(`
          <div class="chat-bubble-wrap from-seller">
            <div class="chat-bubble" style="background:#1a1a2e;color:#fff;padding:14px 16px;">
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
                <span style="font-size:24px;">📹</span>
                <div>
                  <div style="font-weight:700;font-size:14px;">Video Call Invite</div>
                  <div style="font-size:12px;color:#c8a96e;">Room: ${entry.roomId}</div>
                </div>
              </div>
              <a href="peer.html?room=${entry.roomId}&mode=join&name=${buyerName}" target="_blank"
                 style="display:block;text-align:center;background:#c8a96e;color:#fff;padding:10px;border-radius:8px;font-weight:700;font-size:14px;text-decoration:none;">
                📹 Join Video Call
              </a>
            </div>
            <div class="chat-bubble-meta">${sellerName} · ${formatChatTime(entry.ts)}</div>
          </div>`);
        return;
      }

      bubbles.push(`
        <div class="chat-bubble-wrap ${isBuyer ? 'from-buyer' : 'from-seller'}">
          <div class="chat-bubble">${entry.text}</div>
          <div class="chat-bubble-meta">${isBuyer ? 'You' : sellerName} · ${formatChatTime(entry.ts)}</div>
        </div>`);
    });

    // If no thread yet but has old-style reply, show it
    if (thread.length === 0 && msg.reply) {
      bubbles.push(`
        <div class="chat-bubble-wrap from-seller">
          <div class="chat-bubble">${msg.reply}</div>
          <div class="chat-bubble-meta">${sellerName} · ${formatChatTime(msg.replied_at)}</div>
        </div>`);
    }

    messagesEl.innerHTML = bubbles.join('');
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  // Input bar — hide only if not accepted
  const inputBar = document.querySelector('.chat-input-bar');
  document.getElementById('chatAcceptanceHint')?.remove();

  if (inputBar) {
    if (!msg.accepted) {
      inputBar.style.display = 'none';
      const hintEl = document.createElement('p');
      hintEl.id = 'chatAcceptanceHint';
      hintEl.style.cssText = 'text-align:center;padding:16px;font-size:13px;color:#c8a96e;border-top:1px solid #eee;background:#fffbf0;font-weight:600;margin:0;';
      hintEl.textContent = '⏳ Waiting for seller to accept your message...';
      document.getElementById('chatActive').appendChild(hintEl);
    } else {
      inputBar.style.display = 'flex';
    }
  }

  // Mark as read
  if (!msg.is_read) {
    messagesDb.from('messages').update({ is_read: true }).eq('id', msgId);
  }
}

async function sendChatMessage() {
  console.log('[buyer] sendChatMessage called, activeChatId:', activeChatId);
  const input = document.getElementById('chatInput');
  const text  = input?.value.trim();
  
  console.log('[buyer] sendChatMessage - text:', text);
  
  if (!text || !activeChatId) {
    console.warn('[buyer] sendChatMessage - Missing text or activeChatId');
    return;
  }

  const currentUser = authManager.getCurrentUser();
  if (!currentUser) {
    console.error('[buyer] sendChatMessage - No current user');
    return;
  }

  try {
    console.log('[buyer] sendChatMessage - Fetching current thread for:', activeChatId);
    // Fetch current thread
    const { data: msg } = await messagesDb
      .from('messages')
      .select('thread')
      .eq('id', activeChatId)
      .single();

    const thread = Array.isArray(msg?.thread) ? msg.thread : [];
    console.log('[buyer] sendChatMessage - Current thread length:', thread.length);
    
    thread.push({ role: 'buyer', text, ts: new Date().toISOString() });
    console.log('[buyer] sendChatMessage - New thread length:', thread.length);

    const { error } = await messagesDb
      .from('messages')
      .update({ thread })
      .eq('id', activeChatId);

    if (error) throw error;
    
    console.log('[buyer] sendChatMessage - Message sent successfully');
    input.value = '';
    
    // Refresh chat view immediately to show the new message
    await openChat(activeChatId);
    
    // Also refresh the conversation list to update preview
    loadBuyerMessages();
  } catch (err) {
    console.error('[chat] sendChatMessage:', err);
    showError('Error', 'Could not send message.');
  }
}

// Expose globally
window.sendChatMessage = sendChatMessage;

window.openNewInquiryModal = function() {
  // Remove existing overlay if any
  document.getElementById('newInquiryOverlay')?.remove();

  const currentUser = authManager.getCurrentUser();
  const overlay = document.createElement('div');
  overlay.id = 'newInquiryOverlay';
  overlay.className = 'new-inquiry-overlay';
  overlay.innerHTML = `
    <div style="background:#fff;border-radius:16px;padding:32px;max-width:460px;width:90%;box-shadow:0 8px 32px rgba(0,0,0,0.2);">
      <h3 style="margin:0 0 4px;font-size:18px;">New Message</h3>
      <p style="color:#888;font-size:13px;margin:0 0 20px;">Send an inquiry to a seller about a product</p>

      <div style="margin-bottom:12px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Seller Name / Shop</label>
        <input id="niSellerSearch" type="text" placeholder="Search seller by name…"
          style="width:100%;padding:10px 12px;border:1px solid #ddd;border-radius:8px;font-size:14px;box-sizing:border-box;"
          oninput="searchSellersForInquiry(this.value)">
        <div id="niSellerResults" style="border:1px solid #eee;border-radius:8px;margin-top:4px;max-height:140px;overflow-y:auto;display:none;"></div>
        <input type="hidden" id="niSellerId">
        <div id="niSellerChosen" style="display:none;margin-top:6px;padding:8px 12px;background:#fdf8f0;border-radius:8px;font-size:13px;font-weight:600;color:#c8a96e;"></div>
      </div>

      <div style="margin-bottom:12px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Product (optional)</label>
        <input id="niProduct" type="text" placeholder="Which product are you asking about?"
          style="width:100%;padding:10px 12px;border:1px solid #ddd;border-radius:8px;font-size:14px;box-sizing:border-box;">
      </div>

      <div style="margin-bottom:20px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Message</label>
        <textarea id="niMessage" rows="4" placeholder="Ask about sizing, availability, condition…"
          style="width:100%;padding:10px 12px;border:1px solid #ddd;border-radius:8px;font-size:14px;resize:vertical;box-sizing:border-box;"></textarea>
      </div>

      <div style="display:flex;gap:12px;">
        <button onclick="submitNewInquiry()"
          style="flex:1;padding:12px;background:#c8a96e;color:#fff;border:none;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;">
          Send Message
        </button>
        <button onclick="document.getElementById('newInquiryOverlay').remove()"
          style="padding:12px 20px;background:#f5f5f5;color:#333;border:none;border-radius:8px;font-size:15px;cursor:pointer;">
          Cancel
        </button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
};

let _sellerSearchTimer;
window.searchSellersForInquiry = function(query) {
  clearTimeout(_sellerSearchTimer);
  const results = document.getElementById('niSellerResults');
  if (!query || query.length < 2) { results.style.display = 'none'; return; }

  _sellerSearchTimer = setTimeout(async () => {
    const { data } = await db
      .from('sellers')
      .select('id, business_name')
      .ilike('business_name', `%${query}%`)
      .eq('verified', true)
      .limit(6);

    if (!data?.length) {
      results.innerHTML = '<p style="padding:10px;font-size:13px;color:#aaa;">No sellers found.</p>';
      results.style.display = 'block';
      return;
    }

    results.style.display = 'block';
    results.innerHTML = data.map(s => `
      <div onclick="selectSellerForInquiry('${s.id}','${s.business_name.replace(/'/g,"\\'")}') "
        style="padding:10px 14px;cursor:pointer;font-size:14px;border-bottom:1px solid #f5f5f5;"
        onmouseover="this.style.background='#fdf8f0'" onmouseout="this.style.background=''">
        ${s.business_name}
      </div>`).join('');
  }, 300);
};

window.selectSellerForInquiry = function(id, name) {
  document.getElementById('niSellerId').value = id;
  document.getElementById('niSellerSearch').value = name;
  document.getElementById('niSellerResults').style.display = 'none';
  const chosen = document.getElementById('niSellerChosen');
  chosen.textContent = '✓ ' + name;
  chosen.style.display = 'block';
};

window.submitNewInquiry = async function() {
  const sellerId = document.getElementById('niSellerId')?.value;
  const product  = document.getElementById('niProduct')?.value.trim();
  const message  = document.getElementById('niMessage')?.value.trim();
  const currentUser = authManager.getCurrentUser();

  if (!sellerId) { alert('Please select a seller.'); return; }
  if (!message)  { alert('Please enter a message.'); return; }
  if (!currentUser) { alert('Please log in first.'); return; }

  // Check if ChatRouter is available
  if (typeof ChatRouter === 'undefined' || !ChatRouter) {
    console.error('[submitNewInquiry] ChatRouter not available');
    alert('Chat system not initialized. Please refresh the page.');
    return;
  }

  try {
    console.log('[submitNewInquiry] Routing message via ChatRouter:', {
      seller: sellerId,
      buyer: currentUser.email,
      source: 'dashboard'
    });
    
    // Use centralized ChatRouter to send message
    // This ensures the message goes to the SAME conversation if buyer has already chatted with this seller
    const result = await ChatRouter.sendMessage({
      sellerId: sellerId,
      buyerEmail: currentUser.email,
      buyerName: currentUser.name || currentUser.email,
      message: message,
      productId: product && product !== 'undefined' ? product : null,
      source: 'dashboard' // Track that message came from dashboard
    });

    if (!result.success) {
      throw new Error(result.error || 'Failed to send message');
    }

    console.log('[submitNewInquiry] ✓ Message routed successfully:', result);

    document.getElementById('newInquiryOverlay')?.remove();
    
    // Refresh messages list to show the new/updated conversation
    await loadBuyerMessages();
    
    // Auto-open the conversation to show the sent message
    if (result.conversationId) {
      console.log('[submitNewInquiry] Auto-opening conversation:', result.conversationId);
      // Switch to messages tab
      switchTab('buyer-messages');
      // Small delay to ensure messages are loaded
      setTimeout(() => {
        openChat(result.conversationId);
      }, 300);
    }
    
    showSuccess('Message Sent!', 'Your inquiry has been sent to the seller.', 'Got it');
  } catch (err) {
    console.error('[submitNewInquiry] ✗ Exception:', err);
    alert('Could not send message: ' + err.message);
  }
};

// ---- INIT ----
document.addEventListener('DOMContentLoaded', () => {
  loadOverviewStats();
});

// ---- REAL-TIME SUBSCRIPTIONS ----
// Auto-update messages, orders without needing to refresh
function startRealtimeUpdates() {
  const currentUser = authManager?.getCurrentUser();
  if (!currentUser) return;

  // Real-time: messages updates (seller accepted, replied, etc.)
  messagesDb
    .channel('buyer-messages-realtime')
    .on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'messages',
      filter: `buyer_email=eq.${currentUser.email}`
    }, (payload) => {
      console.log('[realtime] Message updated:', payload);
      // Refresh conversation list
      loadBuyerMessages();
      // If this message is currently open, refresh the chat view too
      if (activeChatId === payload.new?.id) {
        openChat(activeChatId);
      }
    })
    .subscribe();

  // Real-time: orders updates (status changes)
  db
    .channel('buyer-orders-realtime')
    .on('postgres_changes', {
      event: 'UPDATE',
      schema: 'public',
      table: 'orders',
      filter: `buyer_email=eq.${currentUser.email}`
    }, (payload) => {
      console.log('[realtime] Order updated:', payload);
      loadBuyerOrders();
      loadOverviewStats();
    })
    .subscribe();

  console.log('[realtime] Buyer real-time subscriptions started');
}

// Start real-time after auth is ready
if (window.authManager?.isInitialized) {
  startRealtimeUpdates();
} else {
  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(startRealtimeUpdates, 1000);
  });
}


// ============================================================
// ORDER DETAILS MODAL
// ============================================================



// Close modal when clicking outside
document.addEventListener('click', function(event) {
  const modal = document.getElementById('orderDetailsModal');
  if (modal && event.target === modal) {
    modal.style.display = 'none';
  }
});


// ============================================================
// WISHLIST MANAGEMENT
// ============================================================

async function loadWishlist() {
  try {
    const currentUser = authManager.getCurrentUser();
    if (!currentUser) return;

    const { data: wishlistItems, error } = await db
      .from('wishlist')
      .select('*, products(id, name, price, image_url)')
      .eq('buyer_email', currentUser.email)
      .order('created_at', { ascending: false });

    if (error) throw error;

    const grid = document.getElementById('wishlistGrid');
    const badge = document.getElementById('wishlistBadge');

    if (!grid) return;

    if (wishlistItems && wishlistItems.length > 0) {
      // Update badge
      if (badge) {
        badge.textContent = wishlistItems.length > 99 ? '99+' : wishlistItems.length;
        badge.style.display = 'inline-flex';
      }

      grid.innerHTML = wishlistItems.map(item => `
        <div class="wishlist-item" data-wishlist-id="${item.id}">
          <div style="position: relative;">
            <img src="${item.products?.image_url || 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22200%22 height=%22200%22%3E%3Crect fill=%22%23f5f5f5%22 width=%22200%22 height=%22200%22/%3E%3C/svg%3E'}" 
                 alt="${item.products?.name || 'Product'}" 
                 class="wishlist-item-image"
                 onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22200%22 height=%22200%22%3E%3Crect fill=%22%23f5f5f5%22 width=%22200%22 height=%22200%22/%3E%3C/svg%3E'">
            ${item.in_stock ? '<span class="wishlist-item-badge">In Stock</span>' : '<span class="wishlist-item-badge" style="background: #999;">Out of Stock</span>'}
          </div>
          <div class="wishlist-item-content">
            <div class="wishlist-item-name">${item.products?.name || 'Product'}</div>
            <div class="wishlist-item-price">₱${parseFloat(item.products?.price || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
            <div class="wishlist-item-actions">
              <button class="wishlist-item-btn wishlist-item-view" onclick="viewWishlistProduct('${item.products?.id}')">
                <i class="fas fa-eye"></i> View
              </button>
              <button class="wishlist-item-btn wishlist-item-remove" onclick="removeFromWishlist('${item.id}')">
                <i class="fas fa-trash"></i>
              </button>
            </div>
          </div>
        </div>
      `).join('');
    } else {
      if (badge) badge.style.display = 'none';
      grid.innerHTML = '<p class="dash-empty" style="grid-column: 1/-1;">Your wishlist is empty. <a href="shop.html">Explore items!</a></p>';
    }
  } catch (error) {
    console.error('[buyer] loadWishlist:', error.message);
  }
}

async function removeFromWishlist(wishlistId) {
  try {
    const { error } = await db
      .from('wishlist')
      .delete()
      .eq('id', wishlistId);

    if (error) throw error;

    // Remove from UI
    const item = document.querySelector(`[data-wishlist-id="${wishlistId}"]`);
    if (item) {
      item.style.animation = 'fadeOut 0.3s ease';
      setTimeout(() => item.remove(), 300);
    }

    // Reload wishlist
    loadWishlist();
  } catch (error) {
    console.error('[buyer] removeFromWishlist:', error.message);
    alert('Could not remove item from wishlist');
  }
}

function viewWishlistProduct(productId) {
  if (productId) {
    window.location.href = `product.html?id=${productId}`;
  }
}

// ============================================================
// RECEIPT VIEWING
// ============================================================

async function openReceipt(orderId) {
  try {
    const { data: order, error } = await db
      .from('orders')
      .select('*, products(id, name, image_url)')
      .eq('id', orderId)
      .single();

    if (error || !order) {
      alert('Could not load receipt');
      return;
    }

    const modal = document.getElementById('receiptModal') || createReceiptModal();
    const product = order.products;
    const lsTracking = JSON.parse(localStorage.getItem(`rewear_tracking_${order.id}`) || '{}');
    const courierName = order.courier_name || lsTracking.courier_name || null;
    const trackingNumber = order.tracking_number || lsTracking.tracking_number || null;

    const receiptHTML = `
      <div class="receipt-header">
        <h2 class="receipt-title">Order Receipt</h2>
        <button class="receipt-close-btn" onclick="closeReceipt()">
          <i class="fas fa-times"></i>
        </button>
      </div>

      <div class="receipt-body">
        <!-- Order Info -->
        <div class="receipt-section">
          <div class="receipt-section-title">Order Information</div>
          <div class="receipt-row">
            <span class="receipt-label">Order ID</span>
            <span class="receipt-value">${order.id.slice(0, 8).toUpperCase()}</span>
          </div>
          <div class="receipt-row">
            <span class="receipt-label">Order Date</span>
            <span class="receipt-value">${new Date(order.created_at).toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
          </div>
          <div class="receipt-row">
            <span class="receipt-label">Status</span>
            <span class="receipt-value" style="text-transform: capitalize;">${order.status.replace(/_/g, ' ')}</span>
          </div>
        </div>

        <!-- Product Info -->
        <div class="receipt-section">
          <div class="receipt-section-title">Product Details</div>
          <div class="receipt-product">
            ${product?.image_url ? `<img src="${product.image_url}" alt="${product?.name}" class="receipt-product-image">` : ''}
            <div class="receipt-product-name">${product?.name || 'Product'}</div>
            <div class="receipt-product-details">Size: ${order.size_selected || '—'}</div>
            <div class="receipt-product-details">Quantity: ${order.quantity || 1}</div>
            <div class="receipt-product-details">Unit Price: ₱${parseFloat(order.unit_price || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
          </div>
        </div>

        <!-- Pricing -->
        <div class="receipt-section">
          <div class="receipt-section-title">Pricing</div>
          <div class="receipt-row">
            <span class="receipt-label">Subtotal</span>
            <span class="receipt-value">₱${parseFloat(order.subtotal || order.total_price || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>
          <div class="receipt-row">
            <span class="receipt-label">Shipping</span>
            <span class="receipt-value">₱${parseFloat(order.shipping_fee || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>
          <div class="receipt-row">
            <span class="receipt-label">Tax</span>
            <span class="receipt-value">₱${parseFloat(order.tax || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>
          <div class="receipt-total-row">
            <span class="receipt-label">Total Amount</span>
            <span class="receipt-value">₱${parseFloat(order.total_price || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>
        </div>

        <!-- Delivery Info -->
        <div class="receipt-section">
          <div class="receipt-section-title">Delivery Information</div>
          <div class="receipt-row">
            <span class="receipt-label">Recipient</span>
            <span class="receipt-value">${order.buyer_name || '—'}</span>
          </div>
          <div class="receipt-row">
            <span class="receipt-label">Email</span>
            <span class="receipt-value" style="font-size: 12px;">${order.buyer_email || '—'}</span>
          </div>
          ${order.delivery_address ? `
          <div class="receipt-row">
            <span class="receipt-label">Address</span>
            <span class="receipt-value">${order.delivery_address}</span>
          </div>` : ''}
          ${courierName ? `
          <div class="receipt-row">
            <span class="receipt-label">Courier</span>
            <span class="receipt-value">${courierName}</span>
          </div>` : ''}
          ${trackingNumber ? `
          <div class="receipt-row">
            <span class="receipt-label">Tracking Number</span>
            <span class="receipt-value">${trackingNumber}</span>
          </div>` : ''}
        </div>

        <!-- Payment Info -->
        <div class="receipt-section">
          <div class="receipt-section-title">Payment Information</div>
          <div class="receipt-row">
            <span class="receipt-label">Payment Method</span>
            <span class="receipt-value">${order.payment_method || 'Bank Transfer'}</span>
          </div>
          <div class="receipt-row">
            <span class="receipt-label">Payment Status</span>
            <span class="receipt-value" style="text-transform: capitalize;">${order.payment_status || 'Pending'}</span>
          </div>
        </div>
      </div>

      <div class="receipt-footer">
        <button class="receipt-btn receipt-btn-secondary" onclick="printReceipt('${order.id}')">
          <i class="fas fa-print"></i> Print
        </button>
        <button class="receipt-btn receipt-btn-primary" onclick="downloadReceipt('${order.id}')">
          <i class="fas fa-download"></i> Download
        </button>
      </div>
    `;

    modal.querySelector('.receipt-modal-content').innerHTML = receiptHTML;
    modal.classList.add('active');
  } catch (error) {
    console.error('[buyer] openReceipt:', error.message);
    alert('Could not open receipt');
  }
}

function createReceiptModal() {
  const modal = document.createElement('div');
  modal.id = 'receiptModal';
  modal.className = 'receipt-modal';
  modal.innerHTML = '<div class="receipt-modal-content"></div>';
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeReceipt();
  });
  document.body.appendChild(modal);
  return modal;
}

function closeReceipt() {
  const modal = document.getElementById('receiptModal');
  if (modal) modal.classList.remove('active');
}

function printReceipt(orderId) {
  window.print();
}

function downloadReceipt(orderId) {
  alert('Receipt download feature coming soon!');
}

// Add CSS for fade out animation
const style = document.createElement('style');
style.textContent = `
  @keyframes fadeOut {
    from { opacity: 1; }
    to { opacity: 0; }
  }
`;
document.head.appendChild(style);

// Load wishlist when tab is clicked
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.dash-nav-link').forEach(link => {
    link.addEventListener('click', () => {
      if (link.dataset.tab === 'wishlist') {
        setTimeout(loadWishlist, 100);
      }
    });
  });
});
