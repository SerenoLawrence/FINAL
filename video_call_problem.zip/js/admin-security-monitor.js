// ============================================================
// admin-security-monitor.js — Security Monitoring for Admin
// Displays fraud alerts, risk scores, and suspicious activity
// ============================================================

// Load fraud alerts for admin
async function loadFraudAlerts() {
    const container = document.getElementById('fraudAlertsList');
    if (!container) return;
    
    container.innerHTML = '<p class="dash-empty">Loading security alerts...</p>';

    try {
        // Get high-risk verifications
        const { data: highRisk, error } = await db
            .from('seller_verifications')
            .select('*')
            .gte('risk_score', 50)
            .order('risk_score', { ascending: false })
            .limit(20);

        if (error) throw error;

        if (!highRisk || highRisk.length === 0) {
            container.innerHTML = '<p class="dash-empty">✅ No high-risk verifications detected.</p>';
            return;
        }

        const alertsHTML = highRisk.map(v => {
            const riskLevel = v.risk_score >= 80 ? 'critical' : v.risk_score >= 60 ? 'high' : 'medium';
            const riskColor = v.risk_score >= 80 ? '#e74c3c' : v.risk_score >= 60 ? '#e67e22' : '#f39c12';
            
            const flags = v.security_flags || {};
            const flagsList = Object.keys(flags).map(key => 
                `<span style="background:#fff3cd;color:#856404;padding:2px 8px;border-radius:4px;font-size:11px;margin-right:4px;">${key.replace(/_/g, ' ')}</span>`
            ).join('');

            return `
                <div class="admin-card" style="border-left: 4px solid ${riskColor};">
                    <div class="admin-card-header">
                        <div>
                            <h3 class="admin-card-title">
                                ${v.first_name} ${v.last_name}
                                <span style="background:${riskColor};color:#fff;padding:4px 12px;border-radius:6px;font-size:12px;margin-left:8px;">
                                    Risk: ${v.risk_score}/100
                                </span>
                            </h3>
                            <p class="admin-card-meta">${v.email} · ${v.phone_number}</p>
                            <p class="admin-card-meta">ID: ${v.id_type.replace(/_/g, ' ').toUpperCase()} - ${v.id_number}</p>
                            <p class="admin-card-meta">Submitted: ${formatDate(v.submitted_at)}</p>
                            ${v.ip_address ? `<p class="admin-card-meta">IP: ${v.ip_address}</p>` : ''}
                            ${flagsList ? `<div style="margin-top:8px;">${flagsList}</div>` : ''}
                        </div>
                        <span class="dash-badge ${v.status === 'approved' ? 'dash-badge-verified' : v.status === 'rejected' ? 'dash-badge-rejected' : 'dash-badge-pending'}">
                            ${v.status}
                        </span>
                    </div>
                    
                    <div style="margin-top:12px;padding:12px;background:#f8f9fa;border-radius:8px;">
                        <h4 style="margin:0 0 8px;font-size:13px;font-weight:600;">Security Analysis</h4>
                        <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px;font-size:12px;">
                            <div>
                                <strong>Risk Level:</strong> 
                                <span style="color:${riskColor};font-weight:600;">${riskLevel.toUpperCase()}</span>
                            </div>
                            <div>
                                <strong>Status:</strong> ${v.status}
                            </div>
                            <div>
                                <strong>Fingerprint:</strong> ${v.submission_fingerprint || 'N/A'}
                            </div>
                            <div>
                                <strong>User Agent:</strong> ${v.user_agent ? v.user_agent.substring(0, 30) + '...' : 'N/A'}
                            </div>
                        </div>
                    </div>

                    <div class="admin-card-actions" style="margin-top:12px;">
                        <button class="admin-btn" onclick="viewVerificationDetails('${v.id}')" style="background:#3498db;color:#fff;">
                            <i class="fas fa-search"></i> View Details
                        </button>
                        ${v.status === 'pending' ? `
                            <button class="admin-btn admin-btn-approve" onclick="approveVerificationWithCheck('${v.id}', ${v.risk_score})">
                                ✓ Approve
                            </button>
                            <button class="admin-btn admin-btn-reject" onclick="rejectVerificationWithReason('${v.id}')">
                                ✕ Reject
                            </button>
                        ` : ''}
                    </div>
                </div>
            `;
        }).join('');

        container.innerHTML = alertsHTML;

    } catch (error) {
        console.error('[admin-security] loadFraudAlerts error:', error);
        container.innerHTML = '<p class="dash-empty">Error loading security alerts.</p>';
    }
}

// Load verification attempts log
async function loadVerificationAttempts() {
    const container = document.getElementById('verificationAttemptsList');
    if (!container) return;
    
    container.innerHTML = '<p class="dash-empty">Loading attempts...</p>';

    try {
        const { data: attempts, error } = await db
            .from('verification_attempts')
            .select('*')
            .order('created_at', { ascending: false })
            .limit(50);

        if (error) throw error;

        if (!attempts || attempts.length === 0) {
            container.innerHTML = '<p class="dash-empty">No verification attempts logged.</p>';
            return;
        }

        const attemptsHTML = attempts.map(a => {
            const typeColor = a.attempt_type === 'submission' ? '#27ae60' : 
                            a.attempt_type === 'validation_failed' ? '#e67e22' : '#e74c3c';
            
            return `
                <div style="padding:12px;border-bottom:1px solid #eee;display:flex;justify-content:space-between;align-items:center;">
                    <div>
                        <span style="background:${typeColor};color:#fff;padding:4px 8px;border-radius:4px;font-size:11px;font-weight:600;">
                            ${a.attempt_type.replace(/_/g, ' ').toUpperCase()}
                        </span>
                        <span style="margin-left:12px;color:#666;font-size:13px;">
                            ${formatDate(a.created_at)}
                        </span>
                        ${a.ip_address ? `<span style="margin-left:12px;color:#999;font-size:12px;">IP: ${a.ip_address}</span>` : ''}
                    </div>
                    <div style="font-size:12px;color:#999;">
                        User: ${a.user_id.substring(0, 8)}...
                    </div>
                </div>
            `;
        }).join('');

        container.innerHTML = attemptsHTML;

    } catch (error) {
        console.error('[admin-security] loadVerificationAttempts error:', error);
        container.innerHTML = '<p class="dash-empty">Error loading attempts.</p>';
    }
}

// Approve verification with risk check
async function approveVerificationWithCheck(verificationId, riskScore) {
    if (riskScore >= 70) {
        const confirmed = confirm(
            `⚠️ HIGH RISK VERIFICATION (${riskScore}/100)\n\n` +
            'This verification has been flagged as high risk. Are you sure you want to approve it?\n\n' +
            'Please review all documents carefully before approving.'
        );
        
        if (!confirmed) return;
    }

    // Call the existing approval function from admin.js
    if (typeof approveVerification === 'function') {
        approveVerification(verificationId);
    } else {
        alert('Approval function not available. Please refresh the page.');
    }
}

// Reject verification with reason
async function rejectVerificationWithReason(verificationId) {
    const reason = prompt(
        'Enter rejection reason (will be shown to user):\n\n' +
        'Common reasons:\n' +
        '- ID image unclear or unreadable\n' +
        '- Information mismatch\n' +
        '- Suspected fraudulent document\n' +
        '- Incomplete information'
    );
    
    if (!reason) return;

    // Call the existing rejection function from admin.js
    if (typeof rejectVerification === 'function') {
        rejectVerification(verificationId, reason);
    } else {
        alert('Rejection function not available. Please refresh the page.');
    }
}

// View verification details
async function viewVerificationDetails(verificationId) {
    try {
        const { data, error } = await db
            .from('seller_verifications')
            .select('*')
            .eq('id', verificationId)
            .single();

        if (error) throw error;

        // Show in modal (reuse existing verification modal from admin.js)
        if (typeof showVerificationModal === 'function') {
            showVerificationModal(data);
        } else {
            // Fallback: show in alert
            alert(
                `Verification Details:\n\n` +
                `Name: ${data.first_name} ${data.last_name}\n` +
                `Email: ${data.email}\n` +
                `Phone: ${data.phone_number}\n` +
                `ID Type: ${data.id_type}\n` +
                `ID Number: ${data.id_number}\n` +
                `Risk Score: ${data.risk_score}/100\n` +
                `Status: ${data.status}\n` +
                `Submitted: ${formatDate(data.submitted_at)}`
            );
        }
    } catch (error) {
        console.error('[admin-security] viewVerificationDetails error:', error);
        alert('Error loading verification details.');
    }
}

// Load security statistics
async function loadSecurityStats() {
    try {
        // Total verifications
        const { count: totalCount } = await db
            .from('seller_verifications')
            .select('*', { count: 'exact', head: true });

        // High risk count
        const { count: highRiskCount } = await db
            .from('seller_verifications')
            .select('*', { count: 'exact', head: true })
            .gte('risk_score', 70);

        // Pending count
        const { count: pendingCount } = await db
            .from('seller_verifications')
            .select('*', { count: 'exact', head: true })
            .eq('status', 'pending');

        // Rejected count
        const { count: rejectedCount } = await db
            .from('seller_verifications')
            .select('*', { count: 'exact', head: true })
            .eq('status', 'rejected');

        // Update stats display
        const el = id => document.getElementById(id);
        if (el('statTotalVerifications')) el('statTotalVerifications').textContent = totalCount || 0;
        if (el('statHighRiskVerifications')) el('statHighRiskVerifications').textContent = highRiskCount || 0;
        if (el('statPendingVerifications')) el('statPendingVerifications').textContent = pendingCount || 0;
        if (el('statRejectedVerifications')) el('statRejectedVerifications').textContent = rejectedCount || 0;

    } catch (error) {
        console.error('[admin-security] loadSecurityStats error:', error);
    }
}

// Format date helper
function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
}

// Export functions
window.adminSecurity = {
    loadFraudAlerts,
    loadVerificationAttempts,
    loadSecurityStats,
    approveVerificationWithCheck,
    rejectVerificationWithReason,
    viewVerificationDetails
};

console.log('[admin-security] Security monitoring loaded');
