// ============================================================
// order-tracking.js — Order Tracking System
// Implements: Order status tracking for buyers
// ============================================================

class OrderTracker {
  constructor() {
    this.statusFlow = [
      { key: 'pending',   label: 'Order Placed',         icon: '<i class="fas fa-shopping-cart"></i>' },
      { key: 'confirmed', label: 'Payment Confirmed',     icon: '<i class="fas fa-check-circle"></i>' },
      { key: 'shipped',   label: 'Shipped',               icon: '<i class="fas fa-truck"></i>' },
      { key: 'delivered', label: 'Delivered',             icon: '<i class="fas fa-box"></i>' },
      { key: 'received',  label: 'Receipt Confirmed',     icon: '<i class="fas fa-check"></i>'  }
    ];
  }

  async trackOrder() {
    const reference = document.getElementById('orderReference').value.trim();
    
    if (!reference) {
      this.showError('Missing Reference', 'Please enter your order ID or reference code');
      return;
    }

    try {
      showLoadingModal('Tracking Order', 'Looking up your order details...');

      let order = null;

      // Try to find by order ID first (UUID format)
      if (reference.length > 10) {
        const { data, error } = await db
          .from('orders')
          .select(`
            *,
            products (
              name,
              image_url,
              category
            )
          `)
          .eq('id', reference)
          .single();
        
        if (data) {
          order = data;
        }
      }

      // If not found by ID, try by payment reference
      if (!order) {
        const { data } = await db
          .from('orders')
          .select(`
            *,
            products (
              name,
              image_url,
              category
            )
          `)
          .or(`payment_reference.ilike.%${reference}%,id.ilike.%${reference}%`)
          .limit(1);
        
        if (data && data.length > 0) {
          order = data[0];
        }
      }

      hideLoadingModal();

      if (!order) {
        this.showError(
          'Order Not Found',
          `No order found with reference "${reference}". Please check your order ID or reference code and try again.`
        );
        return;
      }

      // Hide error and show results
      document.getElementById('trackingError').style.display = 'none';
      document.getElementById('trackingResults').style.display = 'block';

      this.displayOrderInfo(order);
      this.displayTrackingTimeline(order);

    } catch (error) {
      hideLoadingModal();
      this.showError('Tracking Error', 'Could not retrieve order information. Please try again.');
      console.error('[order-tracking] trackOrder:', error);
    }
  }

  /**
   * Show error message
   */
  showError(title, message) {
    const errorDiv = document.getElementById('trackingError');
    if (!errorDiv) {
      console.error('[order-tracking] Error div not found');
      return;
    }

    const titleEl = document.getElementById('errorTitle');
    const messageEl = document.getElementById('errorMessage');

    if (titleEl) titleEl.textContent = title;
    if (messageEl) messageEl.textContent = message;

    errorDiv.style.display = 'block';
    document.getElementById('trackingResults').style.display = 'none';
    
    console.log('[order-tracking] Error shown:', title, message);
  }

  displayOrderInfo(order) {
    // Use enhanced tracker if available
    if (window.enhancedOrderTracker) {
      console.log('[order-tracking] Using enhanced tracker');
      window.enhancedOrderTracker.displayEnhancedTracking(order);
      return;
    }

    console.log('[order-tracking] Using fallback display');
    // Fallback to original display
    const orderInfo = document.getElementById('orderInfo');
    const product = order.products;

    // Prefer DB columns; fall back to localStorage for legacy data
    const lsTracking = JSON.parse(localStorage.getItem(`rewear_tracking_${order.id}`) || '{}');
    const courierName    = order.courier_name    || lsTracking.courier_name    || null;
    const trackingNumber = order.tracking_number || lsTracking.tracking_number || null;

    // Payment status badge
    const paymentBadge = {
      pending:   '<span style="background:#fff3cd;color:#856404;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;"><i class="fas fa-hourglass"></i> Awaiting Payment</span>',
      submitted: '<span style="background:#cce5ff;color:#004085;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;"><i class="fas fa-arrow-up"></i> Payment Submitted</span>',
      verified:  '<span style="background:#d4edda;color:#155724;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;"><i class="fas fa-check-circle"></i> Payment Verified</span>',
      rejected:  '<span style="background:#f8d7da;color:#721c24;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;"><i class="fas fa-times-circle"></i> Payment Rejected</span>'
    }[order.payment_status || 'pending'] || '';
    
    orderInfo.innerHTML = `
      <div class="order-summary-card">
        <div class="order-header">
          <h3>Order ${order.id.slice(0, 8).toUpperCase()}</h3>
          <span class="order-status ${order.status.replace(/_/g, '-')}">${this.getStatusLabel(order.status)}</span>
        </div>
        
        <div class="order-product">
          ${product?.image_url ? `<img src="${product.image_url}" alt="${product.name}" class="order-product-image">` : ''}
          <div class="order-product-details">
            <h4>${product?.name || 'Product'}</h4>
            <p>Size: ${order.size_selected || '—'}</p>
            <p>Quantity: ${order.quantity || 1}</p>
            <p class="order-total">Total: ₱${parseFloat(order.total_price || 0).toFixed(2)}</p>
          </div>
        </div>
        
        <div class="order-details">
          <div class="detail-row"><span>Buyer:</span><span>${order.buyer_name}</span></div>
          <div class="detail-row"><span>Email:</span><span>${order.buyer_email}</span></div>
          ${order.delivery_address ? `<div class="detail-row"><span>Address:</span><span>${order.delivery_address}</span></div>` : ''}
          ${order.payment_reference ? `<div class="detail-row"><span>Ref #:</span><span style="font-weight:600;">${order.payment_reference}</span></div>` : ''}
          <div class="detail-row"><span>Payment:</span><span>${paymentBadge}</span></div>
          ${order.payment_rejected_reason ? `<div class="detail-row" style="color:#c0392b;"><span>Reason:</span><span>${order.payment_rejected_reason}</span></div>` : ''}
          ${courierName ? `<div class="detail-row"><span>Courier:</span><span>${courierName}</span></div>` : ''}
          ${trackingNumber ? `<div class="detail-row"><span>Tracking #:</span><span style="font-weight:600;color:#c8a96e;">${trackingNumber}</span></div>` : ''}
        </div>

        ${order.status === 'delivered' ? `
        <div style="margin-top:16px;text-align:center;">
          <button onclick="confirmReceiptFromTracking('${order.id}')" 
                  style="padding:12px 24px;background:#27ae60;color:#fff;border:none;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;">
            <i class="fas fa-check"></i> Confirm Receipt
          </button>
        </div>` : ''}
        ${order.status === 'received' ? `
        <div style="margin-top:16px;text-align:center;">
          <p style="color:#27ae60;font-weight:600;"><i class="fas fa-check"></i> You have confirmed receipt of this order</p>
          ${!order._reviewed ? `<button onclick="openReviewModal('${order.id}', '${order.products?.name || ''}', '${order.products?.id || ''}')"
            style="margin-top:8px;padding:10px 20px;background:#c8a96e;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;">
            <i class="fas fa-star"></i> Leave a Review
          </button>` : ''}
        </div>` : ''}
      </div>
    `;

    // Check if already reviewed
    if (order.status === 'received' && order.products?.id) {
      const currentUser = window.authManager?.getCurrentUser();
      if (currentUser) {
        db.from('reviews')
          .select('id')
          .eq('order_id', order.id)
          .eq('buyer_email', currentUser.email)
          .single()
          .then(({ data }) => {
            if (data) {
              // Already reviewed — hide the button
              const reviewBtn = orderInfo.querySelector('button[onclick*="openReviewModal"]');
              if (reviewBtn) reviewBtn.style.display = 'none';
            }
          });
      }
    }
  }

  displayTrackingTimeline(order) {
    // Skip if using enhanced tracker
    if (window.enhancedOrderTracker) {
      console.log('[order-tracking] Skipping timeline (using enhanced tracker)');
      return;
    }

    const timeline = document.getElementById('trackingTimeline');
    
    // Check if element exists
    if (!timeline) {
      console.warn('[order-tracking] trackingTimeline element not found (using enhanced tracker)');
      return;
    }

    const currentStatusIndex = this.statusFlow.findIndex(s => s.key === order.status);
    
    const timelineHTML = this.statusFlow.map((status, index) => {
      const isCompleted = index <= currentStatusIndex;
      const isCurrent = index === currentStatusIndex;
      
      return `
        <div class="timeline-item ${isCompleted ? 'completed' : ''} ${isCurrent ? 'current' : ''}">
          <div class="timeline-icon">${status.icon}</div>
          <div class="timeline-content">
            <h4>${status.label}</h4>
            <p>${this.getStatusDescription(status.key, order)}</p>
            ${this.getStatusTimestamp(status.key, order)}
          </div>
        </div>
      `;
    }).join('');
    
    timeline.innerHTML = `
      <div class="timeline-header">
        <h3>Order Progress</h3>
      </div>
      <div class="timeline">
        ${timelineHTML}
      </div>
    `;
    
    console.log('[order-tracking] Timeline displayed for order:', order.id);
  }

  getStatusLabel(status) {
    const statusObj = this.statusFlow.find(s => s.key === status);
    return statusObj ? statusObj.label : status.replace(/_/g, ' ').toUpperCase();
  }

  getStatusDescription(status, order) {
    const pStatus = order.payment_status;
    const descriptions = {
      'pending':   pStatus === 'submitted'
                     ? 'Payment proof submitted — awaiting admin verification'
                     : pStatus === 'rejected'
                       ? `Payment rejected${order.payment_rejected_reason ? ': ' + order.payment_rejected_reason : ''} — please contact support`
                       : 'Order placed — please complete GCash payment and upload proof',
      'confirmed': 'Payment verified — seller is preparing your item',
      'shipped':   'Your order is on the way',
      'delivered': 'Order delivered — please confirm receipt below',
      'received':  'Transaction complete — thank you!',
      'cancelled': 'This order was cancelled'
    };
    return descriptions[status] || 'Status update';
  }

  getStatusTimestamp(status, order) {
    if (status === 'pending' && order.created_at) {
      const date = new Date(order.created_at);
      return `<span class="timestamp">${date.toLocaleDateString()} ${date.toLocaleTimeString()}</span>`;
    }
    return '';
  }
}

// Confirm receipt from tracking page
window.confirmReceiptFromTracking = async (orderId) => {
  if (!confirm('Confirm that you have received this order?')) return;
  try {
    const currentUser = window.authManager?.getCurrentUser();
    let error;

    // Try with received_at first
    ({ error } = await db.from('orders').update({
      status: 'received',
      received_at: new Date().toISOString()
    }).eq('id', orderId));

    // If received_at column doesn't exist, retry without it
    if (error?.message?.includes('received_at')) {
      ({ error } = await db.from('orders').update({ status: 'received' }).eq('id', orderId));
    }

    // If still failing (RLS), try matching by buyer_email too
    if (error && currentUser?.email) {
      ({ error } = await db.from('orders').update({ status: 'received' })
        .eq('id', orderId)
        .eq('buyer_email', currentUser.email));
    }

    if (error) throw error;
    showSuccess('Receipt Confirmed!', 'Thank you for confirming your order receipt.', 'Got it');
    setTimeout(() => window.orderTracker?.trackOrder(), 1000);
  } catch (err) {
    console.error('[order-tracking] confirmReceipt error:', err);
    showError('Error', 'Could not confirm receipt. Please try again.');
  }
};

// Review modal
window.openReviewModal = function(orderId, productName, productId) {
  const overlay = document.createElement('div');
  overlay.id = 'reviewOverlay';
  overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.55);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;';
  overlay.innerHTML = `
    <div style="background:#fff;border-radius:16px;padding:32px;max-width:480px;width:100%;box-shadow:0 8px 32px rgba(0,0,0,0.2);max-height:90vh;overflow-y:auto;">
      <h3 style="margin:0 0 4px;font-size:20px;color:#1a1a2e;">Leave a Review</h3>
      <p style="color:#888;font-size:14px;margin:0 0 24px;">${productName}</p>
      
      <!-- Product Rating -->
      <div style="margin-bottom:20px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:8px;color:#1a1a2e;">Product Rating</label>
        <div id="starPicker" style="display:flex;gap:8px;font-size:28px;cursor:pointer;">
          ${[1,2,3,4,5].map(n => `<span data-star="${n}" style="color:#ddd;transition:color 0.15s;">★</span>`).join('')}
        </div>
        <input type="hidden" id="selectedRating" value="0">
      </div>

      <!-- Seller Rating -->
      <div style="margin-bottom:20px;padding:16px;background:#f9f9f9;border-radius:12px;border:1px solid #e8d5b0;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:10px;color:#1a1a2e;">Rate the Seller</label>
        <p style="font-size:12px;color:#666;margin:0 0 12px;">Was the seller trustworthy and responsive?</p>
        <div style="display:flex;gap:10px;">
          <button id="sellerLikeBtn" onclick="selectSellerRating('like')" 
            style="flex:1;padding:12px;border:2px solid #e0e0e0;border-radius:8px;background:#fff;cursor:pointer;font-size:14px;font-weight:600;color:#666;transition:all 0.2s;display:flex;align-items:center;justify-content:center;gap:6px;">
            <span style="font-size:18px;">👍</span> Trustworthy
          </button>
          <button id="sellerDislikeBtn" onclick="selectSellerRating('dislike')" 
            style="flex:1;padding:12px;border:2px solid #e0e0e0;border-radius:8px;background:#fff;cursor:pointer;font-size:14px;font-weight:600;color:#666;transition:all 0.2s;display:flex;align-items:center;justify-content:center;gap:6px;">
            <span style="font-size:18px;">👎</span> Not Responsive
          </button>
        </div>
        <input type="hidden" id="sellerRating" value="">
      </div>

      <!-- Comment -->
      <div style="margin-bottom:20px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:8px;color:#1a1a2e;">Your Experience (optional)</label>
        <textarea id="reviewComment" rows="3" placeholder="Share details about the product quality, seller communication, shipping speed, etc..."
          style="width:100%;padding:12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;resize:vertical;box-sizing:border-box;font-family:inherit;"></textarea>
      </div>

      <!-- Buttons -->
      <div style="display:flex;gap:12px;">
        <button onclick="submitReview('${orderId}', '${productId}')"
          style="flex:1;padding:14px;background:#c8a96e;color:#fff;border:none;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;transition:background 0.2s;">
          Submit Review
        </button>
        <button onclick="document.getElementById('reviewOverlay').remove()"
          style="padding:14px 24px;background:#f5f5f5;color:#333;border:none;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;">
          Cancel
        </button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);

  // Star picker interaction
  const stars = overlay.querySelectorAll('#starPicker span');
  stars.forEach(star => {
    star.addEventListener('mouseover', () => {
      const n = parseInt(star.dataset.star);
      stars.forEach((s, i) => s.style.color = i < n ? '#c8a96e' : '#ddd');
    });
    star.addEventListener('click', () => {
      document.getElementById('selectedRating').value = star.dataset.star;
    });
  });
  overlay.querySelector('#starPicker').addEventListener('mouseleave', () => {
    const selected = parseInt(document.getElementById('selectedRating').value) || 0;
    stars.forEach((s, i) => s.style.color = i < selected ? '#c8a96e' : '#ddd');
  });
};

// Seller rating selection
window.selectSellerRating = function(type) {
  const likeBtn = document.getElementById('sellerLikeBtn');
  const dislikeBtn = document.getElementById('sellerDislikeBtn');
  const input = document.getElementById('sellerRating');

  if (input.value === type) {
    // Deselect if clicking same button
    input.value = '';
    likeBtn.style.cssText = likeBtn.style.cssText.replace(/border-color:[^;]+;?/, '').replace(/background:[^;]+;?/, '').replace(/color:[^;]+;?/, '') + 'border:2px solid #e0e0e0;background:#fff;color:#666;';
    dislikeBtn.style.cssText = dislikeBtn.style.cssText.replace(/border-color:[^;]+;?/, '').replace(/background:[^;]+;?/, '').replace(/color:[^;]+;?/, '') + 'border:2px solid #e0e0e0;background:#fff;color:#666;';
  } else {
    input.value = type;
    if (type === 'like') {
      likeBtn.style.cssText = likeBtn.style.cssText.replace(/border-color:[^;]+;?/, '').replace(/background:[^;]+;?/, '').replace(/color:[^;]+;?/, '') + 'border-color:#27ae60;background:#e8f5e9;color:#27ae60;';
      dislikeBtn.style.cssText = dislikeBtn.style.cssText.replace(/border-color:[^;]+;?/, '').replace(/background:[^;]+;?/, '').replace(/color:[^;]+;?/, '') + 'border:2px solid #e0e0e0;background:#fff;color:#666;';
    } else {
      dislikeBtn.style.cssText = dislikeBtn.style.cssText.replace(/border-color:[^;]+;?/, '').replace(/background:[^;]+;?/, '').replace(/color:[^;]+;?/, '') + 'border-color:#e74c3c;background:#fdecea;color:#e74c3c;';
      likeBtn.style.cssText = likeBtn.style.cssText.replace(/border-color:[^;]+;?/, '').replace(/background:[^;]+;?/, '').replace(/color:[^;]+;?/, '') + 'border:2px solid #e0e0e0;background:#fff;color:#666;';
    }
  }
};

window.submitReview = async function(orderId, productId) {
  const rating  = parseInt(document.getElementById('selectedRating')?.value || '0');
  const sellerRating = document.getElementById('sellerRating')?.value || '';
  const comment = document.getElementById('reviewComment')?.value.trim();
  const currentUser = window.authManager?.getCurrentUser();

  if (!rating) { alert('Please select a product rating (stars).'); return; }
  if (!sellerRating) { alert('Please rate the seller (Trustworthy or Not Responsive).'); return; }
  if (!currentUser) { alert('Please log in to leave a review.'); return; }

  try {
    // Get seller_id from order
    const { data: order } = await db.from('orders').select('seller_id').eq('id', orderId).single();

    // Insert product review
    const { error: reviewError } = await db.from('reviews').insert({
      order_id:    orderId,
      product_id:  productId,
      seller_id:   order?.seller_id || null,
      buyer_email: currentUser.email,
      rating,
      comment: comment || null
    });
    if (reviewError) throw reviewError;

    // Insert seller rating (only if seller exists)
    if (order?.seller_id) {
      const { error: ratingError } = await db.from('seller_ratings').upsert({
        seller_id: order.seller_id,
        user_id: currentUser.id,
        order_id: orderId,
        vote_type: sellerRating, // 'like' or 'dislike'
        verified_purchase: true
      }, {
        onConflict: 'seller_id,user_id,order_id'
      });
      if (ratingError) throw ratingError;
    }

    document.getElementById('reviewOverlay')?.remove();
    showSuccess('Review Submitted!', 'Thank you for your feedback.', 'Got it');
  } catch (err) {
    console.error('[review]', err);
    alert('Could not submit review. Please try again.');
  }
};

// Global function for HTML onclick
window.trackOrder = () => {
  if (window.orderTracker) {
    window.orderTracker.trackOrder();
  }
};

// Initialize order tracker
document.addEventListener('DOMContentLoaded', () => {
  window.orderTracker = new OrderTracker();
  
  const urlParams = new URLSearchParams(window.location.search);
  const reference = urlParams.get('ref') || urlParams.get('id');
  if (reference) {
    document.getElementById('orderReference').value = reference;
    window.orderTracker.trackOrder();
  }
});

console.log('[order-tracking] Order tracking system loaded');