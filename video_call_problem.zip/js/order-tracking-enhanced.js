/**
 * ============================================================
 * ORDER TRACKING ENHANCED - With Chat Integration
 * ============================================================
 * 
 * Features:
 * - Order status tracking with clear next steps
 * - Chat integration at each stage
 * - Delivery method-specific flows (courier, seller delivers, meet up)
 * - Real-time communication between buyer and seller
 * - Action buttons for each status
 */

class EnhancedOrderTracker {
  constructor() {
    this.currentOrder = null;
    this.currentUser = null;
    
    // Status flow with delivery method variations
    this.statusFlow = [
      { 
        key: 'pending', 
        label: 'Order Placed',
        icon: '🛒',
        description: 'Order placed — please complete payment',
        nextStep: 'Complete GCash payment and upload proof',
        action: 'Upload Payment Proof'
      },
      { 
        key: 'confirmed', 
        label: 'Payment Confirmed',
        icon: '✅',
        description: 'Payment verified — seller is preparing your item',
        nextStep: 'Seller is preparing your item for shipment',
        action: 'Chat with Seller'
      },
      { 
        key: 'shipped', 
        label: 'Shipped',
        icon: '📦',
        description: 'Your order is on the way',
        nextStep: 'Track your package or wait for delivery',
        action: 'View Tracking'
      },
      { 
        key: 'delivered', 
        label: 'Delivered',
        icon: '📍',
        description: 'Order delivered — please confirm receipt',
        nextStep: 'Confirm that you received the item',
        action: 'Confirm Receipt'
      },
      { 
        key: 'received', 
        label: 'Receipt Confirmed',
        icon: '🎉',
        description: 'Transaction complete — thank you!',
        nextStep: 'Leave a review to help other buyers',
        action: 'Leave Review'
      }
    ];
  }

  /**
   * Display enhanced order tracking with chat
   */
  displayEnhancedTracking(order) {
    this.currentOrder = order;
    this.currentUser = window.authManager?.getCurrentUser();
    
    const container = document.getElementById('trackingResults');
    if (!container) return;

    const deliveryMethod = order.shipping_info?.delivery_preference || 'courier';
    const isBuyer = this.currentUser?.email === order.buyer_email;
    const isSeller = this.currentUser?.id === order.seller_id;

    container.innerHTML = `
      <div class="enhanced-tracking-container">
        ${this.renderOrderHeader(order)}
        ${this.renderDeliveryMethodInfo(order, deliveryMethod)}
        ${this.renderStatusTimeline(order)}
        ${this.renderNextSteps(order, deliveryMethod, isBuyer, isSeller)}
        ${this.renderChatSection(order, isBuyer, isSeller)}
        ${this.renderActionButtons(order, isBuyer, isSeller)}
      </div>
    `;

    // Add styles
    this.addEnhancedStyles();
  }

  /**
   * Render order header with key info
   */
  renderOrderHeader(order) {
    const product = order.products;
    const paymentBadge = this.getPaymentBadge(order.payment_status);

    return `
      <div class="order-header-enhanced">
        <div class="order-header-left">
          <h2>Order ${order.id.slice(0, 8).toUpperCase()}</h2>
          <p class="order-date">${new Date(order.created_at).toLocaleDateString()}</p>
        </div>
        <div class="order-header-right">
          <span class="order-status-badge status-${order.status}">${this.getStatusLabel(order.status)}</span>
          ${paymentBadge}
        </div>
      </div>

      <div class="order-product-section">
        ${product?.image_url ? `<img src="${product.image_url}" alt="${product.name}" class="order-product-img">` : ''}
        <div class="order-product-info">
          <h3>${product?.name || 'Product'}</h3>
          <p>Size: ${order.size_selected || '—'} · Qty: ${order.quantity || 1}</p>
          <p class="order-total">₱${parseFloat(order.total_price || 0).toFixed(2)}</p>
        </div>
      </div>
    `;
  }

  /**
   * Render delivery method info
   */
  renderDeliveryMethodInfo(order, deliveryMethod) {
    const deliveryInfo = {
      courier: {
        icon: '📦',
        label: 'Ship via Courier',
        description: 'Your item will be shipped via courier service',
        details: `Courier: ${order.courier_name || 'TBD'} | Tracking: ${order.tracking_number || 'Pending'}`
      },
      seller_delivers: {
        icon: '🛵',
        label: 'Seller Delivers',
        description: 'Seller will deliver the item to you',
        details: `Delivery Address: ${order.delivery_address || 'TBD'}`
      },
      meetup: {
        icon: '🤝',
        label: 'Meet Up',
        description: 'You will meet the seller to receive the item',
        details: `Location: ${order.delivery_address || 'To be confirmed'}`
      }
    };

    const info = deliveryInfo[deliveryMethod] || deliveryInfo.courier;

    return `
      <div class="delivery-method-card">
        <div class="delivery-icon">${info.icon}</div>
        <div class="delivery-info">
          <h4>${info.label}</h4>
          <p>${info.description}</p>
          <p class="delivery-details">${info.details}</p>
        </div>
      </div>
    `;
  }

  /**
   * Render status timeline with next steps
   */
  renderStatusTimeline(order) {
    const currentStatusIndex = this.statusFlow.findIndex(s => s.key === order.status);
    
    const timelineItems = this.statusFlow.map((status, index) => {
      const isCompleted = index <= currentStatusIndex;
      const isCurrent = index === currentStatusIndex;
      
      return `
        <div class="timeline-item-enhanced ${isCompleted ? 'completed' : ''} ${isCurrent ? 'current' : ''}">
          <div class="timeline-marker">
            <div class="timeline-icon">${status.icon}</div>
            ${index < this.statusFlow.length - 1 ? '<div class="timeline-line"></div>' : ''}
          </div>
          <div class="timeline-details">
            <h4>${status.label}</h4>
            <p>${this.getStatusDescription(status.key, order)}</p>
            ${isCurrent ? `<p class="next-step">📌 Next: ${status.nextStep}</p>` : ''}
          </div>
        </div>
      `;
    }).join('');

    return `
      <div class="timeline-section-enhanced">
        <h3>Order Progress</h3>
        <div class="timeline-enhanced">
          ${timelineItems}
        </div>
      </div>
    `;
  }

  /**
   * Render next steps section
   */
  renderNextSteps(order, deliveryMethod, isBuyer, isSeller) {
    const nextStepsMap = {
      pending: {
        buyer: [
          '💳 Complete GCash payment',
          '📸 Upload payment proof',
          '⏳ Wait for admin verification'
        ],
        seller: [
          '⏳ Waiting for buyer payment',
          '💬 Chat with buyer if needed'
        ]
      },
      confirmed: {
        buyer: [
          '📦 Seller is preparing your item',
          '💬 Chat with seller for updates',
          '⏳ Wait for shipment notification'
        ],
        seller: [
          '📦 Prepare the item for shipment',
          '📸 Take photos if needed',
          '🚚 Arrange courier pickup',
          '💬 Notify buyer when shipped'
        ]
      },
      shipped: {
        buyer: [
          '📍 Track your package',
          '💬 Chat with seller for tracking updates',
          '⏳ Wait for delivery'
        ],
        seller: [
          '✅ Item shipped',
          '📍 Provide tracking number to buyer',
          '💬 Keep buyer updated'
        ]
      },
      delivered: {
        buyer: [
          '📦 Check your package',
          '✅ Confirm receipt below',
          '⭐ Leave a review'
        ],
        seller: [
          '✅ Item delivered',
          '⏳ Wait for buyer confirmation',
          '💬 Chat with buyer if issues'
        ]
      },
      received: {
        buyer: [
          '🎉 Transaction complete',
          '⭐ Leave a review',
          '💬 Chat with seller if needed'
        ],
        seller: [
          '🎉 Transaction complete',
          '⭐ Check buyer review',
          '📊 Mark item as sold'
        ]
      }
    };

    const steps = nextStepsMap[order.status];
    const userSteps = isBuyer ? steps?.buyer : (isSeller ? steps?.seller : []);

    return `
      <div class="next-steps-section">
        <h3>📋 What's Next?</h3>
        <div class="next-steps-list">
          ${userSteps?.map((step, i) => `
            <div class="next-step-item">
              <span class="step-number">${i + 1}</span>
              <span class="step-text">${step}</span>
            </div>
          `).join('') || '<p>No pending actions</p>'}
        </div>
      </div>
    `;
  }

  /**
   * Render chat section
   */
  renderChatSection(order, isBuyer, isSeller) {
    if (!isBuyer && !isSeller) return '';

    const otherParty = isBuyer ? order.seller_id : order.buyer_email;
    const otherPartyName = isBuyer ? 'Seller' : order.buyer_name;

    return `
      <div class="chat-section-enhanced">
        <h3>💬 Communication</h3>
        <div class="chat-info">
          <p>Chat with ${otherPartyName} about this order</p>
          <button class="btn-open-chat" onclick="openOrderChat('${order.id}', '${order.seller_id}', '${order.buyer_email}')">
            <i class="fas fa-comments"></i> Open Chat
          </button>
        </div>
        <div class="chat-tips">
          <p><strong>💡 Tips:</strong></p>
          <ul>
            <li>Ask about delivery status</li>
            <li>Confirm delivery address</li>
            <li>Report any issues</li>
            <li>Arrange meet-up time (if applicable)</li>
          </ul>
        </div>
      </div>
    `;
  }

  /**
   * Render action buttons based on status
   */
  renderActionButtons(order, isBuyer, isSeller) {
    const buttons = [];

    if (isBuyer) {
      if (order.status === 'pending' && order.payment_status !== 'verified') {
        buttons.push(`
          <button class="btn-action btn-primary" onclick="uploadPaymentProof('${order.id}')">
            <i class="fas fa-upload"></i> Upload Payment Proof
          </button>
        `);
      }

      if (order.status === 'delivered') {
        buttons.push(`
          <button class="btn-action btn-success" onclick="confirmReceiptFromTracking('${order.id}')">
            <i class="fas fa-check"></i> Confirm Receipt
          </button>
        `);
      }

      if (order.status === 'received') {
        buttons.push(`
          <button class="btn-action btn-secondary" onclick="openReviewModal('${order.id}', '${order.products?.name || ''}', '${order.products?.id || ''}')">
            <i class="fas fa-star"></i> Leave Review
          </button>
        `);
      }
    }

    if (isSeller) {
      if (order.status === 'confirmed') {
        buttons.push(`
          <button class="btn-action btn-primary" onclick="markOrderShipped('${order.id}')">
            <i class="fas fa-truck"></i> Mark as Shipped
          </button>
        `);
      }

      if (order.status === 'received') {
        buttons.push(`
          <button class="btn-action btn-success" onclick="markItemSold('${order.id}', '${order.products?.id || ''}')">
            <i class="fas fa-check"></i> Mark Item as Sold
          </button>
        `);
      }
    }

    // Always show chat button
    buttons.push(`
      <button class="btn-action btn-chat" onclick="openOrderChat('${order.id}', '${order.seller_id}', '${order.buyer_email}')">
        <i class="fas fa-comments"></i> Chat
      </button>
    `);

    return `
      <div class="action-buttons-section">
        <div class="action-buttons">
          ${buttons.join('')}
        </div>
      </div>
    `;
  }

  /**
   * Get payment badge HTML
   */
  getPaymentBadge(paymentStatus) {
    const badges = {
      pending:   '<span class="payment-badge pending">⏳ Awaiting Payment</span>',
      submitted: '<span class="payment-badge submitted">📤 Payment Submitted</span>',
      verified:  '<span class="payment-badge verified">✅ Payment Verified</span>',
      rejected:  '<span class="payment-badge rejected">❌ Payment Rejected</span>'
    };
    return badges[paymentStatus] || '';
  }

  /**
   * Get status label
   */
  getStatusLabel(status) {
    const statusObj = this.statusFlow.find(s => s.key === status);
    return statusObj ? statusObj.label : status.replace(/_/g, ' ').toUpperCase();
  }

  /**
   * Get status description
   */
  getStatusDescription(status, order) {
    const descriptions = {
      'pending':   order.payment_status === 'submitted'
                     ? 'Payment proof submitted — awaiting admin verification'
                     : order.payment_status === 'rejected'
                       ? `Payment rejected — please contact support`
                       : 'Order placed — please complete GCash payment',
      'confirmed': 'Payment verified — seller is preparing your item',
      'shipped':   'Your order is on the way',
      'delivered': 'Order delivered — please confirm receipt',
      'received':  'Transaction complete — thank you!',
      'cancelled': 'This order was cancelled'
    };
    return descriptions[status] || 'Status update';
  }

  /**
   * Add enhanced styles
   */
  addEnhancedStyles() {
    if (document.getElementById('enhanced-tracking-styles')) return;

    const style = document.createElement('style');
    style.id = 'enhanced-tracking-styles';
    style.textContent = `
      .enhanced-tracking-container {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
      }

      .order-header-enhanced {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 24px;
        padding-bottom: 16px;
        border-bottom: 2px solid #f0f0f0;
      }

      .order-header-left h2 {
        margin: 0;
        font-size: 24px;
        color: #333;
      }

      .order-date {
        margin: 4px 0 0;
        color: #888;
        font-size: 14px;
      }

      .order-header-right {
        display: flex;
        gap: 12px;
        align-items: center;
      }

      .order-status-badge {
        padding: 8px 16px;
        border-radius: 20px;
        font-weight: 600;
        font-size: 13px;
      }

      .order-status-badge.status-pending {
        background: #fff3cd;
        color: #856404;
      }

      .order-status-badge.status-confirmed {
        background: #d4edda;
        color: #155724;
      }

      .order-status-badge.status-shipped {
        background: #cce5ff;
        color: #004085;
      }

      .order-status-badge.status-delivered {
        background: #d1ecf1;
        color: #0c5460;
      }

      .order-status-badge.status-received {
        background: #d4edda;
        color: #155724;
      }

      .payment-badge {
        padding: 6px 12px;
        border-radius: 16px;
        font-size: 12px;
        font-weight: 600;
      }

      .payment-badge.pending {
        background: #fff3cd;
        color: #856404;
      }

      .payment-badge.submitted {
        background: #cce5ff;
        color: #004085;
      }

      .payment-badge.verified {
        background: #d4edda;
        color: #155724;
      }

      .payment-badge.rejected {
        background: #f8d7da;
        color: #721c24;
      }

      .order-product-section {
        display: flex;
        gap: 16px;
        margin-bottom: 24px;
        padding: 16px;
        background: #f9f9f9;
        border-radius: 12px;
      }

      .order-product-img {
        width: 100px;
        height: 100px;
        object-fit: cover;
        border-radius: 8px;
      }

      .order-product-info h3 {
        margin: 0 0 8px;
        font-size: 16px;
      }

      .order-product-info p {
        margin: 4px 0;
        font-size: 14px;
        color: #666;
      }

      .order-total {
        font-weight: 600;
        color: #c8a96e;
        font-size: 16px;
      }

      .delivery-method-card {
        display: flex;
        gap: 16px;
        margin-bottom: 24px;
        padding: 16px;
        background: #f0f8ff;
        border-left: 4px solid #c8a96e;
        border-radius: 8px;
      }

      .delivery-icon {
        font-size: 32px;
        min-width: 40px;
      }

      .delivery-info h4 {
        margin: 0 0 4px;
        font-size: 16px;
        color: #333;
      }

      .delivery-info p {
        margin: 4px 0;
        font-size: 14px;
        color: #666;
      }

      .delivery-details {
        font-weight: 600;
        color: #c8a96e;
      }

      .timeline-section-enhanced {
        margin-bottom: 24px;
      }

      .timeline-section-enhanced h3 {
        margin: 0 0 16px;
        font-size: 18px;
        color: #333;
      }

      .timeline-enhanced {
        position: relative;
      }

      .timeline-item-enhanced {
        display: flex;
        gap: 16px;
        margin-bottom: 20px;
        opacity: 0.6;
        transition: opacity 0.3s;
      }

      .timeline-item-enhanced.completed,
      .timeline-item-enhanced.current {
        opacity: 1;
      }

      .timeline-marker {
        display: flex;
        flex-direction: column;
        align-items: center;
        min-width: 50px;
      }

      .timeline-icon {
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        background: #f0f0f0;
        border-radius: 50%;
        z-index: 2;
        position: relative;
      }

      .timeline-item-enhanced.completed .timeline-icon {
        background: #d4edda;
      }

      .timeline-item-enhanced.current .timeline-icon {
        background: #c8a96e;
        color: white;
        box-shadow: 0 0 0 4px rgba(200, 169, 110, 0.2);
      }

      .timeline-line {
        width: 2px;
        height: 40px;
        background: #ddd;
        margin-top: 4px;
      }

      .timeline-item-enhanced.completed .timeline-line {
        background: #d4edda;
      }

      .timeline-details h4 {
        margin: 0 0 4px;
        font-size: 15px;
        color: #333;
      }

      .timeline-details p {
        margin: 4px 0;
        font-size: 13px;
        color: #666;
      }

      .next-step {
        color: #c8a96e;
        font-weight: 600;
        margin-top: 8px !important;
      }

      .next-steps-section {
        margin-bottom: 24px;
        padding: 16px;
        background: #fffbf0;
        border-radius: 12px;
      }

      .next-steps-section h3 {
        margin: 0 0 12px;
        font-size: 16px;
        color: #333;
      }

      .next-steps-list {
        display: flex;
        flex-direction: column;
        gap: 8px;
      }

      .next-step-item {
        display: flex;
        gap: 12px;
        align-items: flex-start;
      }

      .step-number {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 24px;
        height: 24px;
        background: #c8a96e;
        color: white;
        border-radius: 50%;
        font-size: 12px;
        font-weight: 600;
        flex-shrink: 0;
      }

      .step-text {
        font-size: 14px;
        color: #333;
        padding-top: 2px;
      }

      .chat-section-enhanced {
        margin-bottom: 24px;
        padding: 16px;
        background: #f0f8ff;
        border-radius: 12px;
      }

      .chat-section-enhanced h3 {
        margin: 0 0 12px;
        font-size: 16px;
        color: #333;
      }

      .chat-info {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 12px;
        padding-bottom: 12px;
        border-bottom: 1px solid #ddd;
      }

      .chat-info p {
        margin: 0;
        font-size: 14px;
        color: #666;
      }

      .btn-open-chat {
        padding: 8px 16px;
        background: #c8a96e;
        color: white;
        border: none;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.3s;
      }

      .btn-open-chat:hover {
        background: #b8985e;
      }

      .chat-tips {
        font-size: 13px;
        color: #666;
      }

      .chat-tips p {
        margin: 0 0 8px;
        font-weight: 600;
      }

      .chat-tips ul {
        margin: 0;
        padding-left: 20px;
      }

      .chat-tips li {
        margin: 4px 0;
      }

      .action-buttons-section {
        margin-top: 24px;
        padding-top: 16px;
        border-top: 2px solid #f0f0f0;
      }

      .action-buttons {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
      }

      .btn-action {
        padding: 12px 20px;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
        display: flex;
        align-items: center;
        gap: 8px;
      }

      .btn-action.btn-primary {
        background: #c8a96e;
        color: white;
      }

      .btn-action.btn-primary:hover {
        background: #b8985e;
      }

      .btn-action.btn-success {
        background: #27ae60;
        color: white;
      }

      .btn-action.btn-success:hover {
        background: #229954;
      }

      .btn-action.btn-secondary {
        background: #3498db;
        color: white;
      }

      .btn-action.btn-secondary:hover {
        background: #2980b9;
      }

      .btn-action.btn-chat {
        background: #f0f0f0;
        color: #333;
      }

      .btn-action.btn-chat:hover {
        background: #e0e0e0;
      }

      @media (max-width: 600px) {
        .order-header-enhanced {
          flex-direction: column;
          align-items: flex-start;
          gap: 12px;
        }

        .order-product-section {
          flex-direction: column;
        }

        .order-product-img {
          width: 100%;
          height: 200px;
        }

        .chat-info {
          flex-direction: column;
          align-items: flex-start;
          gap: 12px;
        }

        .action-buttons {
          flex-direction: column;
        }

        .btn-action {
          width: 100%;
          justify-content: center;
        }
      }
    `;

    document.head.appendChild(style);
  }
}

/**
 * Open order chat
 */
window.openOrderChat = async (orderId, sellerId, buyerEmail) => {
  try {
    // Wait for auth manager to be initialized
    let currentUser = null;
    
    // Try to get current user from auth manager
    if (window.authManager) {
      // Wait for auth manager to be ready
      let waitCount = 0;
      while (!window.authManager._initialized && waitCount < 50) {
        await new Promise(r => setTimeout(r, 100));
        waitCount++;
      }
      
      currentUser = window.authManager.getCurrentUser();
    }
    
    // If no user from auth manager, try to get from Supabase session directly
    if (!currentUser) {
      try {
        const { data: { user } } = await db.auth.getUser();
        if (user) {
          currentUser = {
            id: user.id,
            email: user.email,
            name: user.user_metadata?.name || user.email
          };
        }
      } catch (e) {
        console.warn('[openOrderChat] Could not get Supabase session:', e.message);
      }
    }

    // If still no user, show error
    if (!currentUser) {
      console.error('[openOrderChat] No authenticated user found');
      alert('Please log in to chat');
      window.location.href = 'login.html';
      return;
    }

    console.log('[openOrderChat] Opening chat for user:', currentUser.email);
    console.log('[openOrderChat] Seller ID:', sellerId);
    console.log('[openOrderChat] Order ID:', orderId);

    // Determine if user is buyer or seller
    const isBuyer = currentUser.id !== sellerId;
    const isSeller = currentUser.id === sellerId;

    // Redirect to dashboard chat with conversation ID
    const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
    
    if (isBuyer) {
      // Buyer: Open chat with seller
      // Store conversation info for dashboard to open
      sessionStorage.setItem('openChatWith', JSON.stringify({
        sellerId: sellerId,
        orderId: orderId,
        type: 'buyer-to-seller'
      }));
      window.location.href = `${prefix}dashboard.html#buyer-messages`;
    } else if (isSeller) {
      // Seller: Open chat with buyer
      sessionStorage.setItem('openChatWith', JSON.stringify({
        buyerEmail: buyerEmail,
        orderId: orderId,
        type: 'seller-to-buyer'
      }));
      window.location.href = `${prefix}dashboard.html#seller-messages`;
    } else {
      // Fallback: Just go to messages
      window.location.href = `${prefix}dashboard.html`;
    }

  } catch (error) {
    console.error('[openOrderChat] Error:', error);
    alert('Error opening chat. Please try again.');
  }
};

/**
 * Upload payment proof - Buyer action
 */
window.uploadPaymentProof = async (orderId) => {
  try {
    // Create file input
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = async (e) => {
      const file = e.target.files[0];
      if (!file) return;

      // Validate file
      if (!file.type.startsWith('image/')) {
        showError('Invalid File', 'Please upload an image file.');
        return;
      }

      if (file.size > 5 * 1024 * 1024) {
        showError('File Too Large', 'Maximum file size is 5MB.');
        return;
      }

      try {
        showLoadingModal('Uploading...', 'Please wait while we upload your payment proof.');

        // Upload to Cloudinary if available
        let proofUrl = null;
        if (window.uploadPaymentReceipt) {
          try {
            proofUrl = await window.uploadPaymentReceipt(file, `order-${orderId}`);
            console.log('[uploadPaymentProof] Uploaded to Cloudinary:', proofUrl);
          } catch (uploadErr) {
            console.warn('[uploadPaymentProof] Cloudinary upload failed:', uploadErr.message);
          }
        }

        // If no Cloudinary, use base64 (not recommended for large files)
        if (!proofUrl) {
          const reader = new FileReader();
          reader.onload = async (event) => {
            proofUrl = event.target.result;
            await savePaymentProof(orderId, proofUrl);
          };
          reader.readAsDataURL(file);
          return;
        }

        // Save to database
        await savePaymentProof(orderId, proofUrl);

      } catch (err) {
        hideLoadingModal();
        console.error('[uploadPaymentProof] Error:', err);
        showError('Upload Failed', 'Could not upload payment proof. Please try again.');
      }
    };
    input.click();
  } catch (err) {
    console.error('[uploadPaymentProof] Error:', err);
    showError('Error', 'Could not open file picker.');
  }
};

/**
 * Save payment proof to database
 */
async function savePaymentProof(orderId, proofUrl) {
  try {
    const currentUser = window.authManager?.getCurrentUser();
    if (!currentUser) {
      showError('Not Logged In', 'Please log in to upload payment proof.');
      return;
    }

    // Update order with payment proof and status
    const { error } = await db.from('orders').update({
      payment_proof_url: proofUrl,
      payment_status: 'submitted'
    }).eq('id', orderId);

    if (error) throw error;

    hideLoadingModal();
    showSuccess('Payment Proof Uploaded!', 'Your payment proof has been submitted. Admin will verify it within 24 hours.', 'Got it');

    // Refresh the order details
    setTimeout(() => {
      if (window.orderTracker) {
        window.orderTracker.trackOrder();
      }
    }, 1000);
  } catch (err) {
    hideLoadingModal();
    console.error('[savePaymentProof] Error:', err);
    showError('Error', 'Could not save payment proof. Please try again.');
  }
}

/**
 * Mark order as shipped
 */
window.markOrderShipped = async (orderId) => {
  if (!confirm('Mark this order as shipped?')) return;

  try {
    showLoadingModal('Updating...', 'Marking order as shipped...');

    const { error } = await db.from('orders').update({
      status: 'shipped'
    }).eq('id', orderId);

    if (error) throw error;

    hideLoadingModal();
    showSuccess('Order Shipped!', 'Buyer has been notified.', 'Got it');
    
    // Refresh tracking
    setTimeout(() => {
      if (window.orderTracker) {
        window.orderTracker.trackOrder();
      }
    }, 1000);
  } catch (err) {
    hideLoadingModal();
    console.error('[order-tracking] markOrderShipped error:', err);
    showError('Error', 'Could not update order status.');
  }
};

/**
 * Mark item as sold
 */
window.markItemSold = async (orderId, productId) => {
  if (!confirm('Mark this item as sold? This will close the order.')) return;

  try {
    showLoadingModal('Updating...', 'Marking item as sold...');

    const { error } = await db.from('orders').update({
      status: 'sold'
    }).eq('id', orderId);

    if (error) throw error;

    hideLoadingModal();
    showSuccess('Item Marked as Sold!', 'Order closed successfully.', 'Got it');
    
    // Refresh
    setTimeout(() => {
      if (window.orderTracker) {
        window.orderTracker.trackOrder();
      }
    }, 1000);
  } catch (err) {
    hideLoadingModal();
    console.error('[order-tracking] markItemSold error:', err);
    showError('Error', 'Could not update order status.');
  }
};

/**
 * Seller uploads payment proof (for cases where seller needs to provide proof)
 */
window.sellerUploadPaymentProof = async (orderId) => {
  try {
    // Create file input
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = async (e) => {
      const file = e.target.files[0];
      if (!file) return;

      // Validate file
      if (!file.type.startsWith('image/')) {
        showError('Invalid File', 'Please upload an image file.');
        return;
      }

      if (file.size > 5 * 1024 * 1024) {
        showError('File Too Large', 'Maximum file size is 5MB.');
        return;
      }

      try {
        showLoadingModal('Uploading...', 'Please wait while we upload the payment proof.');

        // Upload to Cloudinary if available
        let proofUrl = null;
        if (window.uploadPaymentReceipt) {
          try {
            proofUrl = await window.uploadPaymentReceipt(file, `order-proof-${orderId}`);
            console.log('[sellerUploadPaymentProof] Uploaded to Cloudinary:', proofUrl);
          } catch (uploadErr) {
            console.warn('[sellerUploadPaymentProof] Cloudinary upload failed:', uploadErr.message);
          }
        }

        // If no Cloudinary, use base64
        if (!proofUrl) {
          const reader = new FileReader();
          reader.onload = async (event) => {
            proofUrl = event.target.result;
            await saveSellerPaymentProof(orderId, proofUrl);
          };
          reader.readAsDataURL(file);
          return;
        }

        // Save to database
        await saveSellerPaymentProof(orderId, proofUrl);

      } catch (err) {
        hideLoadingModal();
        console.error('[sellerUploadPaymentProof] Error:', err);
        showError('Upload Failed', 'Could not upload payment proof. Please try again.');
      }
    };
    input.click();
  } catch (err) {
    console.error('[sellerUploadPaymentProof] Error:', err);
    showError('Error', 'Could not open file picker.');
  }
};

/**
 * Save seller payment proof to database
 */
async function saveSellerPaymentProof(orderId, proofUrl) {
  try {
    const currentUser = window.authManager?.getCurrentUser();
    if (!currentUser) {
      showError('Not Logged In', 'Please log in to upload payment proof.');
      return;
    }

    // Update order with payment proof
    const { error } = await db.from('orders').update({
      payment_proof_url: proofUrl,
      payment_status: 'submitted'
    }).eq('id', orderId);

    if (error) throw error;

    hideLoadingModal();
    showSuccess('Payment Proof Uploaded!', 'The payment proof has been submitted for verification.', 'Got it');

    // Refresh the seller orders list
    setTimeout(() => {
      if (window.loadSellerOrders) {
        window.loadSellerOrders();
      }
    }, 1000);
  } catch (err) {
    hideLoadingModal();
    console.error('[saveSellerPaymentProof] Error:', err);
    showError('Error', 'Could not save payment proof. Please try again.');
  }
}

// Initialize enhanced tracker
document.addEventListener('DOMContentLoaded', () => {
  window.enhancedOrderTracker = new EnhancedOrderTracker();
  console.log('[order-tracking-enhanced] Enhanced order tracking system loaded');
});

console.log('[order-tracking-enhanced] Enhanced order tracking module loaded');
