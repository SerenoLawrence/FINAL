/**
 * ============================================================
 * VIDEO CALL ENGINE - Unified Video Calling System
 * ============================================================
 * 
 * Consolidated from:
 * - video-call.js (VideoCallManager)
 * - video-call-initiator.js (VideoCallInitiator)
 * - incoming-call-handler.js (IncomingCallHandler)
 * - dashboard-video-call-integration.js (DashboardVideoCallIntegration)
 * 
 * IMPORTANT: This engine reuses functions from master-dashboard.js
 * to maintain a single source of truth for video call functionality.
 * 
 * Functions delegated to master-dashboard.js:
 * - vcGenerateRoomId()
 * - vcGetLocalStream()
 * - vcSetStatus()
 * - vcShowOverlay()
 * - vcOnRemoteStream()
 * - vcHangUp()
 * - vcStartPolling()
 * - sellerVcGetLocalStream()
 * - sellerVcSetStatus()
 * - sellerVcShowOverlay()
 * - sellerVcOnRemoteStream()
 * - sellerVcHangUp()
 * 
 * This file provides:
 * - Backward compatibility wrappers
 * - Global instances for legacy code
 */

// ============================================================
// VIDEO CALL ENGINE - Thin wrapper around master-dashboard
// ============================================================

const VideoCallEngine = {
  // Buyer-side video call functions
  generateRoomId: function() {
    if (typeof vcGenerateRoomId === 'function') {
      return vcGenerateRoomId();
    }
    console.warn('[video-call-engine] vcGenerateRoomId not available from master-dashboard');
    return 'room-' + Date.now();
  },

  getLocalStream: function() {
    if (typeof vcGetLocalStream === 'function') {
      return vcGetLocalStream();
    }
    console.warn('[video-call-engine] vcGetLocalStream not available from master-dashboard');
  },

  setStatus: function(connected, text) {
    if (typeof vcSetStatus === 'function') {
      return vcSetStatus(connected, text);
    }
    console.warn('[video-call-engine] vcSetStatus not available from master-dashboard');
  },

  showOverlay: function(name) {
    if (typeof vcShowOverlay === 'function') {
      return vcShowOverlay(name);
    }
    console.warn('[video-call-engine] vcShowOverlay not available from master-dashboard');
  },

  onRemoteStream: function(stream) {
    if (typeof vcOnRemoteStream === 'function') {
      return vcOnRemoteStream(stream);
    }
    console.warn('[video-call-engine] vcOnRemoteStream not available from master-dashboard');
  },

  hangUp: function() {
    if (typeof vcHangUp === 'function') {
      return vcHangUp();
    }
    console.warn('[video-call-engine] vcHangUp not available from master-dashboard');
  },

  startPolling: function() {
    if (typeof vcStartPolling === 'function') {
      return vcStartPolling();
    }
    console.warn('[video-call-engine] vcStartPolling not available from master-dashboard');
  },

  // Seller-side video call functions
  sellerGetLocalStream: function() {
    if (typeof sellerVcGetLocalStream === 'function') {
      return sellerVcGetLocalStream();
    }
    console.warn('[video-call-engine] sellerVcGetLocalStream not available from master-dashboard');
  },

  sellerSetStatus: function(connected, text) {
    if (typeof sellerVcSetStatus === 'function') {
      return sellerVcSetStatus(connected, text);
    }
    console.warn('[video-call-engine] sellerVcSetStatus not available from master-dashboard');
  },

  sellerShowOverlay: function(name) {
    if (typeof sellerVcShowOverlay === 'function') {
      return sellerVcShowOverlay(name);
    }
    console.warn('[video-call-engine] sellerVcShowOverlay not available from master-dashboard');
  },

  sellerOnRemoteStream: function(stream) {
    if (typeof sellerVcOnRemoteStream === 'function') {
      return sellerVcOnRemoteStream(stream);
    }
    console.warn('[video-call-engine] sellerVcOnRemoteStream not available from master-dashboard');
  },

  sellerHangUp: function() {
    if (typeof sellerVcHangUp === 'function') {
      return sellerVcHangUp();
    }
    console.warn('[video-call-engine] sellerVcHangUp not available from master-dashboard');
  }
};

// ============================================================
// Create global instances - delegate to master-dashboard
// ============================================================

window.VideoCallEngine = VideoCallEngine;

// Backward compatibility - delegate to master-dashboard functions
window.videoCallManager = {
  generateRoomId: () => VideoCallEngine.generateRoomId(),
  getLocalStream: () => VideoCallEngine.getLocalStream(),
  setStatus: (c, t) => VideoCallEngine.setStatus(c, t),
  showOverlay: (n) => VideoCallEngine.showOverlay(n),
  onRemoteStream: (s) => VideoCallEngine.onRemoteStream(s),
  hangUp: () => VideoCallEngine.hangUp(),
  startPolling: () => VideoCallEngine.startPolling()
};

window.incomingCallHandler = window.videoCallManager;
window.videoCallInitiator = window.videoCallManager;
window.dashboardVideoCallIntegration = window.videoCallManager;

// Backward compatibility - delegate to master-dashboard functions
window.vcGenerateRoomId = function() {
  if (typeof vcGenerateRoomId === 'function') {
    return vcGenerateRoomId();
  }
  return VideoCallEngine.generateRoomId();
};

window.vcGetLocalStream = function() {
  if (typeof vcGetLocalStream === 'function') {
    return vcGetLocalStream();
  }
  return VideoCallEngine.getLocalStream();
};

window.vcSetStatus = function(connected, text) {
  if (typeof vcSetStatus === 'function') {
    return vcSetStatus(connected, text);
  }
  return VideoCallEngine.setStatus(connected, text);
};

window.vcShowOverlay = function(name) {
  if (typeof vcShowOverlay === 'function') {
    return vcShowOverlay(name);
  }
  return VideoCallEngine.showOverlay(name);
};

window.vcOnRemoteStream = function(stream) {
  if (typeof vcOnRemoteStream === 'function') {
    return vcOnRemoteStream(stream);
  }
  return VideoCallEngine.onRemoteStream(stream);
};

window.vcHangUp = function() {
  if (typeof vcHangUp === 'function') {
    return vcHangUp();
  }
  return VideoCallEngine.hangUp();
};

window.vcStartPolling = function() {
  if (typeof vcStartPolling === 'function') {
    return vcStartPolling();
  }
  return VideoCallEngine.startPolling();
};

// Seller-side functions
window.sellerVcGetLocalStream = function() {
  if (typeof sellerVcGetLocalStream === 'function') {
    return sellerVcGetLocalStream();
  }
  return VideoCallEngine.sellerGetLocalStream();
};

window.sellerVcSetStatus = function(connected, text) {
  if (typeof sellerVcSetStatus === 'function') {
    return sellerVcSetStatus(connected, text);
  }
  return VideoCallEngine.sellerSetStatus(connected, text);
};

window.sellerVcShowOverlay = function(name) {
  if (typeof sellerVcShowOverlay === 'function') {
    return sellerVcShowOverlay(name);
  }
  return VideoCallEngine.sellerShowOverlay(name);
};

window.sellerVcOnRemoteStream = function(stream) {
  if (typeof sellerVcOnRemoteStream === 'function') {
    return sellerVcOnRemoteStream(stream);
  }
  return VideoCallEngine.sellerOnRemoteStream(stream);
};

window.sellerVcHangUp = function() {
  if (typeof sellerVcHangUp === 'function') {
    return sellerVcHangUp();
  }
  return VideoCallEngine.sellerHangUp();
};

console.log('[video-call-engine] Video call engine loaded - delegating to master-dashboard');
