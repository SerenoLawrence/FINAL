// ============================================================
// seller-profile.js — Public seller profile page
// Tabs: Shop | Reviews | About
// ============================================================

const params   = new URLSearchParams(window.location.search);
const sellerId = params.get('id');

let _allReviews = [];

// ── TAB SWITCHING ──────────────────────────────────────────
window.switchTab = function(tab, btn) {
  ['shop','reviews','about'].forEach(t => {
    const el = document.getElementById('tab-' + t);
    if (el) el.style.display = t === tab ? 'block' : 'none';
  });
  document.querySelectorAll('.sp-tab').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
};

// ── REVIEW FILTER ─────────────────────────────────────────
window.filterReviews = function(type, btn) {
  document.querySelectorAll('.sp-filter-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  const filtered = type === 'all'
    ? _allReviews
    : _allReviews.filter(r => (r.rating >= 3 ? 'positive' : 'negative') === type);
  renderReviews(filtered);
};

// ── LOAD PROFILE ──────────────────────────────────────────
async function loadSellerProfile() {
  if (!sellerId) {
    showError('Not Found', 'Seller not found.');
    return;
  }

  try {
    // Fetch seller record
    const { data: seller, error } = await db
      .from('sellers')
      .select('*')
      .eq('id', sellerId)
      .single();

    if (error || !seller) {
      document.getElementById('spName').textContent = 'Seller not found';
      return;
    }

    // Update page title + breadcrumb
    document.title = `${seller.business_name} - REWEAR`;

    // Avatar
    const avatarEl = document.getElementById('spAvatar');
    if (seller.avatar_url) {
      avatarEl.innerHTML = `<img src="${seller.avatar_url}" alt="${seller.business_name}">`;
    } else {
      avatarEl.textContent = seller.business_name.charAt(0).toUpperCase();
    }

    // Name
    document.getElementById('spName').textContent = seller.business_name;

    // Verified badge
    if (seller.verified) {
      document.getElementById('spVerifiedBadge').style.display = 'flex';
      document.getElementById('spVerifiedLabel').style.display = 'flex';
    }

    // About tab
    document.getElementById('spDescription').textContent =
      seller.description || 'No description provided.';
    if (seller.created_at) {
      const joined = new Date(seller.created_at).toLocaleDateString('en-PH', {
        year: 'numeric', month: 'long', day: 'numeric'
      });
      document.getElementById('spRegistered').textContent = `Registered: ${joined}`;
    }

    // Message button
    document.getElementById('spMsgBtn').onclick = () => openInquiryModal(sellerId, seller.business_name);

    // Load listings + reviews + ratings in parallel
    await Promise.all([
      loadListings(),
      loadReviews(),
      loadSellerRatings()
    ]);

  } catch (err) {
    console.error('[seller-profile]', err);
    document.getElementById('spName').textContent = 'Could not load profile';
  }
}

// ── LOAD LISTINGS ─────────────────────────────────────────
async function loadListings() {
  const grid = document.getElementById('spProductsGrid');

  const { data: products, error } = await db
    .from('products')
    .select('id, name, price, image_url, sizes, rating, in_stock')
    .eq('seller_id', sellerId)
    .eq('status', 'approved')
    .eq('in_stock', true)
    .order('created_at', { ascending: false });

  const count = products?.length || 0;
  const countEl = document.getElementById('spListingCount');
  if (countEl) countEl.textContent = `(${count})`;
  document.getElementById('spStatListings').textContent = count;

  if (error || !count) {
    grid.innerHTML = `
      <div class="sp-empty" style="grid-column:1/-1;">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" width="48" height="48" stroke-width="1.5">
          <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/>
        </svg>
        <p>No active listings yet.</p>
      </div>`;
    return;
  }

  const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
  grid.innerHTML = products.map(p => `
    <div class="sp-product-card" onclick="location.href='${prefix}product.html?id=${p.id}'">
      <img src="${p.image_url || 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%22100%22%3E%3Crect fill=%22%23f0f0f0%22 width=%22100%22 height=%22100%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2214%22 fill=%22%23999%22 text-anchor=%22middle%22 dy=%22.3em%22%3ENo Image%3C/text%3E%3C/svg%3E'}" alt="${p.name}" loading="lazy">
      <div class="sp-product-info">
        <p class="sp-product-name">${p.name}</p>
        <p class="sp-product-price">&#8369;${parseFloat(p.price).toFixed(2)}</p>
      </div>
    </div>`).join('');
}

// ── LOAD REVIEWS ──────────────────────────────────────────
async function loadReviews() {
  const { data: reviews, error } = await db
    .from('reviews')
    .select('id, rating, comment, photo_url, created_at, buyer_email, products(name)')
    .eq('seller_id', sellerId)
    .order('created_at', { ascending: false });

  _allReviews = reviews || [];
  const count = _allReviews.length;

  // Rating percentage (positive = rating >= 3)
  const positive = _allReviews.filter(r => r.rating >= 3).length;
  const pct = count > 0 ? ((positive / count) * 100).toFixed(1) : null;

  document.getElementById('spRatingPct').textContent = pct ? `${pct}%` : '—';
  document.getElementById('spReviewCount').textContent = `${count} review${count !== 1 ? 's' : ''}`;
  document.getElementById('spStatReviews').textContent = count;

  // Avg rating for About tab
  if (count > 0) {
    const avg = (_allReviews.reduce((s, r) => s + r.rating, 0) / count).toFixed(1);
    document.getElementById('spStatRating').textContent = avg;
  }

  renderReviews(_allReviews);
}

// ── LOAD SELLER RATINGS (FROM VERIFIED BUYERS) ───────────
async function loadSellerRatings() {
  try {
    // Get all ratings for this seller
    const { data: ratings, error } = await db
      .from('seller_ratings')
      .select('vote_type, verified_purchase')
      .eq('seller_id', sellerId);

    if (error) throw error;

    const likes = ratings?.filter(r => r.vote_type === 'like').length || 0;
    const dislikes = ratings?.filter(r => r.vote_type === 'dislike').length || 0;
    const total = likes + dislikes;

    // Update the rating percentage display
    if (total > 0) {
      const trustScore = Math.round((likes / total) * 100);
      const currentPct = document.getElementById('spRatingPct');
      if (currentPct) {
        currentPct.textContent = `${trustScore}%`;
        currentPct.title = `${likes} trustworthy, ${dislikes} not responsive (from verified buyers)`;
      }
    }

    console.log(`[seller-ratings] Loaded: ${likes} likes, ${dislikes} dislikes (${total} verified buyers)`);
  } catch (err) {
    console.error('[seller-ratings]', err);
  }
}

function renderReviews(list) {
  const container = document.getElementById('spReviewsList');

  if (!list || list.length === 0) {
    container.innerHTML = `
      <div class="sp-empty">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" width="48" height="48" stroke-width="1.5">
          <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
        </svg>
        <p>No reviews yet.</p>
      </div>`;
    return;
  }

  container.innerHTML = list.map(r => {
    const stars     = '&#9733;'.repeat(r.rating) + '<span style="color:#ddd;">' + '&#9733;'.repeat(5 - r.rating) + '</span>';
    const masked    = r.buyer_email.replace(/(.{2}).*(@.*)/, '$1***$2');
    const initial   = r.buyer_email[0].toUpperCase();
    const avatarBg  = r.rating >= 3 ? '#c8a96e' : '#e74c3c';
    const product   = r.products?.name || '';
    const date      = new Date(r.created_at).toLocaleDateString('en-PH', { year:'numeric', month:'short', day:'numeric' });

    return `
      <div class="sp-review-card" data-type="${r.rating >= 3 ? 'positive' : 'negative'}">
        <div class="sp-review-top">
          <div class="sp-review-buyer">
            <div class="sp-review-avatar" style="background:${avatarBg};">${initial}</div>
            <div>
              <div class="sp-review-buyer-name">${masked}</div>
              ${product ? `<div class="sp-review-product">on ${product}</div>` : ''}
            </div>
          </div>
          <div style="text-align:right;">
            <div class="sp-review-stars">${stars}</div>
            <div class="sp-review-date">${date}</div>
          </div>
        </div>
        ${product ? `<span class="sp-product-tag">${product}</span>` : ''}
        ${r.comment ? `<p class="sp-review-comment">"${r.comment}"</p>` : ''}
        ${r.photo_url ? `<img src="${r.photo_url}" class="sp-review-photo" alt="Review photo" onclick="window.open('${r.photo_url}','_blank')">` : ''}
      </div>`;
  }).join('');
}

// ── INQUIRY MODAL ─────────────────────────────────────────
// Consolidated in core.js - uses window.openInquiryModal() and window.submitInquiry()
// These functions are now shared across all pages (seller-profile, product, etc.)

// ── INIT ──────────────────────────────────────────────────
loadSellerProfile();
