/**
 * PWA Install Prompt Manager
 * Handles install banners for Android Chrome + Desktop
 * Shows custom install UI when PWA criteria are met
 */

class PWAInstallManager {
  constructor() {
    this.deferredPrompt = null;
    this.isInstalled = false;
    this.platform = this.detectPlatform();
    this.init();
  }

  /**
   * Detect user's platform
   */
  detectPlatform() {
    const ua = navigator.userAgent.toLowerCase();
    const isAndroid = /android/.test(ua);
    const isChrome = /chrome/.test(ua) && !/edg/.test(ua);
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches ||
                         window.navigator.standalone === true;

    return {
      isAndroid,
      isChrome,
      isStandalone,
      isMobile: /mobile|android/.test(ua),
      isDesktop: !/mobile|android|iphone|ipad/.test(ua)
    };
  }

  /**
   * Initialize PWA install manager
   */
  init() {
    console.log('[PWA] Initializing install manager...', this.platform);

    // Check if already installed
    if (this.platform.isStandalone) {
      console.log('[PWA] App is already installed');
      this.isInstalled = true;
      this.hideInstallPrompts();
      return;
    }

    // Listen for beforeinstallprompt event (Android Chrome)
    window.addEventListener('beforeinstallprompt', (e) => {
      console.log('[PWA] beforeinstallprompt event fired');
      e.preventDefault(); // Prevent default mini-infobar
      this.deferredPrompt = e;
      this.showInstallBanner();
    });

    // Listen for app installed event
    window.addEventListener('appinstalled', () => {
      console.log('[PWA] App installed successfully');
      this.isInstalled = true;
      this.hideInstallPrompts();
      this.showInstalledToast();
    });

    // Check if user dismissed install prompt before
    const dismissed = localStorage.getItem('pwa_install_dismissed');
    const dismissedTime = dismissed ? parseInt(dismissed) : 0;
    const daysSinceDismissed = (Date.now() - dismissedTime) / (1000 * 60 * 60 * 24);

    // Show install prompt again after 7 days
    if (dismissed && daysSinceDismissed < 7) {
      console.log('[PWA] Install prompt was dismissed recently, waiting...');
      return;
    }

    // For desktop browsers without beforeinstallprompt, show manual instructions
    if (this.platform.isDesktop && !this.deferredPrompt) {
      setTimeout(() => {
        if (!this.isInstalled && !this.deferredPrompt) {
          this.showDesktopInstallInstructions();
        }
      }, 5000); // Show after 5 seconds
    }
  }

  /**
   * Show install banner (Android Chrome)
   */
  showInstallBanner() {
    // Don't show if already dismissed recently
    const dismissed = localStorage.getItem('pwa_install_dismissed');
    if (dismissed) {
      const daysSince = (Date.now() - parseInt(dismissed)) / (1000 * 60 * 60 * 24);
      if (daysSince < 7) return;
    }

    // Create install banner
    const banner = document.createElement('div');
    banner.id = 'pwa-install-banner';
    banner.className = 'pwa-install-banner slide-in-up';
    banner.innerHTML = `
      <div class="pwa-banner-content">
        <div class="pwa-banner-icon">
          <i class="fas fa-mobile-alt"></i>
        </div>
        <div class="pwa-banner-text">
          <h4>Install ReWear App</h4>
          <p>Get quick access and offline support</p>
        </div>
        <div class="pwa-banner-actions">
          <button class="pwa-btn-dismiss" id="pwa-dismiss-btn">Later</button>
          <button class="pwa-btn-install" id="pwa-install-btn">Install</button>
        </div>
      </div>
    `;

    document.body.appendChild(banner);

    // Add event listeners
    document.getElementById('pwa-install-btn').addEventListener('click', () => {
      this.promptInstall();
    });

    document.getElementById('pwa-dismiss-btn').addEventListener('click', () => {
      this.dismissInstallBanner();
    });

    // Auto-hide after 15 seconds
    setTimeout(() => {
      if (document.getElementById('pwa-install-banner')) {
        this.dismissInstallBanner();
      }
    }, 15000);
  }

  /**
   * Show desktop install instructions
   */
  showDesktopInstallInstructions() {
    const modal = document.createElement('div');
    modal.id = 'pwa-desktop-modal';
    modal.className = 'pwa-modal fade-in';
    modal.innerHTML = `
      <div class="pwa-modal-overlay" id="pwa-modal-overlay"></div>
      <div class="pwa-modal-content pop-in">
        <button class="pwa-modal-close" id="pwa-modal-close">
          <i class="fas fa-times"></i>
        </button>
        <div class="pwa-modal-icon">
          <i class="fas fa-laptop"></i>
        </div>
        <h3>Install ReWear on Desktop</h3>
        <p>Get the full app experience with offline access and quick launch.</p>
        
        <div class="pwa-install-steps">
          <div class="pwa-step">
            <div class="pwa-step-number">1</div>
            <div class="pwa-step-text">
              <strong>Click the install icon</strong>
              <span>Look for the install icon in your browser's address bar</span>
            </div>
          </div>
          <div class="pwa-step">
            <div class="pwa-step-number">2</div>
            <div class="pwa-step-text">
              <strong>Or use the menu</strong>
              <span>Chrome: Menu → Install ReWear<br>Edge: Menu → Apps → Install this site as an app</span>
            </div>
          </div>
          <div class="pwa-step">
            <div class="pwa-step-number">3</div>
            <div class="pwa-step-text">
              <strong>Launch from desktop</strong>
              <span>Find the ReWear icon on your desktop or start menu</span>
            </div>
          </div>
        </div>

        <button class="pwa-btn-primary" id="pwa-got-it-btn">Got it!</button>
      </div>
    `;

    document.body.appendChild(modal);

    // Close handlers
    const closeModal = () => {
      modal.classList.add('fade-out');
      setTimeout(() => modal.remove(), 300);
      localStorage.setItem('pwa_install_dismissed', Date.now().toString());
    };

    document.getElementById('pwa-modal-close').addEventListener('click', closeModal);
    document.getElementById('pwa-modal-overlay').addEventListener('click', closeModal);
    document.getElementById('pwa-got-it-btn').addEventListener('click', closeModal);
  }

  /**
   * Prompt user to install PWA
   */
  async promptInstall() {
    if (!this.deferredPrompt) {
      console.log('[PWA] No deferred prompt available');
      return;
    }

    // Show native install prompt
    this.deferredPrompt.prompt();

    // Wait for user choice
    const { outcome } = await this.deferredPrompt.userChoice;
    console.log('[PWA] User choice:', outcome);

    if (outcome === 'accepted') {
      console.log('[PWA] User accepted install');
    } else {
      console.log('[PWA] User dismissed install');
      localStorage.setItem('pwa_install_dismissed', Date.now().toString());
    }

    // Clear deferred prompt
    this.deferredPrompt = null;
    this.hideInstallPrompts();
  }

  /**
   * Dismiss install banner
   */
  dismissInstallBanner() {
    const banner = document.getElementById('pwa-install-banner');
    if (banner) {
      banner.classList.add('slide-out-down');
      setTimeout(() => banner.remove(), 300);
    }
    localStorage.setItem('pwa_install_dismissed', Date.now().toString());
  }

  /**
   * Hide all install prompts
   */
  hideInstallPrompts() {
    const banner = document.getElementById('pwa-install-banner');
    const modal = document.getElementById('pwa-desktop-modal');
    if (banner) banner.remove();
    if (modal) modal.remove();
  }

  /**
   * Show installed toast notification
   */
  showInstalledToast() {
    const toast = document.createElement('div');
    toast.className = 'pwa-toast slide-in-up';
    toast.innerHTML = `
      <div class="pwa-toast-content">
        <i class="fas fa-check pwa-toast-icon"></i>
        <span class="pwa-toast-text">ReWear installed successfully!</span>
      </div>
    `;

    document.body.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('slide-out-down');
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  /**
   * Check if app can be installed
   */
  canInstall() {
    return !this.isInstalled && (this.deferredPrompt !== null || this.platform.isDesktop);
  }

  /**
   * Manually trigger install prompt (for install buttons in UI)
   */
  triggerInstall() {
    if (this.deferredPrompt) {
      this.promptInstall();
    } else if (this.platform.isDesktop) {
      this.showDesktopInstallInstructions();
    } else {
      console.log('[PWA] Install not available on this platform');
    }
  }
}

// Create global instance
const pwaInstallManager = new PWAInstallManager();
window.pwaInstallManager = pwaInstallManager;

// Add install button click handler for any install buttons in the UI
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('[data-pwa-install]').forEach((btn) => {
    btn.addEventListener('click', () => {
      pwaInstallManager.triggerInstall();
    });
  });
});

console.log('[PWA] Install manager loaded');
