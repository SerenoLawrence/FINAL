// ============================================================
// nav-dropdown.js — Navigation Dropdown Handler
// Handles guest and user dropdown menus for Eldorado-style nav
// ============================================================

function initNavDropdown() {
  // Guest Menu Toggle
  const guestMenuToggle = document.getElementById('guestMenuToggle');
  const guestDropdownMenu = document.getElementById('guestDropdownMenu');
  
  if (guestMenuToggle && guestDropdownMenu) {
    console.log('[nav-dropdown] Guest menu initialized');
    
    // Toggle dropdown on button click
    guestMenuToggle.addEventListener('click', (e) => {
      e.stopPropagation();
      console.log('[nav-dropdown] Hamburger clicked!');
      guestDropdownMenu.classList.toggle('visible');
      console.log('[nav-dropdown] Menu classes:', guestDropdownMenu.className);
      console.log('[nav-dropdown] Menu visible:', guestDropdownMenu.classList.contains('visible'));
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (!guestMenuToggle.contains(e.target) && !guestDropdownMenu.contains(e.target)) {
        guestDropdownMenu.classList.remove('visible');
      }
    });
    
    // Close dropdown when clicking on a menu item
    const guestItems = guestDropdownMenu.querySelectorAll('.nav-dropdown-item');
    guestItems.forEach(item => {
      item.addEventListener('click', () => {
        guestDropdownMenu.classList.remove('visible');
      });
    });
  }
  
  // User Profile Dropdown
  const userProfileToggle = document.getElementById('userProfileToggle');
  const userDropdownMenu = document.getElementById('userDropdownMenu');
  
  if (userProfileToggle && userDropdownMenu) {
    // Toggle dropdown on button click
    userProfileToggle.addEventListener('click', (e) => {
      e.stopPropagation();
      userDropdownMenu.classList.toggle('visible');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (!userProfileToggle.contains(e.target) && !userDropdownMenu.contains(e.target)) {
        userDropdownMenu.classList.remove('visible');
      }
    });
    
    // Close dropdown when clicking on a menu item
    const userItems = userDropdownMenu.querySelectorAll('.dropdown-item');
    userItems.forEach(item => {
      item.addEventListener('click', () => {
        userDropdownMenu.classList.remove('visible');
      });
    });
  }
  
  // Notification Panel Toggle
  const notificationBtn = document.getElementById('notificationBtn');
  const notificationPanel = document.getElementById('notificationPanel');
  const notificationCloseBtn = document.getElementById('notificationCloseBtn');
  
  if (notificationBtn && notificationPanel) {
    // Toggle notification panel on button click
    notificationBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      notificationPanel.classList.toggle('visible');
    });
    
    // Close notification panel when clicking close button
    if (notificationCloseBtn) {
      notificationCloseBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        notificationPanel.classList.remove('visible');
      });
    }
    
    // Close notification panel when clicking outside
    document.addEventListener('click', (e) => {
      if (!notificationBtn.contains(e.target) && !notificationPanel.contains(e.target)) {
        notificationPanel.classList.remove('visible');
      }
    });
  }
}

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', initNavDropdown);

// Also initialize immediately if DOM is already ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initNavDropdown);
} else {
  initNavDropdown();
}
