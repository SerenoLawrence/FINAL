/**
 * Notification Center Module for REWEAR
 * Manages all user notifications with real-time updates
 * 
 * RESPONSIBILITY: UI rendering, realtime updates, toast display, user actions
 * 
 * DOES:
 * - Create and manage notification UI
 * - Listen to realtime database changes
 * - Display toast popups for new notifications
 * - Handle user actions (mark as read, delete)
 * - Update badge counts
 * 
 * DOES NOT:
 * - Insert notifications into database (handled by NotificationManager)
 */

class NotificationCenter {
  constructor() {
    this.notifications = [];
    this.unreadCount = 0;
    this.currentUserId = null;
    this.subscription = null;
  }

  /**
   * Initialize notification center
   */
  async init(userId) {
    this.currentUserId = userId;
    
    // Create notification UI
    this.createNotificationUI();
    
    // Load existing notifications
    await this.loadNotifications();
    
    // Subscribe to real-time updates
    this.subscribeToNotifications();
    
    // Update badge
    this.updateBadge();
  }

  /**
   * Create notification UI elements - ONLY ONCE
   */
  createNotificationUI() {
    // Global guard to prevent duplicate UI
    if (window.__notificationUIInitialized) {
      console.log('[notification-center] UI already initialized globally, skipping');
      return;
    }

    // Check if already created in DOM
    if (document.getElementById('notification-center-container')) {
      console.log('[notification-center] UI container already exists in DOM, skipping');
      window.__notificationUIInitialized = true;
      // Attach event listeners if not already attached
      if (!window.__notificationListenersAttached) {
        this.attachEventListeners();
      }
      return;
    }

    console.log('[notification-center] Creating notification UI...');

    const html = `
      <!-- Notification Center Container -->
      <div id="notification-center-container">
        <!-- Notification Bell Icon (in header) - Always visible -->
        <button id="notification-bell" class="notification-bell" title="Notifications" style="display: flex;">
          <i class="fas fa-bell bell-icon"></i>
          <span class="notification-badge" id="notification-badge" style="display: none;">0</span>
        </button>

        <!-- Mobile Overlay (closes panel when clicked) -->
        <div id="notification-overlay" class="notification-overlay hidden"></div>

        <!-- Notification Panel -->
        <div id="notification-panel" class="notification-panel hidden">
          <!-- Panel Header -->
          <div class="notification-panel-header">
            <div class="header-top">
              <h3>Notifications</h3>
              <button id="close-panel-btn" class="close-panel-btn" title="Close">
                <i class="fas fa-times"></i>
              </button>
            </div>
            <div class="header-status">
              <span class="status-dot"></span>
              <span class="status-text">Connected</span>
            </div>
          </div>

          <!-- Mark all as read -->
          <div class="mark-all-section">
            <button id="mark-all-read-btn" class="mark-all-read-btn" title="Mark all as read">
              Mark all as Read
            </button>
          </div>

          <!-- Notification List -->
          <div id="notification-list" class="notification-list">
            <div class="notification-empty">
              <i class="fas fa-inbox empty-icon"></i>
              <h2>You're all caught up!</h2>
              <p>You have no new notifications.<br>Notifications are deleted after 30 days</p>
            </div>
          </div>

          <!-- Panel Footer -->
          <div class="notification-panel-footer">
            <button id="view-all-notifications-btn" class="view-all-btn">
              View all (0)
            </button>
          </div>
        </div>

        <!-- Notification Toast (for new notifications) -->
        <div id="notification-toast" class="notification-toast hidden">
          <div class="toast-content">
            <i class="fas fa-bell toast-icon"></i>
            <div class="toast-text">
              <div class="toast-title" id="toast-title"></div>
              <div class="toast-message" id="toast-message"></div>
            </div>
            <button class="toast-close-btn" onclick="this.parentElement.parentElement.classList.add('hidden')">
              <i class="fas fa-times"></i>
            </button>
          </div>
        </div>
      </div>

      <style>
        /* Notification Center Styles - Eldorado Theme */
        #notification-center-container {
          position: relative;
          display: flex;
          align-items: center;
          height: 100%;
        }

        /* Mobile Overlay */
        .notification-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.5);
          z-index: 9998;
          display: none;
        }

        .notification-overlay.hidden {
          display: none !important;
        }

        @media (max-width: 768px) {
          .notification-overlay {
            display: block;
          }

          .notification-overlay.hidden {
            display: none !important;
          }
        }

        .notification-bell {
          position: relative;
          background: none;
          border: none;
          font-size: 24px;
          cursor: pointer;
          padding: 8px;
          border-radius: 8px;
          transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
          color: #cccccc;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          min-width: 40px !important;
          min-height: 40px !important;
          z-index: 100 !important;
        }

        .notification-bell:hover {
          background: rgba(200, 169, 110, 0.15);
          color: #c8a96e;
          transform: scale(1.05);
        }

        .notification-badge {
          position: absolute;
          top: 0;
          right: 0;
          background: #c8a96e;
          color: #1a1a1a;
          border-radius: 50%;
          width: 24px;
          height: 24px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: 700;
          box-shadow: 0 2px 8px rgba(200, 169, 110, 0.3);
        }

        /* Notification Panel - Eldorado Style */
        .notification-panel {
          position: absolute;
          top: 100%;
          right: 0;
          width: 420px;
          max-height: 700px;
          background: #1a1a1a;
          border-radius: 12px;
          box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
          z-index: 1000;
          display: flex;
          flex-direction: column;
          margin-top: 12px;
          border: 1px solid #2a2a2a;
          overflow: hidden;
          animation: panelSlideIn 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          visibility: visible !important;
          opacity: 1 !important;
        }

        @keyframes panelSlideIn {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .notification-panel.hidden {
          display: none;
        }

        .notification-panel-header {
          padding: 16px;
          border-bottom: 1px solid #2a2a2a;
          background: #1a1a1a;
        }

        .header-top {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 12px;
        }

        .notification-panel-header h3 {
          margin: 0;
          font-size: 18px;
          font-weight: 600;
          color: #ffffff;
          letter-spacing: 0.5px;
        }

        .close-panel-btn {
          background: none;
          border: none;
          cursor: pointer;
          font-size: 20px;
          color: #999999;
          padding: 0;
          width: 32px;
          height: 32px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 6px;
          transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .close-panel-btn:hover {
          background: rgba(200, 169, 110, 0.1);
          color: #c8a96e;
          transform: scale(1.1);
        }

        .header-status {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 13px;
          color: #999999;
          font-weight: 500;
        }

        .status-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #27ae60;
          box-shadow: 0 0 8px rgba(39, 174, 96, 0.4);
        }

        .mark-all-section {
          padding: 12px 16px;
          border-bottom: 1px solid #2a2a2a;
          text-align: center;
        }

        .mark-all-read-btn {
          background: none;
          border: none;
          cursor: pointer;
          font-size: 13px;
          color: #c8a96e;
          padding: 0;
          text-decoration: none;
          transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
          font-weight: 500;
          letter-spacing: 0.3px;
        }

        .mark-all-read-btn:hover {
          color: #d4b896;
          text-decoration: underline;
        }

        .notification-list {
          flex: 1;
          overflow-y: auto;
          max-height: 450px;
          background: #1a1a1a;
        }

        .notification-list::-webkit-scrollbar {
          width: 6px;
        }

        .notification-list::-webkit-scrollbar-track {
          background: transparent;
        }

        .notification-list::-webkit-scrollbar-thumb {
          background: #3a3a3a;
          border-radius: 3px;
        }

        .notification-list::-webkit-scrollbar-thumb:hover {
          background: #4a4a4a;
        }

        .notification-item {
          padding: 12px 16px;
          border-bottom: 1px solid #2a2a2a;
          cursor: pointer;
          transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
          display: flex;
          gap: 12px;
          align-items: flex-start;
          position: relative;
        }

        .notification-item:hover {
          background: rgba(200, 169, 110, 0.08);
        }

        .notification-item.unread {
          background: rgba(200, 169, 110, 0.12);
        }

        .notification-icon {
          font-size: 20px;
          flex-shrink: 0;
          margin-top: 2px;
          background: linear-gradient(135deg, #c8a96e 0%, #a0845f 100%);
          width: 40px;
          height: 40px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #1a1a1a;
          font-weight: 600;
          box-shadow: 0 2px 8px rgba(200, 169, 110, 0.2);
        }

        .notification-content {
          flex: 1;
          min-width: 0;
        }

        .notification-title {
          font-weight: 600;
          color: #ffffff;
          font-size: 14px;
          margin-bottom: 4px;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .unread-indicator {
          display: inline-block;
          width: 8px;
          height: 8px;
          background: #c8a96e;
          border-radius: 50%;
          flex-shrink: 0;
          animation: pulse 2s infinite;
        }

        @keyframes pulse {
          0%, 100% {
            opacity: 1;
          }
          50% {
            opacity: 0.5;
          }
        }

        .notification-message {
          color: #cccccc;
          font-size: 13px;
          line-height: 1.4;
          margin-bottom: 6px;
        }

        .notification-time {
          font-size: 12px;
          color: #999999;
        }

        .notification-item .close-item-btn {
          position: absolute;
          top: 8px;
          right: 8px;
          background: none;
          border: none;
          cursor: pointer;
          font-size: 16px;
          color: #666666;
          padding: 4px;
          opacity: 0;
          transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
          border-radius: 4px;
        }

        .notification-item:hover .close-item-btn {
          opacity: 1;
          color: #c8a96e;
        }

        .notification-item .close-item-btn:hover {
          background: rgba(200, 169, 110, 0.1);
        }

        .notification-empty {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 80px 30px 60px;
          color: #666666;
          text-align: center;
          min-height: 400px;
        }

        .empty-icon {
          font-size: 80px;
          margin-bottom: 24px;
          opacity: 0.6;
          filter: drop-shadow(0 2px 4px rgba(200, 169, 110, 0.15));
          color: #c8a96e;
          width: 80px;
          height: 80px;
          stroke: #c8a96e;
        }

        .notification-empty h2 {
          font-size: 22px;
          font-weight: 600;
          color: #ffffff;
          margin: 0 0 12px 0;
          line-height: 1.3;
          letter-spacing: 0.3px;
        }

        .notification-empty p {
          font-size: 13px;
          color: #999999;
          margin: 0;
          line-height: 1.6;
        }

        .notification-panel-footer {
          padding: 16px;
          border-top: 1px solid #2a2a2a;
          text-align: center;
          background: #1a1a1a;
        }

        .view-all-btn {
          background: transparent;
          border: 1px solid #3a3a3a;
          cursor: pointer;
          color: #c8a96e;
          font-size: 14px;
          font-weight: 600;
          padding: 12px 24px;
          border-radius: 8px;
          transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
          width: 100%;
          letter-spacing: 0.3px;
        }

        .view-all-btn:hover {
          background: rgba(200, 169, 110, 0.1);
          border-color: #c8a96e;
          color: #d4b896;
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(200, 169, 110, 0.15);
        }

        /* Notification Toast */
        .notification-toast {
          position: fixed;
          top: 20px;
          right: 20px;
          background: #1a1a1a;
          border-radius: 12px;
          box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
          z-index: 2000;
          max-width: 380px;
          border: 1px solid #2a2a2a;
          border-left: 4px solid #c8a96e;
          animation: toastSlideIn 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        @keyframes toastSlideIn {
          from {
            transform: translateX(400px);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }

        .notification-toast.hidden {
          display: none;
        }

        .toast-content {
          display: flex;
          gap: 12px;
          align-items: flex-start;
          padding: 16px;
        }

        .toast-icon {
          font-size: 24px;
          flex-shrink: 0;
          color: #c8a96e;
        }

        .toast-text {
          flex: 1;
          min-width: 0;
        }

        .toast-title {
          font-weight: 600;
          color: #ffffff;
          font-size: 14px;
          margin-bottom: 4px;
        }

        .toast-message {
          color: #cccccc;
          font-size: 13px;
          line-height: 1.4;
        }

        .toast-close-btn {
          background: none;
          border: none;
          cursor: pointer;
          font-size: 18px;
          color: #999999;
          padding: 0;
          flex-shrink: 0;
          transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
          border-radius: 4px;
        }

        .toast-close-btn:hover {
          color: #c8a96e;
          background: rgba(200, 169, 110, 0.1);
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
          .notification-panel {
            position: fixed !important;
            top: 0 !important;
            right: 0 !important;
            left: 0 !important;
            bottom: 0 !important;
            width: 100% !important;
            max-width: 100% !important;
            height: 100vh !important;
            max-height: 100vh !important;
            border-radius: 0 !important;
            margin-top: 0 !important;
            z-index: 9999 !important;
            display: flex !important;
            flex-direction: column !important;
            animation: panelSlideInMobile 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
            background: #1a1a1a !important;
            border: none !important;
            box-shadow: none !important;
          }

          .notification-panel.hidden {
            display: none !important;
          }

          @keyframes panelSlideInMobile {
            from {
              transform: translateY(100%);
              opacity: 0;
            }
            to {
              transform: translateY(0);
              opacity: 1;
            }
          }

          .notification-list {
            max-height: calc(100vh - 200px) !important;
            flex: 1 !important;
            overflow-y: auto !important;
          }

          .notification-panel-header {
            padding: 16px !important;
            position: sticky !important;
            top: 0 !important;
            z-index: 10 !important;
            background: #1a1a1a !important;
            border-bottom: 1px solid #2a2a2a !important;
          }

          .notification-panel-header h3 {
            font-size: 18px !important;
          }

          .notification-item {
            padding: 14px 16px !important;
            border-bottom: 1px solid #2a2a2a !important;
          }

          .notification-icon {
            width: 40px !important;
            height: 40px !important;
            font-size: 18px !important;
          }

          .notification-title {
            font-size: 14px !important;
          }

          .notification-message {
            font-size: 13px !important;
          }

          .notification-toast {
            width: calc(100vw - 32px) !important;
            right: 16px !important;
            left: 16px !important;
            top: 16px !important;
            max-width: none !important;
            z-index: 10000 !important;
          }

          .mark-all-section {
            padding: 12px 16px !important;
            border-bottom: 1px solid #2a2a2a !important;
          }

          .notification-panel-footer {
            padding: 16px !important;
            border-top: 1px solid #2a2a2a !important;
            background: #1a1a1a !important;
          }
        }

        @media (max-width: 480px) {
          .notification-panel {
            position: fixed !important;
            top: 0 !important;
            right: 0 !important;
            left: 0 !important;
            bottom: 0 !important;
            width: 100% !important;
            height: 100vh !important;
            max-height: 100vh !important;
            border-radius: 0 !important;
            margin-top: 0 !important;
            z-index: 9999 !important;
          }

          .notification-list {
            max-height: calc(100vh - 180px) !important;
            flex: 1 !important;
            overflow-y: auto !important;
          }

          .notification-panel-header {
            padding: 14px 16px !important;
            position: sticky !important;
            top: 0 !important;
            z-index: 10 !important;
          }

          .notification-panel-header h3 {
            font-size: 16px !important;
          }

          .notification-item {
            padding: 12px 14px !important;
          }

          .notification-icon {
            width: 36px !important;
            height: 36px !important;
            font-size: 16px !important;
          }

          .notification-title {
            font-size: 13px !important;
          }

          .notification-message {
            font-size: 12px !important;
          }

          .notification-time {
            font-size: 11px !important;
          }

          .notification-toast {
            width: calc(100vw - 24px);
            right: 12px;
            left: 12px;
            top: 12px;
          }

          .view-all-btn {
            padding: 10px 16px;
            font-size: 13px;
          }

          .mark-all-read-btn {
            font-size: 12px;
          }
        }
      </style>
    `;

    // Try to insert in notification-wrapper (index.html), nav-actions (desktop), or mobile header (mobile)
    let inserted = false;
    
    // Try notification-wrapper first (index.html)
    const notificationWrapper = document.getElementById('notification-wrapper');
    if (notificationWrapper) {
      console.log('[notification-center] Inserting in notification-wrapper');
      notificationWrapper.insertAdjacentHTML('beforeend', html);
      inserted = true;
    }
    
    // Try nav-actions (other pages)
    if (!inserted) {
      const navActions = document.querySelector('.nav-actions');
      if (navActions) {
        console.log('[notification-center] Inserting in nav-actions');
        navActions.insertAdjacentHTML('afterbegin', html);
        inserted = true;
      }
    }
    
    // Try mobile header
    if (!inserted) {
      const mobileHeader = document.querySelector('.mobile-dashboard-header');
      if (mobileHeader) {
        console.log('[notification-center] Inserting in mobile header');
        mobileHeader.insertAdjacentHTML('beforeend', html);
        inserted = true;
      }
    }
    
    // Fallback: insert at end of body
    if (!inserted) {
      console.log('[notification-center] Inserting at end of body (fallback)');
      document.body.insertAdjacentHTML('beforeend', html);
    }
    
    console.log('[notification-center] Notification UI inserted successfully');
    
    // Mark as initialized globally
    window.__notificationUIInitialized = true;
    
    // Attach event listeners IMMEDIATELY after HTML is inserted
    this.attachEventListeners();
  }

  /**
   * Attach event listeners - ONLY ONCE
   */
  attachEventListeners() {
    // Global guard to prevent duplicate listeners
    if (window.__notificationListenersAttached) {
      console.log('[notification-center] Event listeners already attached globally, skipping');
      return;
    }

    console.log('[notification-center] Attaching event listeners...');

    const bellBtn = document.getElementById('notification-bell');
    const closeBtn = document.getElementById('close-panel-btn');
    const markAllReadBtn = document.getElementById('mark-all-read-btn');
    const panel = document.getElementById('notification-panel');
    const overlay = document.getElementById('notification-overlay');

    // Validate required elements
    if (!bellBtn) {
      console.error('[notification-center] CRITICAL ERROR: notification-bell not found!');
      return;
    }

    if (!panel) {
      console.error('[notification-center] CRITICAL ERROR: notification-panel not found!');
      return;
    }

    console.log('[notification-center] All required elements found');

    // Bell click handler - CRITICAL FIX
    bellBtn.addEventListener('click', (e) => {
      console.log('[notification-center] 🔔 Bell clicked!');
      e.stopPropagation();
      e.preventDefault();
      
      const isHidden = panel.classList.contains('hidden');
      console.log('[notification-center] Panel currently hidden:', isHidden);
      
      panel.classList.toggle('hidden');
      if (overlay) {
        overlay.classList.toggle('hidden');
      }
      
      console.log('[notification-center] Panel toggled - now hidden:', panel.classList.contains('hidden'));
    });

    // Close button handler
    if (closeBtn) {
      closeBtn.addEventListener('click', (e) => {
        console.log('[notification-center] Close button clicked');
        e.stopPropagation();
        panel.classList.add('hidden');
        if (overlay) {
          overlay.classList.add('hidden');
        }
      });
    }

    // Overlay click handler (mobile)
    if (overlay) {
      overlay.addEventListener('click', () => {
        console.log('[notification-center] Overlay clicked');
        panel.classList.add('hidden');
        overlay.classList.add('hidden');
      });
    }

    // Mark all as read button
    if (markAllReadBtn) {
      markAllReadBtn.addEventListener('click', () => {
        console.log('[notification-center] Mark all as read clicked');
        this.markAllAsRead();
      });
    }

    // Close panel when clicking outside (desktop only)
    document.addEventListener('click', (e) => {
      const container = document.getElementById('notification-center-container');
      if (container && !container.contains(e.target) && !panel.classList.contains('hidden')) {
        console.log('[notification-center] Clicked outside, closing panel');
        panel.classList.add('hidden');
        if (overlay) {
          overlay.classList.add('hidden');
        }
      }
    });

    // Mark as attached globally
    window.__notificationListenersAttached = true;
    console.log('[notification-center] ✅ Event listeners attached successfully');
  }

  /**
   * Load notifications from database
   */
  async loadNotifications() {
    try {
      const { data, error } = await db
        .from('notifications')
        .select('*')
        .eq('user_id', this.currentUserId)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;

      this.notifications = data || [];
      this.updateNotificationList();
      this.updateUnreadCount();
    } catch (error) {
      console.error('[notification-center] Error loading notifications:', error);
    }
  }

  /**
   * Subscribe to real-time notification updates
   */
  subscribeToNotifications() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }

    this.subscription = db
      .channel(`notifications:${this.currentUserId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'notifications',
        filter: `user_id=eq.${this.currentUserId}`
      }, (payload) => {
        this.handleNewNotification(payload.new);
      })
      .subscribe();
  }

  /**
   * Handle new notification from realtime
   */
  handleNewNotification(notification) {
    // Add to beginning of list
    this.notifications.unshift(notification);
    
    // Keep only last 50
    if (this.notifications.length > 50) {
      this.notifications.pop();
    }

    // Update UI
    this.updateNotificationList();
    this.updateUnreadCount();
    
    // Show toast ONLY here (NotificationCenter handles all toasts)
    this.showNotificationToast(notification);
    
    console.log('[notification-center] New notification added:', notification.title);
  }

  /**
   * Update notification list UI
   */
  updateNotificationList() {
    const list = document.getElementById('notification-list');
    if (!list) return;

    if (this.notifications.length === 0) {
      list.innerHTML = `
        <div class="notification-empty">
          <svg class="empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
            <polyline points="9 22 9 12 15 12 15 22"/>
          </svg>
          <h2>You're all caught up!</h2>
          <p>You have no new notifications.<br>Notifications are deleted after 30 days</p>
        </div>
      `;
      return;
    }

    list.innerHTML = this.notifications.map(notif => `
      <div class="notification-item ${notif.is_read ? '' : 'unread'}" onclick="window.notificationCenter.markAsRead('${notif.id}')">
        <div class="notification-icon">${this.getNotificationIcon(notif.notification_type)}</div>
        <div class="notification-content">
          <div class="notification-title">
            ${notif.title}
            ${!notif.is_read ? '<span class="unread-indicator">●</span>' : ''}
          </div>
          <div class="notification-message">${notif.message}</div>
          <div class="notification-time">${this.formatTime(notif.created_at)}</div>
        </div>
        <button class="close-item-btn" onclick="event.stopPropagation(); window.notificationCenter.deleteNotification('${notif.id}')">
          <i class="fas fa-times"></i>
        </button>
      </div>
    `).join('');

    // Update view all button
    const viewAllBtn = document.getElementById('view-all-notifications-btn');
    if (viewAllBtn) {
      viewAllBtn.textContent = `View all (${this.notifications.length})`;
    }
  }

  /**
   * Update unread count badge
   */
  updateUnreadCount() {
    this.unreadCount = this.notifications.filter(n => !n.is_read).length;
    const badge = document.getElementById('notification-badge');
    const bellBtn = document.getElementById('notification-bell');
    
    if (badge && bellBtn) {
      // ALWAYS show the bell icon (even with no notifications)
      bellBtn.style.display = 'flex';
      
      if (this.unreadCount > 0) {
        // Show badge when there are unread notifications
        badge.textContent = this.unreadCount > 99 ? '99+' : this.unreadCount;
        badge.style.display = 'flex';
        console.log('[notification-center] Bell visible - unread:', this.unreadCount);
      } else {
        // Hide badge when no unread notifications
        badge.style.display = 'none';
        console.log('[notification-center] Bell visible - no unread notifications');
      }
    }
  }

  /**
   * Update badge
   */
  updateBadge() {
    this.updateUnreadCount();
  }

  /**
   * Show notification toast - ONLY called by NotificationCenter
   */
  showNotificationToast(notification) {
    const toast = document.getElementById('notification-toast');
    if (!toast) {
      console.warn('[notification-center] Toast element not found');
      return;
    }

    const titleEl = document.getElementById('toast-title');
    const messageEl = document.getElementById('toast-message');

    if (titleEl) titleEl.textContent = notification.title;
    if (messageEl) messageEl.textContent = notification.message;

    toast.classList.remove('hidden');
    console.log('[notification-center] Toast shown:', notification.title);

    // Auto-hide after 5 seconds
    setTimeout(() => {
      toast.classList.add('hidden');
    }, 5000);
  }

  /**
   * Mark notification as read
   * DECREASES badge count
   */
  async markAsRead(notificationId) {
    try {
      const { error } = await db
        .from('notifications')
        .update({ is_read: true })
        .eq('id', notificationId);

      if (error) throw error;

      // Update local state
      const notif = this.notifications.find(n => n.id === notificationId);
      if (notif) {
        notif.is_read = true;
        this.updateNotificationList();
        this.updateUnreadCount(); // DECREASES badge
      }
      
      console.log('[notification-center] Notification marked as read:', notificationId);
    } catch (error) {
      console.error('[notification-center] Error marking as read:', error);
    }
  }

  /**
   * Mark all as read
   * DECREASES badge count for all
   */
  async markAllAsRead() {
    try {
      const unreadIds = this.notifications
        .filter(n => !n.is_read)
        .map(n => n.id);

      if (unreadIds.length === 0) return;

      const { error } = await db
        .from('notifications')
        .update({ is_read: true })
        .in('id', unreadIds);

      if (error) throw error;

      // Update local state
      this.notifications.forEach(n => { n.is_read = true; });
      this.updateNotificationList();
      this.updateUnreadCount(); // DECREASES badge
      
      console.log('[notification-center] All notifications marked as read');
    } catch (error) {
      console.error('[notification-center] Error marking all as read:', error);
    }
  }

  /**
   * Delete notification
   * DECREASES badge count
   */
  async deleteNotification(notificationId) {
    try {
      const { error } = await db
        .from('notifications')
        .delete()
        .eq('id', notificationId);

      if (error) throw error;

      // Update local state
      this.notifications = this.notifications.filter(n => n.id !== notificationId);
      this.updateNotificationList();
      this.updateUnreadCount(); // DECREASES badge
      
      console.log('[notification-center] Notification deleted:', notificationId);
    } catch (error) {
      console.error('[notification-center] Error deleting notification:', error);
    }
  }

  /**
   * Get notification icon based on type
   */
  getNotificationIcon(type) {
    const icons = {
      'new_message': '<i class="fas fa-comment"></i>',
      'order_status': '<i class="fas fa-box"></i>',
      'payment_received': '<i class="fas fa-money-bill"></i>',
      'seller_application_approved': '<i class="fas fa-check-circle"></i>',
      'seller_application_rejected': '<i class="fas fa-times-circle"></i>',
      'incoming_video_call': '<i class="fas fa-video"></i>',
      'missed_video_call': '<i class="fas fa-phone"></i>',
      'product_review': '<i class="fas fa-star"></i>',
      'seller_verification_approved': '<i class="fas fa-check"></i>',
      'seller_verification_rejected': '<i class="fas fa-times"></i>',
      'listing_fee_payment': '<i class="fas fa-credit-card"></i>',
      'new_listing': '<i class="fas fa-tag"></i>',
      'order_received': '<i class="fas fa-inbox"></i>',
      'order_shipped': '<i class="fas fa-truck"></i>',
      'order_delivered': '<i class="fas fa-check"></i>',
      'payment_pending': '<i class="fas fa-hourglass"></i>',
      'buyer_review': '<i class="fas fa-star"></i>',
      'seller_review': '<i class="fas fa-star"></i>',
      'chat_message': '<i class="fas fa-comment"></i>',
      'default': '<i class="fas fa-bell"></i>'
    };
    return icons[type] || icons['default'];
  }

  /**
   * Format time for display
   */
  formatTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;

    return date.toLocaleDateString();
  }

  /**
   * Send notification to user
   */
  async sendNotification(userId, type, title, message, data = {}) {
    try {
      const { error } = await db
        .from('notifications')
        .insert({
          user_id: userId,
          notification_type: type,
          title,
          message,
          data,
          is_read: false,
          created_at: new Date().toISOString()
        });

      if (error) throw error;
    } catch (error) {
      console.error('[notification-center] Error sending notification:', error);
    }
  }
}

// Create global instance
window.notificationCenter = new NotificationCenter();

// Initialize when auth is ready
function initNotificationCenter() {
  const currentUser = window.authManager?.getCurrentUser();
  if (currentUser?.id) {
    console.log('[notification-center] Initializing with user:', currentUser.id);
    window.notificationCenter.init(currentUser.id);
  } else {
    // Retry after a short delay if auth not ready yet
    setTimeout(initNotificationCenter, 500);
  }
}

// Start initialization when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initNotificationCenter);
} else {
  // DOM already loaded
  setTimeout(initNotificationCenter, 100);
}

console.log('[notification-center] Notification center loaded');

// ===== TEST FUNCTION =====
// Use this in the browser console to test notifications:
// testNotification('Test Message', 'This is a test notification!');
window.testNotification = function(title, message) {
  console.log('[test] Creating test notification pop-up...');
  
  // Show toast pop-up immediately (no login needed)
  const toast = document.getElementById('notification-toast');
  if (toast) {
    const toastTitle = toast.querySelector('.toast-title');
    const toastMessage = toast.querySelector('.toast-message');
    
    if (toastTitle) toastTitle.textContent = title;
    if (toastMessage) toastMessage.textContent = message;
    
    toast.classList.remove('hidden');
    console.log('[test] Toast notification shown:', title, message);
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
      toast.classList.add('hidden');
    }, 5000);
  } else {
    console.error('[test] Toast element not found');
  }
};

console.log('[notification-center] Test function available: testNotification(title, message)');
/**
 * ============================================================
 * NOTIFICATION MANAGER - Database Insertion Only
 * ============================================================
 * 
 * RESPONSIBILITY: ONLY inserts notifications into the database
 * 
 * DOES NOT:
 * - Show toast popups (handled by NotificationCenter via realtime)
 * - Update UI (handled by NotificationCenter)
 * - Display badges (handled by NotificationCenter)
 * 
 * FLOW:
 * 1. NotificationManager detects event (new message, order update, etc.)
 * 2. NotificationManager inserts notification into database
 * 3. Supabase realtime triggers NotificationCenter
 * 4. NotificationCenter updates UI and shows toast
 * 
 * This prevents duplicate notifications and duplicate toasts.
 */

class NotificationManager {
  constructor() {
    this.notifications = [];
    this.unreadCount = 0;
    this.currentUserId = null;
    this.subscriptions = [];
  }

  /**
   * Initialize notification manager
   */
  async init(userId) {
    this.currentUserId = userId;
    
    console.log('[notification-manager] Initializing for user:', userId);
    
    // Subscribe to different notification types
    await this.subscribeToMessages();
    await this.subscribeToOrderUpdates();
    await this.subscribeToPaymentUpdates();
    
    console.log('[notification-manager] Notification manager initialized');
  }

  /**
   * Subscribe to new messages
   */
  async subscribeToMessages() {
    try {
      // Subscribe to messages where user is seller
      const sellerSub = db
        .channel(`messages:seller:${this.currentUserId}`)
        .on('postgres_changes', {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `seller_id=eq.${this.currentUserId}`
        }, (payload) => {
          this.handleNewMessage(payload.new, 'seller');
        })
        .subscribe();

      this.subscriptions.push(sellerSub);

      // Subscribe to messages where user is buyer
      const currentUser = window.authManager?.getCurrentUser();
      if (currentUser?.email) {
        const buyerSub = db
          .channel(`messages:buyer:${currentUser.email}`)
          .on('postgres_changes', {
            event: 'INSERT',
            schema: 'public',
            table: 'messages',
            filter: `buyer_email=eq.${currentUser.email}`
          }, (payload) => {
            this.handleNewMessage(payload.new, 'buyer');
          })
          .subscribe();

        this.subscriptions.push(buyerSub);
      }

      console.log('[notification-manager] Message subscriptions active');
    } catch (error) {
      console.error('[notification-manager] Error subscribing to messages:', error);
    }
  }

  /**
   * Subscribe to order updates
   */
  async subscribeToOrderUpdates() {
    try {
      // Subscribe to orders where user is seller
      const sellerOrderSub = db
        .channel(`orders:seller:${this.currentUserId}`)
        .on('postgres_changes', {
          event: 'UPDATE',
          schema: 'public',
          table: 'orders',
          filter: `seller_id=eq.${this.currentUserId}`
        }, (payload) => {
          this.handleOrderUpdate(payload.new, payload.old, 'seller');
        })
        .subscribe();

      this.subscriptions.push(sellerOrderSub);

      // Subscribe to orders where user is buyer
      const currentUser = window.authManager?.getCurrentUser();
      if (currentUser?.email) {
        const buyerOrderSub = db
          .channel(`orders:buyer:${currentUser.email}`)
          .on('postgres_changes', {
            event: 'UPDATE',
            schema: 'public',
            table: 'orders',
            filter: `buyer_email=eq.${currentUser.email}`
          }, (payload) => {
            this.handleOrderUpdate(payload.new, payload.old, 'buyer');
          })
          .subscribe();

        this.subscriptions.push(buyerOrderSub);
      }

      console.log('[notification-manager] Order subscriptions active');
    } catch (error) {
      console.error('[notification-manager] Error subscribing to orders:', error);
    }
  }

  /**
   * Subscribe to payment updates
   */
  async subscribeToPaymentUpdates() {
    try {
      const currentUser = window.authManager?.getCurrentUser();
      if (!currentUser?.email) return;

      const paymentSub = db
        .channel(`payments:${currentUser.email}`)
        .on('postgres_changes', {
          event: 'UPDATE',
          schema: 'public',
          table: 'orders',
          filter: `buyer_email=eq.${currentUser.email}`
        }, (payload) => {
          if (payload.new.payment_status !== payload.old.payment_status) {
            this.handlePaymentUpdate(payload.new);
          }
        })
        .subscribe();

      this.subscriptions.push(paymentSub);

      console.log('[notification-manager] Payment subscriptions active');
    } catch (error) {
      console.error('[notification-manager] Error subscribing to payments:', error);
    }
  }

  /**
   * Handle new message notification
   * Creates a notification for EACH unread message
   * ONLY inserts into DB - NotificationCenter handles toast display
   */
  handleNewMessage(message, role) {
    // Only create notification if message is unread
    if (message.is_read) return;

    const title = role === 'seller' 
      ? `New message from ${message.buyer_name}`
      : 'New message from seller';

    const notifData = {
      type: 'new_message',
      title,
      message: message.message.substring(0, 50) + (message.message.length > 50 ? '...' : ''),
      actionData: {
        conversationId: message.id,
        sellerId: message.seller_id,
        buyerEmail: message.buyer_email,
        messageId: message.id
      }
    };

    // ONLY insert into database - NotificationCenter will show toast via realtime
    this.createNotification(notifData);
    
    console.log('[notification-manager] New message notification created:', title);
  }

  /**
   * Handle order status update
   * ONLY inserts into DB - NotificationCenter handles toast display
   */
  handleOrderUpdate(newOrder, oldOrder, role) {
    if (newOrder.status === oldOrder.status) return;

    const statusMessages = {
      pending: 'Order placed',
      confirmed: 'Payment confirmed',
      shipped: 'Order shipped',
      delivered: 'Order delivered',
      received: 'Receipt confirmed',
      cancelled: 'Order cancelled'
    };

    const title = role === 'seller'
      ? `Order ${newOrder.id.slice(0, 8).toUpperCase()} - ${statusMessages[newOrder.status]}`
      : `Your order - ${statusMessages[newOrder.status]}`;

    const notifData = {
      type: 'order_status',
      title,
      message: `Order status updated to ${statusMessages[newOrder.status]}`,
      actionData: {
        orderId: newOrder.id
      }
    };

    // ONLY insert into database - NotificationCenter will show toast via realtime
    this.createNotification(notifData);
  }

  /**
   * Handle payment status update
   * ONLY inserts into DB - NotificationCenter handles toast display
   */
  handlePaymentUpdate(order) {
    const paymentMessages = {
      pending: 'Payment pending',
      submitted: 'Payment submitted',
      verified: 'Payment verified',
      rejected: 'Payment rejected'
    };

    const title = `Payment ${paymentMessages[order.payment_status]}`;
    const message = order.payment_status === 'rejected'
      ? `Payment rejected: ${order.payment_rejected_reason || 'Please contact support'}`
      : `Your payment has been ${paymentMessages[order.payment_status].toLowerCase()}`;

    const notifData = {
      type: 'payment_status',
      title,
      message,
      actionData: {
        orderId: order.id
      }
    };

    // ONLY insert into database - NotificationCenter will show toast via realtime
    this.createNotification(notifData);
  }

  /**
   * Create notification - ONLY inserts into database
   * NotificationCenter will handle UI updates via realtime subscription
   */
  async createNotification(notifData) {
    try {
      const { error } = await db
        .from('notifications')
        .insert({
          user_id: this.currentUserId,
          notification_type: notifData.type,
          title: notifData.title,
          message: notifData.message,
          data: notifData.actionData,
          is_read: false,
          created_at: new Date().toISOString()
        });

      if (error) throw error;

      console.log('[notification-manager] Notification inserted into DB:', notifData.title);
    } catch (error) {
      console.error('[notification-manager] Error creating notification:', error);
    }
  }



  /**
   * Cleanup subscriptions
   */
  cleanup() {
    this.subscriptions.forEach(sub => {
      if (sub && typeof sub.unsubscribe === 'function') {
        sub.unsubscribe();
      }
    });
    this.subscriptions = [];
  }
}

// Create global instance
window.notificationManager = new NotificationManager();

// Initialize when auth is ready
function initNotificationManager() {
  const currentUser = window.authManager?.getCurrentUser();
  if (currentUser?.id) {
    console.log('[notification-manager] Initializing with user:', currentUser.id);
    window.notificationManager.init(currentUser.id);
  } else {
    // Retry after a short delay if auth not ready yet
    setTimeout(initNotificationManager, 500);
  }
}

// Start initialization when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initNotificationManager);
} else {
  // DOM already loaded
  setTimeout(initNotificationManager, 100);
}

console.log('[notification-manager] Notification manager loaded');
// ============================================================
// mobile-header.js — Mobile Header Functionality for All Pages
// ============================================================

(function() {
    const mobileHeader = document.querySelector('.mobile-dashboard-header');
    const navbar = document.querySelector('.navbar');
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const navMenu = document.getElementById('navMenu');
    
    // Toggle between mobile header and desktop navbar
    function checkMobile() {
        if (window.innerWidth <= 767) {
            if (mobileHeader) mobileHeader.style.display = 'flex';
            if (navbar) navbar.style.display = 'none';
        } else {
            if (mobileHeader) mobileHeader.style.display = 'none';
            if (navbar) navbar.style.display = 'block';
        }
    }
    
    // Initialize on load
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    // Hamburger menu toggle
    if (mobileMenuBtn && navMenu) {
        mobileMenuBtn.addEventListener('click', () => {
            navMenu.classList.toggle('mobile-open');
        });
    }
    
    // Messages button
    const mobileMessagesBtn = document.getElementById('mobileMessagesBtn');
    if (mobileMessagesBtn) {
        mobileMessagesBtn.addEventListener('click', () => {
            // Detect if we're in pages/ folder or root
            const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
            window.location.href = prefix + 'dashboard.html#messages';
        });
    }
    
    // Notifications button - ONLY toggles panel, does NOT recreate UI
    const mobileNotificationsBtn = document.getElementById('mobileNotificationsBtn');
    if (mobileNotificationsBtn) {
        mobileNotificationsBtn.addEventListener('click', () => {
            console.log('[mobile-header] Notification button clicked');
            
            const notificationPanel = document.getElementById('notification-panel');
            const notificationOverlay = document.getElementById('notification-overlay');
            
            if (notificationPanel) {
                // Panel exists, toggle it
                console.log('[mobile-header] Toggling notification panel');
                notificationPanel.classList.toggle('hidden');
                if (notificationOverlay) {
                    notificationOverlay.classList.toggle('hidden');
                }
            } else {
                // Panel doesn't exist yet, navigate to dashboard
                console.log('[mobile-header] Panel not found, navigating to dashboard');
                const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
                window.location.href = prefix + 'dashboard.html#notifications';
            }
        });
    }
    
    // Profile button
    const mobileProfileBtn = document.getElementById('mobileProfileBtn');
    if (mobileProfileBtn) {
        mobileProfileBtn.addEventListener('click', () => {
            // Detect if we're in pages/ folder or root
            const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
            window.location.href = prefix + 'dashboard.html#profile';
        });
    }
    
    console.log('[Mobile Header] Initialized');
})();
