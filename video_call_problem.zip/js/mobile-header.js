// ============================================================
// mobile-header.js — Mobile Header Functionality for All Pages
// ============================================================

(function() {
    const mobileHeader = document.querySelector('.mobile-dashboard-header');
    const navbar = document.querySelector('.navbar');
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const navMenu = document.getElementById('navMenu');
    
    // Toggle between mobile header and desktop navbar
    function checkMobile() {
        if (window.innerWidth <= 767) {
            if (mobileHeader) mobileHeader.style.display = 'flex';
            if (navbar) navbar.style.display = 'none';
        } else {
            if (mobileHeader) mobileHeader.style.display = 'none';
            if (navbar) navbar.style.display = 'block';
        }
    }
    
    // Initialize on load
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    // Hamburger menu toggle
    console.log('[Mobile Header] mobileMenuBtn:', mobileMenuBtn);
    console.log('[Mobile Header] navMenu:', navMenu);
    
    if (mobileMenuBtn && navMenu) {
        const overlay = document.getElementById('mobileMenuOverlay');
        const closeBtn = document.getElementById('mobileMenuClose');
        
        console.log('[Mobile Header] ✅ Both elements found, attaching click listener');
        
        // Toggle menu (open/close)
        mobileMenuBtn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            console.log('[Mobile Header] 🔔 Hamburger clicked!');
            
            const isOpen = navMenu.classList.contains('mobile-open');
            console.log('[Mobile Header] Menu currently open:', isOpen);
            
            if (isOpen) {
                // Close menu
                navMenu.classList.remove('mobile-open');
                if (overlay) overlay.classList.remove('active');
                console.log('[Mobile Header] Menu closed');
            } else {
                // Open menu
                navMenu.classList.add('mobile-open');
                if (overlay) overlay.classList.add('active');
                console.log('[Mobile Header] Menu opened');
            }
        });
    } else {
        console.log('[Mobile Header] ❌ Elements not found!');
    }
        
        // Close menu - close button
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                navMenu.classList.remove('mobile-open');
                if (overlay) overlay.classList.remove('active');
                console.log('[Mobile Header] Menu closed via X button');
            });
        }
        
        // Close menu - overlay click
        if (overlay) {
            overlay.addEventListener('click', () => {
                navMenu.classList.remove('mobile-open');
                overlay.classList.remove('active');
                console.log('[Mobile Header] Menu closed via overlay');
            });
        }
        
        // Close menu when clicking a menu item
        const menuItems = navMenu.querySelectorAll('.mobile-menu-item');
        menuItems.forEach(item => {
            item.addEventListener('click', () => {
                navMenu.classList.remove('mobile-open');
                if (overlay) overlay.classList.remove('active');
            });
        });
    }
    
    // Messages button
    const mobileMessagesBtn = document.getElementById('mobileMessagesBtn');
    if (mobileMessagesBtn) {
        mobileMessagesBtn.addEventListener('click', () => {
            // Detect if we're in pages/ folder or root
            const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
            window.location.href = prefix + 'dashboard.html#messages';
        });
    }
    
    // Notifications button
    const mobileNotificationsBtn = document.getElementById('mobileNotificationsBtn');
    if (mobileNotificationsBtn) {
        mobileNotificationsBtn.addEventListener('click', () => {
            // Wait for notification center to be initialized
            const checkNotificationCenter = setInterval(() => {
                const notificationPanel = document.getElementById('notification-panel');
                
                if (notificationPanel) {
                    clearInterval(checkNotificationCenter);
                    // Panel exists, toggle it
                    notificationPanel.classList.toggle('hidden');
                } else if (window.notificationCenter && window.notificationCenter.currentUserId) {
                    // Notification center is initialized, create UI if needed
                    clearInterval(checkNotificationCenter);
                    window.notificationCenter.createNotificationUI();
                    setTimeout(() => {
                        const panel = document.getElementById('notification-panel');
                        if (panel) {
                            panel.classList.remove('hidden');
                        }
                    }, 100);
                }
            }, 100);
            
            // Timeout after 3 seconds
            setTimeout(() => {
                clearInterval(checkNotificationCenter);
                if (!document.getElementById('notification-panel')) {
                    // Notification center not initialized, navigate to dashboard
                    const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
                    window.location.href = prefix + 'dashboard.html#notifications';
                }
            }, 3000);
        });
    }
    
    // Profile button
    const mobileProfileBtn = document.getElementById('mobileProfileBtn');
    if (mobileProfileBtn) {
        mobileProfileBtn.addEventListener('click', () => {
            // Detect if we're in pages/ folder or root
            const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
            window.location.href = prefix + 'dashboard.html#profile';
        });
    }
    
    console.log('[Mobile Header] Initialized');
})();
