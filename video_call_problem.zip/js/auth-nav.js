// ============================================================
// auth-nav.js — Universal Navigation Auth State Handler
// Used on all pages to update navigation based on auth state
// ============================================================

function initAuthNavigation() {
  const updateNavigation = () => {
    // Ensure authManager is available
    if (!window.authManager) {
      setTimeout(updateNavigation, 100);
      return;
    }

    const authNav = document.getElementById('authNav');
    const userNav = document.getElementById('userNav');
    const userGreeting = document.getElementById('userGreeting');
    
    // Check if we're on the dashboard page
    const isDashboardPage = window.location.pathname.includes('dashboard') || 
                           window.location.href.includes('dashboard.html');
    
    if (window.authManager.isAuthenticated()) {
      const user = window.authManager.getCurrentUser();
      
      // Show user navigation
      if (authNav) authNav.classList.add('hidden');
      if (userNav) userNav.classList.remove('hidden');
      
      // Update greeting
      if (userGreeting) {
        userGreeting.textContent = `Hi, ${user.name || user.email.split('@')[0]}!`;
      }
    } else {
      // Show auth navigation
      if (authNav) authNav.classList.remove('hidden');
      if (userNav) userNav.classList.add('hidden');
    }
  };

  // Initialize immediately and on auth state changes
  updateNavigation();
  
  // Listen for auth state changes (custom event)
  document.addEventListener('authStateChanged', updateNavigation);
  
  // Also update on page load and visibility change
  window.addEventListener('load', updateNavigation);
  document.addEventListener('visibilitychange', updateNavigation);
}

// Auto-initialize on DOM ready
document.addEventListener('DOMContentLoaded', initAuthNavigation);

// Also initialize immediately if DOM is already ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initAuthNavigation);
} else {
  initAuthNavigation();
}
