﻿/**
 * ============================================================
 * MESSAGING ENGINE - Unified Messaging System
 * ============================================================
 * 
 * Consolidated from chat.js and admin-messaging.js
 * 
 * IMPORTANT: This engine reuses functions from master-dashboard.js
 * to maintain a single source of truth for messaging functionality.
 * 
 * Functions delegated to master-dashboard.js:
 * - loadBuyerMessages()
 * - loadSellerMessages()
 * - openChat()
 * - sendChatMessage()
 * - formatChatTime()
 * 
 * This file provides:
 * - Admin messaging interface
 * - Conversation monitoring
 * - Message search and filtering
 */

// ============================================================
// MESSAGING ENGINE - Thin wrapper around master-dashboard
// ============================================================

const MessagingEngine = {
  loadBuyerMessages: function() {
    if (typeof loadBuyerMessages === 'function') {
      return loadBuyerMessages();
    }
    console.warn('[messaging-engine] loadBuyerMessages not available from master-dashboard');
  },

  loadSellerMessages: function() {
    if (typeof loadSellerMessages === 'function') {
      return loadSellerMessages();
    }
    console.warn('[messaging-engine] loadSellerMessages not available from master-dashboard');
  },

  openChat: function(msgId, cachedData) {
    if (typeof openChat === 'function') {
      return openChat(msgId, cachedData);
    }
    console.warn('[messaging-engine] openChat not available from master-dashboard');
  },

  sendChatMessage: function() {
    if (typeof sendChatMessage === 'function') {
      return sendChatMessage();
    }
    console.warn('[messaging-engine] sendChatMessage not available from master-dashboard');
  },

  formatChatTime: function(ts) {
    if (typeof formatChatTime === 'function') {
      return formatChatTime(ts);
    }
    return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
};

// ============================================================
// ADMIN MESSAGING - Message monitoring interface
// ============================================================

let allConversations = [];
let selectedMessageId = null;

async function loadAdminMessaging() {
  const container = document.getElementById('adminMessagingContainer');
  if (!container) return;
  container.innerHTML = '<div class="admin-messaging-layout"><div class="messaging-sidebar"><div class="messaging-sidebar-header"><h3>Buyer-Seller Messages</h3><input type="text" id="messageSearchInput" placeholder="Search conversations..." style="width:100%;padding:8px;border:1px solid #ddd;border-radius:6px;margin-top:8px;"></div><div class="messaging-user-list" id="messagingConversationList"><p style="padding:20px;color:#aaa;font-size:13px;">Loading conversations...</p></div></div><div class="messaging-main"><div class="messaging-empty-state" id="messagingEmptyState"><div style="text-align:center;padding:60px 20px;color:#888;"><div style="font-size:48px;margin-bottom:16px;">💬</div><h3>Message Monitoring</h3><p>Select a conversation to view messages</p></div></div><div class="messaging-active" id="messagingActive" style="display:none;"><div class="messaging-header" id="messagingHeader"></div><div class="messaging-messages" id="messagingMessages"></div></div></div></div>';
  await loadConversations();
  document.getElementById('messageSearchInput')?.addEventListener('input', (e) => {
    filterConversations(e.target.value);
  });
}

async function loadConversations() {
  const convList = document.getElementById('messagingConversationList');
  if (!convList) return;
  try {
    if (typeof messagesDb === 'undefined' || !messagesDb) {
      console.warn('[messaging-engine] messagesDb not available for admin messaging');
      convList.innerHTML = '<p style="padding:20px;color:#e74c3c;font-size:13px;">Message database not initialized</p>';
      return;
    }
    const { data: messages, error } = await messagesDb
      .from('messages')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    if (!messages || messages.length === 0) {
      convList.innerHTML = '<p style="padding:20px;color:#aaa;font-size:13px;">No conversations yet</p>';
      return;
    }
    allConversations = messages;
    renderConversationList(allConversations);
  } catch (error) {
    console.error('[messaging-engine] loadConversations error:', error);
    convList.innerHTML = '<p style="padding:20px;color:#e74c3c;font-size:13px;">Error loading conversations</p>';
  }
}

function renderConversationList(conversations) {
  const convList = document.getElementById('messagingConversationList');
  if (!convList) return;
  if (!conversations.length) {
    convList.innerHTML = '<p style="padding:20px;color:#aaa;font-size:13px;">No conversations found</p>';
    return;
  }
  let html = '';
  for (let msg of conversations) {
    const time = formatMessageTime(msg.created_at);
    const active = selectedMessageId === msg.id ? 'active' : '';
    html += '<div class="messaging-user-item ' + active + '" onclick="viewConversation(\'' + msg.id + '\')" data-msg-id="' + msg.id + '">';
    html += '<div class="user-info"><div class="user-name">Message ID: ' + msg.id + '</div>';
    html += '<div class="message-preview" style="font-size:12px;color:#666;margin-top:4px;">' + msg.message.substring(0, 50) + '...</div>';
    html += '<div class="user-meta" style="margin-top:4px;"><span style="font-size:11px;color:#888;">' + time + '</span></div></div></div>';
  }
  convList.innerHTML = html;
}

function filterConversations(query) {
  if (!query.trim()) {
    renderConversationList(allConversations);
    return;
  }
  const filtered = allConversations.filter(conv => 
    conv.message.toLowerCase().includes(query.toLowerCase())
  );
  renderConversationList(filtered);
}

async function viewConversation(messageId) {
  selectedMessageId = messageId;
  const items = document.querySelectorAll('.messaging-user-item');
  for (let item of items) {
    if (item.dataset.msgId === messageId) {
      item.classList.add('active');
    } else {
      item.classList.remove('active');
    }
  }
  const conversation = allConversations.find(c => c.id === messageId);
  if (!conversation) return;
  document.getElementById('messagingEmptyState').style.display = 'none';
  document.getElementById('messagingActive').style.display = 'flex';
  const header = document.getElementById('messagingHeader');
  if (header) {
    header.innerHTML = '<div style="padding:16px;border-bottom:1px solid #eee;"><div style="font-weight:700;font-size:16px;">Message Details</div><div style="font-size:13px;color:#666;margin-top:8px;">ID: ' + conversation.id + '</div></div>';
  }
  const messagesContainer = document.getElementById('messagingMessages');
  if (messagesContainer) {
    messagesContainer.innerHTML = '<div class="message-bubble"><div class="message-content">' + conversation.message + '</div><div class="message-meta">' + formatMessageTime(conversation.created_at) + '</div></div>';
  }
}

function formatMessageTime(timestamp) {
  if (!timestamp) return '';
  const date = new Date(timestamp);
  const now = new Date();
  const diffDays = Math.floor((now - date) / (1000 * 60 * 60 * 24));
  if (diffDays === 0) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  } else if (diffDays === 1) {
    return 'Yesterday';
  } else if (diffDays < 7) {
    return date.toLocaleDateString([], { weekday: 'short' });
  } else {
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  }
}

// ============================================================
// GLOBAL EXPORTS - Delegate to master-dashboard
// ============================================================

window.MessagingEngine = MessagingEngine;
window.loadAdminMessaging = loadAdminMessaging;
window.viewConversation = viewConversation;

window.loadBuyerMessages = function() {
  if (typeof loadBuyerMessages === 'function') {
    return loadBuyerMessages();
  }
  console.warn('[messaging-engine] loadBuyerMessages not available');
};

window.loadSellerMessages = function() {
  if (typeof loadSellerMessages === 'function') {
    return loadSellerMessages();
  }
  console.warn('[messaging-engine] loadSellerMessages not available');
};

window.openChat = function(msgId, cachedData) {
  if (typeof openChat === 'function') {
    return openChat(msgId, cachedData);
  }
  console.warn('[messaging-engine] openChat not available');
};

window.sendChatMessage = function() {
  if (typeof sendChatMessage === 'function') {
    return sendChatMessage();
  }
  console.warn('[messaging-engine] sendChatMessage not available');
};

console.log('[messaging-engine] Messaging engine loaded - delegating to master-dashboard');
