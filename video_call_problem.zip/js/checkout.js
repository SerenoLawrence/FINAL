// ============================================================
// checkout.js — Checkout Page Logic
// ============================================================

let currentUser = null;
let uploadedReceiptUrl = null;
let checkoutItems = [];

// Load order summary
async function loadOrderSummary() {
  const orderItemsEl = document.getElementById('orderItems');
  
  // Check if Supabase is ready
  if (!window.db) {
    console.error('[checkout] Supabase not initialized');
    alert('System not ready. Please refresh the page.');
    return;
  }  
  // Check if coming from direct product link (URL params)
  const urlParams = new URLSearchParams(window.location.search);
  const productId = urlParams.get('productId');
  const size = urlParams.get('size');
  
  if (productId && size) {
    // Direct purchase from product page
    try {
      console.log('[checkout] Loading product:', productId);
      console.log('[checkout] Size:', size);
      
      // Try to fetch the product
      const { data: product, error } = await db
        .from('products')
        .select('*')
        .eq('id', productId)
        .limit(1)
        .then(r => ({ data: r.data?.[0] || null, error: r.error }));
      
      if (error) {
        console.error('[checkout] Database error:', error);
        throw new Error(`Database error: ${error.message}`);
      }
      
      if (!product) {
        console.error('[checkout] Product not found in database');
        throw new Error('Product not found in database');
      }
      
      console.log('[checkout] Product loaded:', product);
      
      checkoutItems = [{
        id: product.id,
        name: product.name,
        price: parseFloat(product.price),
        image: product.image_url,
        size: size,
        quantity: 1,
        seller_id: product.seller_id
      }];
      
      console.log('[checkout] Direct purchase loaded:', product.name);
    } catch (error) {
      console.error('[checkout] Error loading product:', error);
      alert('Unable to load product. Please try again or contact support.\n\nError: ' + error.message);
      // Don't redirect immediately, let user see the error
      setTimeout(() => {
        location.href = 'shop.html';
      }, 3000);
      return;
    }
  } else if (window.cart && window.cart.getItems().length > 0) {
    // Purchase from cart
    checkoutItems = window.cart.getItems();
    console.log('[checkout] Cart purchase:', checkoutItems.length, 'items');
  } else {
    // No items
    console.log('[checkout] No items found');
    alert('Your cart is empty!');
    location.href = 'shop.html';
    return;
  }
  
  // Render items
  orderItemsEl.innerHTML = checkoutItems.map(item => `
    <div class="order-item">
      <img src="${item.image || 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%22100%22%3E%3Crect fill=%22%23f0f0f0%22 width=%22100%22 height=%22100%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2214%22 fill=%22%23999%22 text-anchor=%22middle%22 dy=%22.3em%22%3ENo Image%3C/text%3E%3C/svg%3E'}" alt="${item.name}">
      <div class="order-item-details">
        <h4>${item.name}</h4>
        <p>Size: ${item.size} | Qty: ${item.quantity}</p>
        <p style="font-weight: 600; color: #c8a96e;">₱${(item.price * item.quantity).toFixed(2)}</p>
      </div>
    </div>
  `).join('');
  
  // Update summary — no fixed shipping, arranged via chat
  const subtotal = checkoutItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const total    = subtotal;
  
  document.getElementById('summarySubtotal').textContent = `₱${subtotal.toFixed(2)}`;
  // summaryShipping is already set to "Via chat with seller" in HTML
  document.getElementById('summaryTotal').textContent = `₱${total.toFixed(2)}`;
  
  console.log('[checkout] Order summary loaded successfully');
}

// Select payment method (GCash only)
function selectPayment(method) {
  document.querySelectorAll('.payment-method').forEach(el => {
    el.classList.remove('selected');
  });
  
  const radio = document.getElementById(`payment${method.charAt(0).toUpperCase() + method.slice(1)}`);
  if (radio) {
    radio.checked = true;
    radio.closest('.payment-method').classList.add('selected');
  }
  
  // Receipt upload is always required
  const receiptInput = document.getElementById('receiptFile');
  if (receiptInput) receiptInput.required = true;
}

// Handle receipt file selection
function handleReceiptFileSelect(e) {
  const file = e.target.files[0];
  if (!file) return;
  showReceiptPreview(file);
}

// Show receipt preview in drop zone
function showReceiptPreview(file) {
  const dropIcon = document.getElementById('receiptDropIcon');
  const dropPreview = document.getElementById('receiptDropPreview');
  const previewImg = document.getElementById('receiptPreviewImg');
  const fileName = document.getElementById('receiptFileName');
  const fileSize = document.getElementById('receiptFileSize');

  const reader = new FileReader();
  reader.onload = (event) => {
    previewImg.src = event.target.result;
    dropIcon.style.display = 'none';
    dropPreview.style.display = 'flex';
  };
  reader.readAsDataURL(file);

  fileName.textContent = file.name;
  fileSize.textContent = (file.size / 1024).toFixed(1) + ' KB';
}

// Remove selected receipt
function removeReceipt(e) {
  e.stopPropagation(); // Don't trigger the drop zone click
  document.getElementById('receiptFile').value = '';
  document.getElementById('receiptDropIcon').style.display = 'flex';
  document.getElementById('receiptDropPreview').style.display = 'none';
}

// Setup drag & drop on the receipt zone
function setupReceiptDropZone() {
  const zone = document.getElementById('receiptDropZone');
  const input = document.getElementById('receiptFile');
  if (!zone || !input) return;

  zone.addEventListener('dragover', (e) => {
    e.preventDefault();
    zone.classList.add('drag-over');
  });

  zone.addEventListener('dragleave', () => {
    zone.classList.remove('drag-over');
  });

  zone.addEventListener('drop', (e) => {
    e.preventDefault();
    zone.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      // Set the file on the input
      const dt = new DataTransfer();
      dt.items.add(file);
      input.files = dt.files;
      showReceiptPreview(file);
    }
  });
}

// Upload receipt to Cloudinary
async function uploadReceipt(file, orderId) {
  const progressSection = document.getElementById('receiptUploadProgress');
  const progressBar = document.getElementById('receiptProgressBar');
  const progressText = document.getElementById('receiptProgressText');
  
  try {
    // Show progress
    progressSection.style.display = 'block';
    progressBar.style.width = '30%';
    progressText.textContent = 'Uploading receipt...';
    
    // Upload using helper function
    const receiptUrl = await window.uploadPaymentReceipt(file, orderId);
    
    // Complete
    progressBar.style.width = '100%';
    progressText.textContent = 'Upload complete!';
    
    console.log('[checkout] Receipt uploaded:', receiptUrl);
    return receiptUrl;
    
  } catch (error) {
    console.error('[checkout] Receipt upload failed:', error);
    progressText.textContent = 'Upload failed: ' + error.message;
    progressText.style.color = '#dc3545';
    throw error;
  }
}

// Load user data if logged in
async function loadUserData() {
  try {
    const { data: { user } } = await db.auth.getUser();
    
    if (user) {
      currentUser = user;
      console.log('[checkout] Loading user data for:', user.email);
      
      // Try to get buyer data
      const { data: buyer, error: buyerError } = await db
        .from('buyers')
        .select('*')
        .eq('email', user.email)
        .single();
      
      console.log('[checkout] Buyer data:', buyer, 'Error:', buyerError);
      
      if (buyer) {
        // Pre-fill buyer information
        const fullNameInput = document.getElementById('fullName');
        const emailInput = document.getElementById('email');
        const phoneInput = document.getElementById('phone');
        
        if (fullNameInput && buyer.name) {
          fullNameInput.value = buyer.name;
          console.log('[checkout] Auto-filled name:', buyer.name);
        }
        
        if (emailInput && buyer.email) {
          emailInput.value = buyer.email;
          console.log('[checkout] Auto-filled email:', buyer.email);
        }
        
        if (phoneInput && buyer.phone) {
          phoneInput.value = buyer.phone;
          console.log('[checkout] Auto-filled phone:', buyer.phone);
        }
        
        // Try to get buyer's default address
        const { data: addresses } = await db
          .from('buyer_addresses')
          .select('*')
          .eq('buyer_id', buyer.id)
          .order('created_at', { ascending: false })
          .limit(1);
        
        if (addresses && addresses.length > 0) {
          const address = addresses[0];
          const deliveryAddressInput = document.getElementById('delivery_address');
          
          if (deliveryAddressInput) {
            // Format address as single line
            const fullAddress = `${address.street_address}, ${address.city}, ${address.province}, ${address.postal_code}`;
            deliveryAddressInput.value = fullAddress;
            console.log('[checkout] Auto-filled address:', fullAddress);
          }
        }
      } else {
        // No buyer record, just fill email from auth
        const emailInput = document.getElementById('email');
        if (emailInput && user.email) {
          emailInput.value = user.email;
          console.log('[checkout] Auto-filled email from auth:', user.email);
        }
        
        // Try to get name from user metadata
        const fullNameInput = document.getElementById('fullName');
        if (fullNameInput && user.user_metadata?.name) {
          fullNameInput.value = user.user_metadata.name;
          console.log('[checkout] Auto-filled name from metadata:', user.user_metadata.name);
        }
      }
      
      console.log('[checkout] ✅ User data loaded and form auto-filled');
    } else {
      console.log('[checkout] No user logged in');
    }
  } catch (error) {
    console.error('[checkout] Error loading user data:', error);
  }
}

// Handle form submission
async function handleCheckout(e) {
  e.preventDefault();
  
  const submitBtn = e.target.querySelector('button[type="submit"]');
  submitBtn.disabled = true;
  submitBtn.textContent = 'Processing...';
  
  try {
    // Get form data
    const formData = new FormData(e.target);
    const shippingInfo = {
      fullName:            formData.get('fullName'),
      email:               formData.get('email'),
      phone:               formData.get('phone'),
      notes:               formData.get('notes'),
      delivery_preference: formData.get('deliveryPreference') || 'meetup',
      delivery_address:    formData.get('deliveryAddress') || null
    };
    
    const paymentMethod = formData.get('payment');
    const items    = checkoutItems;
    const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const total    = subtotal; // No fixed shipping — arranged via chat
    
    // Handle receipt upload (required for all payments)
    const receiptFile = document.getElementById('receiptFile').files[0];
    
    if (!receiptFile) {
      alert('Please upload a payment receipt');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Place Order';
      return;
    }
    
    // Upload receipt first (use temporary order ID)
    const tempOrderId = `temp_${Date.now()}`;
    submitBtn.textContent = 'Uploading receipt...';
    const receiptUrl = await uploadReceipt(receiptFile, tempOrderId);
    console.log('[checkout] Receipt uploaded successfully:', receiptUrl);
    
    // Get or create buyer user_id
    let buyerUserId = null;
    if (currentUser) {
      buyerUserId = currentUser.id;
    }
    
    // Save/update buyer information for future auto-fill
    submitBtn.textContent = 'Saving your information...';
    try {
      // Check if buyer record exists
      const { data: existingBuyer } = await db
        .from('buyers')
        .select('id')
        .eq('email', shippingInfo.email)
        .single();
      
      if (existingBuyer) {
        // Update existing buyer record
        await db
          .from('buyers')
          .update({
            name: shippingInfo.fullName,
            phone: shippingInfo.phone
          })
          .eq('email', shippingInfo.email);
        
        console.log('[checkout] ✅ Updated buyer information');
        
        // Save/update delivery address if provided
        if (shippingInfo.delivery_address) {
          // Check if address exists
          const { data: existingAddress } = await db
            .from('buyer_addresses')
            .select('id')
            .eq('buyer_id', existingBuyer.id)
            .limit(1)
            .single();
          
          // Parse address (simple parsing - you can improve this)
          const addressParts = shippingInfo.delivery_address.split(',').map(s => s.trim());
          const addressData = {
            buyer_id: existingBuyer.id,
            street_address: addressParts[0] || shippingInfo.delivery_address,
            city: addressParts[1] || 'N/A',
            province: addressParts[2] || 'N/A',
            postal_code: addressParts[3] || '0000',
            country: 'Philippines',
            label: 'Home'
          };
          
          if (existingAddress) {
            // Update existing address
            await db
              .from('buyer_addresses')
              .update(addressData)
              .eq('id', existingAddress.id);
          } else {
            // Insert new address
            await db
              .from('buyer_addresses')
              .insert([addressData]);
          }
          
          console.log('[checkout] ✅ Saved delivery address');
        }
      } else {
        // Create new buyer record
        const { data: newBuyer } = await db
          .from('buyers')
          .insert([{
            name: shippingInfo.fullName,
            email: shippingInfo.email,
            phone: shippingInfo.phone
          }])
          .select()
          .single();
        
        console.log('[checkout] ✅ Created new buyer record');
        
        // Save delivery address if provided
        if (newBuyer && shippingInfo.delivery_address) {
          const addressParts = shippingInfo.delivery_address.split(',').map(s => s.trim());
          await db
            .from('buyer_addresses')
            .insert([{
              buyer_id: newBuyer.id,
              street_address: addressParts[0] || shippingInfo.delivery_address,
              city: addressParts[1] || 'N/A',
              province: addressParts[2] || 'N/A',
              postal_code: addressParts[3] || '0000',
              country: 'Philippines',
              label: 'Home'
            }]);
          
          console.log('[checkout] ✅ Saved delivery address');
        }
      }
    } catch (saveError) {
      console.warn('[checkout] Could not save buyer info (non-critical):', saveError);
      // Continue with order creation even if saving buyer info fails
    }
    
    // Create orders for each item
    submitBtn.textContent = 'Creating orders...';
    const orderPromises = items.map(async (item) => {
      // Fetch seller information from sellers table
      let sellerEmail = null;
      let sellerName = null;
      
      if (item.seller_id) {
        try {
          // Get seller info from sellers table
          const { data: sellerData } = await db
            .from('sellers')
            .select('email, business_name, store_name')
            .eq('user_id', item.seller_id)
            .single();
          
          if (sellerData) {
            sellerEmail = sellerData.email;
            sellerName = sellerData.store_name || sellerData.business_name || sellerData.email?.split('@')[0] || 'Seller';
          }
        } catch (e) {
          console.warn('[checkout] Could not fetch seller info:', e);
        }
      }
      
      const orderData = {
        product_id: item.id,
        seller_id: item.seller_id,
        seller_email: sellerEmail,
        seller_name: sellerName,
        buyer_user_id: buyerUserId,
        buyer_name: shippingInfo.fullName,
        buyer_email: shippingInfo.email,
        buyer_phone: shippingInfo.phone,
        delivery_address: shippingInfo.delivery_address,
        size_selected: item.size,
        quantity: item.quantity,
        total_price: item.price * item.quantity,
        status: 'pending',
        payment_method: paymentMethod,
        payment_proof_url: receiptUrl,
        payment_status: 'submitted',
        payment_reference: `REF-${Date.now()}`
      };
      
      const { data, error } = await db
        .from('orders')
        .insert([orderData])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    });
    
    const orders = await Promise.all(orderPromises);
    
    console.log('[checkout] Orders created:', orders);
    
    // Clear cart if items came from cart
    const urlParams = new URLSearchParams(window.location.search);
    if (!urlParams.get('productId') && window.cart) {
      window.cart.clearCart();
    }
    
    // Redirect to confirmation page with order IDs
    const orderIds = orders.map(o => o.id).join(',');
    location.href = `order-confirmation.html?orders=${orderIds}`;
    
  } catch (error) {
    console.error('[checkout] Error:', error);
    alert('Failed to place order: ' + error.message);
    submitBtn.disabled = false;
    submitBtn.textContent = 'Place Order';
  }
}

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
  await loadOrderSummary();
  await loadUserData();
  
  // Add form submit handler
  document.getElementById('checkoutForm').addEventListener('submit', handleCheckout);
  
  // Add receipt file input handler
  const receiptInput = document.getElementById('receiptFile');
  if (receiptInput) {
    receiptInput.addEventListener('change', handleReceiptFileSelect);
  }
  
  // Setup drag & drop
  setupReceiptDropZone();
  
  // Set default payment method
  selectPayment('gcash');
});

console.log('[checkout] Checkout page initialized');
