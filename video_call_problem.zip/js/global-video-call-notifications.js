/**
 * GLOBAL VIDEO CALL NOTIFICATION SYSTEM
 * 
 * Ensures buyers receive incoming call notifications on ANY page
 * Features: Browser notifications, Real-time subscriptions, Visual banner
 */

class GlobalVideoCallNotifications {
  constructor() {
    this.currentUserId = null;
    this.currentUserEmail = null;
    this.subscription = null;
    this.notificationPermission = 'default';
    this.activeCallInvite = null;
  }

  async init() {
    console.log('[global-vc] Initializing...');
    
    // Wait for auth manager to be ready
    if (typeof window.authManager === 'undefined') {
      setTimeout(() => this.init(), 500);
      return;
    }

    // Wait for auth manager to initialize
    if (window.authManager._initPromise) {
      await window.authManager._initPromise;
    }

    const user = window.authManager.getCurrentUser();
    if (!user || !user.id) {
      console.log('[global-vc] No user logged in, will retry when user logs in');
      // Set up a listener for when user logs in
      setTimeout(() => this.init(), 2000);
      return;
    }

    this.currentUserId = user.id;
    this.currentUserEmail = user.email;
    
    console.log('[global-vc] User:', this.currentUserEmail);

    await this.requestNotificationPermission();
    this.createBannerUI();
    this.subscribeToVideoCallInvites();

    console.log('[global-vc] Active');
  }

  async requestNotificationPermission() {
    if (!('Notification' in window)) {
      console.warn('[global-vc] Browser does not support notifications');
      return;
    }

    this.notificationPermission = Notification.permission;

    // Check if we already asked the user before
    const hasAskedBefore = localStorage.getItem('rewear_notification_asked');
    
    // If permission is default (not asked yet) AND we haven't asked before
    if (this.notificationPermission === 'default' && !hasAskedBefore) {
      console.log('[global-vc] First time - requesting notification permission from user...');
      
      // Show a friendly message before requesting
      const shouldRequest = confirm(
        '📹 Video Call Notifications\n\n' +
        'Allow REWEAR to send you notifications when someone calls you?\n\n' +
        'You can receive video call alerts even when browsing other pages.\n\n' +
        'Click OK to enable notifications.'
      );
      
      // Mark that we asked (so we don't ask again)
      localStorage.setItem('rewear_notification_asked', 'true');
      
      if (shouldRequest) {
        this.notificationPermission = await Notification.requestPermission();
        
        if (this.notificationPermission === 'granted') {
          console.log('[global-vc] ✅ Notification permission GRANTED by user');
          // Show a test notification
          new Notification('🎉 Notifications Enabled!', {
            body: 'You will now receive video call notifications',
            icon: '/yoww-main/images/logo.png',
            tag: 'permission-granted'
          });
        } else {
          console.log('[global-vc] ⚠️ Notification permission DENIED by user');
        }
      } else {
        console.log('[global-vc] User declined to enable notifications');
        this.notificationPermission = 'denied';
      }
    } else if (this.notificationPermission === 'granted') {
      console.log('[global-vc] ✅ Notification permission already granted');
    } else if (hasAskedBefore) {
      console.log('[global-vc] Already asked user before, respecting their choice');
    } else {
      console.log('[global-vc] ⚠️ Notification permission denied (user can change in browser settings)');
    }
  }

  createBannerUI() {
    if (document.getElementById('global-vc-banner')) {
      return;
    }

    const banner = document.createElement('div');
    banner.id = 'global-vc-banner';
    banner.innerHTML = `
      <div style="display:flex;align-items:center;gap:16px;">
        <div style="width:48px;height:48px;border-radius:50%;background:rgba(255,255,255,0.2);display:flex;align-items:center;justify-content:center;font-size:24px;">📹</div>
        <div>
          <div style="font-weight:700;font-size:16px;margin-bottom:4px;" id="vc-banner-caller">Incoming Video Call</div>
          <div style="font-size:13px;opacity:0.9;">Someone is calling you...</div>
        </div>
      </div>
      <div style="display:flex;gap:12px;">
        <button id="vc-banner-answer" style="background:#27ae60;color:white;border:none;padding:12px 24px;border-radius:8px;font-weight:700;font-size:14px;cursor:pointer;">📞 Answer</button>
        <button id="vc-banner-decline" style="background:rgba(255,255,255,0.2);color:white;border:none;padding:12px 24px;border-radius:8px;font-weight:700;font-size:14px;cursor:pointer;">✕ Decline</button>
      </div>
    `;
    
    Object.assign(banner.style, {
      position: 'fixed',
      top: '-100px',
      left: '0',
      right: '0',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white',
      padding: '16px 20px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
      zIndex: '999999',
      transition: 'top 0.3s ease',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    });

    document.body.appendChild(banner);

    document.getElementById('vc-banner-answer').onclick = () => this.answerCall();
    document.getElementById('vc-banner-decline').onclick = () => this.declineCall();

    console.log('[global-vc] Banner UI created');
  }

  subscribeToVideoCallInvites() {
    if (!window.messagesDb) {
      setTimeout(() => this.subscribeToVideoCallInvites(), 1000);
      return;
    }

    const user = window.authManager.getCurrentUser();
    const roles = user?.roles || [];
    const isSeller = roles.includes('seller');
    const isBuyer = roles.includes('buyer');

    console.log('[global-vc] Setting up subscription for:', this.currentUserEmail, '| Roles:', roles);

    // Subscribe to buyer messages (when seller calls buyer)
    if (isBuyer) {
      console.log('[global-vc] Subscribing as BUYER (receive calls from sellers)');
      this.buyerSubscription = window.messagesDb
        .channel('global-vc-buyer')
        .on('postgres_changes', {
          event: 'UPDATE',
          schema: 'public',
          table: 'messages',
          filter: `buyer_email=eq.${this.currentUserEmail}`
        }, (payload) => {
          console.log('[global-vc] BUYER subscription triggered:', payload);
          this.handleMessageUpdate(payload, 'seller');
        })
        .subscribe();
    }

    // Subscribe to seller messages (when buyer calls seller)
    if (isSeller) {
      console.log('[global-vc] Subscribing as SELLER (receive calls from buyers)');
      this.sellerSubscription = window.messagesDb
        .channel('global-vc-seller')
        .on('postgres_changes', {
          event: 'UPDATE',
          schema: 'public',
          table: 'messages',
          filter: `seller_id=eq.${this.currentUserId}`
        }, (payload) => {
          console.log('[global-vc] SELLER subscription triggered:', payload);
          this.handleMessageUpdate(payload, 'buyer');
        })
        .subscribe();
    }

    console.log('[global-vc] Subscriptions active');
  }

  handleMessageUpdate(payload, callerRole) {
    const message = payload.new;
    
    if (!message || !message.thread) return;

    const thread = Array.isArray(message.thread) ? message.thread : [];
    
    // Look for video call invites from the caller
    const latestInvite = thread.slice().reverse().find(entry => 
      entry.type === 'video_call' && 
      entry.role === callerRole &&
      entry.roomId
    );

    if (!latestInvite) return;

    if (this.activeCallInvite && this.activeCallInvite.ts === latestInvite.ts) {
      return;
    }

    console.log('[global-vc] 🎥 INCOMING CALL from', callerRole, '!', latestInvite);

    // Determine caller name based on role
    let callerName;
    if (callerRole === 'seller') {
      callerName = message.seller_id ? `Seller ${message.seller_id.substring(0, 8)}` : 'Seller';
    } else {
      callerName = message.buyer_name || message.buyer_email || 'Buyer';
    }

    this.activeCallInvite = {
      ...latestInvite,
      messageId: message.id,
      sellerId: message.seller_id,
      buyerId: message.buyer_email,
      callerName: callerName,
      callerRole: callerRole
    };

    this.showIncomingCall();
  }

  showIncomingCall() {
    if (!this.activeCallInvite) return;

    const callerName = this.activeCallInvite.callerName;
    console.log('[global-vc] Showing call from:', callerName);

    this.showBrowserNotification(callerName);
    this.showBanner(callerName);
    this.playNotificationSound();
  }

  showBrowserNotification(callerName) {
    if (this.notificationPermission !== 'granted') {
      return;
    }

    const notification = new Notification('📹 Incoming Video Call', {
      body: `${callerName} is calling you`,
      tag: 'video-call',
      requireInteraction: true,
      vibrate: [200, 100, 200]
    });

    notification.onclick = () => {
      this.answerCall();
      notification.close();
    };

    console.log('[global-vc] Browser notification shown');
  }

  showBanner(callerName) {
    const banner = document.getElementById('global-vc-banner');
    const callerElement = document.getElementById('vc-banner-caller');

    if (banner && callerElement) {
      callerElement.textContent = `${callerName} is calling...`;
      banner.style.top = '0';
    }
  }

  hideBanner() {
    const banner = document.getElementById('global-vc-banner');
    if (banner) {
      banner.style.top = '-100px';
    }
  }

  playNotificationSound() {
    try {
      const audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.value = 800;
      oscillator.type = 'sine';

      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.5);
    } catch (e) {
      console.warn('[global-vc] Sound error:', e);
    }
  }

  answerCall() {
    if (!this.activeCallInvite) return;

    console.log('[global-vc] Answering call...', this.activeCallInvite);

    this.hideBanner();

    // Store call info for dashboard to pick up
    sessionStorage.setItem('incomingVideoCall', JSON.stringify({
      roomId: this.activeCallInvite.roomId,
      callerName: this.activeCallInvite.callerName,
      messageId: this.activeCallInvite.messageId,
      sellerId: this.activeCallInvite.sellerId,
      buyerId: this.activeCallInvite.buyerId,
      callerRole: this.activeCallInvite.callerRole,
      timestamp: new Date().toISOString()
    }));

    console.log('[global-vc] Stored call info in sessionStorage, redirecting to dashboard...');

    // Redirect to dashboard
    const currentPath = window.location.pathname;
    if (currentPath.includes('dashboard.html')) {
      // Already on dashboard, just trigger the call acceptance
      console.log('[global-vc] Already on dashboard, triggering call acceptance...');
      if (typeof window.vcAccept === 'function') {
        window.vcAccept();
      }
    } else {
      // Redirect to dashboard
      window.location.href = '/yoww-main/pages/dashboard.html#buyer-messages';
    }
  }

  declineCall() {
    console.log('[global-vc] Call declined');
    this.hideBanner();
    this.activeCallInvite = null;
  }

  destroy() {
    if (this.buyerSubscription) {
      this.buyerSubscription.unsubscribe();
    }
    if (this.sellerSubscription) {
      this.sellerSubscription.unsubscribe();
    }
    
    const banner = document.getElementById('global-vc-banner');
    if (banner) {
      banner.remove();
    }
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.globalVideoCallNotifications = new GlobalVideoCallNotifications();
    window.globalVideoCallNotifications.init();
    
    // Also listen for auth state changes
    if (window.authManager) {
      const originalOnAuthStateChange = window.authManager.onAuthStateChange;
      window.authManager.onAuthStateChange = function(callback) {
        const wrappedCallback = (event, session) => {
          if (event === 'SIGNED_IN' && session) {
            console.log('[global-vc] User signed in, initializing...');
            setTimeout(() => {
              window.globalVideoCallNotifications.init();
            }, 1000);
          }
          if (callback) callback(event, session);
        };
        if (originalOnAuthStateChange) {
          return originalOnAuthStateChange.call(this, wrappedCallback);
        }
      };
    }
  });
} else {
  window.globalVideoCallNotifications = new GlobalVideoCallNotifications();
  window.globalVideoCallNotifications.init();
  
  // Also listen for auth state changes
  if (window.authManager) {
    const originalOnAuthStateChange = window.authManager.onAuthStateChange;
    window.authManager.onAuthStateChange = function(callback) {
      const wrappedCallback = (event, session) => {
        if (event === 'SIGNED_IN' && session) {
          console.log('[global-vc] User signed in, initializing...');
          setTimeout(() => {
            window.globalVideoCallNotifications.init();
          }, 1000);
        }
        if (callback) callback(event, session);
      };
      if (originalOnAuthStateChange) {
        return originalOnAuthStateChange.call(this, wrappedCallback);
      }
    };
  }
}

console.log('[global-vc] Global video call notification system loaded');
