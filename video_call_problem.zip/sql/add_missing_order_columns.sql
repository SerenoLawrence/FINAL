-- Add missing columns to orders table
-- These columns are needed for the checkout process

-- Add payment-related columns
ALTER TABLE orders 
ADD COLUMN IF NOT EXISTS payment_method TEXT,
ADD COLUMN IF NOT EXISTS payment_proof_url TEXT,
ADD COLUMN IF NOT EXISTS payment_status TEXT DEFAULT 'pending',
ADD COLUMN IF NOT EXISTS payment_reference TEXT;

-- Add delivery-related columns
ALTER TABLE orders 
ADD COLUMN IF NOT EXISTS buyer_phone TEXT,
ADD COLUMN IF NOT EXISTS delivery_address TEXT,
ADD COLUMN IF NOT EXISTS delivery_preference TEXT DEFAULT 'meetup';

-- Add order tracking columns
ALTER TABLE orders 
ADD COLUMN IF NOT EXISTS courier_name TEXT,
ADD COLUMN IF NOT EXISTS tracking_number TEXT,
ADD COLUMN IF NOT EXISTS accepted BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS accepted_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_orders_payment_status ON orders(payment_status);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_buyer_email ON orders(buyer_email);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);

-- Add comments
COMMENT ON COLUMN orders.payment_method IS 'Payment method used (gcash, bank_transfer, etc)';
COMMENT ON COLUMN orders.payment_proof_url IS 'Cloudinary URL of payment receipt';
COMMENT ON COLUMN orders.payment_status IS 'Payment verification status: pending, submitted, verified, rejected';
COMMENT ON COLUMN orders.payment_reference IS 'Payment reference number';
COMMENT ON COLUMN orders.buyer_phone IS 'Buyer contact phone number';
COMMENT ON COLUMN orders.delivery_address IS 'Full delivery address';
COMMENT ON COLUMN orders.delivery_preference IS 'Delivery method: meetup, seller_delivers, courier';
COMMENT ON COLUMN orders.courier_name IS 'Courier service name (if applicable)';
COMMENT ON COLUMN orders.tracking_number IS 'Shipment tracking number';
COMMENT ON COLUMN orders.accepted IS 'Whether seller accepted the order';
COMMENT ON COLUMN orders.accepted_at IS 'Timestamp when seller accepted order';
