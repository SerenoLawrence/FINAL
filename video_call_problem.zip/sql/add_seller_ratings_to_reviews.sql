-- ============================================================
-- SELLER RATINGS - Integrated with Order Reviews
-- Only verified buyers (completed orders) can rate sellers
-- ============================================================

-- Table: seller_ratings (like/dislike votes from verified buyers)
CREATE TABLE IF NOT EXISTS seller_ratings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id UUID NOT NULL REFERENCES sellers(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  vote_type TEXT NOT NULL CHECK (vote_type IN ('like', 'dislike')),
  verified_purchase BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  -- One rating per user per seller per order
  UNIQUE(seller_id, user_id, order_id)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_seller_ratings_seller ON seller_ratings(seller_id);
CREATE INDEX IF NOT EXISTS idx_seller_ratings_user ON seller_ratings(user_id);
CREATE INDEX IF NOT EXISTS idx_seller_ratings_order ON seller_ratings(order_id);
CREATE INDEX IF NOT EXISTS idx_seller_ratings_vote_type ON seller_ratings(vote_type);

-- Enable Row Level Security
ALTER TABLE seller_ratings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for seller_ratings
CREATE POLICY "Anyone can view seller ratings"
  ON seller_ratings FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can insert their own ratings"
  ON seller_ratings FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own ratings"
  ON seller_ratings FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own ratings"
  ON seller_ratings FOR DELETE
  USING (auth.uid() = user_id);

-- Trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_seller_ratings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_seller_ratings_timestamp
  BEFORE UPDATE ON seller_ratings
  FOR EACH ROW
  EXECUTE FUNCTION update_seller_ratings_updated_at();

-- Grant permissions
GRANT SELECT ON seller_ratings TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON seller_ratings TO authenticated;

-- ============================================================
-- HELPER VIEWS (Optional - for easy querying)
-- ============================================================

-- View: Seller trust scores
CREATE OR REPLACE VIEW seller_trust_scores AS
SELECT 
  seller_id,
  COUNT(*) as total_ratings,
  COUNT(*) FILTER (WHERE vote_type = 'like') as likes,
  COUNT(*) FILTER (WHERE vote_type = 'dislike') as dislikes,
  ROUND(
    (COUNT(*) FILTER (WHERE vote_type = 'like')::numeric / 
     NULLIF(COUNT(*)::numeric, 0)) * 100
  ) as trust_score_percentage
FROM seller_ratings
GROUP BY seller_id;

-- Grant view access
GRANT SELECT ON seller_trust_scores TO anon, authenticated;

COMMENT ON TABLE seller_ratings IS 'Seller ratings from verified buyers (linked to completed orders)';
COMMENT ON COLUMN seller_ratings.vote_type IS 'like = trustworthy, dislike = not responsive';
COMMENT ON COLUMN seller_ratings.verified_purchase IS 'Always true - rating comes from completed order';
COMMENT ON VIEW seller_trust_scores IS 'Aggregated trust scores for sellers';
