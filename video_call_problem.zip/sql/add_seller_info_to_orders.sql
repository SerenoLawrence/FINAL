-- Add seller email and name columns to orders table
-- This allows displaying seller information without additional queries

ALTER TABLE orders 
ADD COLUMN IF NOT EXISTS seller_email TEXT,
ADD COLUMN IF NOT EXISTS seller_name TEXT;

-- Create index for faster seller lookups
CREATE INDEX IF NOT EXISTS idx_orders_seller_email ON orders(seller_email);

-- Add comment
COMMENT ON COLUMN orders.seller_email IS 'Seller email address for contact purposes';
COMMENT ON COLUMN orders.seller_name IS 'Seller display name at time of order';
