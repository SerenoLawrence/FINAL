-- ============================================================
-- SECURE ADMIN SYSTEM - Database-Based Admin Roles
-- Protects against client-side JavaScript manipulation
-- ============================================================

-- Table: admin_users (stores admin email whitelist)
CREATE TABLE IF NOT EXISTS admin_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL UNIQUE,
  full_name TEXT,
  added_by UUID REFERENCES auth.users(id),
  added_at TIMESTAMPTZ DEFAULT NOW(),
  last_login TIMESTAMPTZ,
  is_active BOOLEAN DEFAULT true,
  notes TEXT
);

-- Table: admin_audit_log (tracks all admin actions)
CREATE TABLE IF NOT EXISTS admin_audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_email TEXT NOT NULL,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id UUID,
  details JSONB,
  ip_address TEXT,
  user_agent TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_admin_users_email ON admin_users(email);
CREATE INDEX IF NOT EXISTS idx_admin_users_active ON admin_users(is_active);
CREATE INDEX IF NOT EXISTS idx_admin_audit_log_email ON admin_audit_log(admin_email);
CREATE INDEX IF NOT EXISTS idx_admin_audit_log_created ON admin_audit_log(created_at DESC);

-- Enable Row Level Security
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_audit_log ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- RLS POLICIES - CRITICAL FOR SECURITY
-- ============================================================

-- Policy: Only admins can view admin_users table
CREATE POLICY "Only admins can view admin users"
  ON admin_users FOR SELECT
  USING (
    email IN (SELECT email FROM admin_users WHERE is_active = true)
    OR
    auth.jwt() ->> 'email' IN (SELECT email FROM admin_users WHERE is_active = true)
  );

-- Policy: Only admins can insert new admins
CREATE POLICY "Only admins can add new admins"
  ON admin_users FOR INSERT
  WITH CHECK (
    auth.jwt() ->> 'email' IN (SELECT email FROM admin_users WHERE is_active = true)
  );

-- Policy: Only admins can update admin users
CREATE POLICY "Only admins can update admin users"
  ON admin_users FOR UPDATE
  USING (
    auth.jwt() ->> 'email' IN (SELECT email FROM admin_users WHERE is_active = true)
  );

-- Policy: Only admins can view audit logs
CREATE POLICY "Only admins can view audit logs"
  ON admin_audit_log FOR SELECT
  USING (
    auth.jwt() ->> 'email' IN (SELECT email FROM admin_users WHERE is_active = true)
  );

-- Policy: Anyone can insert audit logs (for tracking)
CREATE POLICY "Allow audit log inserts"
  ON admin_audit_log FOR INSERT
  WITH CHECK (true);

-- ============================================================
-- HELPER FUNCTION: Check if user is admin
-- ============================================================

CREATE OR REPLACE FUNCTION is_admin(user_email TEXT)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM admin_users 
    WHERE email = user_email 
    AND is_active = true
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- HELPER FUNCTION: Log admin action
-- ============================================================

CREATE OR REPLACE FUNCTION log_admin_action(
  p_admin_email TEXT,
  p_action TEXT,
  p_target_type TEXT DEFAULT NULL,
  p_target_id UUID DEFAULT NULL,
  p_details JSONB DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
  v_log_id UUID;
BEGIN
  INSERT INTO admin_audit_log (
    admin_email,
    action,
    target_type,
    target_id,
    details
  ) VALUES (
    p_admin_email,
    p_action,
    p_target_type,
    p_target_id,
    p_details
  ) RETURNING id INTO v_log_id;
  
  RETURN v_log_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- INSERT INITIAL ADMIN USERS
-- ⚠️ IMPORTANT: Replace these with your actual admin emails!
-- ============================================================

INSERT INTO admin_users (email, full_name, notes) VALUES
  ('admin1@gmail.com', 'Admin 1', 'Primary administrator - CHANGE THIS EMAIL'),
  ('admin2@gmail.com', 'Admin 2', 'Secondary administrator - CHANGE THIS EMAIL'),
  ('admin3@gmail.com', 'Admin 3', 'Tertiary administrator - CHANGE THIS EMAIL')
ON CONFLICT (email) DO NOTHING;

-- ============================================================
-- GRANT PERMISSIONS
-- ============================================================

GRANT SELECT ON admin_users TO authenticated;
GRANT INSERT ON admin_users TO authenticated;
GRANT UPDATE ON admin_users TO authenticated;

GRANT SELECT, INSERT ON admin_audit_log TO authenticated, anon;

-- ============================================================
-- VERIFICATION QUERIES (Run these to test)
-- ============================================================

-- View all admin users
-- SELECT * FROM admin_users;

-- Check if an email is admin
-- SELECT is_admin('your-email@gmail.com');

-- View recent admin actions
-- SELECT * FROM admin_audit_log ORDER BY created_at DESC LIMIT 10;

-- ============================================================
-- SECURITY NOTES
-- ============================================================

/*
1. Admin emails are stored SERVER-SIDE in database
2. RLS policies prevent non-admins from viewing admin list
3. JavaScript cannot bypass these security checks
4. All admin actions are logged with timestamp
5. Admins can be deactivated without deleting records
6. Audit trail shows who did what and when

TO ADD A NEW ADMIN:
INSERT INTO admin_users (email, full_name) 
VALUES ('newemail@gmail.com', 'New Admin Name');

TO REMOVE AN ADMIN:
UPDATE admin_users SET is_active = false WHERE email = 'email@gmail.com';

TO VIEW AUDIT LOG:
SELECT * FROM admin_audit_log WHERE admin_email = 'email@gmail.com';
*/

COMMENT ON TABLE admin_users IS 'Stores admin user whitelist - server-side security';
COMMENT ON TABLE admin_audit_log IS 'Tracks all admin actions for security auditing';
COMMENT ON FUNCTION is_admin IS 'Server-side function to verify admin status';
COMMENT ON FUNCTION log_admin_action IS 'Logs admin actions for audit trail';
