-- Add payment_proof_url column to orders table if it doesn't exist
-- This column stores the URL of the payment proof image uploaded by buyers

ALTER TABLE orders
ADD COLUMN IF NOT EXISTS payment_proof_url TEXT;

-- Add comment to document the column
COMMENT ON COLUMN orders.payment_proof_url IS 'URL of the payment proof image uploaded by the buyer for verification';

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_orders_payment_proof_url ON orders(payment_proof_url) WHERE payment_proof_url IS NOT NULL;
