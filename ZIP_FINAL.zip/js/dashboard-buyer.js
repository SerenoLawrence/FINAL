// ============================================================
// dashboard-buyer.js — Buyer dashboard logic
// Used on: dashboard-buyer.html
// ============================================================

// ============================================================
// ORDER DETAILS MODAL FUNCTION
// ============================================================
async function openOrderDetailsModal(orderId) {
  console.log('[orderDetailsModal] ✅ FUNCTION CALLED from dashboard-buyer.js with orderId:', orderId);
  
  const modal = document.getElementById('orderDetailsModal');
  const content = document.getElementById('orderDetailsContent');
  
  console.log('[orderDetailsModal] Modal element:', modal ? '✅ FOUND' : '❌ NOT FOUND');
  console.log('[orderDetailsModal] Content element:', content ? '✅ FOUND' : '❌ NOT FOUND');
  
  if (!modal || !content) {
    console.error('[orderDetailsModal] ❌ Modal or content element not found');
    return;
  }
  
  content.innerHTML = '<p style="text-align:center;color:#999;">Loading order details...</p>';
  modal.style.display = 'block';
  console.log('[orderDetailsModal] Modal displayed');
  
  try {
    const { data: order, error } = await db
      .from('orders')
      .select('*, products(id, name, image_url)')
      .eq('id', orderId)
      .single();
    
    if (error || !order) {
      console.error('[orderDetailsModal] Error loading order:', error);
      content.innerHTML = '<p style="color:#e74c3c;">Could not load order details.</p>';
      return;
    }
    
    console.log('[orderDetailsModal] Order loaded:', order);
    
    const product = order.products;
    const lsTracking = JSON.parse(localStorage.getItem(`rewear_tracking_${order.id}`) || '{}');
    const courierName = order.courier_name || lsTracking.courier_name || null;
    const trackingNumber = order.tracking_number || lsTracking.tracking_number || null;
    
    const paymentBadge = {
      pending:   '<span style="background:#fff3cd;color:#856404;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">⏳ Awaiting Payment</span>',
      submitted: '<span style="background:#cce5ff;color:#004085;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">📤 Payment Submitted</span>',
      verified:  '<span style="background:#d4edda;color:#155724;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">✅ Payment Verified</span>',
      rejected:  '<span style="background:#f8d7da;color:#721c24;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">❌ Payment Rejected</span>'
    }[order.payment_status || 'pending'] || '';
    
    let html = `
      <div style="margin-bottom:20px;">
        <h3 style="margin:0 0 12px;font-size:16px;font-weight:700;">Order ${order.id.slice(0, 8).toUpperCase()}</h3>
        <p style="margin:0;color:#999;font-size:13px;">Placed on ${new Date(order.created_at).toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' })}</p>
      </div>
      
      <div style="background:#f9f9f9;border-radius:12px;padding:16px;margin-bottom:16px;">
        <div style="display:flex;gap:12px;margin-bottom:12px;">
          ${product?.image_url ? `<img src="${product.image_url}" alt="${product?.name}" style="width:80px;height:80px;object-fit:cover;border-radius:8px;">` : '<div style="width:80px;height:80px;background:#eee;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:24px;">📦</div>'}
          <div style="flex:1;">
            <h4 style="margin:0 0 4px;font-size:15px;font-weight:700;">${product?.name || 'Product'}</h4>
            <p style="margin:0 0 4px;color:#666;font-size:13px;">Size: ${order.size_selected || '—'}</p>
            <p style="margin:0;color:#666;font-size:13px;">Quantity: ${order.quantity || 1}</p>
          </div>
        </div>
        <div style="border-top:1px solid #e0e0e0;padding-top:12px;text-align:right;">
          <p style="margin:0;font-size:14px;font-weight:700;color:#1a1a2e;">Total: ₱${parseFloat(order.total_price || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
        </div>
      </div>
      
      <div style="background:#f9f9f9;border-radius:12px;padding:16px;margin-bottom:16px;">
        <h4 style="margin:0 0 12px;font-size:14px;font-weight:700;">Order Information</h4>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:13px;">
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Status</p>
            <p style="margin:0;color:#1a1a2e;font-weight:600;">${order.status.replace(/_/g, ' ').toUpperCase()}</p>
          </div>
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Payment</p>
            <p style="margin:0;">${paymentBadge}</p>
          </div>
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Buyer Name</p>
            <p style="margin:0;color:#1a1a2e;">${order.buyer_name || '—'}</p>
          </div>
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Buyer Email</p>
            <p style="margin:0;color:#1a1a2e;font-size:12px;">${order.buyer_email || '—'}</p>
          </div>
        </div>
        
        ${order.delivery_address ? `
        <div style="margin-top:12px;padding-top:12px;border-top:1px solid #e0e0e0;">
          <p style="margin:0 0 4px;color:#999;font-weight:600;font-size:13px;">Delivery Address</p>
          <p style="margin:0;color:#1a1a2e;font-size:13px;">${order.delivery_address}</p>
        </div>` : ''}
        
        ${order.payment_reference ? `
        <div style="margin-top:12px;padding-top:12px;border-top:1px solid #e0e0e0;">
          <p style="margin:0 0 4px;color:#999;font-weight:600;font-size:13px;">Payment Reference</p>
          <p style="margin:0;color:#c8a96e;font-weight:700;font-size:13px;">${order.payment_reference}</p>
        </div>` : ''}
      </div>
      
      ${courierName || trackingNumber ? `
      <div style="background:#f0f9f0;border-radius:12px;padding:16px;margin-bottom:16px;">
        <h4 style="margin:0 0 12px;font-size:14px;font-weight:700;">📦 Tracking Information</h4>
        <div style="font-size:13px;">
          ${courierName ? `<p style="margin:0 0 8px;"><strong>Courier:</strong> ${courierName}</p>` : ''}
          ${trackingNumber ? `<p style="margin:0;"><strong>Tracking #:</strong> <span style="color:#c8a96e;font-weight:700;">${trackingNumber}</span></p>` : ''}
        </div>
      </div>` : ''}
    `;
    
    content.innerHTML = html;
    console.log('[orderDetailsModal] ✅ Modal content updated successfully');
    
    const trackingLink = document.getElementById('orderTrackingLink');
    if (trackingLink) {
      const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
      trackingLink.href = `${prefix}order-tracking.html?id=${order.id}`;
    }
    
  } catch (error) {
    console.error('[orderDetailsModal] ❌ Error:', error);
    content.innerHTML = '<p style="color:#e74c3c;">Error loading order details. Please try again.</p>';
  }
}

function closeOrderDetailsModal() {
  console.log('[orderDetailsModal] Closing modal');
  const modal = document.getElementById('orderDetailsModal');
  if (modal) modal.style.display = 'none';
}

// ---- TAB SWITCHING ----
document.querySelectorAll('.dash-nav-link').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const tab = link.dataset.tab;
    console.log('[buyer] Tab clicked:', tab);
    document.querySelectorAll('.dash-nav-link').forEach(l => l.classList.remove('active'));
    document.querySelectorAll('.dash-tab').forEach(t => t.classList.remove('active'));
    link.classList.add('active');
    const tabEl = document.getElementById(`tab-${tab}`);
    if (tabEl) tabEl.classList.add('active');
    const titleEl = document.getElementById('dashPageTitle');
    if (titleEl) titleEl.textContent = link.textContent.trim();
    
    if (tab === 'orders')   loadBuyerOrders();
    if (tab === 'addresses') loadBuyerAddresses();
    if (tab === 'messages') {
      console.log('[buyer] Messages tab activated, calling loadBuyerMessages()');
      // Small delay to ensure DOM is ready
      setTimeout(() => {
        loadBuyerMessages();
      }, 100);
    }
  });
});

// ---- OVERVIEW STATS ----
async function loadOverviewStats() {
  const currentUser = authManager.getCurrentUser();
  if (!currentUser) return;

  try {
    console.log('[buyer] Loading stats for user:', currentUser.email);

    // Use buyer_email to match orders since buyer_user_id doesn't exist
    const { count: totalOrders } = await db
      .from('orders')
      .select('*', { count: 'exact', head: true })
      .eq('buyer_email', currentUser.email);

    const { count: pendingOrders } = await db
      .from('orders')
      .select('*', { count: 'exact', head: true })
      .eq('buyer_email', currentUser.email)
      .eq('status', 'pending');

    const { count: deliveredOrders } = await db
      .from('orders')
      .select('*', { count: 'exact', head: true })
      .eq('buyer_email', currentUser.email)
      .eq('status', 'delivered');

    // Calculate total spent
    const { data: orders } = await db
      .from('orders')
      .select('total_price')
      .eq('buyer_email', currentUser.email);

    const totalSpent = (orders || []).reduce((sum, order) => sum + parseFloat(order.total_price || 0), 0);

    console.log('[buyer] Stats loaded:', { totalOrders, pendingOrders, deliveredOrders, totalSpent });

    // Update stats
    const el = id => document.getElementById(id);
    if (el('statTotalOrders')) el('statTotalOrders').textContent = totalOrders ?? 0;
    if (el('statPendingOrders')) el('statPendingOrders').textContent = pendingOrders ?? 0;
    if (el('statDeliveredOrders')) el('statDeliveredOrders').textContent = deliveredOrders ?? 0;
    if (el('statTotalSpent')) el('statTotalSpent').textContent = formatPHP(totalSpent);

    // Update orders badge in sidebar
    const ordersBadge = document.getElementById('ordersBadge');
    if (ordersBadge) {
      if (totalOrders > 0) {
        ordersBadge.textContent = totalOrders > 99 ? '99+' : totalOrders;
        ordersBadge.style.display = 'inline-flex';
      } else {
        ordersBadge.style.display = 'none';
      }
    }

    // Load recent orders
    const { data: recentOrders } = await db
      .from('orders')
      .select('*, products(id, name, image_url)')
      .eq('buyer_email', currentUser.email)
      .order('created_at', { ascending: false })
      .limit(5);

    const list = document.getElementById('recentOrdersList');
    if (list) {
      const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
      list.innerHTML = recentOrders?.length
        ? recentOrders.map(o => orderRowHTML(o)).join('')
        : `<p class="dash-empty">No orders yet. <a href="${prefix}shop.html">Start shopping!</a></p>`;
    }

  } catch (error) {
    console.error('[buyer] loadOverviewStats:', error.message);
    console.error('[buyer] Full error:', error);
  }
}

// ---- ORDERS TAB ----
function orderRowHTML(o) {
  // Get the order ID - try different possible field names
  const orderId = o.id || o.order_id || o.uuid || o.product_id;
  
  const productName  = o.products?.name || 'Product';
  const productImage = o.products?.image_url || '';
  const productId    = o.products?.id || o.product_id || '';
  const lsTracking = JSON.parse(localStorage.getItem(`rewear_tracking_${orderId}`) || '{}');
  const courierName    = o.courier_name    || lsTracking.courier_name    || null;
  const trackingNumber = o.tracking_number || lsTracking.tracking_number || null;
  const hasTracking    = courierName || trackingNumber;
  const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';

  // Debug: log the order object
  console.log('[buyer] orderRowHTML - Full order object:', o);
  console.log('[buyer] orderRowHTML - Resolved orderId:', orderId, 'All keys:', Object.keys(o));

  // Flow status banner
  const flowBanners = {
    pending:   { bg:'#fff8e1', color:'#856404', icon:'⏳', text:'Waiting for your payment proof upload' },
    confirmed: { bg:'#e8f5e9', color:'#1b5e20', icon:'✅', text:'Payment verified — seller is preparing your item' },
    shipped:   { bg:'#e3f2fd', color:'#0d47a1', icon:'🚚', text:'Your order is on the way!' },
    delivered: { bg:'#f3e5f5', color:'#4a148c', icon:'🎉', text:'Order delivered — please confirm receipt to complete the transaction' },
    received:  { bg:'#e8f5e9', color:'#1b5e20', icon:'🏁', text:'Transaction complete — thank you for shopping on REWEAR!' },
    cancelled: { bg:'#fce4ec', color:'#880e4f', icon:'❌', text:'Order cancelled' }
  };
  const pStatus = o.payment_status;
  let banner = flowBanners[o.status] || { bg:'#f5f5f5', color:'#333', icon:'•', text: o.status };

  if (pStatus === 'submitted' && o.status === 'pending') {
    banner = { bg:'#e3f2fd', color:'#0d47a1', icon:'📤', text:'Payment proof submitted — awaiting admin verification' };
  } else if (pStatus === 'rejected') {
    banner = { bg:'#fce4ec', color:'#880e4f', icon:'❌', text:`Payment rejected${o.payment_rejected_reason ? ': ' + o.payment_rejected_reason : ''}` };
  }

  // Escape strings for inline onclick
  const safeProductName = productName.replace(/'/g, "\\'").replace(/"/g, '&quot;');
  const safeProductImg  = productImage.replace(/'/g, "\\'");
  const formattedPrice = formatPHP(o.total_price || 0);

  return `
    <div class="dash-order-row" data-order-id="${orderId}" style="cursor:pointer;transition:all 0.2s;border-left:4px solid #c8a96e;">
      <div style="display:flex;align-items:flex-start;gap:16px;flex:1;">
        <!-- Product Image -->
        <div style="flex-shrink:0;">
          ${productImage
            ? `<img src="${productImage}" alt="${productName}"
                 style="width:80px;height:80px;object-fit:cover;border-radius:12px;cursor:pointer;border:2px solid #f0f0f0;box-shadow:0 2px 8px rgba(0,0,0,0.1);"
                 onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%22100%22%3E%3Crect fill=%22%23f0f0f0%22 width=%22100%22 height=%22100%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 text-anchor=%22middle%22 dy=%22.3em%22 font-size=%2214%22 fill=%22%23999%22%3ENo Image%3C/text%3E%3C/svg%3E'">`
            : `<div style="width:80px;height:80px;background:#f0f0f0;border-radius:12px;display:flex;align-items:center;justify-content:center;color:#999;font-size:12px;text-align:center;">No Image</div>`
          }
        </div>

        <!-- Order Details PREVIEW -->
        <div style="flex:1;">
          <p class="dash-order-name" style="cursor:pointer;text-decoration:underline;text-decoration-color:#c8a96e;margin:0 0 6px 0;font-weight:700;font-size:15px;">
            ${productName}
          </p>
          <p class="dash-order-meta" style="margin:0 0 4px 0;font-size:13px;">
            <strong>${formattedPrice}</strong> · Size: ${o.size_selected || '—'} · Qty: ${o.quantity || 1}
          </p>
          <p class="dash-order-meta" style="margin:0 0 8px 0;font-size:12px;color:#999;">
            Order Date: ${formatDate(o.created_at)}
          </p>

          <!-- Order Status Banner -->
          <div style="margin-top:8px;padding:8px 12px;background:${banner.bg};border-radius:6px;font-size:13px;color:${banner.color};font-weight:500;">
            ${banner.icon} ${banner.text}
          </div>

          <!-- Tracking Info if available -->
          ${hasTracking ? `
          <div style="margin-top:8px;padding:8px 12px;background:#f0f9f0;border-radius:6px;font-size:12px;">
            <strong>📦 Tracking:</strong> ${courierName ? courierName + ' · ' : ''}${trackingNumber || 'Pending'}
          </div>` : ''}

          <!-- Delivery Address Preview -->
          ${o.delivery_address ? `
          <div style="margin-top:8px;padding:8px 12px;background:#f5f5f5;border-radius:6px;font-size:12px;">
            <strong>📍 Delivery:</strong> ${o.delivery_address.substring(0, 50)}${o.delivery_address.length > 50 ? '...' : ''}
          </div>` : ''}

          <!-- Action Buttons -->
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;">
            <a href="${prefix}order-tracking.html?id=${orderId}"
              style="padding:7px 14px;background:#f5f5f5;color:#333;border:none;border-radius:6px;font-size:13px;font-weight:600;cursor:pointer;text-decoration:none;transition:all 0.2s;">
              🔍 Track
            </a>
            ${o.status === 'pending' ? `
            <button onclick="cancelOrder('${orderId}');event.stopPropagation();"
                    style="padding:7px 14px;background:#e74c3c;color:#fff;border:none;border-radius:6px;font-size:13px;font-weight:600;cursor:pointer;transition:all 0.2s;">
              ✕ Cancel
            </button>` : ''}
            ${o.status === 'delivered' ? `
            <button onclick="confirmReceipt('${orderId}');event.stopPropagation();"
                    style="padding:7px 14px;background:#27ae60;color:#fff;border:none;border-radius:6px;font-size:13px;font-weight:600;cursor:pointer;transition:all 0.2s;">
              ✓ Confirm Receipt
            </button>` : ''}
            ${o.status === 'received' ? `
            <button onclick="openBuyerReviewModal('${orderId}','${safeProductName}','${productId}','${safeProductImg}');event.stopPropagation();"
                    style="padding:7px 14px;background:linear-gradient(135deg,#c8a96e,#e0c080);color:#fff;border:none;border-radius:6px;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 3px 10px rgba(200,169,110,.4);transition:all 0.2s;">
              ⭐ Review
            </button>` : ''}
            <button onclick="openOrderChat('${orderId}','${safeProductName}');event.stopPropagation();"
                    style="padding:7px 14px;background:#3498db;color:#fff;border:none;border-radius:6px;font-size:13px;font-weight:600;cursor:pointer;transition:all 0.2s;">
              💬 Chat
            </button>
          </div>
        </div>
      </div>
      <span class="dash-order-status status-${o.status}">${o.status.replace(/_/g,' ')}</span>
    </div>`;
}

async function confirmReceipt(orderId) {
  if (!confirm('Confirm that you have received this order?')) return;
  
  try {
    // Try with received_at first (requires 06_buyer_flow.sql)
    let error;
    ({ error } = await db.from('orders').update({
      status: 'received',
      received_at: new Date().toISOString()
    }).eq('id', orderId));

    if (error?.message?.includes('received_at')) {
      ({ error } = await db.from('orders').update({ status: 'received' }).eq('id', orderId));
    }
    if (error) throw error;
      
    showSuccess('Receipt Confirmed!', 'Thank you for confirming your order receipt.', 'Got it');
    loadBuyerOrders();
    loadOverviewStats();
  } catch (error) {
    showError('Error', 'Could not confirm receipt. Please try again.');
    console.error('[buyer] confirmReceipt:', error);
  }
}

async function cancelOrder(orderId) {
  if (!confirm('Are you sure you want to cancel this order? This action cannot be undone.')) return;
  
  try {
    const { error } = await db.from('orders').update({
      status: 'cancelled',
      cancelled_at: new Date().toISOString()
    }).eq('id', orderId);
    
    if (error) throw error;
    
    showSuccess('Order Cancelled', 'Your order has been cancelled successfully.', 'Got it');
    loadBuyerOrders();
    loadOverviewStats();
  } catch (error) {
    showError('Error', 'Could not cancel order. Please try again.');
    console.error('[buyer] cancelOrder:', error);
  }
}

function openOrderChat(orderId, productName) {
  console.log('[buyer] Opening chat for order:', orderId, 'Product:', productName);
  
  // Switch to messages tab
  const messagesTab = document.querySelector('[data-tab="buyer-messages"]');
  if (messagesTab) {
    messagesTab.click();
    
    // Store the order context for the chat
    sessionStorage.setItem('orderChatContext', JSON.stringify({
      orderId: orderId,
      productName: productName,
      timestamp: new Date().toISOString()
    }));
    
    showSuccess('Chat Opened', `You can now discuss "${productName}" with the seller.`, 'Got it');
  } else {
    showError('Error', 'Could not open messages. Please try again.');
  }
}

async function loadBuyerOrders() {
  const currentUser = authManager.getCurrentUser();
  if (!currentUser) return;

  const list = document.getElementById('buyerOrdersList');
  if (!list) return;
  list.innerHTML = '<p class="dash-empty">Loading…</p>';

  const statusFilter = document.getElementById('orderStatusFilter')?.value || 'all';
  let query = db
    .from('orders')
    .select('*,products(id,name,image_url)')
    .eq('buyer_email', currentUser.email)
    .order('created_at', { ascending: false });

  if (statusFilter !== 'all') {
    query = query.eq('status', statusFilter);
  }

  try {
    const { data, error } = await query;
    if (error) throw error;

    console.log('[buyer] Orders loaded:', data?.length || 0, 'orders');
    console.log('[buyer] First order object:', data?.[0]);
    console.log('[buyer] First order keys:', Object.keys(data?.[0] || {}));

    list.innerHTML = data?.length 
      ? data.map(o => orderRowHTML(o)).join('') 
      : '<p class="dash-empty">No orders found.</p>';

    // Add event listeners to order rows
    document.querySelectorAll('.dash-order-row').forEach(row => {
      const orderId = row.getAttribute('data-order-id');
      console.log('[buyer] Setting up click listener for order:', orderId);
      row.addEventListener('click', function(e) {
        // Don't trigger if clicking on buttons or links
        if (e.target.closest('button, a')) {
          console.log('[buyer] Click on button/link, ignoring');
          return;
        }
        const orderId = this.getAttribute('data-order-id');
        console.log('[buyer] Order row clicked - orderId:', orderId, 'Type:', typeof orderId);
        if (orderId && orderId !== 'null' && orderId !== '') {
          console.log('[buyer] Opening modal for order:', orderId);
          openOrderDetailsModal(orderId);
        } else {
          console.error('[buyer] Invalid orderId:', orderId);
        }
      });
    });

    // Update badge in sidebar
    const badge = document.getElementById('buyerOrdersCount');
    if (badge && data?.length > 0) {
      badge.textContent = data.length > 99 ? '99+' : data.length;
      badge.style.display = 'inline-block';
    } else if (badge) {
      badge.style.display = 'none';
    }

    // Also call the dashboard badge update function if it exists
    if (typeof updateBuyerOrdersBadge === 'function') {
      updateBuyerOrdersBadge();
    }

  } catch (error) {
    list.innerHTML = '<p class="dash-empty">Could not load orders.</p>';
    console.error('[buyer] loadBuyerOrders:', error.message);
    console.error('[buyer] Full error:', error);
  }
}

document.getElementById('orderStatusFilter')?.addEventListener('change', loadBuyerOrders);

// ---- PROFILE MANAGEMENT ----
async function loadBuyerProfile() {
  const currentUser = authManager.getCurrentUser();
  if (!currentUser) return;

  try {
    console.log('[buyer] Loading profile for user:', currentUser.email);

    // Populate form fields with current user data
    const nameField = document.getElementById('buyerName');
    const emailField = document.getElementById('buyerEmail');
    const phoneField = document.getElementById('buyerPhone');

    if (nameField) nameField.value = currentUser.name || '';
    if (emailField) emailField.value = currentUser.email || '';
    if (phoneField) phoneField.value = ''; // Phone not stored in local auth

    console.log('[buyer] Profile loaded successfully');

  } catch (error) {
    console.error('[buyer] loadBuyerProfile:', error.message);
  }
}

// ---- PROFILE FORM ----
document.getElementById('buyerProfileForm')?.addEventListener('submit', async e => {
  e.preventDefault();
  
  const currentUser = authManager.getCurrentUser();
  if (!currentUser) return;

  const payload = {
    name: document.getElementById('buyerName').value.trim(),
    phone: document.getElementById('buyerPhone').value.trim()
  };

  // Validation
  if (!payload.name || payload.name.length < 2) {
    showError('Validation Error', 'Name must be at least 2 characters');
    return;
  }

  if (payload.phone && !validators.phone(payload.phone)) {
    showError('Validation Error', validationMessages.phone);
    return;
  }

  showLoadingModal('Saving…', 'Updating your profile.');

  try {
    // Update local auth user data
    const users = JSON.parse(localStorage.getItem('rewear_users') || '[]');
    const userIndex = users.findIndex(u => u.id === currentUser.id);
    
    if (userIndex !== -1) {
      users[userIndex].name = payload.name;
      localStorage.setItem('rewear_users', JSON.stringify(users));
      
      // Update current user session
      currentUser.name = payload.name;
      localStorage.setItem('rewear_current_user', JSON.stringify(currentUser));
    }

    hideLoadingModal();
    showSuccess('Profile Updated!', 'Your profile has been saved successfully.', 'Got it');

    console.log('[buyer] Profile updated successfully');

  } catch (error) {
    hideLoadingModal();
    showError('Save Failed', error.message);
    console.error('[buyer] saveProfile:', error.message);
  }
});

// ---- ADDRESSES MANAGEMENT ----
async function loadBuyerAddresses() {
  const currentUser = authManager.getCurrentUser();
  if (!currentUser) return;

  const list = document.getElementById('addressesList');
  if (!list) return;

  list.innerHTML = '<p class="dash-empty">Address management coming soon...</p>';

  // Note: Address functionality is not implemented in the current database schema
  console.log('[buyer] Address management not implemented yet');
}

// ---- ADDRESS ACTIONS ----
async function editAddress(addressId) {
  // Open address editing modal
  const currentUser = window.authManager?.getCurrentUser();
  if (!currentUser) return;
  
  try {
    // Fetch the address
    const { data: address, error } = await window.db
      .from('buyer_addresses')
      .select('*')
      .eq('id', addressId)
      .eq('buyer_email', currentUser.email)
      .single();
    
    if (error || !address) {
      showError('Not Found', 'Address not found.');
      return;
    }
    
    // Create edit modal
    const overlay = document.createElement('div');
    overlay.id = 'editAddressOverlay';
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;';
    
    overlay.innerHTML = `
      <div style="background:#fff;border-radius:16px;padding:28px;max-width:440px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,0.3);">
        <h3 style="margin:0 0 4px;font-size:18px;">Edit Address</h3>
        <p style="color:#888;font-size:13px;margin:0 0 20px;">Update your delivery address</p>
        
        <div style="margin-bottom:12px;">
          <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Full Name</label>
          <input id="editAddrName" type="text" value="${address.full_name || ''}" placeholder="Full name"
            style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
        </div>
        
        <div style="margin-bottom:12px;">
          <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Phone</label>
          <input id="editAddrPhone" type="tel" value="${address.phone || ''}" placeholder="+63 XXX XXX XXXX"
            style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
        </div>
        
        <div style="margin-bottom:12px;">
          <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Street Address</label>
          <input id="editAddrStreet" type="text" value="${address.street || ''}" placeholder="Street address"
            style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
        </div>
        
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
          <div>
            <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">City</label>
            <input id="editAddrCity" type="text" value="${address.city || ''}" placeholder="City"
              style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
          </div>
          <div>
            <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Postal Code</label>
            <input id="editAddrZip" type="text" value="${address.postal_code || ''}" placeholder="Postal code"
              style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
          </div>
        </div>
        
        <div style="display:flex;gap:10px;">
          <button onclick="saveEditedAddress('${addressId}')"
            style="flex:1;padding:12px;background:#1a1a2e;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:700;cursor:pointer;">
            Save Changes
          </button>
          <button onclick="document.getElementById('editAddressOverlay').remove()"
            style="padding:12px 18px;background:#f5f5f5;color:#333;border:none;border-radius:8px;font-size:14px;cursor:pointer;">
            Cancel
          </button>
        </div>
      </div>`;
    
    document.body.appendChild(overlay);
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
    
  } catch (err) {
    console.error('[editAddress]', err);
    showError('Error', 'Could not load address.');
  }
}

async function saveEditedAddress(addressId) {
  const name = document.getElementById('editAddrName')?.value.trim();
  const phone = document.getElementById('editAddrPhone')?.value.trim();
  const street = document.getElementById('editAddrStreet')?.value.trim();
  const city = document.getElementById('editAddrCity')?.value.trim();
  const zip = document.getElementById('editAddrZip')?.value.trim();
  
  if (!name || !phone || !street || !city || !zip) {
    showError('Missing Fields', 'Please fill in all address fields.');
    return;
  }
  
  try {
    showLoadingModal('Saving…', 'Updating your address.');
    
    const { error } = await window.db
      .from('buyer_addresses')
      .update({
        full_name: name,
        phone,
        street,
        city,
        postal_code: zip,
        updated_at: new Date().toISOString()
      })
      .eq('id', addressId);
    
    if (error) throw error;
    
    hideLoadingModal();
    document.getElementById('editAddressOverlay')?.remove();
    showSuccess('Address Updated', 'Your address has been saved.', 'Got it');
    loadBuyerAddresses();
    
  } catch (err) {
    hideLoadingModal();
    console.error('[saveEditedAddress]', err);
    showError('Save Failed', 'Could not save address.');
  }
}

async function deleteAddress(addressId) {
  if (!confirm('Are you sure you want to delete this address?')) return;

  showLoadingModal('Deleting…', 'Removing address.');

  try {
    const { error } = await db
      .from('buyer_addresses')
      .delete()
      .eq('id', addressId);

    if (error) throw error;

    hideLoadingModal();
    showSuccess('Address Deleted', 'The address has been removed.', 'Got it');
    loadBuyerAddresses();

  } catch (error) {
    hideLoadingModal();
    showError('Delete Failed', error.message);
    console.error('[buyer] deleteAddress:', error.message);
  }
}

document.getElementById('addAddressBtn')?.addEventListener('click', () => {
  // Open add address modal
  const currentUser = window.authManager?.getCurrentUser();
  if (!currentUser) return;
  
  const overlay = document.createElement('div');
  overlay.id = 'addAddressOverlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;';
  
  overlay.innerHTML = `
    <div style="background:#fff;border-radius:16px;padding:28px;max-width:440px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,0.3);">
      <h3 style="margin:0 0 4px;font-size:18px;">Add New Address</h3>
      <p style="color:#888;font-size:13px;margin:0 0 20px;">Add a new delivery address</p>
      
      <div style="margin-bottom:12px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Full Name</label>
        <input id="newAddrName" type="text" placeholder="Full name"
          style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
      </div>
      
      <div style="margin-bottom:12px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Phone</label>
        <input id="newAddrPhone" type="tel" placeholder="+63 XXX XXX XXXX"
          style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
      </div>
      
      <div style="margin-bottom:12px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Street Address</label>
        <input id="newAddrStreet" type="text" placeholder="Street address"
          style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
      </div>
      
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
        <div>
          <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">City</label>
          <input id="newAddrCity" type="text" placeholder="City"
            style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
        </div>
        <div>
          <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Postal Code</label>
          <input id="newAddrZip" type="text" placeholder="Postal code"
            style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
        </div>
      </div>
      
      <div style="display:flex;gap:10px;">
        <button onclick="saveNewAddress()"
          style="flex:1;padding:12px;background:#1a1a2e;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:700;cursor:pointer;">
          Add Address
        </button>
        <button onclick="document.getElementById('addAddressOverlay').remove()"
          style="padding:12px 18px;background:#f5f5f5;color:#333;border:none;border-radius:8px;font-size:14px;cursor:pointer;">
          Cancel
        </button>
      </div>
    </div>`;
  
  document.body.appendChild(overlay);
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
});

async function saveNewAddress() {
  const currentUser = window.authManager?.getCurrentUser();
  if (!currentUser) return;
  
  const name = document.getElementById('newAddrName')?.value.trim();
  const phone = document.getElementById('newAddrPhone')?.value.trim();
  const street = document.getElementById('newAddrStreet')?.value.trim();
  const city = document.getElementById('newAddrCity')?.value.trim();
  const zip = document.getElementById('newAddrZip')?.value.trim();
  
  if (!name || !phone || !street || !city || !zip) {
    showError('Missing Fields', 'Please fill in all address fields.');
    return;
  }
  
  try {
    showLoadingModal('Adding…', 'Creating new address.');
    
    const { error } = await window.db
      .from('buyer_addresses')
      .insert({
        buyer_email: currentUser.email,
        full_name: name,
        phone,
        street,
        city,
        postal_code: zip,
        is_default: false,
        created_at: new Date().toISOString()
      });
    
    if (error) throw error;
    
    hideLoadingModal();
    document.getElementById('addAddressOverlay')?.remove();
    showSuccess('Address Added', 'Your new address has been saved.', 'Got it');
    loadBuyerAddresses();
    
  } catch (err) {
    hideLoadingModal();
    console.error('[saveNewAddress]', err);
    showError('Add Failed', 'Could not add address.');
  }
}

// ---- MESSAGES / CHAT TAB ----
let activeChatId = null; // currently open message thread id

async function loadBuyerMessages() {
  const currentUser = authManager.getCurrentUser();
  console.log('[buyer] loadBuyerMessages: Current user:', currentUser);
  
  if (!currentUser) {
    console.error('[buyer] loadBuyerMessages: No current user found');
    return;
  }

  const convList = document.getElementById('chatConvList');
  if (!convList) {
    console.error('[buyer] loadBuyerMessages: chatConvList element not found');
    return;
  }
  convList.innerHTML = '<p style="padding:20px;font-size:13px;color:#aaa;">Loading…</p>';

  // Check if messagesDb is available
  if (typeof messagesDb === 'undefined' || !messagesDb) {
    console.error('[buyer] loadBuyerMessages: messagesDb is not defined!');
    convList.innerHTML = '<p class="dash-empty" style="padding:20px;color:#e74c3c;">Message system not initialized. Please refresh the page.</p>';
    return;
  }

  try {
    console.log('[buyer] loadBuyerMessages: Querying messages for email:', currentUser.email);
    console.log('[buyer] loadBuyerMessages: Using messagesDb:', messagesDb);
    
    // DEBUG: Check ALL messages in the database first
    const { data: allMessages, error: debugError } = await messagesDb
      .from('messages')
      .select('*');
    
    console.log('[buyer] loadBuyerMessages: ALL messages in database:', allMessages);
    console.log('[buyer] loadBuyerMessages: Total messages in DB:', allMessages?.length || 0);
    if (allMessages && allMessages.length > 0) {
      console.log('[buyer] loadBuyerMessages: Sample message emails:', 
        allMessages.map(m => ({ id: m.id, buyer_email: m.buyer_email, message: m.message?.substring(0, 30) }))
      );
    }
    
    // Use messagesDb for messages (separate Supabase project)
    // Note: products and sellers tables don't exist in messages DB, so we can't join
    const { data, error } = await messagesDb
      .from('messages')
      .select('*')
      .eq('buyer_email', currentUser.email)
      .order('created_at', { ascending: false });

    console.log('[buyer] loadBuyerMessages: Query result for', currentUser.email, ':', { data, error });

    if (error) {
      console.error('[buyer] loadBuyerMessages: Database error:', error);
      throw error;
    }

    if (!data?.length) {
      console.log('[buyer] loadBuyerMessages: No messages found');
      convList.innerHTML = '<p class="dash-empty" style="padding:20px;font-size:13px;">No conversations yet.<br>Click <strong>+ New</strong> to message a seller.</p>';
      return;
    }

    console.log('[buyer] loadBuyerMessages: Found', data.length, 'messages');

    convList.innerHTML = data.map(m => {
      // Use seller_id directly since we can't join with sellers table
      const sellerName  = m.seller_id ? `Seller ${m.seller_id.substring(0, 8)}` : 'Seller';
      const lastMsg     = m.reply || m.message;
      const isUnread    = m.reply && !m.is_read;
      const initial     = 'S'; // S for Seller
      const time        = formatChatTime(m.reply ? m.replied_at : m.created_at);
      
      // Status indicator
      let statusBadge = '';
      if (m.rejected) {
        statusBadge = '<span style="font-size:11px;color:#e74c3c;font-weight:600;">✕ Rejected</span>';
      } else if (m.reply) {
        statusBadge = '<span style="font-size:11px;color:#27ae60;font-weight:600;">✓ Replied</span>';
      } else if (m.accepted) {
        statusBadge = '<span style="font-size:11px;color:#3498db;font-weight:600;">✓ Accepted</span>';
      } else {
        statusBadge = '<span style="font-size:11px;color:#c8a96e;font-weight:600;">⏳ Pending</span>';
      }

      return `
        <div class="chat-conv-item ${isUnread ? 'unread' : ''} ${activeChatId === m.id ? 'active' : ''}"
             onclick="openChat('${m.id}')" data-msg-id="${m.id}">
          <div class="chat-conv-avatar">${initial}</div>
          <div class="chat-conv-info">
            <div class="chat-conv-name">${sellerName}</div>
            <div class="chat-conv-preview">${lastMsg.length > 40 ? lastMsg.slice(0,40)+'…' : lastMsg}</div>
            <div style="margin-top:4px;">${statusBadge}</div>
          </div>
          <div class="chat-conv-time">${time}</div>
          ${isUnread ? '<div class="chat-unread-dot"></div>' : ''}
        </div>`;
    }).join('');

    console.log('[buyer] loadBuyerMessages: Messages rendered successfully');

    // Re-open active chat if one was selected
    if (activeChatId) openChat(activeChatId, data);

  } catch (err) {
    convList.innerHTML = '<p class="dash-empty" style="padding:20px;">Could not load messages.</p>';
    console.error('[buyer] loadBuyerMessages: Exception:', err);
  }
}

function formatChatTime(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  const now = new Date();
  const diffDays = Math.floor((now - d) / 86400000);
  if (diffDays === 0) return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7)  return d.toLocaleDateString([], { weekday: 'short' });
  return d.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

async function openChat(msgId, cachedData) {
  activeChatId = msgId;

  document.querySelectorAll('.chat-conv-item').forEach(el => {
    el.classList.toggle('active', el.dataset.msgId === msgId);
  });

  const emptyState = document.getElementById('chatEmptyState');
  const chatActive = document.getElementById('chatActive');
  if (emptyState) emptyState.style.display = 'none';
  if (chatActive) chatActive.style.display = 'flex';

  // Always fetch fresh data
  const { data: msg } = await messagesDb
    .from('messages')
    .select('*')
    .eq('id', msgId)
    .single();

  if (!msg) return;

  const currentUser = authManager.getCurrentUser();
  const sellerName = msg.seller_id ? `Seller ${msg.seller_id.substring(0, 8)}` : 'Seller';

  // Header — Messenger style with PC + VC buttons
  const header = document.getElementById('chatWindowHeader');
  if (header) {
    header.className = 'messenger-header';
    header.innerHTML = `
      <div class="messenger-header-left">
        <div class="messenger-avatar">${sellerName.charAt(0).toUpperCase()}</div>
        <div class="messenger-info">
          <span class="messenger-name" id="buyerChatName">${sellerName}</span>
          <span class="messenger-status">Active now</span>
        </div>
      </div>
      <div class="messenger-header-actions">
        <button class="messenger-action-btn" title="Phone Call" onclick="buyerStartVoiceCall()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" width="16" height="16">
            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.61 3.4 2 2 0 0 1 3.6 1.22h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.82a16 16 0 0 0 6.29 6.29l.96-.96a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z" stroke-width="2"/>
          </svg>
          <span style="font-size:11px;font-weight:700;">PC</span>
        </button>
        <button class="messenger-action-btn messenger-video-btn" title="Video Call" onclick="buyerStartVideoCall()">
          <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16">
            <path d="M15 10l4.553-2.276A1 1 0 0 1 21 8.723v6.554a1 1 0 0 1-1.447.894L15 14v-4zM3 8a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8z"/>
          </svg>
          <span style="font-size:11px;font-weight:700;">VC</span>
        </button>
      </div>`;
  }

  // Build thread from: original message + thread array
  const messagesEl = document.getElementById('chatMessages');
  if (messagesEl) {
    const bubbles = [];

    // First message (buyer's original)
    bubbles.push(`
      <div class="chat-bubble-wrap from-buyer">
        <div class="chat-bubble">${msg.message}</div>
        <div class="chat-bubble-meta">${formatChatTime(msg.created_at)}</div>
      </div>`);

    // Thread messages (subsequent back-and-forth)
    const thread = Array.isArray(msg.thread) ? msg.thread : [];
    thread.forEach(entry => {
      const isBuyer = entry.role === 'buyer';
      
      // Special: video call invite from seller
      if (entry.type === 'video_call' && entry.roomId) {
        const buyerName = encodeURIComponent(authManager.getCurrentUser()?.name || authManager.getCurrentUser()?.email || 'Buyer');
        bubbles.push(`
          <div class="chat-bubble-wrap from-seller">
            <div class="chat-bubble" style="background:#1a1a2e;color:#fff;padding:14px 16px;">
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
                <span style="font-size:24px;">📹</span>
                <div>
                  <div style="font-weight:700;font-size:14px;">Video Call Invite</div>
                  <div style="font-size:12px;color:#c8a96e;">Room: ${entry.roomId}</div>
                </div>
              </div>
              <a href="peer.html?room=${entry.roomId}&mode=join&name=${buyerName}" target="_blank"
                 style="display:block;text-align:center;background:#c8a96e;color:#fff;padding:10px;border-radius:8px;font-weight:700;font-size:14px;text-decoration:none;">
                📹 Join Video Call
              </a>
            </div>
            <div class="chat-bubble-meta">${sellerName} · ${formatChatTime(entry.ts)}</div>
          </div>`);
        return;
      }

      bubbles.push(`
        <div class="chat-bubble-wrap ${isBuyer ? 'from-buyer' : 'from-seller'}">
          <div class="chat-bubble">${entry.text}</div>
          <div class="chat-bubble-meta">${isBuyer ? 'You' : sellerName} · ${formatChatTime(entry.ts)}</div>
        </div>`);
    });

    // If no thread yet but has old-style reply, show it
    if (thread.length === 0 && msg.reply) {
      bubbles.push(`
        <div class="chat-bubble-wrap from-seller">
          <div class="chat-bubble">${msg.reply}</div>
          <div class="chat-bubble-meta">${sellerName} · ${formatChatTime(msg.replied_at)}</div>
        </div>`);
    }

    messagesEl.innerHTML = bubbles.join('');
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  // Input bar — hide only if not accepted
  const inputBar = document.querySelector('.chat-input-bar');
  document.getElementById('chatAcceptanceHint')?.remove();

  if (inputBar) {
    if (!msg.accepted) {
      inputBar.style.display = 'none';
      const hintEl = document.createElement('p');
      hintEl.id = 'chatAcceptanceHint';
      hintEl.style.cssText = 'text-align:center;padding:16px;font-size:13px;color:#c8a96e;border-top:1px solid #eee;background:#fffbf0;font-weight:600;margin:0;';
      hintEl.textContent = '⏳ Waiting for seller to accept your message...';
      document.getElementById('chatActive').appendChild(hintEl);
    } else {
      inputBar.style.display = 'flex';
    }
  }

  // Mark as read
  if (!msg.is_read) {
    messagesDb.from('messages').update({ is_read: true }).eq('id', msgId);
  }
}

async function sendChatMessage() {
  const input = document.getElementById('chatInput');
  const text  = input?.value.trim();
  if (!text || !activeChatId) return;

  const currentUser = authManager.getCurrentUser();
  if (!currentUser) return;

  try {
    // Fetch current thread
    const { data: msg } = await messagesDb
      .from('messages')
      .select('thread')
      .eq('id', activeChatId)
      .single();

    const thread = Array.isArray(msg?.thread) ? msg.thread : [];
    thread.push({ role: 'buyer', text, ts: new Date().toISOString() });

    const { error } = await messagesDb
      .from('messages')
      .update({ thread })
      .eq('id', activeChatId);

    if (error) throw error;
    input.value = '';
    // Refresh chat view
    openChat(activeChatId);
    loadBuyerMessages();
  } catch (err) {
    console.error('[chat] sendChatMessage:', err);
    showError('Error', 'Could not send message.');
  }
}

window.openNewInquiryModal = function() {
  // Remove existing overlay if any
  document.getElementById('newInquiryOverlay')?.remove();

  const currentUser = authManager.getCurrentUser();
  const overlay = document.createElement('div');
  overlay.id = 'newInquiryOverlay';
  overlay.className = 'new-inquiry-overlay';
  overlay.innerHTML = `
    <div style="background:#fff;border-radius:16px;padding:32px;max-width:460px;width:90%;box-shadow:0 8px 32px rgba(0,0,0,0.2);">
      <h3 style="margin:0 0 4px;font-size:18px;">New Message</h3>
      <p style="color:#888;font-size:13px;margin:0 0 20px;">Send an inquiry to a seller about a product</p>

      <div style="margin-bottom:12px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Seller Name / Shop</label>
        <input id="niSellerSearch" type="text" placeholder="Search seller by name…"
          style="width:100%;padding:10px 12px;border:1px solid #ddd;border-radius:8px;font-size:14px;box-sizing:border-box;"
          oninput="searchSellersForInquiry(this.value)">
        <div id="niSellerResults" style="border:1px solid #eee;border-radius:8px;margin-top:4px;max-height:140px;overflow-y:auto;display:none;"></div>
        <input type="hidden" id="niSellerId">
        <div id="niSellerChosen" style="display:none;margin-top:6px;padding:8px 12px;background:#fdf8f0;border-radius:8px;font-size:13px;font-weight:600;color:#c8a96e;"></div>
      </div>

      <div style="margin-bottom:12px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Product (optional)</label>
        <input id="niProduct" type="text" placeholder="Which product are you asking about?"
          style="width:100%;padding:10px 12px;border:1px solid #ddd;border-radius:8px;font-size:14px;box-sizing:border-box;">
      </div>

      <div style="margin-bottom:20px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Message</label>
        <textarea id="niMessage" rows="4" placeholder="Ask about sizing, availability, condition…"
          style="width:100%;padding:10px 12px;border:1px solid #ddd;border-radius:8px;font-size:14px;resize:vertical;box-sizing:border-box;"></textarea>
      </div>

      <div style="display:flex;gap:12px;">
        <button onclick="submitNewInquiry()"
          style="flex:1;padding:12px;background:#c8a96e;color:#fff;border:none;border-radius:8px;font-size:15px;font-weight:600;cursor:pointer;">
          Send Message
        </button>
        <button onclick="document.getElementById('newInquiryOverlay').remove()"
          style="padding:12px 20px;background:#f5f5f5;color:#333;border:none;border-radius:8px;font-size:15px;cursor:pointer;">
          Cancel
        </button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
};

let _sellerSearchTimer;
window.searchSellersForInquiry = function(query) {
  clearTimeout(_sellerSearchTimer);
  const results = document.getElementById('niSellerResults');
  if (!query || query.length < 2) { results.style.display = 'none'; return; }

  _sellerSearchTimer = setTimeout(async () => {
    const { data } = await db
      .from('sellers')
      .select('id, business_name')
      .ilike('business_name', `%${query}%`)
      .eq('verified', true)
      .limit(6);

    if (!data?.length) {
      results.innerHTML = '<p style="padding:10px;font-size:13px;color:#aaa;">No sellers found.</p>';
      results.style.display = 'block';
      return;
    }

    results.style.display = 'block';
    results.innerHTML = data.map(s => `
      <div onclick="selectSellerForInquiry('${s.id}','${s.business_name.replace(/'/g,"\\'")}') "
        style="padding:10px 14px;cursor:pointer;font-size:14px;border-bottom:1px solid #f5f5f5;"
        onmouseover="this.style.background='#fdf8f0'" onmouseout="this.style.background=''">
        ${s.business_name}
      </div>`).join('');
  }, 300);
};

window.selectSellerForInquiry = function(id, name) {
  document.getElementById('niSellerId').value = id;
  document.getElementById('niSellerSearch').value = name;
  document.getElementById('niSellerResults').style.display = 'none';
  const chosen = document.getElementById('niSellerChosen');
  chosen.textContent = '✓ ' + name;
  chosen.style.display = 'block';
};

window.submitNewInquiry = async function() {
  const sellerId = document.getElementById('niSellerId')?.value;
  const product  = document.getElementById('niProduct')?.value.trim();
  const message  = document.getElementById('niMessage')?.value.trim();
  const currentUser = authManager.getCurrentUser();

  if (!sellerId) { alert('Please select a seller.'); return; }
  if (!message)  { alert('Please enter a message.'); return; }
  if (!currentUser) { alert('Please log in first.'); return; }

  try {
    console.log('[submitNewInquiry] Using buyer email:', currentUser.email);
    
    const payload = {
      seller_id:   sellerId,
      buyer_name:  currentUser.name || currentUser.email,
      buyer_email: currentUser.email, // Use logged-in user's email consistently
      message
    };

    console.log('[submitNewInquiry] Sending message:', payload);

    const { error } = await messagesDb.from('messages').insert(payload);
    if (error) throw error;

    document.getElementById('newInquiryOverlay')?.remove();
    showSuccess('Message Sent!', 'Your inquiry has been sent to the seller.', 'Got it');
    loadBuyerMessages();
  } catch (err) {
    console.error('[chat] submitNewInquiry:', err);
    alert('Could not send message: ' + err.message);
  }
};

// ---- INIT ----
document.addEventListener('DOMContentLoaded', () => {
  loadOverviewStats();
});

// ---- REAL-TIME SUBSCRIPTIONS ----
// Auto-update messages, orders without needing to refresh
function startRealtimeUpdates() {
  const currentUser = authManager?.getCurrentUser();
  if (!currentUser) return;

  // Real-time: messages updates (seller accepted, replied, etc.)
  messagesDb
    .channel('buyer-messages-realtime')
    .on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'messages',
      filter: `buyer_email=eq.${currentUser.email}`
    }, (payload) => {
      console.log('[realtime] Message updated:', payload);
      // Refresh conversation list
      loadBuyerMessages();
      // If this message is currently open, refresh the chat view too
      if (activeChatId === payload.new?.id) {
        openChat(activeChatId);
      }
    })
    .subscribe();

  // Real-time: orders updates (status changes)
  db
    .channel('buyer-orders-realtime')
    .on('postgres_changes', {
      event: 'UPDATE',
      schema: 'public',
      table: 'orders',
      filter: `buyer_email=eq.${currentUser.email}`
    }, (payload) => {
      console.log('[realtime] Order updated:', payload);
      loadBuyerOrders();
      loadOverviewStats();
    })
    .subscribe();

  console.log('[realtime] Buyer real-time subscriptions started');
}

// Start real-time after auth is ready
if (window.authManager?.isInitialized) {
  startRealtimeUpdates();
} else {
  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(startRealtimeUpdates, 1000);
  });
}


// ============================================================
// ORDER DETAILS MODAL
// ============================================================

async function openOrderDetailsModal(orderId) {
  console.log('[orderDetailsModal] ✅ FUNCTION CALLED with orderId:', orderId);
  
  const modal = document.getElementById('orderDetailsModal');
  const content = document.getElementById('orderDetailsContent');
  
  console.log('[orderDetailsModal] Modal element:', modal ? '✅ FOUND' : '❌ NOT FOUND');
  console.log('[orderDetailsModal] Content element:', content ? '✅ FOUND' : '❌ NOT FOUND');
  
  if (!modal || !content) {
    console.error('[orderDetailsModal] ❌ Modal or content element not found');
    return;
  }
  
  content.innerHTML = '<p style="text-align:center;color:#999;">Loading order details...</p>';
  modal.style.display = 'block';
  console.log('[orderDetailsModal] Modal displayed');
  
  try {
    // Fetch order with product details
    const { data: order, error } = await db
      .from('orders')
      .select('*, products(id, name, image_url)')
      .eq('id', orderId)
      .single();
    
    if (error || !order) {
      console.error('[orderDetailsModal] Error loading order:', error);
      content.innerHTML = '<p style="color:#e74c3c;">Could not load order details.</p>';
      return;
    }
    
    console.log('[orderDetailsModal] Order loaded:', order);
    
    const product = order.products;
    const lsTracking = JSON.parse(localStorage.getItem(`rewear_tracking_${order.id}`) || '{}');
    const courierName = order.courier_name || lsTracking.courier_name || null;
    const trackingNumber = order.tracking_number || lsTracking.tracking_number || null;
    
    // Payment status badge
    const paymentBadge = {
      pending:   '<span style="background:#fff3cd;color:#856404;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">⏳ Awaiting Payment</span>',
      submitted: '<span style="background:#cce5ff;color:#004085;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">📤 Payment Submitted</span>',
      verified:  '<span style="background:#d4edda;color:#155724;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">✅ Payment Verified</span>',
      rejected:  '<span style="background:#f8d7da;color:#721c24;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">❌ Payment Rejected</span>'
    }[order.payment_status || 'pending'] || '';
    
    // Build HTML
    let html = `
      <div style="margin-bottom:20px;">
        <h3 style="margin:0 0 12px;font-size:16px;font-weight:700;">Order ${order.id.slice(0, 8).toUpperCase()}</h3>
        <p style="margin:0;color:#999;font-size:13px;">Placed on ${formatDate(order.created_at)}</p>
      </div>
      
      <!-- Product Section -->
      <div style="background:#f9f9f9;border-radius:12px;padding:16px;margin-bottom:16px;">
        <div style="display:flex;gap:12px;margin-bottom:12px;">
          ${product?.image_url ? `<img src="${product.image_url}" alt="${product?.name}" style="width:80px;height:80px;object-fit:cover;border-radius:8px;">` : ''}
          <div style="flex:1;">
            <h4 style="margin:0 0 4px;font-size:15px;font-weight:700;">${product?.name || 'Product'}</h4>
            <p style="margin:0 0 4px;color:#666;font-size:13px;">Size: ${order.size_selected || '—'}</p>
            <p style="margin:0;color:#666;font-size:13px;">Quantity: ${order.quantity || 1}</p>
          </div>
        </div>
        <div style="border-top:1px solid #e0e0e0;padding-top:12px;text-align:right;">
          <p style="margin:0;font-size:14px;font-weight:700;color:#1a1a2e;">Total: ${formatPHP(order.total_price || 0)}</p>
        </div>
      </div>
      
      <!-- Order Details -->
      <div style="background:#f9f9f9;border-radius:12px;padding:16px;margin-bottom:16px;">
        <h4 style="margin:0 0 12px;font-size:14px;font-weight:700;">Order Information</h4>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:13px;">
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Status</p>
            <p style="margin:0;color:#1a1a2e;font-weight:600;">${order.status.replace(/_/g, ' ').toUpperCase()}</p>
          </div>
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Payment</p>
            <p style="margin:0;">${paymentBadge}</p>
          </div>
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Buyer Name</p>
            <p style="margin:0;color:#1a1a2e;">${order.buyer_name || '—'}</p>
          </div>
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Buyer Email</p>
            <p style="margin:0;color:#1a1a2e;font-size:12px;">${order.buyer_email || '—'}</p>
          </div>
        </div>
        
        ${order.delivery_address ? `
        <div style="margin-top:12px;padding-top:12px;border-top:1px solid #e0e0e0;">
          <p style="margin:0 0 4px;color:#999;font-weight:600;font-size:13px;">Delivery Address</p>
          <p style="margin:0;color:#1a1a2e;font-size:13px;">${order.delivery_address}</p>
        </div>` : ''}
        
        ${order.payment_reference ? `
        <div style="margin-top:12px;padding-top:12px;border-top:1px solid #e0e0e0;">
          <p style="margin:0 0 4px;color:#999;font-weight:600;font-size:13px;">Payment Reference</p>
          <p style="margin:0;color:#c8a96e;font-weight:700;font-size:13px;">${order.payment_reference}</p>
        </div>` : ''}
        
        ${order.payment_rejected_reason ? `
        <div style="margin-top:12px;padding-top:12px;border-top:1px solid #e0e0e0;background:#fce4ec;padding:12px;border-radius:8px;">
          <p style="margin:0 0 4px;color:#880e4f;font-weight:600;font-size:13px;">❌ Rejection Reason</p>
          <p style="margin:0;color:#880e4f;font-size:13px;">${order.payment_rejected_reason}</p>
        </div>` : ''}
      </div>
      
      <!-- Tracking Section -->
      ${courierName || trackingNumber ? `
      <div style="background:#f0f9f0;border-radius:12px;padding:16px;margin-bottom:16px;">
        <h4 style="margin:0 0 12px;font-size:14px;font-weight:700;">📦 Tracking Information</h4>
        <div style="font-size:13px;">
          ${courierName ? `<p style="margin:0 0 8px;"><strong>Courier:</strong> ${courierName}</p>` : ''}
          ${trackingNumber ? `<p style="margin:0;"><strong>Tracking #:</strong> <span style="color:#c8a96e;font-weight:700;">${trackingNumber}</span></p>` : ''}
        </div>
      </div>` : ''}
      
      <!-- Action Buttons -->
      ${order.status === 'delivered' ? `
      <div style="background:#e8f5e9;border-radius:12px;padding:16px;margin-bottom:16px;text-align:center;">
        <button onclick="confirmReceipt('${order.id}');closeOrderDetailsModal();" 
                style="padding:12px 24px;background:#27ae60;color:#fff;border:none;border-radius:8px;font-weight:700;cursor:pointer;width:100%;">
          ✓ Confirm Receipt
        </button>
      </div>` : ''}
      
      ${order.status === 'received' ? `
      <div style="background:#e8f5e9;border-radius:12px;padding:16px;margin-bottom:16px;text-align:center;">
        <p style="margin:0 0 12px;color:#27ae60;font-weight:700;">✓ You have confirmed receipt of this order</p>
        <button onclick="openBuyerReviewModal('${order.id}','${product?.name || 'Product'}','${product?.id || ''}','${product?.image_url || ''}');closeOrderDetailsModal();" 
                style="padding:10px 20px;background:#c8a96e;color:#fff;border:none;border-radius:8px;font-weight:700;cursor:pointer;">
          ⭐ Leave a Review
        </button>
      </div>` : ''}
    `;
    
    content.innerHTML = html;
    console.log('[orderDetailsModal] Modal content updated');
    
    // Update tracking link
    const trackingLink = document.getElementById('orderTrackingLink');
    if (trackingLink) {
      const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
      trackingLink.href = `${prefix}order-tracking.html?id=${order.id}`;
    }
    
  } catch (error) {
    console.error('[orderDetailsModal]', error);
    content.innerHTML = '<p style="color:#e74c3c;">Error loading order details. Please try again.</p>';
  }
}

function closeOrderDetailsModal() {
  console.log('[orderDetailsModal] Closing modal');
  const modal = document.getElementById('orderDetailsModal');
  if (modal) modal.style.display = 'none';
}

// Close modal when clicking outside
document.addEventListener('click', function(event) {
  const modal = document.getElementById('orderDetailsModal');
  if (modal && event.target === modal) {
    modal.style.display = 'none';
  }
});
