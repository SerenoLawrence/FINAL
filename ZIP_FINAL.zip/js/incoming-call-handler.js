/**
 * Incoming Call Handler
 * Displays incoming call notifications and handles call acceptance/rejection
 */

class IncomingCallHandler {
  constructor() {
    this.currentUserId = null;
    this.callSubscription = null;
    this.ringtoneAudio = null;
  }

  /**
   * Initialize incoming call handler
   */
  async init(userId) {
    this.currentUserId = userId;
    
    // Create incoming call modal UI
    this.createIncomingCallModal();
    
    // Subscribe to incoming calls
    this.subscribeToIncomingCalls();
    
    // Create ringtone audio element
    this.createRingtone();
  }

  /**
   * Create incoming call modal UI
   */
  createIncomingCallModal() {
    if (document.getElementById('incoming-call-modal')) return;

    const html = `
      <!-- Incoming Call Modal -->
      <div id="incoming-call-modal" class="incoming-call-modal hidden">
        <div class="incoming-call-overlay"></div>
        <div class="incoming-call-content">
          <div class="call-avatar">
            <span class="avatar-icon">👤</span>
          </div>
          <h2 id="caller-name-display">Someone</h2>
          <p class="call-type">
            <span class="call-icon">📹</span>
            <span>Video Call</span>
          </p>
          <p class="call-status">Incoming call...</p>
          
          <div class="call-actions">
            <button class="btn-decline" id="decline-call-btn" onclick="window.incomingCallHandler.declineCall()">
              <span class="icon">❌</span>
              <span>Decline</span>
            </button>
            <button class="btn-accept" id="accept-call-btn" onclick="window.incomingCallHandler.acceptCall()">
              <span class="icon">✅</span>
              <span>Accept</span>
            </button>
          </div>
        </div>
      </div>

      <style>
        .incoming-call-modal {
          position: fixed;
          inset: 0;
          z-index: 9999;
          display: flex;
          align-items: center;
          justify-content: center;
          animation: fadeIn 0.3s ease;
        }

        .incoming-call-modal.hidden {
          display: none;
        }

        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        .incoming-call-overlay {
          position: absolute;
          inset: 0;
          background: rgba(0, 0, 0, 0.7);
          backdrop-filter: blur(4px);
        }

        .incoming-call-content {
          position: relative;
          background: white;
          border-radius: 20px;
          padding: 40px 30px;
          width: 90%;
          max-width: 380px;
          text-align: center;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
          animation: slideUp 0.4s ease;
        }

        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(40px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .call-avatar {
          width: 100px;
          height: 100px;
          border-radius: 50%;
          background: linear-gradient(135deg, #c8a96e, #a68a52);
          display: flex;
          align-items: center;
          justify-content: center;
          margin: 0 auto 20px;
          font-size: 48px;
          animation: pulse 2s ease infinite;
        }

        @keyframes pulse {
          0%, 100% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.1);
          }
        }

        #caller-name-display {
          font-size: 24px;
          font-weight: 700;
          color: #1a1a2e;
          margin: 0 0 8px;
        }

        .call-type {
          font-size: 16px;
          color: #666;
          margin: 0 0 20px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
        }

        .call-icon {
          font-size: 20px;
        }

        .call-status {
          font-size: 14px;
          color: #999;
          margin: 0 0 30px;
          font-style: italic;
        }

        .call-actions {
          display: flex;
          gap: 12px;
          justify-content: center;
        }

        .btn-decline,
        .btn-accept {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 6px;
          padding: 16px 24px;
          border: none;
          border-radius: 12px;
          font-size: 14px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
          min-width: 100px;
        }

        .btn-decline {
          background: #f0f0f0;
          color: #666;
        }

        .btn-decline:hover {
          background: #e0e0e0;
          transform: translateY(-2px);
        }

        .btn-accept {
          background: #27ae60;
          color: white;
        }

        .btn-accept:hover {
          background: #229954;
          transform: translateY(-2px);
        }

        .btn-decline .icon,
        .btn-accept .icon {
          font-size: 24px;
        }

        /* Mobile */
        @media (max-width: 480px) {
          .incoming-call-content {
            padding: 30px 20px;
          }

          .call-avatar {
            width: 80px;
            height: 80px;
            font-size: 40px;
          }

          #caller-name-display {
            font-size: 20px;
          }

          .call-actions {
            flex-direction: column;
          }

          .btn-decline,
          .btn-accept {
            width: 100%;
          }
        }
      </style>
    `;

    document.body.insertAdjacentHTML('beforeend', html);
  }

  /**
   * Create ringtone audio element
   */
  createRingtone() {
    // Create a simple ringtone using Web Audio API
    // For now, we'll use a notification sound
    this.ringtoneAudio = new Audio();
    // You can set a ringtone URL here
    // this.ringtoneAudio.src = 'path/to/ringtone.mp3';
  }

  /**
   * Subscribe to incoming calls
   */
  subscribeToIncomingCalls() {
    if (this.callSubscription) {
      this.callSubscription.unsubscribe();
    }

    this.callSubscription = db
      .channel(`incoming_calls:${this.currentUserId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'video_call_invitations',
        filter: `callee_id=eq.${this.currentUserId}`
      }, (payload) => {
        if (payload.new.status === 'pending') {
          this.handleIncomingCall(payload.new);
        }
      })
      .subscribe();
  }

  /**
   * Handle incoming call
   */
  async handleIncomingCall(invitation) {
    this.currentInvitation = invitation;

    // Update modal with caller info
    document.getElementById('caller-name-display').textContent = invitation.caller_name;

    // Show modal
    const modal = document.getElementById('incoming-call-modal');
    modal.classList.remove('hidden');

    // Play ringtone
    this.playRingtone();

    // Auto-decline after 60 seconds if not answered
    this.callTimeout = setTimeout(() => {
      if (this.currentInvitation && this.currentInvitation.status === 'pending') {
        this.declineCall();
      }
    }, 60000);
  }

  /**
   * Accept incoming call
   */
  async acceptCall() {
    if (!this.currentInvitation) return;

    try {
      // Stop ringtone
      this.stopRingtone();

      // Clear timeout
      if (this.callTimeout) clearTimeout(this.callTimeout);

      // Accept call via video call initiator
      const accepted = await window.videoCallInitiator?.acceptCall(
        this.currentInvitation.id,
        this.currentInvitation.room_id,
        this.currentInvitation.caller_name
      );

      if (accepted) {
        // Hide modal
        document.getElementById('incoming-call-modal').classList.add('hidden');
      }
    } catch (error) {
      console.error('[incoming-call-handler] Error accepting call:', error);
    }
  }

  /**
   * Decline incoming call
   */
  async declineCall() {
    if (!this.currentInvitation) return;

    try {
      // Stop ringtone
      this.stopRingtone();

      // Clear timeout
      if (this.callTimeout) clearTimeout(this.callTimeout);

      // Decline call
      await window.videoCallInitiator?.declineCall(this.currentInvitation.id);

      // Log missed call
      await this.logMissedCall(this.currentInvitation);

      // Hide modal
      document.getElementById('incoming-call-modal').classList.add('hidden');

      // Clear current invitation
      this.currentInvitation = null;
    } catch (error) {
      console.error('[incoming-call-handler] Error declining call:', error);
    }
  }

  /**
   * Log missed call
   */
  async logMissedCall(invitation) {
    try {
      // Create missed call notification
      await db.from('notifications').insert({
        user_id: this.currentUserId,
        notification_type: 'missed_video_call',
        title: '📞 Missed Video Call',
        message: `You missed a call from ${invitation.caller_name}`,
        data: {
          caller_id: invitation.caller_id,
          caller_name: invitation.caller_name
        },
        is_read: false,
        created_at: new Date().toISOString()
      });
    } catch (error) {
      console.warn('[incoming-call-handler] Error logging missed call:', error);
    }
  }

  /**
   * Play ringtone
   */
  playRingtone() {
    try {
      // Create a simple beep sound using Web Audio API
      const audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      oscillator.frequency.value = 800;
      oscillator.type = 'sine';

      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.5);

      // Repeat every 2 seconds
      this.ringtoneInterval = setInterval(() => {
        const osc = audioContext.createOscillator();
        const gain = audioContext.createGain();

        osc.connect(gain);
        gain.connect(audioContext.destination);

        osc.frequency.value = 800;
        osc.type = 'sine';

        gain.gain.setValueAtTime(0.3, audioContext.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);

        osc.start(audioContext.currentTime);
        osc.stop(audioContext.currentTime + 0.5);
      }, 2000);
    } catch (error) {
      console.warn('[incoming-call-handler] Error playing ringtone:', error);
    }
  }

  /**
   * Stop ringtone
   */
  stopRingtone() {
    if (this.ringtoneInterval) {
      clearInterval(this.ringtoneInterval);
      this.ringtoneInterval = null;
    }
  }

  /**
   * Cleanup
   */
  destroy() {
    this.stopRingtone();
    if (this.callSubscription) {
      this.callSubscription.unsubscribe();
    }
  }
}

// Create global instance
window.incomingCallHandler = new IncomingCallHandler();

console.log('[incoming-call-handler] Incoming call handler loaded');
