// ============================================================
// data-mapper.js — Data mapping layer for database ↔ JavaScript
// Requirement 1.8.4: Create Data Mapping Layer
// ============================================================

/**
 * Field mappings for special cases that don't follow simple snake_case/camelCase conversion
 */
const FIELD_MAPPINGS = {
  // Database → JavaScript (snake_case → camelCase)
  db_to_js: {
    'gcash_number': 'gcashNumber',
    'gcash_name': 'gcashName',
    'gcash_qr_url': 'gcashQrUrl',
    'rls': 'rowLevelSecurity',
    'id': 'id', // Keep as-is
    'email': 'email', // Keep as-is
    'phone': 'phone', // Keep as-is
    'name': 'name', // Keep as-is
    'price': 'price', // Keep as-is
    'status': 'status', // Keep as-is
    'category': 'category', // Keep as-is
    'condition': 'condition', // Keep as-is
    'size': 'size', // Keep as-is
    'sizes': 'sizes', // Keep as-is
    'color': 'color', // Keep as-is
    'brand': 'brand', // Keep as-is
    'material': 'material', // Keep as-is
    'images': 'images', // Keep as-is
    'description': 'description', // Keep as-is
    'rating': 'rating', // Keep as-is
    'quantity': 'quantity', // Keep as-is
    'tier': 'tier', // Keep as-is
    'amount': 'amount', // Keep as-is
    'message': 'message', // Keep as-is
    'reply': 'reply', // Keep as-is
    'thread': 'thread', // Keep as-is
    'notes': 'notes', // Keep as-is
    'reason': 'reason', // Keep as-is
    'details': 'details', // Keep as-is
    'title': 'title', // Keep as-is
    'excerpt': 'excerpt', // Keep as-is
    'subject': 'subject', // Keep as-is
    'comment': 'comment', // Keep as-is
    'response': 'response', // Keep as-is
    'address': 'address', // Keep as-is
    'data': 'data', // Keep as-is
    'source': 'source', // Keep as-is
    'action': 'action', // Keep as-is
    'verified': 'verified', // Keep as-is (boolean)
    'accepted': 'accepted', // Keep as-is (boolean)
    'rejected': 'rejected', // Keep as-is (boolean)
    'read': 'read' // Keep as-is (boolean)
  },
  // JavaScript → Database (camelCase → snake_case)
  js_to_db: {
    'gcashNumber': 'gcash_number',
    'gcashName': 'gcash_name',
    'gcashQrUrl': 'gcash_qr_url',
    'rowLevelSecurity': 'rls',
    'id': 'id', // Keep as-is
    'email': 'email', // Keep as-is
    'phone': 'phone', // Keep as-is
    'name': 'name', // Keep as-is
    'price': 'price', // Keep as-is
    'status': 'status', // Keep as-is
    'category': 'category', // Keep as-is
    'condition': 'condition', // Keep as-is
    'size': 'size', // Keep as-is
    'sizes': 'sizes', // Keep as-is
    'color': 'color', // Keep as-is
    'brand': 'brand', // Keep as-is
    'material': 'material', // Keep as-is
    'images': 'images', // Keep as-is
    'description': 'description', // Keep as-is
    'rating': 'rating', // Keep as-is
    'quantity': 'quantity', // Keep as-is
    'tier': 'tier', // Keep as-is
    'amount': 'amount', // Keep as-is
    'message': 'message', // Keep as-is
    'reply': 'reply', // Keep as-is
    'thread': 'thread', // Keep as-is
    'notes': 'notes', // Keep as-is
    'reason': 'reason', // Keep as-is
    'details': 'details', // Keep as-is
    'title': 'title', // Keep as-is
    'excerpt': 'excerpt', // Keep as-is
    'subject': 'subject', // Keep as-is
    'comment': 'comment', // Keep as-is
    'response': 'response', // Keep as-is
    'address': 'address', // Keep as-is
    'data': 'data', // Keep as-is
    'source': 'source', // Keep as-is
    'action': 'action', // Keep as-is
    'verified': 'verified', // Keep as-is (boolean)
    'accepted': 'accepted', // Keep as-is (boolean)
    'rejected': 'rejected', // Keep as-is (boolean)
    'read': 'read' // Keep as-is (boolean)
  }
};

/**
 * Convert snake_case string to camelCase
 * @param {string} str - Snake case string
 * @returns {string} Camel case string
 */
function snakeToCamel(str) {
  if (!str || typeof str !== 'string') return str;
  
  // Check if there's a special mapping
  if (FIELD_MAPPINGS.db_to_js[str]) {
    return FIELD_MAPPINGS.db_to_js[str];
  }
  
  // Convert snake_case to camelCase
  return str.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
}

/**
 * Convert camelCase string to snake_case
 * @param {string} str - Camel case string
 * @returns {string} Snake case string
 */
function camelToSnake(str) {
  if (!str || typeof str !== 'string') return str;
  
  // Check if there's a special mapping
  if (FIELD_MAPPINGS.js_to_db[str]) {
    return FIELD_MAPPINGS.js_to_db[str];
  }
  
  // Convert camelCase to snake_case
  return str.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
}

/**
 * Convert database object (snake_case) to JavaScript object (camelCase)
 * @param {Object|Array|null} dbObject - Database object with snake_case keys
 * @returns {Object|Array|null} JavaScript object with camelCase keys
 * 
 * @example
 * const dbProduct = { seller_id: '123', created_at: '2025-01-01', in_stock: true };
 * const jsProduct = dbToJs(dbProduct);
 * // { sellerId: '123', createdAt: '2025-01-01', inStock: true }
 */
function dbToJs(dbObject) {
  // Handle null/undefined
  if (dbObject === null || dbObject === undefined) {
    return dbObject;
  }
  
  // Handle arrays
  if (Array.isArray(dbObject)) {
    return dbObject.map(item => dbToJs(item));
  }
  
  // Handle non-objects (primitives)
  if (typeof dbObject !== 'object') {
    return dbObject;
  }
  
  // Handle Date objects
  if (dbObject instanceof Date) {
    return dbObject;
  }
  
  // Convert object keys from snake_case to camelCase
  const jsObject = {};
  
  for (const [key, value] of Object.entries(dbObject)) {
    const camelKey = snakeToCamel(key);
    
    // Recursively convert nested objects
    if (value !== null && typeof value === 'object' && !(value instanceof Date)) {
      jsObject[camelKey] = dbToJs(value);
    } else {
      jsObject[camelKey] = value;
    }
  }
  
  return jsObject;
}

/**
 * Convert JavaScript object (camelCase) to database object (snake_case)
 * @param {Object|Array|null} jsObject - JavaScript object with camelCase keys
 * @returns {Object|Array|null} Database object with snake_case keys
 * 
 * @example
 * const jsOrder = { buyerId: '456', totalPrice: 1299.00, sizeSelected: 'M' };
 * const dbOrder = jsToDb(jsOrder);
 * // { buyer_id: '456', total_price: 1299.00, size_selected: 'M' }
 */
function jsToDb(jsObject) {
  // Handle null/undefined
  if (jsObject === null || jsObject === undefined) {
    return jsObject;
  }
  
  // Handle arrays
  if (Array.isArray(jsObject)) {
    return jsObject.map(item => jsToDb(item));
  }
  
  // Handle non-objects (primitives)
  if (typeof jsObject !== 'object') {
    return jsObject;
  }
  
  // Handle Date objects
  if (jsObject instanceof Date) {
    return jsObject;
  }
  
  // Convert object keys from camelCase to snake_case
  const dbObject = {};
  
  for (const [key, value] of Object.entries(jsObject)) {
    const snakeKey = camelToSnake(key);
    
    // Recursively convert nested objects
    if (value !== null && typeof value === 'object' && !(value instanceof Date)) {
      dbObject[snakeKey] = jsToDb(value);
    } else {
      dbObject[snakeKey] = value;
    }
  }
  
  return dbObject;
}

/**
 * Wrap Supabase query result with automatic data mapping
 * @param {Promise} queryPromise - Supabase query promise
 * @returns {Promise} Promise with mapped data
 * 
 * @example
 * const { data, error } = await mapQuery(
 *   db.from('products').select('*').eq('status', 'approved')
 * );
 * // data is automatically converted to camelCase
 */
async function mapQuery(queryPromise) {
  const result = await queryPromise;
  
  if (result.error) {
    return result;
  }
  
  return {
    ...result,
    data: dbToJs(result.data)
  };
}

/**
 * Helper function to map Supabase insert/update payload
 * @param {Object|Array} jsPayload - JavaScript object to insert/update
 * @returns {Object|Array} Database-ready payload
 * 
 * @example
 * const jsProduct = { sellerId: '123', inStock: true, createdAt: new Date() };
 * const dbPayload = mapPayload(jsProduct);
 * await db.from('products').insert(dbPayload);
 */
function mapPayload(jsPayload) {
  return jsToDb(jsPayload);
}

/**
 * Add custom field mapping
 * @param {string} dbField - Database field name (snake_case)
 * @param {string} jsField - JavaScript field name (camelCase)
 * 
 * @example
 * addFieldMapping('special_field_name', 'specialFieldName');
 */
function addFieldMapping(dbField, jsField) {
  FIELD_MAPPINGS.db_to_js[dbField] = jsField;
  FIELD_MAPPINGS.js_to_db[jsField] = dbField;
}

/**
 * Get all field mappings (for debugging)
 * @returns {Object} Current field mappings
 */
function getFieldMappings() {
  return { ...FIELD_MAPPINGS };
}

// ============================================================
// USAGE EXAMPLES
// ============================================================

/*
// Example 1: Convert database query result
const { data: dbProducts } = await db.from('products').select('*');
const jsProducts = dbToJs(dbProducts);
console.log(jsProducts[0].sellerId); // camelCase

// Example 2: Convert before insert
const jsProduct = {
  sellerId: '123',
  name: 'Vintage Jacket',
  price: 1299.00,
  inStock: true,
  createdAt: new Date()
};
const dbProduct = jsToDb(jsProduct);
await db.from('products').insert(dbProduct);

// Example 3: Use mapQuery wrapper
const { data: products, error } = await mapQuery(
  db.from('products').select('*').eq('status', 'approved')
);
// products is automatically camelCase

// Example 4: Nested objects
const dbOrder = {
  buyer_id: '456',
  total_price: 1299.00,
  products: {
    seller_id: '123',
    created_at: '2025-01-01'
  }
};
const jsOrder = dbToJs(dbOrder);
// {
//   buyerId: '456',
//   totalPrice: 1299.00,
//   products: {
//     sellerId: '123',
//     createdAt: '2025-01-01'
//   }
// }

// Example 5: Arrays
const dbOrders = [
  { buyer_id: '1', total_price: 100 },
  { buyer_id: '2', total_price: 200 }
];
const jsOrders = dbToJs(dbOrders);
// [
//   { buyerId: '1', totalPrice: 100 },
//   { buyerId: '2', totalPrice: 200 }
// ]
*/

// ============================================================
// EXPORT FOR TESTING
// ============================================================

const _test = {
  snakeToCamel,
  camelToSnake,
  FIELD_MAPPINGS
};


// Make functions available globally for non-module scripts
if (typeof window !== 'undefined') {
  window.dbToJs = dbToJs;
  window.jsToDb = jsToDb;
  window.mapQuery = mapQuery;
  window.mapPayload = mapPayload;
  window.addFieldMapping = addFieldMapping;
  window.getFieldMappings = getFieldMappings;
  window._test = _test;
}
