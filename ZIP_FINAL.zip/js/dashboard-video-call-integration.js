/**
 * Dashboard Video Call Integration
 * Adds video call buttons to dashboard, chat, and order interfaces
 */

class DashboardVideoCallIntegration {
  constructor() {
    this.currentUserId = null;
    this.currentUserRole = null;
  }

  /**
   * Initialize integration
   */
  async init(userId, userRole) {
    this.currentUserId = userId;
    this.currentUserRole = userRole;

    // Initialize all components
    await this.initializePresenceManager();
    await this.initializeIncomingCallHandler();
    await this.initializeVideoCallInitiator();

    // Add video call buttons to UI
    this.addVideoCallButtonsToChatInterface();
    this.addVideoCallButtonsToOrderInterface();
    this.addPresenceIndicators();
  }

  /**
   * Initialize presence manager
   */
  async initializePresenceManager() {
    if (window.userPresenceManager) {
      await window.userPresenceManager.init(this.currentUserId);
    }
  }

  /**
   * Initialize incoming call handler
   */
  async initializeIncomingCallHandler() {
    if (window.incomingCallHandler) {
      await window.incomingCallHandler.init(this.currentUserId);
    }
  }

  /**
   * Initialize video call initiator
   */
  async initializeVideoCallInitiator() {
    if (window.videoCallInitiator) {
      await window.videoCallInitiator.init(this.currentUserId, this.currentUserRole);
    }
  }

  /**
   * Add video call buttons to chat interface
   */
  addVideoCallButtonsToChatInterface() {
    // This will be called from chat.js
    // Add a video call button next to the message input
    const chatContainer = document.querySelector('[data-chat-container]');
    if (!chatContainer) return;

    // Create video call button
    const videoCallBtn = document.createElement('button');
    videoCallBtn.id = 'chat-video-call-btn';
    videoCallBtn.className = 'chat-video-call-btn';
    videoCallBtn.title = 'Start Video Call';
    videoCallBtn.innerHTML = '📹';
    videoCallBtn.style.cssText = `
      background: #c8a96e;
      border: none;
      color: white;
      padding: 10px 16px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      transition: background 0.2s;
      margin-right: 8px;
    `;

    videoCallBtn.addEventListener('mouseover', () => {
      videoCallBtn.style.background = '#a68a52';
    });

    videoCallBtn.addEventListener('mouseout', () => {
      videoCallBtn.style.background = '#c8a96e';
    });

    videoCallBtn.addEventListener('click', () => {
      this.initiateCallFromChat();
    });

    // Find the message input area and add button
    const messageInput = document.querySelector('[data-message-input]');
    if (messageInput && messageInput.parentElement) {
      messageInput.parentElement.insertBefore(videoCallBtn, messageInput);
    }
  }

  /**
   * Add video call buttons to order interface
   */
  addVideoCallButtonsToOrderInterface() {
    // This will be called from order-tracking.js
    // Add a video call button to order details
    const orderActions = document.querySelector('[data-order-actions]');
    if (!orderActions) return;

    const videoCallBtn = document.createElement('button');
    videoCallBtn.className = 'order-video-call-btn';
    videoCallBtn.innerHTML = '📹 Video Call';
    videoCallBtn.style.cssText = `
      background: #c8a96e;
      border: none;
      color: white;
      padding: 10px 16px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 14px;
      transition: background 0.2s;
      margin-right: 8px;
    `;

    videoCallBtn.addEventListener('click', () => {
      this.initiateCallFromOrder();
    });

    orderActions.appendChild(videoCallBtn);
  }

  /**
   * Add presence indicators to user profiles
   */
  addPresenceIndicators() {
    // Add presence indicator styling
    const style = document.createElement('style');
    style.textContent = `
      [data-presence-indicator] {
        display: inline-block;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        margin-right: 6px;
      }

      [data-presence-indicator].online {
        background: #27ae60;
        box-shadow: 0 0 8px rgba(39, 174, 96, 0.6);
      }

      [data-presence-indicator].offline {
        background: #95a5a6;
      }

      [data-presence-status] {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
      }

      [data-presence-status].online {
        background: #d5f4e6;
        color: #27ae60;
      }

      [data-presence-status].offline {
        background: #ecf0f1;
        color: #7f8c8d;
      }
    `;
    document.head.appendChild(style);
  }

  /**
   * Initiate call from chat
   */
  async initiateCallFromChat() {
    // Get the other user from current chat
    const chatData = window.chatManager?.getCurrentChat?.();
    if (!chatData) {
      alert('No active chat');
      return;
    }

    const otherUserId = this.currentUserRole === 'seller' 
      ? chatData.buyer_id 
      : chatData.seller_id;

    const otherUserName = this.currentUserRole === 'seller'
      ? chatData.buyer_name
      : chatData.seller_name;

    // Check if user is seller (only sellers can initiate calls)
    if (this.currentUserRole !== 'seller') {
      alert('Only sellers can initiate video calls');
      return;
    }

    // Initiate call
    const success = await window.videoCallInitiator?.initiateCall(
      otherUserId,
      otherUserName,
      null,
      chatData.id
    );

    if (success) {
      // Show success message
      if (window.showToast) {
        window.showToast('📹 Video call initiated. Opening call window...', 'success');
      }
    }
  }

  /**
   * Initiate call from order
   */
  async initiateCallFromOrder() {
    // Get the order data
    const orderData = window.orderTracker?.getCurrentOrder?.();
    if (!orderData) {
      alert('No active order');
      return;
    }

    const otherUserId = this.currentUserRole === 'seller'
      ? orderData.buyer_id
      : orderData.seller_id;

    const otherUserName = this.currentUserRole === 'seller'
      ? orderData.buyer_name
      : orderData.seller_name;

    // Check if user is seller
    if (this.currentUserRole !== 'seller') {
      alert('Only sellers can initiate video calls');
      return;
    }

    // Initiate call
    const success = await window.videoCallInitiator?.initiateCall(
      otherUserId,
      otherUserName,
      orderData.id,
      null
    );

    if (success) {
      if (window.showToast) {
        window.showToast('📹 Video call initiated. Opening call window...', 'success');
      }
    }
  }

  /**
   * Display incoming call notification
   */
  displayIncomingCallNotification(invitation) {
    // This is handled by incomingCallHandler
    // Just ensure it's visible
    const modal = document.getElementById('incoming-call-modal');
    if (modal) {
      modal.classList.remove('hidden');
    }
  }

  /**
   * Update user presence in UI
   */
  updateUserPresenceUI(userId, isOnline) {
    const indicators = document.querySelectorAll(`[data-user-id="${userId}"][data-presence-indicator]`);
    indicators.forEach(indicator => {
      if (isOnline) {
        indicator.classList.add('online');
        indicator.classList.remove('offline');
      } else {
        indicator.classList.add('offline');
        indicator.classList.remove('online');
      }
    });
  }

  /**
   * Show call history
   */
  async showCallHistory() {
    try {
      const { data: calls, error } = await db
        .from('call_logs')
        .select('*')
        .or(`caller_id.eq.${this.currentUserId},callee_id.eq.${this.currentUserId}`)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;

      // Display call history
      console.log('Call History:', calls);
      return calls;
    } catch (error) {
      console.error('[dashboard-video-call-integration] Error loading call history:', error);
      return [];
    }
  }

  /**
   * Get call statistics
   */
  async getCallStatistics() {
    try {
      const { data: stats, error } = await db
        .from('call_logs')
        .select('status, COUNT(*) as count')
        .or(`caller_id.eq.${this.currentUserId},callee_id.eq.${this.currentUserId}`)
        .group_by('status');

      if (error) throw error;

      return stats;
    } catch (error) {
      console.error('[dashboard-video-call-integration] Error loading statistics:', error);
      return [];
    }
  }

  /**
   * Cleanup
   */
  destroy() {
    if (window.userPresenceManager) {
      window.userPresenceManager.destroy();
    }
    if (window.incomingCallHandler) {
      window.incomingCallHandler.destroy();
    }
  }
}

// Create global instance
window.dashboardVideoCallIntegration = new DashboardVideoCallIntegration();

console.log('[dashboard-video-call-integration] Dashboard video call integration loaded');
