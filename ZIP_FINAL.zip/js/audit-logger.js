// ============================================================
// audit-logger.js — Admin Audit Logging Utility
// Requirement 1.2.4: Implement Admin Audit Logging
// ============================================================

class AuditLogger {
  constructor() {
    this.isInitialized = false;
    this.init();
  }

  async init() {
    // Check if user is admin
    const isAdmin = await this.checkAdminStatus();
    if (isAdmin) {
      this.isInitialized = true;
      console.log('[audit-logger] Audit logger initialized for admin user');
    } else {
      console.log('[audit-logger] User is not admin, audit logging disabled');
    }
  }

  async checkAdminStatus() {
    try {
      const { data: { session } } = await db.auth.getSession();
      if (!session) return false;
      
      const user = session.user;
      return user.user_metadata?.role === 'admin' || user.app_metadata?.role === 'admin';
    } catch (error) {
      console.error('[audit-logger] Error checking admin status:', error);
      return false;
    }
  }

  /**
   * Log an admin action
   * @param {string} action - Action type (seller_approved, listing_rejected, etc.)
   * @param {object} details - Additional details about the action
   * @param {string} entityType - Type of entity (seller, listing, payment, etc.)
   * @param {string} entityId - ID of the affected entity
   */
  async logAction(action, details = {}, entityType = null, entityId = null) {
    if (!this.isInitialized) {
      console.warn('[audit-logger] Audit logger not initialized, skipping log');
      return null;
    }

    try {
      console.log('[audit-logger] Logging action:', action, details);
      
      const { data, error } = await db.rpc('log_admin_action', {
        p_action: action,
        p_details: details,
        p_entity_type: entityType,
        p_entity_id: entityId
      });

      if (error) {
        console.error('[audit-logger] Error logging action:', error);
        return null;
      }

      console.log('[audit-logger] Action logged successfully:', data);
      return data;
    } catch (error) {
      console.error('[audit-logger] Failed to log action:', error);
      return null;
    }
  }

  /**
   * Log seller approval
   */
  async logSellerApproval(sellerId, sellerEmail) {
    return await this.logAction(
      'seller_approved',
      {
        seller_id: sellerId,
        seller_email: sellerEmail,
        approved_at: new Date().toISOString()
      },
      'seller',
      sellerId
    );
  }

  /**
   * Log seller rejection
   */
  async logSellerRejection(sellerId, sellerEmail, reason = null) {
    return await this.logAction(
      'seller_rejected',
      {
        seller_id: sellerId,
        seller_email: sellerEmail,
        reason: reason,
        rejected_at: new Date().toISOString()
      },
      'seller',
      sellerId
    );
  }

  /**
   * Log listing approval
   */
  async logListingApproval(listingId, listingName, sellerId) {
    return await this.logAction(
      'listing_approved',
      {
        listing_id: listingId,
        listing_name: listingName,
        seller_id: sellerId,
        approved_at: new Date().toISOString()
      },
      'listing',
      listingId
    );
  }

  /**
   * Log listing rejection
   */
  async logListingRejection(listingId, listingName, sellerId, reason = null) {
    return await this.logAction(
      'listing_rejected',
      {
        listing_id: listingId,
        listing_name: listingName,
        seller_id: sellerId,
        reason: reason,
        rejected_at: new Date().toISOString()
      },
      'listing',
      listingId
    );
  }

  /**
   * Log payment verification
   */
  async logPaymentVerification(paymentId, amount, sellerId, verified = true) {
    return await this.logAction(
      verified ? 'payment_verified' : 'payment_rejected',
      {
        payment_id: paymentId,
        amount: amount,
        seller_id: sellerId,
        verified: verified,
        verified_at: new Date().toISOString()
      },
      'payment',
      paymentId
    );
  }

  /**
   * Log admin login
   */
  async logAdminLogin() {
    return await this.logAction(
      'admin_login',
      {
        login_at: new Date().toISOString(),
        user_agent: navigator.userAgent
      }
    );
  }

  /**
   * Log admin logout
   */
  async logAdminLogout() {
    return await this.logAction(
      'admin_logout',
      {
        logout_at: new Date().toISOString()
      }
    );
  }

  /**
   * Get audit logs with filtering
   */
  async getAuditLogs(options = {}) {
    const {
      limit = 50,
      offset = 0,
      actionFilter = null,
      adminFilter = null,
      startDate = null,
      endDate = null
    } = options;

    try {
      const { data, error } = await db.rpc('get_audit_logs', {
        p_limit: limit,
        p_offset: offset,
        p_action_filter: actionFilter,
        p_admin_filter: adminFilter,
        p_start_date: startDate,
        p_end_date: endDate
      });

      if (error) {
        console.error('[audit-logger] Error fetching audit logs:', error);
        return [];
      }

      return data || [];
    } catch (error) {
      console.error('[audit-logger] Failed to fetch audit logs:', error);
      return [];
    }
  }
}

// ---- GLOBAL INSTANCE ----
const auditLogger = new AuditLogger();
window.auditLogger = auditLogger;

console.log('[audit-logger] Audit Logger loaded');
