/**
 * Notification Center Module for REWEAR
 * Manages all user notifications with real-time updates
 */

class NotificationCenter {
  constructor() {
    this.notifications = [];
    this.unreadCount = 0;
    this.currentUserId = null;
    this.subscription = null;
  }

  /**
   * Initialize notification center
   */
  async init(userId) {
    this.currentUserId = userId;
    
    // Create notification UI
    this.createNotificationUI();
    
    // Load existing notifications
    await this.loadNotifications();
    
    // Subscribe to real-time updates
    this.subscribeToNotifications();
    
    // Update badge
    this.updateBadge();
  }

  /**
   * Create notification UI elements
   */
  createNotificationUI() {
    // Check if already created
    if (document.getElementById('notification-center-container')) return;

    const html = `
      <!-- Notification Center Container -->
      <div id="notification-center-container">
        <!-- Notification Bell Icon (in header) -->
        <button id="notification-bell" class="notification-bell" title="Notifications">
          <span class="bell-icon">🔔</span>
          <span class="notification-badge" id="notification-badge" style="display: none;">0</span>
        </button>

        <!-- Notification Panel -->
        <div id="notification-panel" class="notification-panel hidden">
          <!-- Panel Header -->
          <div class="notification-panel-header">
            <div class="header-top">
              <h3>Notifications</h3>
              <button id="close-panel-btn" class="close-panel-btn" title="Close">
                ✕
              </button>
            </div>
            <div class="header-status">
              <span class="status-dot"></span>
              <span class="status-text">Connected</span>
            </div>
          </div>

          <!-- Mark all as read -->
          <div class="mark-all-section">
            <button id="mark-all-read-btn" class="mark-all-read-btn" title="Mark all as read">
              Mark all as Read
            </button>
          </div>

          <!-- Notification List -->
          <div id="notification-list" class="notification-list">
            <div class="notification-empty">
              <span class="empty-icon">📭</span>
              <p>No notifications yet</p>
            </div>
          </div>

          <!-- Panel Footer -->
          <div class="notification-panel-footer">
            <button id="view-all-notifications-btn" class="view-all-btn">
              View all (0)
            </button>
          </div>
        </div>

        <!-- Notification Toast (for new notifications) -->
        <div id="notification-toast" class="notification-toast hidden">
          <div class="toast-content">
            <span class="toast-icon">🔔</span>
            <div class="toast-text">
              <div class="toast-title" id="toast-title"></div>
              <div class="toast-message" id="toast-message"></div>
            </div>
            <button class="toast-close-btn" onclick="this.parentElement.parentElement.classList.add('hidden')">✕</button>
          </div>
        </div>
      </div>

      <style>
        /* Notification Center Styles - REWEAR Color Scheme */
        #notification-center-container {
          position: relative;
        }

        .notification-bell {
          position: relative;
          background: none;
          border: none;
          font-size: 24px;
          cursor: pointer;
          padding: 8px;
          border-radius: 8px;
          transition: background 0.2s;
        }

        .notification-bell:hover {
          background: rgba(200, 169, 110, 0.1);
        }

        .notification-badge {
          position: absolute;
          top: 0;
          right: 0;
          background: #c8a96e;
          color: white;
          border-radius: 50%;
          width: 24px;
          height: 24px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: bold;
          font-weight: 700;
        }

        /* Notification Panel */
        .notification-panel {
          position: absolute;
          top: 100%;
          right: 0;
          width: 420px;
          max-height: 600px;
          background: #1a1a2e;
          border-radius: 12px;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
          z-index: 1000;
          display: flex;
          flex-direction: column;
          margin-top: 8px;
          border: 1px solid #2a2a3e;
        }

        .notification-panel.hidden {
          display: none;
        }

        .notification-panel-header {
          padding: 16px;
          border-bottom: 1px solid #2a2a3e;
        }

        .header-top {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 12px;
        }

        .notification-panel-header h3 {
          margin: 0;
          font-size: 20px;
          font-weight: 700;
          color: #ffffff;
        }

        .close-panel-btn {
          background: none;
          border: none;
          cursor: pointer;
          font-size: 24px;
          color: #999;
          padding: 0;
          width: 32px;
          height: 32px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 6px;
          transition: background 0.2s;
        }

        .close-panel-btn:hover {
          background: rgba(200, 169, 110, 0.1);
        }

        .header-status {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 14px;
          color: #999;
        }

        .status-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #27ae60;
        }

        .mark-all-section {
          padding: 0 16px 12px;
          text-align: center;
        }

        .mark-all-read-btn {
          background: none;
          border: none;
          cursor: pointer;
          font-size: 14px;
          color: #c8a96e;
          padding: 0;
          text-decoration: underline;
          transition: color 0.2s;
          font-weight: 500;
        }

        .mark-all-read-btn:hover {
          color: #a68a52;
        }

        .notification-list {
          flex: 1;
          overflow-y: auto;
          max-height: 400px;
        }

        .notification-list::-webkit-scrollbar {
          width: 6px;
        }

        .notification-list::-webkit-scrollbar-track {
          background: transparent;
        }

        .notification-list::-webkit-scrollbar-thumb {
          background: #3a3a4e;
          border-radius: 3px;
        }

        .notification-list::-webkit-scrollbar-thumb:hover {
          background: #4a4a5e;
        }

        .notification-item {
          padding: 12px 16px;
          border-bottom: 1px solid #2a2a3e;
          cursor: pointer;
          transition: background 0.2s;
          display: flex;
          gap: 12px;
          align-items: flex-start;
          position: relative;
        }

        .notification-item:hover {
          background: rgba(200, 169, 110, 0.05);
        }

        .notification-item.unread {
          background: rgba(200, 169, 110, 0.1);
        }

        .notification-icon {
          font-size: 24px;
          flex-shrink: 0;
          margin-top: 2px;
          background: #c8a96e;
          width: 40px;
          height: 40px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .notification-content {
          flex: 1;
          min-width: 0;
        }

        .notification-title {
          font-weight: 600;
          color: #ffffff;
          font-size: 14px;
          margin-bottom: 4px;
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .notification-message {
          color: #b0b0b0;
          font-size: 13px;
          line-height: 1.4;
          margin-bottom: 6px;
        }

        .notification-time {
          font-size: 12px;
          color: #666;
        }

        .notification-item .close-item-btn {
          position: absolute;
          top: 8px;
          right: 8px;
          background: none;
          border: none;
          cursor: pointer;
          font-size: 18px;
          color: #666;
          padding: 4px;
          opacity: 0;
          transition: opacity 0.2s;
        }

        .notification-item:hover .close-item-btn {
          opacity: 1;
        }

        .notification-empty {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 60px 20px;
          color: #666;
        }

        .empty-icon {
          font-size: 48px;
          margin-bottom: 12px;
        }

        .notification-panel-footer {
          padding: 12px 16px;
          border-top: 1px solid #2a2a3e;
          text-align: center;
        }

        .view-all-btn {
          background: none;
          border: none;
          cursor: pointer;
          color: #ffffff;
          font-size: 14px;
          font-weight: 600;
          padding: 8px 16px;
          border-radius: 6px;
          transition: background 0.2s;
          width: 100%;
        }

        .view-all-btn:hover {
          background: rgba(200, 169, 110, 0.1);
        }

        /* Notification Toast */
        .notification-toast {
          position: fixed;
          top: 20px;
          right: 20px;
          background: #1a1a2e;
          border-radius: 12px;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
          z-index: 2000;
          max-width: 380px;
          border-left: 4px solid #c8a96e;
          animation: slideIn 0.3s ease;
          border: 1px solid #2a2a3e;
        }

        .notification-toast.hidden {
          display: none;
        }

        @keyframes slideIn {
          from {
            transform: translateX(400px);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }

        .toast-content {
          display: flex;
          gap: 12px;
          align-items: flex-start;
          padding: 16px;
        }

        .toast-icon {
          font-size: 24px;
          flex-shrink: 0;
        }

        .toast-text {
          flex: 1;
          min-width: 0;
        }

        .toast-title {
          font-weight: 600;
          color: #ffffff;
          font-size: 14px;
          margin-bottom: 4px;
        }

        .toast-message {
          color: #b0b0b0;
          font-size: 13px;
          line-height: 1.4;
        }

        .toast-close-btn {
          background: none;
          border: none;
          cursor: pointer;
          font-size: 18px;
          color: #666;
          padding: 0;
          flex-shrink: 0;
          transition: color 0.2s;
        }

        .toast-close-btn:hover {
          color: #999;
        }

        /* Mobile Responsive */
        @media (max-width: 480px) {
          .notification-panel {
            width: calc(100vw - 32px);
            right: 16px;
            left: 16px;
          }

          .notification-toast {
            width: calc(100vw - 32px);
            right: 16px;
            left: 16px;
          }
        }
      </style>
    `;

    document.body.insertAdjacentHTML('beforeend', html);
    this.attachEventListeners();
  }

  /**
   * Attach event listeners
   */
  attachEventListeners() {
    const bellBtn = document.getElementById('notification-bell');
    const closeBtn = document.getElementById('close-panel-btn');
    const markAllReadBtn = document.getElementById('mark-all-read-btn');
    const panel = document.getElementById('notification-panel');

    bellBtn?.addEventListener('click', () => {
      panel.classList.toggle('hidden');
    });

    closeBtn?.addEventListener('click', () => {
      panel.classList.add('hidden');
    });

    markAllReadBtn?.addEventListener('click', () => {
      this.markAllAsRead();
    });

    // Close panel when clicking outside
    document.addEventListener('click', (e) => {
      if (!e.target.closest('#notification-center-container')) {
        panel?.classList.add('hidden');
      }
    });
  }

  /**
   * Load notifications from database
   */
  async loadNotifications() {
    try {
      const { data, error } = await db
        .from('notifications')
        .select('*')
        .eq('user_id', this.currentUserId)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;

      this.notifications = data || [];
      this.updateNotificationList();
      this.updateUnreadCount();
    } catch (error) {
      console.error('[notification-center] Error loading notifications:', error);
    }
  }

  /**
   * Subscribe to real-time notification updates
   */
  subscribeToNotifications() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }

    this.subscription = db
      .channel(`notifications:${this.currentUserId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'notifications',
        filter: `user_id=eq.${this.currentUserId}`
      }, (payload) => {
        this.handleNewNotification(payload.new);
      })
      .subscribe();
  }

  /**
   * Handle new notification
   */
  handleNewNotification(notification) {
    // Add to beginning of list
    this.notifications.unshift(notification);
    
    // Keep only last 50
    if (this.notifications.length > 50) {
      this.notifications.pop();
    }

    // Update UI
    this.updateNotificationList();
    this.updateUnreadCount();
    this.showNotificationToast(notification);
  }

  /**
   * Update notification list UI
   */
  updateNotificationList() {
    const list = document.getElementById('notification-list');
    if (!list) return;

    if (this.notifications.length === 0) {
      list.innerHTML = `
        <div class="notification-empty">
          <span class="empty-icon">📭</span>
          <p>No notifications yet</p>
        </div>
      `;
      return;
    }

    list.innerHTML = this.notifications.map(notif => `
      <div class="notification-item ${notif.is_read ? '' : 'unread'}" onclick="window.notificationCenter.markAsRead('${notif.id}')">
        <div class="notification-icon">${this.getNotificationIcon(notif.notification_type)}</div>
        <div class="notification-content">
          <div class="notification-title">${notif.title}</div>
          <div class="notification-message">${notif.message}</div>
          <div class="notification-time">${this.formatTime(notif.created_at)}</div>
        </div>
        <button class="close-item-btn" onclick="event.stopPropagation(); window.notificationCenter.deleteNotification('${notif.id}')">✕</button>
      </div>
    `).join('');

    // Update view all button
    const viewAllBtn = document.getElementById('view-all-notifications-btn');
    if (viewAllBtn) {
      viewAllBtn.textContent = `View all (${this.notifications.length})`;
    }
  }

  /**
   * Update unread count badge
   */
  updateUnreadCount() {
    this.unreadCount = this.notifications.filter(n => !n.is_read).length;
    const badge = document.getElementById('notification-badge');
    
    if (badge) {
      if (this.unreadCount > 0) {
        badge.textContent = this.unreadCount > 99 ? '99+' : this.unreadCount;
        badge.style.display = 'flex';
      } else {
        badge.style.display = 'none';
      }
    }
  }

  /**
   * Update badge
   */
  updateBadge() {
    this.updateUnreadCount();
  }

  /**
   * Show notification toast
   */
  showNotificationToast(notification) {
    const toast = document.getElementById('notification-toast');
    if (!toast) return;

    document.getElementById('toast-title').textContent = notification.title;
    document.getElementById('toast-message').textContent = notification.message;

    toast.classList.remove('hidden');

    // Auto-hide after 5 seconds
    setTimeout(() => {
      toast.classList.add('hidden');
    }, 5000);
  }

  /**
   * Mark notification as read
   */
  async markAsRead(notificationId) {
    try {
      const { error } = await db
        .from('notifications')
        .update({ is_read: true })
        .eq('id', notificationId);

      if (error) throw error;

      // Update local state
      const notif = this.notifications.find(n => n.id === notificationId);
      if (notif) {
        notif.is_read = true;
        this.updateNotificationList();
        this.updateUnreadCount();
      }
    } catch (error) {
      console.error('[notification-center] Error marking as read:', error);
    }
  }

  /**
   * Mark all as read
   */
  async markAllAsRead() {
    try {
      const unreadIds = this.notifications
        .filter(n => !n.is_read)
        .map(n => n.id);

      if (unreadIds.length === 0) return;

      const { error } = await db
        .from('notifications')
        .update({ is_read: true })
        .in('id', unreadIds);

      if (error) throw error;

      // Update local state
      this.notifications.forEach(n => { n.is_read = true; });
      this.updateNotificationList();
      this.updateUnreadCount();
    } catch (error) {
      console.error('[notification-center] Error marking all as read:', error);
    }
  }

  /**
   * Delete notification
   */
  async deleteNotification(notificationId) {
    try {
      const { error } = await db
        .from('notifications')
        .delete()
        .eq('id', notificationId);

      if (error) throw error;

      // Update local state
      this.notifications = this.notifications.filter(n => n.id !== notificationId);
      this.updateNotificationList();
      this.updateUnreadCount();
    } catch (error) {
      console.error('[notification-center] Error deleting notification:', error);
    }
  }

  /**
   * Get notification icon based on type
   */
  getNotificationIcon(type) {
    const icons = {
      'new_message': '💬',
      'order_status': '📦',
      'payment_received': '💰',
      'seller_application_approved': '✅',
      'seller_application_rejected': '❌',
      'incoming_video_call': '📹',
      'missed_video_call': '📞',
      'product_review': '⭐',
      'seller_verification_approved': '✓',
      'seller_verification_rejected': '✗',
      'listing_fee_payment': '💳',
      'new_listing': '🏷️',
      'order_received': '📥',
      'order_shipped': '🚚',
      'order_delivered': '✔️',
      'payment_pending': '⏳',
      'buyer_review': '⭐',
      'seller_review': '⭐',
      'chat_message': '💬',
      'default': '🔔'
    };
    return icons[type] || icons['default'];
  }

  /**
   * Format time for display
   */
  formatTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;

    return date.toLocaleDateString();
  }

  /**
   * Send notification to user
   */
  async sendNotification(userId, type, title, message, data = {}) {
    try {
      const { error } = await db
        .from('notifications')
        .insert({
          user_id: userId,
          notification_type: type,
          title,
          message,
          data,
          is_read: false,
          created_at: new Date().toISOString()
        });

      if (error) throw error;
    } catch (error) {
      console.error('[notification-center] Error sending notification:', error);
    }
  }
}

// Create global instance
window.notificationCenter = new NotificationCenter();

console.log('[notification-center] Notification center loaded');
