/**
 * Environment Configuration
 * 
 * This module provides environment detection and feature flags for the REWEAR marketplace.
 * It determines whether the application is running in production or development mode
 * and provides flags to control debug features.
 */

/**
 * Detect if the application is running in production environment
 * @returns {boolean} True if running in production
 */
function isProduction() {
  // Check hostname for production indicators
  const hostname = window.location.hostname;
  
  // Production hostnames (customize based on your deployment)
  const productionHosts = [
    'rewear.ph',
    'www.rewear.ph',
    'rewear.com',
    'www.rewear.com'
  ];
  
  // Check if current hostname matches production
  return productionHosts.some(host => hostname.includes(host));
}

/**
 * Detect if the application is running in development environment
 * @returns {boolean} True if running in development
 */
function isDevelopment() {
  const hostname = window.location.hostname;
  
  // Development indicators
  return hostname === 'localhost' || 
         hostname === '127.0.0.1' || 
         hostname.startsWith('192.168.') ||
         hostname.startsWith('10.') ||
         hostname.includes('dev.') ||
         hostname.includes('staging.');
}

/**
 * Environment configuration object
 */
const ENV_CONFIG = {
  // Environment flags
  IS_PRODUCTION: isProduction(),
  IS_DEVELOPMENT: isDevelopment(),
  IS_STAGING: window.location.hostname.includes('staging.'),
  
  // Feature flags
  ENABLE_DEBUG_LOGGING: isDevelopment(),
  ENABLE_DEBUG_BUTTONS: isDevelopment(),
  ENABLE_TEST_PAGES: isDevelopment(),
  ENABLE_MOCK_DATA: false, // Always disabled - use real data only
  ENABLE_PERFORMANCE_MONITORING: isProduction(),
  
  // API configuration
  API_TIMEOUT: isProduction() ? 30000 : 60000, // 30s prod, 60s dev
  
  // Logging configuration
  LOG_LEVEL: isProduction() ? 'error' : 'debug',
  
  // Get environment name
  getEnvironmentName() {
    if (this.IS_PRODUCTION) return 'production';
    if (this.IS_STAGING) return 'staging';
    if (this.IS_DEVELOPMENT) return 'development';
    return 'unknown';
  }
};

/**
 * Safe logging function that respects environment configuration
 * Only logs in development mode
 * 
 * @param {string} level - Log level (log, info, warn, error)
 * @param {...any} args - Arguments to log
 */
function safeLog(level, ...args) {
  if (!ENV_CONFIG.ENABLE_DEBUG_LOGGING) {
    // In production, only log errors
    if (level === 'error') {
      console.error(...args);
    }
    return;
  }
  
  // In development, log everything
  switch (level) {
    case 'log':
      console.log(...args);
      break;
    case 'info':
      console.info(...args);
      break;
    case 'warn':
      console.warn(...args);
      break;
    case 'error':
      console.error(...args);
      break;
    default:
      console.log(...args);
  }
}

/**
 * Feature flag checker
 * Use this to conditionally enable/disable features based on environment
 * 
 * @param {string} featureName - Name of the feature flag
 * @returns {boolean} True if feature is enabled
 */
function isFeatureEnabled(featureName) {
  return ENV_CONFIG[featureName] === true;
}

/**
 * Assert that we're in development mode
 * Throws an error if called in production
 * Use this to guard development-only code
 */
function assertDevelopment() {
  if (ENV_CONFIG.IS_PRODUCTION) {
    throw new Error('This feature is only available in development mode');
  }
}

// Export configuration
if (typeof module !== 'undefined' && module.exports) {
  // Node.js environment (for tests)
  module.exports = {
    ENV_CONFIG,
    safeLog,
    isFeatureEnabled,
    assertDevelopment,
    isProduction,
    isDevelopment
  };
}

// Log environment on load (development only)
if (ENV_CONFIG.ENABLE_DEBUG_LOGGING) {
  console.log(`[REWEAR] Environment: ${ENV_CONFIG.getEnvironmentName()}`);
  console.log('[REWEAR] Configuration:', ENV_CONFIG);
}
