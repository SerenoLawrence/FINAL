// ============================================================
// data-mapper.test.js — Unit tests for data-mapper.js
// Requirement 1.8.4: Test data mapper with all database tables
// ============================================================

import { dbToJs, jsToDb, mapPayload, _test } from '../data-mapper.js';

const { snakeToCamel, camelToSnake } = _test;

// ============================================================
// TEST UTILITIES
// ============================================================

function assert(condition, message) {
  if (!condition) {
    throw new Error(`Assertion failed: ${message}`);
  }
}

function assertEqual(actual, expected, message) {
  if (JSON.stringify(actual) !== JSON.stringify(expected)) {
    console.error('Expected:', expected);
    console.error('Actual:', actual);
    throw new Error(`Assertion failed: ${message}`);
  }
}

// ============================================================
// BASIC CONVERSION TESTS
// ============================================================

function testSnakeToCamel() {
  console.log('Testing snakeToCamel...');
  
  assertEqual(snakeToCamel('seller_id'), 'sellerId', 'seller_id → sellerId');
  assertEqual(snakeToCamel('created_at'), 'createdAt', 'created_at → createdAt');
  assertEqual(snakeToCamel('business_name'), 'businessName', 'business_name → businessName');
  assertEqual(snakeToCamel('in_stock'), 'inStock', 'in_stock → inStock');
  assertEqual(snakeToCamel('is_featured'), 'isFeatured', 'is_featured → isFeatured');
  assertEqual(snakeToCamel('payment_proof_url'), 'paymentProofUrl', 'payment_proof_url → paymentProofUrl');
  
  // Single word (no conversion)
  assertEqual(snakeToCamel('id'), 'id', 'id → id');
  assertEqual(snakeToCamel('name'), 'name', 'name → name');
  assertEqual(snakeToCamel('price'), 'price', 'price → price');
  
  // Special mappings
  assertEqual(snakeToCamel('gcash_number'), 'gcashNumber', 'gcash_number → gcashNumber');
  assertEqual(snakeToCamel('gcash_name'), 'gcashName', 'gcash_name → gcashName');
  assertEqual(snakeToCamel('gcash_qr_url'), 'gcashQrUrl', 'gcash_qr_url → gcashQrUrl');
  
  console.log('✅ snakeToCamel tests passed');
}

function testCamelToSnake() {
  console.log('Testing camelToSnake...');
  
  assertEqual(camelToSnake('sellerId'), 'seller_id', 'sellerId → seller_id');
  assertEqual(camelToSnake('createdAt'), 'created_at', 'createdAt → created_at');
  assertEqual(camelToSnake('businessName'), 'business_name', 'businessName → business_name');
  assertEqual(camelToSnake('inStock'), 'in_stock', 'inStock → in_stock');
  assertEqual(camelToSnake('isFeatured'), 'is_featured', 'isFeatured → is_featured');
  assertEqual(camelToSnake('paymentProofUrl'), 'payment_proof_url', 'paymentProofUrl → payment_proof_url');
  
  // Single word (no conversion)
  assertEqual(camelToSnake('id'), 'id', 'id → id');
  assertEqual(camelToSnake('name'), 'name', 'name → name');
  assertEqual(camelToSnake('price'), 'price', 'price → price');
  
  // Special mappings
  assertEqual(camelToSnake('gcashNumber'), 'gcash_number', 'gcashNumber → gcash_number');
  assertEqual(camelToSnake('gcashName'), 'gcash_name', 'gcashName → gcash_name');
  assertEqual(camelToSnake('gcashQrUrl'), 'gcash_qr_url', 'gcashQrUrl → gcash_qr_url');
  
  console.log('✅ camelToSnake tests passed');
}

// ============================================================
// OBJECT CONVERSION TESTS
// ============================================================

function testDbToJs() {
  console.log('Testing dbToJs...');
  
  // Simple object
  const dbProduct = {
    id: '123',
    seller_id: '456',
    name: 'Vintage Jacket',
    price: 1299.00,
    in_stock: true,
    created_at: '2025-01-01T00:00:00Z'
  };
  
  const jsProduct = dbToJs(dbProduct);
  
  assertEqual(jsProduct.id, '123', 'id preserved');
  assertEqual(jsProduct.sellerId, '456', 'seller_id → sellerId');
  assertEqual(jsProduct.name, 'Vintage Jacket', 'name preserved');
  assertEqual(jsProduct.price, 1299.00, 'price preserved');
  assertEqual(jsProduct.inStock, true, 'in_stock → inStock');
  assertEqual(jsProduct.createdAt, '2025-01-01T00:00:00Z', 'created_at → createdAt');
  
  // Null handling
  assertEqual(dbToJs(null), null, 'null → null');
  assertEqual(dbToJs(undefined), undefined, 'undefined → undefined');
  
  // Primitive handling
  assertEqual(dbToJs('string'), 'string', 'string preserved');
  assertEqual(dbToJs(123), 123, 'number preserved');
  assertEqual(dbToJs(true), true, 'boolean preserved');
  
  console.log('✅ dbToJs tests passed');
}

function testJsToDb() {
  console.log('Testing jsToDb...');
  
  // Simple object
  const jsOrder = {
    id: '789',
    buyerId: '101',
    productId: '202',
    totalPrice: 1500.00,
    sizeSelected: 'M',
    inStock: true,
    createdAt: '2025-01-01T00:00:00Z'
  };
  
  const dbOrder = jsToDb(jsOrder);
  
  assertEqual(dbOrder.id, '789', 'id preserved');
  assertEqual(dbOrder.buyer_id, '101', 'buyerId → buyer_id');
  assertEqual(dbOrder.product_id, '202', 'productId → product_id');
  assertEqual(dbOrder.total_price, 1500.00, 'totalPrice → total_price');
  assertEqual(dbOrder.size_selected, 'M', 'sizeSelected → size_selected');
  assertEqual(dbOrder.in_stock, true, 'inStock → in_stock');
  assertEqual(dbOrder.created_at, '2025-01-01T00:00:00Z', 'createdAt → created_at');
  
  // Null handling
  assertEqual(jsToDb(null), null, 'null → null');
  assertEqual(jsToDb(undefined), undefined, 'undefined → undefined');
  
  // Primitive handling
  assertEqual(jsToDb('string'), 'string', 'string preserved');
  assertEqual(jsToDb(123), 123, 'number preserved');
  assertEqual(jsToDb(false), false, 'boolean preserved');
  
  console.log('✅ jsToDb tests passed');
}

// ============================================================
// ARRAY CONVERSION TESTS
// ============================================================

function testArrayConversion() {
  console.log('Testing array conversion...');
  
  // Array of objects (DB → JS)
  const dbProducts = [
    { id: '1', seller_id: '10', in_stock: true },
    { id: '2', seller_id: '20', in_stock: false }
  ];
  
  const jsProducts = dbToJs(dbProducts);
  
  assertEqual(jsProducts.length, 2, 'array length preserved');
  assertEqual(jsProducts[0].sellerId, '10', 'first item converted');
  assertEqual(jsProducts[1].sellerId, '20', 'second item converted');
  assertEqual(jsProducts[0].inStock, true, 'boolean preserved');
  
  // Array of objects (JS → DB)
  const jsOrders = [
    { id: '1', buyerId: '100', totalPrice: 1000 },
    { id: '2', buyerId: '200', totalPrice: 2000 }
  ];
  
  const dbOrders = jsToDb(jsOrders);
  
  assertEqual(dbOrders.length, 2, 'array length preserved');
  assertEqual(dbOrders[0].buyer_id, '100', 'first item converted');
  assertEqual(dbOrders[1].buyer_id, '200', 'second item converted');
  assertEqual(dbOrders[0].total_price, 1000, 'number preserved');
  
  console.log('✅ Array conversion tests passed');
}

// ============================================================
// NESTED OBJECT TESTS
// ============================================================

function testNestedObjects() {
  console.log('Testing nested objects...');
  
  // Nested object (DB → JS)
  const dbOrder = {
    id: '1',
    buyer_id: '100',
    product: {
      id: '200',
      seller_id: '300',
      in_stock: true
    }
  };
  
  const jsOrder = dbToJs(dbOrder);
  
  assertEqual(jsOrder.buyerId, '100', 'top-level converted');
  assertEqual(jsOrder.product.sellerId, '300', 'nested converted');
  assertEqual(jsOrder.product.inStock, true, 'nested boolean preserved');
  
  // Nested object (JS → DB)
  const jsData = {
    orderId: '1',
    buyer: {
      userId: '100',
      fullName: 'John Doe'
    }
  };
  
  const dbData = jsToDb(jsData);
  
  assertEqual(dbData.order_id, '1', 'top-level converted');
  assertEqual(dbData.buyer.user_id, '100', 'nested converted');
  assertEqual(dbData.buyer.full_name, 'John Doe', 'nested string preserved');
  
  console.log('✅ Nested object tests passed');
}

// ============================================================
// TABLE-SPECIFIC TESTS
// ============================================================

function testProductsTable() {
  console.log('Testing products table conversion...');
  
  const dbProduct = {
    id: 'prod-123',
    seller_id: 'seller-456',
    name: 'Vintage Denim Jacket',
    description: 'Classic 90s style',
    price: 1299.00,
    original_price: 2500.00,
    category: 'jackets',
    condition: 'good',
    size: 'M',
    sizes: ['S', 'M', 'L'],
    color: 'Blue',
    brand: 'Levi\'s',
    images: ['img1.jpg', 'img2.jpg'],
    image_url: 'main.jpg',
    status: 'approved',
    in_stock: true,
    is_featured: false,
    listing_fee_id: 'fee-789',
    created_at: '2025-01-01T00:00:00Z',
    updated_at: '2025-01-02T00:00:00Z'
  };
  
  const jsProduct = dbToJs(dbProduct);
  
  assertEqual(jsProduct.sellerId, 'seller-456', 'sellerId converted');
  assertEqual(jsProduct.originalPrice, 2500.00, 'originalPrice converted');
  assertEqual(jsProduct.inStock, true, 'inStock converted');
  assertEqual(jsProduct.isFeatured, false, 'isFeatured converted');
  assertEqual(jsProduct.listingFeeId, 'fee-789', 'listingFeeId converted');
  assertEqual(jsProduct.imageUrl, 'main.jpg', 'imageUrl converted');
  assertEqual(jsProduct.createdAt, '2025-01-01T00:00:00Z', 'createdAt converted');
  assertEqual(jsProduct.updatedAt, '2025-01-02T00:00:00Z', 'updatedAt converted');
  
  // Arrays preserved
  assert(Array.isArray(jsProduct.sizes), 'sizes is array');
  assert(Array.isArray(jsProduct.images), 'images is array');
  
  console.log('✅ Products table tests passed');
}

function testSellersTable() {
  console.log('Testing sellers table conversion...');
  
  const dbSeller = {
    id: 'seller-123',
    user_id: 'user-456',
    business_name: 'Vintage Fashion Co',
    email: 'seller@example.com',
    phone: '+639171234567',
    business_description: 'Quality preloved fashion',
    verified: true,
    verified_at: '2025-01-01T00:00:00Z',
    verification_level: 'premium',
    total_sales: 50000.00,
    total_earnings: 45000.00,
    rating: 4.8,
    total_reviews: 120,
    active_listings: 25,
    gcash_number: '09171234567',
    gcash_name: 'Juan Dela Cruz',
    gcash_qr_url: 'qr.jpg',
    created_at: '2024-12-01T00:00:00Z'
  };
  
  const jsSeller = dbToJs(dbSeller);
  
  assertEqual(jsSeller.userId, 'user-456', 'userId converted');
  assertEqual(jsSeller.businessName, 'Vintage Fashion Co', 'businessName converted');
  assertEqual(jsSeller.businessDescription, 'Quality preloved fashion', 'businessDescription converted');
  assertEqual(jsSeller.verifiedAt, '2025-01-01T00:00:00Z', 'verifiedAt converted');
  assertEqual(jsSeller.verificationLevel, 'premium', 'verificationLevel converted');
  assertEqual(jsSeller.totalSales, 50000.00, 'totalSales converted');
  assertEqual(jsSeller.totalEarnings, 45000.00, 'totalEarnings converted');
  assertEqual(jsSeller.totalReviews, 120, 'totalReviews converted');
  assertEqual(jsSeller.activeListings, 25, 'activeListings converted');
  assertEqual(jsSeller.gcashNumber, '09171234567', 'gcashNumber converted');
  assertEqual(jsSeller.gcashName, 'Juan Dela Cruz', 'gcashName converted');
  assertEqual(jsSeller.gcashQrUrl, 'qr.jpg', 'gcashQrUrl converted');
  
  console.log('✅ Sellers table tests passed');
}

function testOrdersTable() {
  console.log('Testing orders table conversion...');
  
  const dbOrder = {
    id: 'order-123',
    buyer_id: 'buyer-456',
    buyer_name: 'Maria Santos',
    buyer_email: 'maria@example.com',
    buyer_phone: '+639181234567',
    product_id: 'prod-789',
    seller_id: 'seller-101',
    quantity: 1,
    size_selected: 'M',
    color_selected: 'Blue',
    unit_price: 1299.00,
    total_price: 1299.00,
    shipping_address: '123 Main St, Manila',
    delivery_method: 'delivery',
    delivery_fee: 100.00,
    payment_method: 'gcash',
    payment_status: 'verified',
    payment_proof_url: 'proof.jpg',
    payment_reference: 'REF123456',
    status: 'confirmed',
    tracking_number: 'TRACK123',
    courier_name: 'J&T Express',
    confirmed_at: '2025-01-01T00:00:00Z',
    created_at: '2025-01-01T00:00:00Z'
  };
  
  const jsOrder = dbToJs(dbOrder);
  
  assertEqual(jsOrder.buyerId, 'buyer-456', 'buyerId converted');
  assertEqual(jsOrder.buyerName, 'Maria Santos', 'buyerName converted');
  assertEqual(jsOrder.buyerEmail, 'maria@example.com', 'buyerEmail converted');
  assertEqual(jsOrder.buyerPhone, '+639181234567', 'buyerPhone converted');
  assertEqual(jsOrder.productId, 'prod-789', 'productId converted');
  assertEqual(jsOrder.sellerId, 'seller-101', 'sellerId converted');
  assertEqual(jsOrder.sizeSelected, 'M', 'sizeSelected converted');
  assertEqual(jsOrder.colorSelected, 'Blue', 'colorSelected converted');
  assertEqual(jsOrder.unitPrice, 1299.00, 'unitPrice converted');
  assertEqual(jsOrder.totalPrice, 1299.00, 'totalPrice converted');
  assertEqual(jsOrder.shippingAddress, '123 Main St, Manila', 'shippingAddress converted');
  assertEqual(jsOrder.deliveryMethod, 'delivery', 'deliveryMethod converted');
  assertEqual(jsOrder.deliveryFee, 100.00, 'deliveryFee converted');
  assertEqual(jsOrder.paymentMethod, 'gcash', 'paymentMethod converted');
  assertEqual(jsOrder.paymentStatus, 'verified', 'paymentStatus converted');
  assertEqual(jsOrder.paymentProofUrl, 'proof.jpg', 'paymentProofUrl converted');
  assertEqual(jsOrder.paymentReference, 'REF123456', 'paymentReference converted');
  assertEqual(jsOrder.trackingNumber, 'TRACK123', 'trackingNumber converted');
  assertEqual(jsOrder.courierName, 'J&T Express', 'courierName converted');
  assertEqual(jsOrder.confirmedAt, '2025-01-01T00:00:00Z', 'confirmedAt converted');
  
  console.log('✅ Orders table tests passed');
}

function testListingFeesTable() {
  console.log('Testing listing_fees table conversion...');
  
  const dbFee = {
    id: 'fee-123',
    seller_id: 'seller-456',
    tier: 'premium',
    amount_paid: 500.00,
    payment_method: 'gcash',
    payment_ref: 'REF789',
    proof_url: 'proof.jpg',
    status: 'active',
    max_listings: 10,
    listings_used: 3,
    paid_at: '2025-01-01T00:00:00Z',
    verified_at: '2025-01-02T00:00:00Z',
    verified_by: 'admin-123',
    expires_at: '2025-02-01T00:00:00Z',
    created_at: '2025-01-01T00:00:00Z'
  };
  
  const jsFee = dbToJs(dbFee);
  
  assertEqual(jsFee.sellerId, 'seller-456', 'sellerId converted');
  assertEqual(jsFee.amountPaid, 500.00, 'amountPaid converted');
  assertEqual(jsFee.paymentMethod, 'gcash', 'paymentMethod converted');
  assertEqual(jsFee.paymentRef, 'REF789', 'paymentRef converted');
  assertEqual(jsFee.proofUrl, 'proof.jpg', 'proofUrl converted');
  assertEqual(jsFee.maxListings, 10, 'maxListings converted');
  assertEqual(jsFee.listingsUsed, 3, 'listingsUsed converted');
  assertEqual(jsFee.paidAt, '2025-01-01T00:00:00Z', 'paidAt converted');
  assertEqual(jsFee.verifiedAt, '2025-01-02T00:00:00Z', 'verifiedAt converted');
  assertEqual(jsFee.verifiedBy, 'admin-123', 'verifiedBy converted');
  assertEqual(jsFee.expiresAt, '2025-02-01T00:00:00Z', 'expiresAt converted');
  
  console.log('✅ Listing fees table tests passed');
}

function testMessagesTable() {
  console.log('Testing messages table conversion...');
  
  const dbMessage = {
    id: 'msg-123',
    seller_id: 'seller-456',
    buyer_name: 'Maria Santos',
    buyer_email: 'maria@example.com',
    product_id: 'prod-789',
    message: 'Is this still available?',
    reply: 'Yes, it is!',
    thread: [
      { sender: 'buyer', text: 'Hello' },
      { sender: 'seller', text: 'Hi there' }
    ],
    accepted: false,
    rejected: false,
    is_read: true,
    created_at: '2025-01-01T00:00:00Z',
    replied_at: '2025-01-01T01:00:00Z'
  };
  
  const jsMessage = dbToJs(dbMessage);
  
  assertEqual(jsMessage.sellerId, 'seller-456', 'sellerId converted');
  assertEqual(jsMessage.buyerName, 'Maria Santos', 'buyerName converted');
  assertEqual(jsMessage.buyerEmail, 'maria@example.com', 'buyerEmail converted');
  assertEqual(jsMessage.productId, 'prod-789', 'productId converted');
  assertEqual(jsMessage.isRead, true, 'isRead converted');
  assertEqual(jsMessage.createdAt, '2025-01-01T00:00:00Z', 'createdAt converted');
  assertEqual(jsMessage.repliedAt, '2025-01-01T01:00:00Z', 'repliedAt converted');
  assert(Array.isArray(jsMessage.thread), 'thread is array');
  
  console.log('✅ Messages table tests passed');
}

// ============================================================
// ROUND-TRIP TESTS
// ============================================================

function testRoundTrip() {
  console.log('Testing round-trip conversion...');
  
  // DB → JS → DB
  const originalDb = {
    seller_id: '123',
    created_at: '2025-01-01',
    in_stock: true,
    total_price: 1299.00
  };
  
  const js = dbToJs(originalDb);
  const backToDb = jsToDb(js);
  
  assertEqual(backToDb, originalDb, 'DB → JS → DB preserves data');
  
  // JS → DB → JS
  const originalJs = {
    sellerId: '456',
    createdAt: '2025-01-02',
    inStock: false,
    totalPrice: 2500.00
  };
  
  const db = jsToDb(originalJs);
  const backToJs = dbToJs(db);
  
  assertEqual(backToJs, originalJs, 'JS → DB → JS preserves data');
  
  console.log('✅ Round-trip tests passed');
}

// ============================================================
// EDGE CASES
// ============================================================

function testEdgeCases() {
  console.log('Testing edge cases...');
  
  // Empty object
  assertEqual(dbToJs({}), {}, 'empty object');
  assertEqual(jsToDb({}), {}, 'empty object');
  
  // Empty array
  assertEqual(dbToJs([]), [], 'empty array');
  assertEqual(jsToDb([]), [], 'empty array');
  
  // Object with null values
  const objWithNull = { seller_id: null, name: 'Test' };
  const converted = dbToJs(objWithNull);
  assertEqual(converted.sellerId, null, 'null value preserved');
  assertEqual(converted.name, 'Test', 'non-null value preserved');
  
  // Object with undefined values
  const objWithUndefined = { seller_id: undefined, name: 'Test' };
  const converted2 = dbToJs(objWithUndefined);
  assertEqual(converted2.sellerId, undefined, 'undefined value preserved');
  
  // Date objects
  const date = new Date('2025-01-01');
  const objWithDate = { created_at: date };
  const converted3 = dbToJs(objWithDate);
  assert(converted3.createdAt instanceof Date, 'Date object preserved');
  
  console.log('✅ Edge case tests passed');
}

// ============================================================
// RUN ALL TESTS
// ============================================================

export function runAllTests() {
  console.log('='.repeat(60));
  console.log('DATA MAPPER TESTS');
  console.log('='.repeat(60));
  
  try {
    // Basic conversion
    testSnakeToCamel();
    testCamelToSnake();
    
    // Object conversion
    testDbToJs();
    testJsToDb();
    
    // Array conversion
    testArrayConversion();
    
    // Nested objects
    testNestedObjects();
    
    // Table-specific tests
    testProductsTable();
    testSellersTable();
    testOrdersTable();
    testListingFeesTable();
    testMessagesTable();
    
    // Round-trip
    testRoundTrip();
    
    // Edge cases
    testEdgeCases();
    
    console.log('='.repeat(60));
    console.log('✅ ALL TESTS PASSED');
    console.log('='.repeat(60));
    
    return true;
  } catch (error) {
    console.error('='.repeat(60));
    console.error('❌ TEST FAILED');
    console.error('='.repeat(60));
    console.error(error);
    return false;
  }
}

// Run tests if executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runAllTests();
}
