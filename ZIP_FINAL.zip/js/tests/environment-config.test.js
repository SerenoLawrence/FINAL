/**
 * Environment Configuration Tests
 * 
 * Tests for the environment detection and feature flags system.
 * Run these tests to verify the config.js module works correctly.
 */

// Mock window.location for testing
function mockHostname(hostname) {
  delete window.location;
  window.location = { hostname };
}

// Test Suite
const tests = {
  // Environment Detection Tests
  'should detect production environment for rewear.ph': () => {
    mockHostname('rewear.ph');
    const { isProduction, isDevelopment } = require('../config.js');
    
    if (!isProduction()) throw new Error('Failed to detect production');
    if (isDevelopment()) throw new Error('Incorrectly detected development');
  },
  
  'should detect production environment for www.rewear.ph': () => {
    mockHostname('www.rewear.ph');
    const { isProduction } = require('../config.js');
    
    if (!isProduction()) throw new Error('Failed to detect production');
  },
  
  'should detect development environment for localhost': () => {
    mockHostname('localhost');
    const { isProduction, isDevelopment } = require('../config.js');
    
    if (isProduction()) throw new Error('Incorrectly detected production');
    if (!isDevelopment()) throw new Error('Failed to detect development');
  },
  
  'should detect development environment for 127.0.0.1': () => {
    mockHostname('127.0.0.1');
    const { isDevelopment } = require('../config.js');
    
    if (!isDevelopment()) throw new Error('Failed to detect development');
  },
  
  'should detect development environment for local network IP': () => {
    mockHostname('192.168.1.100');
    const { isDevelopment } = require('../config.js');
    
    if (!isDevelopment()) throw new Error('Failed to detect development');
  },
  
  'should detect staging environment': () => {
    mockHostname('staging.rewear.ph');
    const { ENV_CONFIG } = require('../config.js');
    
    if (!ENV_CONFIG.IS_STAGING) throw new Error('Failed to detect staging');
    if (!ENV_CONFIG.IS_DEVELOPMENT) throw new Error('Staging should also be development');
  },
  
  // Feature Flag Tests
  'should enable debug logging in development': () => {
    mockHostname('localhost');
    const { ENV_CONFIG } = require('../config.js');
    
    if (!ENV_CONFIG.ENABLE_DEBUG_LOGGING) throw new Error('Debug logging should be enabled in development');
  },
  
  'should disable debug logging in production': () => {
    mockHostname('rewear.ph');
    const { ENV_CONFIG } = require('../config.js');
    
    if (ENV_CONFIG.ENABLE_DEBUG_LOGGING) throw new Error('Debug logging should be disabled in production');
  },
  
  'should never enable mock data': () => {
    mockHostname('localhost');
    const { ENV_CONFIG } = require('../config.js');
    
    if (ENV_CONFIG.ENABLE_MOCK_DATA) throw new Error('Mock data should always be disabled');
    
    mockHostname('rewear.ph');
    if (ENV_CONFIG.ENABLE_MOCK_DATA) throw new Error('Mock data should always be disabled');
  },
  
  'should enable performance monitoring in production': () => {
    mockHostname('rewear.ph');
    const { ENV_CONFIG } = require('../config.js');
    
    if (!ENV_CONFIG.ENABLE_PERFORMANCE_MONITORING) throw new Error('Performance monitoring should be enabled in production');
  },
  
  'should disable performance monitoring in development': () => {
    mockHostname('localhost');
    const { ENV_CONFIG } = require('../config.js');
    
    if (ENV_CONFIG.ENABLE_PERFORMANCE_MONITORING) throw new Error('Performance monitoring should be disabled in development');
  },
  
  // Safe Logging Tests
  'should log errors in production': () => {
    mockHostname('rewear.ph');
    const { safeLog } = require('../config.js');
    
    let logged = false;
    const originalError = console.error;
    console.error = () => { logged = true; };
    
    safeLog('error', 'Test error');
    
    console.error = originalError;
    
    if (!logged) throw new Error('Errors should be logged in production');
  },
  
  'should not log debug messages in production': () => {
    mockHostname('rewear.ph');
    const { safeLog } = require('../config.js');
    
    let logged = false;
    const originalLog = console.log;
    console.log = () => { logged = true; };
    
    safeLog('log', 'Test debug message');
    
    console.log = originalLog;
    
    if (logged) throw new Error('Debug messages should not be logged in production');
  },
  
  'should log debug messages in development': () => {
    mockHostname('localhost');
    const { safeLog } = require('../config.js');
    
    let logged = false;
    const originalLog = console.log;
    console.log = () => { logged = true; };
    
    safeLog('log', 'Test debug message');
    
    console.log = originalLog;
    
    if (!logged) throw new Error('Debug messages should be logged in development');
  },
  
  // Feature Flag Checker Tests
  'should correctly check feature flags': () => {
    mockHostname('localhost');
    const { isFeatureEnabled } = require('../config.js');
    
    if (!isFeatureEnabled('ENABLE_DEBUG_LOGGING')) throw new Error('Should detect enabled feature');
    if (isFeatureEnabled('ENABLE_MOCK_DATA')) throw new Error('Should detect disabled feature');
  },
  
  // Development Assertion Tests
  'should not throw in development': () => {
    mockHostname('localhost');
    const { assertDevelopment } = require('../config.js');
    
    try {
      assertDevelopment();
    } catch (error) {
      throw new Error('Should not throw in development');
    }
  },
  
  'should throw in production': () => {
    mockHostname('rewear.ph');
    const { assertDevelopment } = require('../config.js');
    
    let threw = false;
    try {
      assertDevelopment();
    } catch (error) {
      threw = true;
    }
    
    if (!threw) throw new Error('Should throw in production');
  },
  
  // Environment Name Tests
  'should return correct environment name': () => {
    mockHostname('rewear.ph');
    const { ENV_CONFIG } = require('../config.js');
    
    if (ENV_CONFIG.getEnvironmentName() !== 'production') {
      throw new Error('Should return "production"');
    }
    
    mockHostname('localhost');
    if (ENV_CONFIG.getEnvironmentName() !== 'development') {
      throw new Error('Should return "development"');
    }
    
    mockHostname('staging.rewear.ph');
    if (ENV_CONFIG.getEnvironmentName() !== 'staging') {
      throw new Error('Should return "staging"');
    }
  },
  
  // API Timeout Tests
  'should use shorter timeout in production': () => {
    mockHostname('rewear.ph');
    const { ENV_CONFIG } = require('../config.js');
    
    if (ENV_CONFIG.API_TIMEOUT !== 30000) {
      throw new Error('Production timeout should be 30 seconds');
    }
  },
  
  'should use longer timeout in development': () => {
    mockHostname('localhost');
    const { ENV_CONFIG } = require('../config.js');
    
    if (ENV_CONFIG.API_TIMEOUT !== 60000) {
      throw new Error('Development timeout should be 60 seconds');
    }
  },
  
  // Log Level Tests
  'should use error log level in production': () => {
    mockHostname('rewear.ph');
    const { ENV_CONFIG } = require('../config.js');
    
    if (ENV_CONFIG.LOG_LEVEL !== 'error') {
      throw new Error('Production log level should be "error"');
    }
  },
  
  'should use debug log level in development': () => {
    mockHostname('localhost');
    const { ENV_CONFIG } = require('../config.js');
    
    if (ENV_CONFIG.LOG_LEVEL !== 'debug') {
      throw new Error('Development log level should be "debug"');
    }
  }
};

// Test Runner
function runTests() {
  console.log('Running Environment Configuration Tests...\n');
  
  let passed = 0;
  let failed = 0;
  const failures = [];
  
  for (const [name, test] of Object.entries(tests)) {
    try {
      test();
      console.log(`✅ ${name}`);
      passed++;
    } catch (error) {
      console.error(`❌ ${name}`);
      console.error(`   ${error.message}`);
      failed++;
      failures.push({ name, error: error.message });
    }
  }
  
  console.log(`\n${'='.repeat(60)}`);
  console.log(`Tests: ${passed + failed}`);
  console.log(`Passed: ${passed}`);
  console.log(`Failed: ${failed}`);
  console.log(`${'='.repeat(60)}`);
  
  if (failed > 0) {
    console.log('\nFailed Tests:');
    failures.forEach(({ name, error }) => {
      console.log(`  - ${name}`);
      console.log(`    ${error}`);
    });
  }
  
  return failed === 0;
}

// Run tests if this file is executed directly
if (typeof module !== 'undefined' && require.main === module) {
  const success = runTests();
  process.exit(success ? 0 : 1);
}

// Export for use in other test runners
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { tests, runTests };
}
