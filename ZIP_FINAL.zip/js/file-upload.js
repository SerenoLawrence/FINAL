// ============================================================
// file-upload.js — File upload utility for Supabase Storage
// Requirement 1.6: Payment Proof Persistent Storage
// ============================================================

const FileUpload = {
  /**
   * Upload payment proof to Supabase Storage
   * @param {File} file - The file to upload
   * @param {string} userId - The user ID (seller or buyer)
   * @param {string} type - Type of payment proof ('listing_fee' or 'order')
   * @returns {Promise<{success: boolean, url: string|null, error: string|null}>}
   */
  async uploadPaymentProof(file, userId, type = 'order') {
    try {
      // Validate file
      const validation = this.validatePaymentProofFile(file);
      if (!validation.valid) {
        return { success: false, url: null, error: validation.error };
      }

      // Generate unique filename
      const filename = this.generateUniqueFilename(file, userId, type);
      
      // Upload to Supabase Storage
      const { data, error } = await db.storage
        .from('payment-proofs')
        .upload(filename, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) {
        console.error('[file-upload] Upload error:', error);
        return { 
          success: false, 
          url: null, 
          error: `Upload failed: ${error.message}` 
        };
      }

      // Get public URL
      const { data: urlData } = db.storage
        .from('payment-proofs')
        .getPublicUrl(filename);

      if (!urlData || !urlData.publicUrl) {
        return { 
          success: false, 
          url: null, 
          error: 'Failed to get storage URL' 
        };
      }

      console.log('[file-upload] Upload successful:', urlData.publicUrl);
      
      return { 
        success: true, 
        url: urlData.publicUrl, 
        error: null 
      };

    } catch (error) {
      console.error('[file-upload] Exception:', error);
      return { 
        success: false, 
        url: null, 
        error: error.message || 'Upload failed' 
      };
    }
  },

  /**
   * Validate payment proof file
   * @param {File} file - The file to validate
   * @returns {{valid: boolean, error: string|null}}
   */
  validatePaymentProofFile(file) {
    if (!file) {
      return { valid: false, error: 'No file provided' };
    }

    // Check file size (max 5MB)
    const maxSize = 5 * 1024 * 1024; // 5MB in bytes
    if (file.size > maxSize) {
      return { 
        valid: false, 
        error: `File size exceeds 5MB limit. Your file is ${(file.size / 1024 / 1024).toFixed(2)}MB` 
      };
    }

    // Check file type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
    if (!allowedTypes.includes(file.type)) {
      return { 
        valid: false, 
        error: 'Invalid file type. Only JPEG, PNG, and PDF files are allowed' 
      };
    }

    return { valid: true, error: null };
  },

  /**
   * Generate unique filename for payment proof
   * @param {File} file - The file
   * @param {string} userId - The user ID
   * @param {string} type - Type of payment proof
   * @returns {string} Unique filename
   */
  generateUniqueFilename(file, userId, type) {
    const timestamp = Date.now();
    const randomStr = Math.random().toString(36).substring(2, 8);
    const extension = file.name.split('.').pop().toLowerCase();
    
    // Format: {userId}/{type}_{timestamp}_{random}.{ext}
    return `${userId}/${type}_${timestamp}_${randomStr}.${extension}`;
  },

  /**
   * Upload payment proof with progress tracking
   * @param {File} file - The file to upload
   * @param {string} userId - The user ID
   * @param {string} type - Type of payment proof
   * @param {Function} onProgress - Progress callback (percent)
   * @returns {Promise<{success: boolean, url: string|null, error: string|null}>}
   */
  async uploadPaymentProofWithProgress(file, userId, type, onProgress) {
    try {
      // Validate file
      const validation = this.validatePaymentProofFile(file);
      if (!validation.valid) {
        return { success: false, url: null, error: validation.error };
      }

      // Generate unique filename
      const filename = this.generateUniqueFilename(file, userId, type);
      
      // Simulate progress (Supabase doesn't provide native progress tracking)
      let progress = 0;
      const progressInterval = setInterval(() => {
        progress += 10;
        if (progress <= 90) {
          onProgress(progress);
        }
      }, 100);

      // Upload to Supabase Storage
      const { data, error } = await db.storage
        .from('payment-proofs')
        .upload(filename, file, {
          cacheControl: '3600',
          upsert: false
        });

      clearInterval(progressInterval);
      onProgress(100);

      if (error) {
        console.error('[file-upload] Upload error:', error);
        return { 
          success: false, 
          url: null, 
          error: `Upload failed: ${error.message}` 
        };
      }

      // Get public URL
      const { data: urlData } = db.storage
        .from('payment-proofs')
        .getPublicUrl(filename);

      if (!urlData || !urlData.publicUrl) {
        return { 
          success: false, 
          url: null, 
          error: 'Failed to get storage URL' 
        };
      }

      console.log('[file-upload] Upload successful:', urlData.publicUrl);
      
      return { 
        success: true, 
        url: urlData.publicUrl, 
        error: null 
      };

    } catch (error) {
      console.error('[file-upload] Exception:', error);
      return { 
        success: false, 
        url: null, 
        error: error.message || 'Upload failed' 
      };
    }
  },

  /**
   * Delete payment proof from storage
   * @param {string} url - The storage URL to delete
   * @returns {Promise<{success: boolean, error: string|null}>}
   */
  async deletePaymentProof(url) {
    try {
      // Extract filename from URL
      const filename = this.extractFilenameFromUrl(url);
      if (!filename) {
        return { success: false, error: 'Invalid URL' };
      }

      const { error } = await db.storage
        .from('payment-proofs')
        .remove([filename]);

      if (error) {
        console.error('[file-upload] Delete error:', error);
        return { success: false, error: error.message };
      }

      return { success: true, error: null };

    } catch (error) {
      console.error('[file-upload] Delete exception:', error);
      return { success: false, error: error.message };
    }
  },

  /**
   * Extract filename from storage URL
   * @param {string} url - The storage URL
   * @returns {string|null} Filename or null
   */
  extractFilenameFromUrl(url) {
    try {
      // URL format: https://{project}.supabase.co/storage/v1/object/public/payment-proofs/{filename}
      const parts = url.split('/payment-proofs/');
      if (parts.length === 2) {
        return parts[1];
      }
      return null;
    } catch (error) {
      return null;
    }
  },

  /**
   * Get file metadata from storage
   * @param {string} url - The storage URL
   * @returns {Promise<{size: number, contentType: string, lastModified: string}|null>}
   */
  async getFileMetadata(url) {
    try {
      const filename = this.extractFilenameFromUrl(url);
      if (!filename) return null;

      const { data, error } = await db.storage
        .from('payment-proofs')
        .list(filename.split('/')[0], {
          limit: 100,
          offset: 0,
          sortBy: { column: 'name', order: 'asc' }
        });

      if (error || !data) return null;

      const file = data.find(f => filename.includes(f.name));
      if (!file) return null;

      return {
        size: file.metadata?.size || 0,
        contentType: file.metadata?.mimetype || 'unknown',
        lastModified: file.created_at || file.updated_at
      };

    } catch (error) {
      console.error('[file-upload] Metadata error:', error);
      return null;
    }
  },

  /**
   * Create image preview from file
   * @param {File} file - The file to preview
   * @returns {Promise<string>} Data URL for preview
   */
  async createPreview(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        resolve(e.target.result);
      };
      
      reader.onerror = (error) => {
        reject(error);
      };
      
      reader.readAsDataURL(file);
    });
  },

  /**
   * Format file size for display
   * @param {number} bytes - File size in bytes
   * @returns {string} Formatted size (e.g., "2.5 MB")
   */
  formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  }
};

// Make globally available
window.FileUpload = FileUpload;

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
  module.exports = FileUpload;
}
