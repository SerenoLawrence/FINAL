// ============================================================
// dashboard.js — Unified Dashboard Logic
// Mode toggle, tab switching, auth check, video call engine
// ============================================================

let currentMode = 'buyer';
let sellerIsVerified = false;
let userIsSeller = false;

// ---- DOM REFS ----
const modeToggle    = document.getElementById('modeToggle');
const buyerLabel    = document.getElementById('buyerLabel');
const sellerLabel   = document.getElementById('sellerLabel');
const buyerNav      = document.getElementById('buyerNav');
const sellerNav     = document.getElementById('sellerNav');
const buyerContent  = document.getElementById('buyerContent');
const sellerContent = document.getElementById('sellerContent');
const modeBadge     = document.getElementById('modeBadge');
const verifyGate    = document.getElementById('verifyGate');
const becomeGate    = document.getElementById('becomeSellerGate');
const pendingGate   = document.getElementById('pendingGate');

// ---- MODE SWITCH ----
function switchMode(mode) {
    if (mode === 'seller') {
        // Always update toggle UI first
        modeToggle.classList.add('seller-mode');
        buyerLabel.classList.remove('active');
        sellerLabel.classList.add('active');
        buyerNav.style.display = 'none';
        sellerNav.style.display = 'block';
        modeBadge.textContent = 'Seller';
        modeBadge.style.background = '#c8a96e';
        document.getElementById('pageTitle').textContent = 'Seller Dashboard';

        // If auth hasn't resolved yet, show a loading state and retry
        if (!window.authManager?.isInitialized) {
            currentMode = 'seller';
            buyerContent.style.display = 'none';
            sellerContent.style.display = 'none';
            verifyGate.style.display = 'none';
            becomeGate.style.display = 'none';
            document.getElementById('pageSubtitle').textContent = 'Loading…';
            // Retry once auth is ready
            const retryPoll = setInterval(() => {
                if (window.authManager?.isInitialized) {
                    clearInterval(retryPoll);
                    switchMode('seller');
                }
            }, 200);
            return;
        }

        if (!userIsSeller) {
            currentMode = 'seller';
            buyerContent.style.display = 'none';
            sellerContent.style.display = 'none';
            verifyGate.style.display = 'none';
            pendingGate.style.display = 'none';
            becomeGate.style.display = 'block';
            document.getElementById('pageSubtitle').textContent = 'Open your shop on REWEAR';
            return;
        }
        if (!sellerIsVerified) {
            currentMode = 'seller';
            buyerContent.style.display = 'none';
            sellerContent.style.display = 'none';
            becomeGate.style.display = 'none';
            // Check if verification is pending or not submitted
            if (window._verificationPending) {
                verifyGate.style.display = 'none';
                pendingGate.style.display = 'block';
                document.getElementById('pageSubtitle').textContent = 'Verification under review';
            } else {
                pendingGate.style.display = 'none';
                verifyGate.style.display = 'block';
                document.getElementById('pageSubtitle').textContent = 'Verify your identity to start selling';
            }
            return;
        }
        // Verified seller
        currentMode = 'seller';
        buyerContent.style.display = 'none';
        sellerContent.style.display = 'block';
        verifyGate.style.display = 'none';
        becomeGate.style.display = 'none';
        document.getElementById('pageSubtitle').textContent = 'Manage your listings and sales';

        // Force overview tab visible — strip active from all, re-add to overview
        sellerContent.querySelectorAll('.tab-content').forEach(t => {
            t.classList.remove('active');
            t.style.display = 'none';
        });
        const overviewTab = document.getElementById('tab-seller-overview');
        if (overviewTab) {
            overviewTab.classList.add('active');
            overviewTab.style.display = 'block';
        }

        // Update sidebar nav active state
        sellerNav.querySelectorAll('.nav-item').forEach(l => l.classList.remove('active'));
        const overviewNavItem = sellerNav.querySelector('[data-tab="seller-overview"]');
        if (overviewNavItem) overviewNavItem.classList.add('active');

        if (typeof loadOverviewStats === 'function') loadOverviewStats();
        if (typeof loadSellerMessages === 'function') loadSellerMessages();
    } else {
        // Buyer mode
        currentMode = 'buyer';
        modeToggle.classList.remove('seller-mode');
        buyerLabel.classList.add('active');
        sellerLabel.classList.remove('active');
        buyerNav.style.display = 'block';
        sellerNav.style.display = 'none';
        buyerContent.style.display = 'block';
        sellerContent.style.display = 'none';
        verifyGate.style.display = 'none';
        pendingGate.style.display = 'none';
        becomeGate.style.display = 'none';
        modeBadge.textContent = 'Buyer';
        modeBadge.style.background = '#4CAF50';
        document.getElementById('pageTitle').textContent = 'My Account';
        document.getElementById('pageSubtitle').textContent = 'Manage your orders and profile';

        // Ensure buyer overview tab is visible
        buyerContent.querySelectorAll('.tab-content').forEach(t => {
            t.classList.remove('active');
            t.style.display = 'none';
        });
        const buyerOverview = document.getElementById('tab-buyer-overview');
        if (buyerOverview) {
            buyerOverview.classList.add('active');
            buyerOverview.style.display = 'block';
        }
        buyerNav.querySelectorAll('.nav-item').forEach(l => l.classList.remove('active'));
        const buyerOverviewNav = buyerNav.querySelector('[data-tab="buyer-overview"]');
        if (buyerOverviewNav) buyerOverviewNav.classList.add('active');
    }
}

// ---- TAB SWITCHING ----
document.querySelectorAll('.nav-item[data-tab]').forEach(link => {
    link.addEventListener('click', e => {
        e.preventDefault();
        const tab     = link.dataset.tab;
        const section = link.dataset.section;
        const navEl   = section === 'seller' ? sellerNav : buyerNav;

        navEl.querySelectorAll('.nav-item').forEach(l => l.classList.remove('active'));
        link.classList.add('active');

        const contentEl = section === 'seller' ? sellerContent : buyerContent;

        // Remove active + hide all tabs in this section
        contentEl.querySelectorAll('.tab-content').forEach(t => {
            t.classList.remove('active');
            t.style.display = 'none';
        });

        // Show the target tab
        const tabEl = document.getElementById('tab-' + tab);
        if (tabEl) {
            tabEl.classList.add('active');
            tabEl.style.display = 'block';
        }

        // Lazy-load data per tab
        const loaders = {
            'seller-listings': () => typeof loadSellerListings === 'function' && loadSellerListings(),
            'seller-orders':   () => typeof loadSellerOrders   === 'function' && loadSellerOrders(),
            'seller-fees':     () => typeof loadFeesTab        === 'function' && loadFeesTab(),
            'seller-earnings': () => typeof loadEarningsTab    === 'function' && loadEarningsTab(),
            'seller-messages': () => typeof loadSellerMessages === 'function' && loadSellerMessages(),
            'seller-profile':  () => { typeof loadSellerProfile  === 'function' && loadSellerProfile(); loadSellerAccountSettings(); },
            'seller-overview': () => typeof loadOverviewStats  === 'function' && loadOverviewStats(),
            'seller-reviews':  () => loadSellerReviews(),
            'buyer-orders':    () => typeof loadBuyerOrders    === 'function' && loadBuyerOrders(),
            'buyer-messages':  () => typeof loadBuyerMessages  === 'function' && loadBuyerMessages(),
            'buyer-profile':   () => typeof loadBuyerProfile   === 'function' && loadBuyerProfile(),
        };
        if (loaders[tab]) loaders[tab]();
    });
});

// ---- AUTH CHECK + INIT ----
document.addEventListener('DOMContentLoaded', async () => {
    console.log('[Dashboard] DOMContentLoaded - Loading dashboard...');
    
    // Load dashboard content immediately without waiting for auth
    loadMostAffordable();
    loadMostPopular();
    
    // Wait for auth to be ready, then initialize dashboard
    async function initDashboard() {
        if (!window.authManager?.isInitialized || !authManager.isAuthenticated?.()) {
            console.log('[Dashboard] Auth not ready or user not authenticated');
            return;
        }

        const user = authManager.getCurrentUser();
        console.log('[Dashboard] Auth ready, user:', user?.email, 'roles:', user?.roles);

        // --- Resolve seller status from DB (source of truth) ---
        // Check by user.id first, then fall back to email
        let sellerRecord = null;
        try {
            const { data: byIdArr } = await db
                .from('sellers')
                .select('id, verified, user_id')
                .eq('id', user.id)
                .limit(1);

            if (byIdArr && byIdArr.length > 0) {
                sellerRecord = byIdArr[0];
            } else {
                // Fallback: look up by email
                const { data: byEmailArr } = await db
                    .from('sellers')
                    .select('id, verified, user_id')
                    .eq('email', user.email)
                    .limit(1);
                sellerRecord = (byEmailArr && byEmailArr.length > 0) ? byEmailArr[0] : null;
            }
        } catch(e) {
            console.warn('[Dashboard] Could not query sellers table:', e.message);
        }

        // A user is a seller if: their metadata says so OR a sellers record exists for them
        userIsSeller = authManager.isSeller() || !!sellerRecord;
        sellerIsVerified = sellerRecord?.verified === true;

        // Check if verification is pending (submitted but not yet approved)
        window._verificationPending = false;
        if (userIsSeller && !sellerIsVerified) {
            try {
                const { data: verArr } = await db
                    .from('seller_verifications')
                    .select('status')
                    .eq('user_id', user.id)
                    .in('status', ['pending', 'approved'])
                    .limit(1);
                if (verArr && verArr.length > 0) {
                    window._verificationPending = verArr[0].status === 'pending';
                    // If somehow approved in verifications but not in sellers, sync it
                    if (verArr[0].status === 'approved') {
                        sellerIsVerified = true;
                    }
                }
            } catch(e) {
                console.warn('[Dashboard] Could not check verification status:', e.message);
            }
        }

        // If seller record exists but user_metadata doesn't have 'seller' role yet, sync it
        if (sellerRecord && !authManager.isSeller()) {
            console.log('[Dashboard] Seller record found but role not in metadata — syncing...');
            try {
                await authManager.addSellerRole();
                userIsSeller = true;
            } catch(e) {
                console.warn('[Dashboard] Could not sync seller role:', e.message);
                userIsSeller = true;
            }
        }

        console.log('[Dashboard] Seller status resolved:', { userIsSeller, sellerIsVerified, verificationPending: window._verificationPending });

        // Load buyer data
        if (typeof loadBuyerProfile === 'function') loadBuyerProfile();
        if (typeof loadBuyerOrders  === 'function') loadBuyerOrders();
        if (typeof loadOverviewStats === 'function' && currentMode === 'buyer') {
            // loadOverviewStats in buyer context = buyer stats
            // (seller overview stats are loaded when switching to seller mode)
        }

        // Auto-open tab from URL hash
        const hash = window.location.hash.replace('#', '');
        if (hash === 'seller') {
            // Auto-switch to seller mode (handles redirect from verification page)
            switchMode('seller');
        } else if (hash) {
            const link = document.querySelector(`.nav-item[data-tab="${hash}"]`);
            if (link) link.click();
        }
    }

    // Poll for auth readiness — check every 200ms up to 5s
    let authWaitMs = 0;
    const authPoll = setInterval(async () => {
        authWaitMs += 200;
        if (window.authManager?.isInitialized) {
            clearInterval(authPoll);
            await initDashboard();
        } else if (authWaitMs >= 5000) {
            clearInterval(authPoll);
            console.warn('[Dashboard] Auth timed out after 5s');
            await initDashboard(); // Try anyway
        }
    }, 200);
});

// ---- CHECK VERIFICATION STATUS (called from pendingGate button) ----
window.checkVerificationStatus = async function() {
    const user = window.authManager?.getCurrentUser();
    if (!user) return;

    try {
        const { data: verArr } = await db
            .from('seller_verifications')
            .select('status')
            .eq('user_id', user.id)
            .order('submitted_at', { ascending: false })
            .limit(1);

        if (verArr && verArr.length > 0) {
            const status = verArr[0].status;
            if (status === 'approved') {
                // Re-check sellers table
                const { data: sellerArr } = await db
                    .from('sellers')
                    .select('id, verified')
                    .eq('user_id', user.id)
                    .limit(1);
                if (sellerArr && sellerArr.length > 0 && sellerArr[0].verified) {
                    sellerIsVerified = true;
                    window._verificationPending = false;
                    switchMode('seller');
                    return;
                }
            } else if (status === 'rejected') {
                window._verificationPending = false;
                alert('Your verification was rejected. Please resubmit with correct documents.');
                location.href = 'seller-verification.html';
                return;
            }
        }
        // Still pending
        showSuccess('Still Under Review', 'Your verification is still being reviewed. Please check back later.', 'OK');
    } catch(e) {
        console.warn('[Dashboard] checkVerificationStatus error:', e.message);
    }
};

// ---- MOST AFFORDABLE ----
async function loadMostAffordable() {
    const el = document.getElementById('mostCheapList');
    if (!el) return;
    try {
        const { data, error } = await db
            .from('products')
            .select('id, name, price, image_url')
            .eq('status', 'approved')
            .eq('in_stock', true)
            .order('price', { ascending: true })
            .limit(6);
        if (error || !data?.length) { el.innerHTML = '<p style="color:#aaa;font-size:13px;">No products found.</p>'; return; }
        el.innerHTML = data.map(p => `
            <a href="product.html?id=${p.id}" style="text-decoration:none;display:block;">
                <div style="border-radius:10px;overflow:hidden;background:#f5f5f5;border:1px solid #eee;transition:transform .2s;" onmouseover="this.style.transform='translateY(-3px)'" onmouseout="this.style.transform='none'">
                    <img src="${p.image_url || 'https://via.placeholder.com/130'}" alt="${p.name}" style="width:100%;aspect-ratio:1;object-fit:cover;">
                    <div style="padding:8px;">
                        <p style="margin:0;font-size:12px;font-weight:600;color:#1a1a2e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${p.name}</p>
                        <p style="margin:3px 0 0;font-size:13px;font-weight:700;color:#c8a96e;">₱${parseFloat(p.price).toFixed(2)}</p>
                    </div>
                </div>
            </a>`).join('');
    } catch(e) { el.innerHTML = '<p style="color:#aaa;font-size:13px;">Could not load.</p>'; }
}

// ---- MOST POPULAR (most orders) ----
async function loadMostPopular() {
    const el = document.getElementById('mostPopularList');
    if (!el) return;
    try {
        // Get products ordered by number of orders (most purchased)
        const { data: orders } = await db
            .from('orders')
            .select('product_id')
            .not('product_id', 'is', null);

        if (!orders?.length) {
            // Fallback: just show newest approved products
            const { data } = await db.from('products').select('id, name, price, image_url').eq('status', 'approved').eq('in_stock', true).order('created_at', { ascending: false }).limit(6);
            renderPopular(el, data || []);
            return;
        }

        // Count orders per product
        const counts = {};
        orders.forEach(o => { counts[o.product_id] = (counts[o.product_id] || 0) + 1; });
        const topIds = Object.entries(counts).sort((a,b) => b[1]-a[1]).slice(0,6).map(e => e[0]);

        const { data } = await db.from('products').select('id, name, price, image_url').eq('status', 'approved').eq('in_stock', true).in('id', topIds);
        // Sort by order count
        const sorted = (data || []).sort((a,b) => (counts[b.id]||0) - (counts[a.id]||0));
        renderPopular(el, sorted);
    } catch(e) { el.innerHTML = '<p style="color:#aaa;font-size:13px;">Could not load.</p>'; }
}

function renderPopular(el, products) {
    if (!products.length) { el.innerHTML = '<p style="color:#aaa;font-size:13px;">No products found.</p>'; return; }
    el.innerHTML = products.map(p => `
        <a href="product.html?id=${p.id}" style="text-decoration:none;display:block;">
            <div style="border-radius:10px;overflow:hidden;background:#f5f5f5;border:1px solid #eee;transition:transform .2s;" onmouseover="this.style.transform='translateY(-3px)'" onmouseout="this.style.transform='none'">
                <img src="${p.image_url || 'https://via.placeholder.com/130'}" alt="${p.name}" style="width:100%;aspect-ratio:1;object-fit:cover;">
                <div style="padding:8px;">
                    <p style="margin:0;font-size:12px;font-weight:600;color:#1a1a2e;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${p.name}</p>
                    <p style="margin:3px 0 0;font-size:13px;font-weight:700;color:#c8a96e;">₱${parseFloat(p.price).toFixed(2)}</p>
                </div>
            </div>
        </a>`).join('');
}

// ---- TOGGLE EVENTS ----
// Use the visual state of the toggle (not currentMode) to determine direction
modeToggle.addEventListener('click', () => {
    const goingToSeller = !modeToggle.classList.contains('seller-mode');
    switchMode(goingToSeller ? 'seller' : 'buyer');
});
buyerLabel.addEventListener('click',  () => switchMode('buyer'));
sellerLabel.addEventListener('click', () => switchMode('seller'));

// ---- SELLER STUBS (overridden by dashboard-seller.js) ----
window.selectFeeTier   = window.selectFeeTier   || function(tier) { console.log('[dashboard] selectFeeTier stub:', tier); };
window.submitFeePayment = window.submitFeePayment || function() { console.log('[dashboard] submitFeePayment stub'); };

// ---- VIDEO CALL ENGINE ----
window.vcPeer = null;
window.vcLocalStream = null;
window.vcCurrentCall = null;
window.vcMuted = false;
window.vcCamOff = false;
window.vcPollingInterval = null;

function vcGenerateRoomId() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let id = '';
    for (let i = 0; i < 6; i++) id += chars[Math.floor(Math.random() * chars.length)];
    return id;
}

async function vcGetLocalStream() {
    window.vcLocalStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    document.getElementById('vcLocalVideo').srcObject = window.vcLocalStream;
    return window.vcLocalStream;
}

function vcSetStatus(connected, text) {
    const dot    = document.getElementById('vcDot');
    const status = document.getElementById('vcTopStatus');
    if (dot)    dot.className = 'vc-dot' + (connected ? ' connected' : '');
    if (status) status.textContent = text;
}

function vcShowOverlay(name) {
    document.getElementById('vcWaitingAvatar').textContent = name.charAt(0).toUpperCase();
    document.getElementById('vcWaitingName').textContent   = name;
    document.getElementById('vcTopName').textContent       = name;
    document.getElementById('vcOverlay').classList.add('active');
    document.getElementById('vcWaiting').style.display     = 'flex';
    document.getElementById('vcRemoteVideo').style.display = 'none';
}

function vcOnRemoteStream(stream) {
    const v = document.getElementById('vcRemoteVideo');
    v.srcObject = stream;
    v.style.display = 'block';
    document.getElementById('vcWaiting').style.display = 'none';
    vcSetStatus(true, 'Connected');
}

async function vcHangUp() {
    if (window.vcCurrentCall) { window.vcCurrentCall.close(); window.vcCurrentCall = null; }
    if (window.vcLocalStream) { window.vcLocalStream.getTracks().forEach(t => t.stop()); window.vcLocalStream = null; }
    if (window.vcPeer)        { window.vcPeer.destroy(); window.vcPeer = null; }
    if (window.vcPollingInterval) { clearInterval(window.vcPollingInterval); window.vcPollingInterval = null; }
    document.getElementById('vcOverlay').classList.remove('active');
    document.getElementById('vcIncoming').classList.remove('active');
    document.getElementById('vcLocalVideo').srcObject  = null;
    document.getElementById('vcRemoteVideo').srcObject = null;
    window.vcMuted = false; window.vcCamOff = false;
    document.getElementById('vcMicBtn').textContent = '🎤';
    document.getElementById('vcCamBtn').textContent = '📷';
}
window.vcHangUp = vcHangUp;

window.vcToggleMic = function() {
    if (!window.vcLocalStream) return;
    window.vcMuted = !window.vcMuted;
    window.vcLocalStream.getAudioTracks().forEach(t => t.enabled = !window.vcMuted);
    document.getElementById('vcMicBtn').textContent  = window.vcMuted ? '🔇' : '🎤';
    document.getElementById('vcMicBtn').className    = 'vc-btn' + (window.vcMuted ? ' off' : '');
};

window.vcToggleCam = function() {
    if (!window.vcLocalStream) return;
    window.vcCamOff = !window.vcCamOff;
    window.vcLocalStream.getVideoTracks().forEach(t => t.enabled = !window.vcCamOff);
    document.getElementById('vcCamBtn').textContent = window.vcCamOff ? '📕' : '📷';
    document.getElementById('vcCamBtn').className   = 'vc-btn' + (window.vcCamOff ? ' off' : '');
};

// Buyer starts video call
window.buyerStartVideoCall = async function() {
    const chatId = window.activeChatId;
    if (!chatId) { alert('Open a conversation first'); return; }
    const name   = document.getElementById('buyerChatName')?.textContent || 'Seller';
    const roomId = vcGenerateRoomId();
    try {
        const { data: msg } = await messagesDb.from('messages').select('thread').eq('id', chatId).single();
        const thread = Array.isArray(msg?.thread) ? msg.thread : [];
        thread.push({ role: 'buyer', text: '📹 Video call invite', ts: new Date().toISOString(), type: 'video_call', roomId });
        await messagesDb.from('messages').update({ thread }).eq('id', chatId);
    } catch(e) { console.error('[vc] invite error:', e); }
    vcShowOverlay(name);
    vcSetStatus(false, 'Waiting for ' + name + ' to join…');
    try {
        await vcGetLocalStream();
        window.vcPeer = new Peer(roomId, { debug: 1 });
        window.vcPeer.on('open', () => vcSetStatus(false, 'Waiting for ' + name + '…'));
        window.vcPeer.on('call', call => {
            window.vcCurrentCall = call;
            call.answer(window.vcLocalStream);
            call.on('stream', vcOnRemoteStream);
            call.on('close', vcHangUp);
        });
        window.vcPeer.on('error', e => { console.error('[vc]', e); vcHangUp(); });
    } catch(e) { console.error('[vc]', e); vcHangUp(); }
};

window.buyerStartVoiceCall = function() {
    alert('Voice call — coming soon!');
};

// Incoming call
window.vcShowIncoming = function(roomId, callerName) {
    document.getElementById('vcIncomingAvatar').textContent = callerName.charAt(0).toUpperCase();
    document.getElementById('vcIncomingName').textContent   = callerName;
    document.getElementById('vcIncoming').classList.add('active');
    window._vcPendingRoomId     = roomId;
    window._vcPendingCallerName = callerName;
};

window.vcAccept = async function() {
    const roomId = window._vcPendingRoomId;
    const name   = window._vcPendingCallerName || 'Caller';
    document.getElementById('vcIncoming').classList.remove('active');
    vcShowOverlay(name);
    vcSetStatus(false, 'Connecting…');
    try {
        await vcGetLocalStream();
        const joinerId = roomId + '-' + Math.random().toString(36).substring(2, 7);
        window.vcPeer = new Peer(joinerId, { debug: 1 });
        window.vcPeer.on('open', () => {
            const call = window.vcPeer.call(roomId, window.vcLocalStream);
            window.vcCurrentCall = call;
            call.on('stream', vcOnRemoteStream);
            call.on('close', vcHangUp);
        });
        window.vcPeer.on('error', e => { console.error('[vc]', e); vcHangUp(); });
    } catch(e) { vcHangUp(); }
};

window.vcDecline = function() {
    document.getElementById('vcIncoming').classList.remove('active');
};

// Poll for incoming video call invites
function vcStartPolling() {
    if (window.vcPollingInterval) return;
    let lastSeenTs = null;
    window.vcPollingInterval = setInterval(async () => {
        if (!window.activeChatId || !window.messagesDb) return;
        try {
            const { data: msg } = await messagesDb.from('messages').select('thread').eq('id', window.activeChatId).single();
            const thread = Array.isArray(msg?.thread) ? msg.thread : [];
            const invite = thread.slice().reverse().find(e =>
                e.type === 'video_call' && e.role === 'seller' && e.ts !== lastSeenTs
            );
            if (invite) {
                lastSeenTs = invite.ts;
                const sellerName = document.getElementById('buyerChatName')?.textContent || 'Seller';
                window.vcShowIncoming(invite.roomId, sellerName);
            }
        } catch(e) {}
    }, 3000);
}

// Start polling when messages tab opens
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.nav-item[data-tab]').forEach(link => {
        link.addEventListener('click', () => {
            if (link.dataset.tab === 'buyer-messages') vcStartPolling();
        });
    });
});

// Seller video call
window.startVideoCallFromChat = async function() {
    const name   = document.getElementById('sellerChatName')?.textContent || 'Buyer';
    const chatId = window.activeSellerChatId;
    const chars  = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let roomId   = '';
    for (let i = 0; i < 6; i++) roomId += chars[Math.floor(Math.random() * chars.length)];
    if (chatId && window.messagesDb) {
        try {
            const { data: msg } = await messagesDb.from('messages').select('thread').eq('id', chatId).single();
            const thread = Array.isArray(msg?.thread) ? msg.thread : [];
            thread.push({ role: 'seller', text: '📹 Video call invite', ts: new Date().toISOString(), type: 'video_call', roomId });
            await messagesDb.from('messages').update({ thread, reply: '📹 Video call invite', replied_at: new Date().toISOString() }).eq('id', chatId);
            if (window.openSellerChat) openSellerChat(chatId);
        } catch(e) { console.error('[vc] invite error:', e); }
    }
    sellerVcShowOverlay(name);
    sellerVcSetStatus(false, chatId ? ('Waiting for ' + name + '…') : ('Room: ' + roomId));
    try {
        await sellerVcGetLocalStream();
        window.sellerVcPeer = new Peer(roomId, { debug: 1 });
        window.sellerVcPeer.on('open', () => sellerVcSetStatus(false, 'Room: ' + roomId));
        window.sellerVcPeer.on('call', call => {
            window.sellerVcCurrentCall = call;
            call.answer(window.sellerVcLocalStream);
            call.on('stream', sellerVcOnRemoteStream);
            call.on('close', sellerVcHangUp);
        });
        window.sellerVcPeer.on('error', e => { console.error('[vc]', e); sellerVcHangUp(); });
    } catch(e) { console.error('[vc]', e); sellerVcHangUp(); }
};

window.startVoiceCall = function() { alert('Voice call — coming soon!'); };

// Seller VC engine
window.sellerVcPeer = null;
window.sellerVcLocalStream = null;
window.sellerVcCurrentCall = null;

async function sellerVcGetLocalStream() {
    window.sellerVcLocalStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    document.getElementById('sellerVcLocalVideo').srcObject = window.sellerVcLocalStream;
    return window.sellerVcLocalStream;
}
function sellerVcSetStatus(connected, text) {
    const dot    = document.getElementById('sellerVcDot');
    const status = document.getElementById('sellerVcTopStatus');
    if (dot)    dot.className = 'vc-dot' + (connected ? ' connected' : '');
    if (status) status.textContent = text;
}
function sellerVcShowOverlay(name) {
    document.getElementById('sellerVcWaitingAvatar').textContent = name.charAt(0).toUpperCase();
    document.getElementById('sellerVcWaitingName').textContent   = name;
    document.getElementById('sellerVcTopName').textContent       = name;
    document.getElementById('sellerVcOverlay').classList.add('active');
    document.getElementById('sellerVcWaiting').style.display     = 'flex';
    document.getElementById('sellerVcRemoteVideo').style.display = 'none';
}
function sellerVcOnRemoteStream(stream) {
    const v = document.getElementById('sellerVcRemoteVideo');
    v.srcObject = stream;
    v.style.display = 'block';
    document.getElementById('sellerVcWaiting').style.display = 'none';
    sellerVcSetStatus(true, 'Connected');
}
async function sellerVcHangUp() {
    if (window.sellerVcCurrentCall) { window.sellerVcCurrentCall.close(); window.sellerVcCurrentCall = null; }
    if (window.sellerVcLocalStream) { window.sellerVcLocalStream.getTracks().forEach(t => t.stop()); window.sellerVcLocalStream = null; }
    if (window.sellerVcPeer)        { window.sellerVcPeer.destroy(); window.sellerVcPeer = null; }
    document.getElementById('sellerVcOverlay').classList.remove('active');
    document.getElementById('sellerVcLocalVideo').srcObject  = null;
    document.getElementById('sellerVcRemoteVideo').srcObject = null;
    document.getElementById('sellerVcMicBtn').textContent = '🎤';
    document.getElementById('sellerVcCamBtn').textContent = '📷';
}
window.sellerVcHangUp = sellerVcHangUp;
window.sellerVcToggleMic = function() {
    if (!window.sellerVcLocalStream) return;
    const on = window.sellerVcLocalStream.getAudioTracks()[0]?.enabled;
    window.sellerVcLocalStream.getAudioTracks().forEach(t => t.enabled = !t.enabled);
    document.getElementById('sellerVcMicBtn').textContent = on ? '🔇' : '🎤';
    document.getElementById('sellerVcMicBtn').className   = 'vc-btn' + (on ? ' off' : '');
};
window.sellerVcToggleCam = function() {
    if (!window.sellerVcLocalStream) return;
    const on = window.sellerVcLocalStream.getVideoTracks()[0]?.enabled;
    window.sellerVcLocalStream.getVideoTracks().forEach(t => t.enabled = !t.enabled);
    document.getElementById('sellerVcCamBtn').textContent = on ? '📕' : '📷';
    document.getElementById('sellerVcCamBtn').className   = 'vc-btn' + (on ? ' off' : '');
};

console.log('[dashboard] Unified dashboard JS loaded');

// ---- MOBILE SIDEBAR TOGGLE ----
// NOTE: On mobile, hamburger now opens the nav drawer (mobileNavDrawer)
// The sidebar (.modern-sidebar) is only used on desktop
(function() {
    const menuBtn = document.getElementById('mobileMenuBtn');
    const sidebar = document.querySelector('.modern-sidebar');
    const overlay = document.getElementById('sidebarOverlay');

    // On desktop: show sidebar normally, hide hamburger
    // On mobile: hamburger opens the nav drawer (handled in inline script)
    function checkMobile() {
        if (window.innerWidth <= 767) {
            // Hide old sidebar on mobile (drawer handles navigation)
            if (sidebar) {
                sidebar.classList.remove('open');
            }
        } else {
            // Desktop: close drawer if open
            const drawer = document.getElementById('mobileNavDrawer');
            if (drawer) drawer.classList.remove('open');
            if (overlay) overlay.classList.remove('show');
        }
    }
    checkMobile();
    window.addEventListener('resize', checkMobile);

    // Close sidebar when a nav item is clicked on mobile
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', () => {
            if (window.innerWidth <= 767) {
                if (sidebar) sidebar.classList.remove('open');
                if (overlay) overlay.classList.remove('show');
            }
        });
    });
})();


// ============================================================
// MOBILE HEADER FUNCTIONALITY
// ============================================================

function initMobileHeader() {
    const mobileMessagesBtn = document.getElementById('mobileMessagesBtn');
    const mobileNotificationsBtn = document.getElementById('mobileNotificationsBtn');
    const mobileProfileBtn = document.getElementById('mobileProfileBtn');
    const messagesBadge = document.getElementById('messagesBadge');
    const notificationsBadge = document.getElementById('notificationsBadge');
    const mobileProfileAvatar = document.getElementById('mobileProfileAvatar');
    
    // Messages button click
    if (mobileMessagesBtn) {
        mobileMessagesBtn.addEventListener('click', () => {
            // Switch to messages tab
            const messagesTab = document.querySelector('[data-tab="buyer-messages"]') || 
                               document.querySelector('[data-tab="seller-messages"]');
            if (messagesTab) {
                messagesTab.click();
            }
            
            // Add active state
            mobileMessagesBtn.classList.add('active');
            setTimeout(() => mobileMessagesBtn.classList.remove('active'), 300);
        });
    }
    
    // Notifications button click
    if (mobileNotificationsBtn) {
        mobileNotificationsBtn.addEventListener('click', () => {
            // Show notifications panel - navigate to notifications tab if available
            const notificationsTab = document.querySelector('[data-tab="buyer-notifications"]') || 
                                    document.querySelector('[data-tab="seller-notifications"]');
            if (notificationsTab) {
                notificationsTab.click();
            } else {
                // Fallback: show message
                showError('Notifications', 'Notifications panel is not available on this page.');
            }
            
            // Add active state
            mobileNotificationsBtn.classList.add('active');
            setTimeout(() => mobileNotificationsBtn.classList.remove('active'), 300);
        });
    }
    
    // Profile button click
    if (mobileProfileBtn) {
        mobileProfileBtn.addEventListener('click', () => {
            // Switch to profile tab
            const profileTab = document.querySelector('[data-tab="buyer-profile"]') || 
                              document.querySelector('[data-tab="seller-profile"]');
            if (profileTab) {
                profileTab.click();
            }
            
            // Add active state
            mobileProfileBtn.classList.add('active');
            setTimeout(() => mobileProfileBtn.classList.remove('active'), 300);
        });
    }
    
    // Update notification badges
    async function updateNotificationBadges() {
        if (!window.authManager) return;
        
        const user = window.authManager.getCurrentUser();
        if (!user) return;
        
        try {
            // Get unread messages count
            const { data: messages, error: msgErr } = await window.db
                .from('messages')
                .select('id')
                .eq('seller_id', user.id)
                .eq('read', false);
            
            const unreadMessages = msgErr ? 0 : (messages?.length || 0);
            if (messagesBadge && unreadMessages > 0) {
                messagesBadge.textContent = unreadMessages > 99 ? '99+' : unreadMessages;
                messagesBadge.style.display = 'block';
            } else if (messagesBadge) {
                messagesBadge.style.display = 'none';
            }
            
            // Get unread notifications count
            const { data: notifs, error: notifErr } = await window.db
                .from('notifications')
                .select('id')
                .eq('user_id', user.id)
                .eq('read', false);
            
            const unreadNotifications = notifErr ? 0 : (notifs?.length || 0);
            if (notificationsBadge && unreadNotifications > 0) {
                notificationsBadge.textContent = unreadNotifications > 99 ? '99+' : unreadNotifications;
                notificationsBadge.style.display = 'block';
            } else if (notificationsBadge) {
                notificationsBadge.style.display = 'none';
            }
        } catch (err) {
            console.error('[updateNotificationBadges]', err);
        }
    }
    
    // Update profile avatar
    function updateProfileAvatar() {
        if (!window.authManager || !mobileProfileAvatar) return;
        
        const user = window.authManager.getCurrentUser();
        if (user && user.avatar_url) {
            mobileProfileAvatar.innerHTML = `<img src="${user.avatar_url}" alt="Profile">`;
        } else if (user && user.name) {
            // Show initials
            const initials = user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
            mobileProfileAvatar.innerHTML = `<span style="font-size:14px;font-weight:700;">${initials}</span>`;
        }
    }
    
    // Initialize
    updateNotificationBadges();
    updateProfileAvatar();
    
    // Update periodically
    setInterval(updateNotificationBadges, 30000); // Every 30 seconds
}

// Initialize mobile header when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initMobileHeader);
} else {
    initMobileHeader();
}

// ---- GCash QR Code Uploader ----
class QRCodeUploader {
  constructor() {
    this.qrImage = null;
    this.init();
  }

  init() {
    const dropzone  = document.getElementById('qrDropzone');
    const input     = document.getElementById('qrInput');
    const removeBtn = document.getElementById('qrRemove');

    if (!dropzone || !input) return;

    dropzone.addEventListener('click', () => input.click());

    input.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) this.handleFile(file);
    });

    dropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropzone.classList.add('drag-over');
    });

    dropzone.addEventListener('dragleave', () => {
      dropzone.classList.remove('drag-over');
    });

    dropzone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropzone.classList.remove('drag-over');
      const file = e.dataTransfer.files[0];
      if (file) this.handleFile(file);
    });

    if (removeBtn) {
      removeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.removeQR();
      });
    }
  }

  handleFile(file) {
    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file');
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      alert('File size must be less than 2MB');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      this.qrImage = { file, url: e.target.result };
      this.showPreview();
    };
    reader.readAsDataURL(file);
  }

  showPreview() {
    const dropzone = document.getElementById('qrDropzone');
    const preview  = document.getElementById('qrPreview');
    const img      = document.getElementById('qrImage');
    if (dropzone && preview && img) {
      dropzone.style.display = 'none';
      preview.style.display  = 'block';
      img.src = this.qrImage.url;
    }
  }

  removeQR() {
    const dropzone = document.getElementById('qrDropzone');
    const preview  = document.getElementById('qrPreview');
    const input    = document.getElementById('qrInput');
    if (dropzone && preview) {
      dropzone.style.display = 'block';
      preview.style.display  = 'none';
    }
    if (input) input.value = '';
    this.qrImage = null;
  }

  getQRImage() { return this.qrImage; }
}

// Init QR uploader + description char counter on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  window.qrUploader = new QRCodeUploader();

  const descTextarea = document.getElementById('newDescription');
  const charCount    = document.getElementById('descCharCount');
  if (descTextarea && charCount) {
    descTextarea.addEventListener('input', () => {
      const count = descTextarea.value.length;
      charCount.textContent = count;
      charCount.style.color = count > 500 ? '#EF4444' : '';
    });
  }
});

// ============================================================
// PRODUCT PREVIEW MODAL (buyer orders)
// ============================================================
window.openOrderProductPreview = function(orderId, productName, productImage, price, size, status) {
  document.getElementById('orderProductOverlay')?.remove();

  const overlay = document.createElement('div');
  overlay.id = 'orderProductOverlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;';

  const canReview = status === 'received';

  overlay.innerHTML = `
    <div style="background:#fff;border-radius:20px;max-width:460px;width:100%;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.3);animation:rwPopIn .22s ease;">
      ${productImage
        ? `<img src="${productImage}" alt="${productName}" style="width:100%;height:220px;object-fit:cover;">`
        : `<div style="width:100%;height:180px;background:linear-gradient(135deg,#1a1a2e,#2d2520);display:flex;align-items:center;justify-content:center;font-size:64px;">👕</div>`}
      <div style="padding:22px;">
        <h2 style="margin:0 0 6px;font-size:20px;font-weight:800;">${productName}</h2>
        <p style="font-size:22px;font-weight:800;color:#c8a96e;margin:0 0 10px;">${price}</p>
        ${size ? `<span style="background:#f5f5f5;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">Size: ${size}</span>` : ''}
        <div style="display:flex;gap:10px;margin-top:18px;">
          <button onclick="document.getElementById('orderProductOverlay').remove()"
            style="flex:1;padding:12px;background:#f5f5f5;color:#333;border:none;border-radius:10px;font-size:14px;font-weight:600;cursor:pointer;">
            Close
          </button>
          ${canReview ? `
          <button onclick="document.getElementById('orderProductOverlay').remove(); openBuyerReviewModal('${orderId}','${productName.replace(/'/g,"\\'")}','','${productImage.replace(/'/g,"\\'")}');"
            style="flex:1;padding:12px;background:linear-gradient(135deg,#c8a96e,#e0c080);color:#fff;border:none;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(200,169,110,.4);">
            ⭐ Write a Review
          </button>` : ''}
        </div>
      </div>
    </div>`;

  document.body.appendChild(overlay);
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
};

// ============================================================
// BUYER REVIEW MODAL — promo style with photo upload
// ============================================================
window.openBuyerReviewModal = function(orderId, productName, productId, productImage) {
  document.getElementById('buyerReviewOverlay')?.remove();

  const overlay = document.createElement('div');
  overlay.id = 'buyerReviewOverlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;';

  overlay.innerHTML = `
    <div style="background:#fff;border-radius:20px;max-width:440px;width:100%;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.35);animation:rwPopIn .22s ease;">
      <!-- Hero -->
      <div style="background:linear-gradient(135deg,#1a1a2e,#2d2520);padding:24px;text-align:center;">
        ${productImage
          ? `<img src="${productImage}" alt="${productName}" style="width:90px;height:90px;border-radius:12px;object-fit:cover;border:3px solid #c8a96e;margin-bottom:12px;">`
          : `<div style="width:90px;height:90px;border-radius:12px;background:#c8a96e;display:inline-flex;align-items:center;justify-content:center;font-size:36px;margin-bottom:12px;">👕</div>`}
        <h2 style="color:#fff;font-size:20px;margin:0 0 4px;">Share your experience!</h2>
        <p style="color:rgba(255,255,255,.6);font-size:13px;margin:0;">${productName} · Help other buyers decide</p>
      </div>
      <!-- Body -->
      <div style="padding:24px;">
        <!-- Stars -->
        <div style="text-align:center;margin-bottom:16px;">
          <div id="rwStarRow" style="display:inline-flex;gap:6px;font-size:38px;cursor:pointer;">
            <span data-v="1" style="color:#ddd;transition:color .1s;user-select:none;">★</span>
            <span data-v="2" style="color:#ddd;transition:color .1s;user-select:none;">★</span>
            <span data-v="3" style="color:#ddd;transition:color .1s;user-select:none;">★</span>
            <span data-v="4" style="color:#ddd;transition:color .1s;user-select:none;">★</span>
            <span data-v="5" style="color:#ddd;transition:color .1s;user-select:none;">★</span>
          </div>
          <input type="hidden" id="rwSelectedRating" value="0">
        </div>
        <!-- Comment -->
        <textarea id="rwComment" rows="3" placeholder="What did you think? (optional)"
          style="width:100%;padding:12px;border:1px solid #ddd;border-radius:10px;font-size:14px;resize:vertical;font-family:inherit;box-sizing:border-box;margin-bottom:14px;"></textarea>
        <!-- Photo upload -->
        <label for="rwPhotoInput" style="display:flex;align-items:center;gap:8px;padding:10px 14px;border:2px dashed #ddd;border-radius:10px;cursor:pointer;font-size:13px;color:#888;margin-bottom:14px;transition:border-color .2s;"
          onmouseover="this.style.borderColor='#c8a96e';this.style.color='#c8a96e';"
          onmouseout="this.style.borderColor='#ddd';this.style.color='#888';">
          📷 Add a photo <span style="font-size:11px;margin-left:4px;">(optional)</span>
        </label>
        <input type="file" id="rwPhotoInput" accept="image/*" style="display:none;" onchange="rwPreviewPhoto(this)">
        <img id="rwPhotoPreview" src="" alt="Preview" style="display:none;width:90px;height:90px;border-radius:10px;object-fit:cover;border:2px solid #c8a96e;margin-bottom:14px;">
        <!-- Submit -->
        <button onclick="submitBuyerReview('${orderId}','${productId}')"
          style="width:100%;padding:14px;background:linear-gradient(135deg,#c8a96e,#e0c080);color:#fff;border:none;border-radius:10px;font-size:16px;font-weight:700;cursor:pointer;margin-bottom:10px;box-shadow:0 4px 14px rgba(200,169,110,.4);">
          Submit Review ⭐
        </button>
        <div style="text-align:center;">
          <span onclick="document.getElementById('buyerReviewOverlay').remove()"
            style="color:#aaa;font-size:13px;cursor:pointer;text-decoration:underline;">Maybe Later</span>
        </div>
      </div>
    </div>`;

  document.body.appendChild(overlay);
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });

  // Star picker
  let rwSelected = 0;
  const stars = overlay.querySelectorAll('#rwStarRow span');
  stars.forEach(s => {
    s.addEventListener('mouseover', () => {
      const v = +s.dataset.v;
      stars.forEach((x, i) => x.style.color = i < v ? '#c8a96e' : '#ddd');
    });
    s.addEventListener('click', () => {
      rwSelected = +s.dataset.v;
      document.getElementById('rwSelectedRating').value = rwSelected;
      stars.forEach((x, i) => x.style.color = i < rwSelected ? '#c8a96e' : '#ddd');
    });
  });
  overlay.querySelector('#rwStarRow').addEventListener('mouseleave', () => {
    stars.forEach((x, i) => x.style.color = i < rwSelected ? '#c8a96e' : '#ddd');
  });
};

window.rwPreviewPhoto = function(input) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    const img = document.getElementById('rwPhotoPreview');
    img.src = e.target.result;
    img.style.display = 'block';
  };
  reader.readAsDataURL(file);
};

window.submitBuyerReview = async function(orderId, productId) {
  const rating  = parseInt(document.getElementById('rwSelectedRating')?.value || '0');
  const comment = document.getElementById('rwComment')?.value.trim();
  const photoInput = document.getElementById('rwPhotoInput');
  const user = window.authManager?.getCurrentUser();

  if (!rating) { alert('Please select a star rating.'); return; }
  if (!user)   { alert('Please log in to leave a review.'); return; }

  // Verify order is eligible
  const { data: order, error: orderErr } = await window.db
    .from('orders')
    .select('id, status, seller_id, buyer_email')
    .eq('id', orderId)
    .eq('buyer_email', user.email)
    .eq('status', 'received')
    .single();

  if (orderErr || !order) {
    alert('This order is not eligible for a review.');
    return;
  }

  // Check not already reviewed
  const { data: existing } = await window.db
    .from('reviews').select('id').eq('order_id', orderId).single();
  if (existing) {
    alert('You have already reviewed this order.');
    document.getElementById('buyerReviewOverlay')?.remove();
    return;
  }

  // Upload photo if provided
  let photoUrl = null;
  const photoFile = photoInput?.files[0];
  if (photoFile && window.uploadToCloudinary) {
    try {
      photoUrl = await window.uploadToCloudinary(photoFile);
    } catch(e) {
      console.warn('[review] photo upload failed:', e.message);
    }
  }

  try {
    const { error } = await window.db.from('reviews').insert({
      order_id:    orderId,
      product_id:  productId || null,
      seller_id:   order.seller_id || null,
      buyer_email: user.email,
      rating,
      comment:     comment || null,
      photo_url:   photoUrl
    });
    if (error) throw error;

    document.getElementById('buyerReviewOverlay')?.remove();

    // Show promo-style success toast
    const toast = document.createElement('div');
    toast.style.cssText = 'position:fixed;bottom:30px;left:50%;transform:translateX(-50%);background:#1a1a2e;color:#fff;padding:16px 28px;border-radius:14px;font-size:14px;font-weight:600;z-index:99999;box-shadow:0 8px 24px rgba(0,0,0,.3);display:flex;align-items:center;gap:10px;';
    toast.innerHTML = '<span style="font-size:22px;">⭐</span> Review submitted! Thank you for helping other buyers.';
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);

    // Refresh pending reviews if on profile tab
    if (typeof loadPendingReviews === 'function') loadPendingReviews();
    if (typeof loadFeedback === 'function') loadFeedback();
  } catch(err) {
    console.error('[review]', err);
    alert('Could not submit review. Please try again.');
  }
};

// ============================================================
// SELLER REVIEWS TAB
// ============================================================
window.filterSellerReviews = function(type, btn) {
  document.querySelectorAll('.fb-filter-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  document.querySelectorAll('.seller-review-card').forEach(card => {
    card.style.display = (type === 'all' || card.dataset.type === type) ? 'block' : 'none';
  });
};

async function loadSellerReviews() {
  const list  = document.getElementById('sellerReviewsList');
  const empty = document.getElementById('sellerReviewsEmpty');
  if (!list) return;

  const sellerId = await getSellerIdForCurrentUser();
  if (!sellerId) return;

  list.querySelectorAll('.seller-review-card').forEach(c => c.remove());

  try {
    const { data: reviews, error } = await window.db
      .from('reviews')
      .select('id, rating, comment, photo_url, created_at, buyer_email, products(name, image_url)')
      .eq('seller_id', sellerId)
      .order('created_at', { ascending: false });

    if (error) throw error;

    if (!reviews || reviews.length === 0) {
      if (empty) empty.style.display = 'block';
      // Update badge
      const badge = document.getElementById('sellerReviewsCount');
      if (badge) badge.style.display = 'none';
      return;
    }

    if (empty) empty.style.display = 'none';

    // Update badge
    const badge = document.getElementById('sellerReviewsCount');
    if (badge) { badge.textContent = reviews.length; badge.style.display = 'inline-block'; }

    reviews.forEach(r => {
      const stars = '★'.repeat(r.rating) + '☆'.repeat(5 - r.rating);
      const type  = r.rating >= 3 ? 'positive' : 'negative';
      const maskedEmail = r.buyer_email.replace(/(.{2}).*(@.*)/, '$1***$2');
      const initial = r.buyer_email[0].toUpperCase();
      const avatarBg = type === 'positive' ? '#c8a96e' : '#e74c3c';
      const productName = r.products?.name || '—';
      const date = new Date(r.created_at).toLocaleDateString('en-PH', { year:'numeric', month:'short', day:'numeric' });

      const card = document.createElement('div');
      card.className = 'seller-review-card';
      card.dataset.type = type;
      card.style.cssText = 'background:#fff;border-radius:14px;box-shadow:0 2px 12px rgba(0,0,0,.07);padding:18px;margin-bottom:14px;border:1px solid #f0f0f0;';
      card.innerHTML = `
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">
          <div style="width:42px;height:42px;border-radius:50%;background:${avatarBg};color:#fff;font-size:16px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0;">${initial}</div>
          <div style="flex:1;">
            <div style="font-weight:700;font-size:14px;">${maskedEmail}</div>
            <div style="font-size:12px;color:#888;">on: ${productName}</div>
          </div>
          <div style="font-size:12px;color:#bbb;">${date}</div>
        </div>
        <div style="display:inline-block;background:#fdf8f0;color:#c8a96e;border:1px solid #e8d5b0;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:600;margin-bottom:8px;">${productName}</div>
        <div style="color:#c8a96e;font-size:20px;margin-bottom:8px;letter-spacing:2px;">${stars}</div>
        ${r.comment ? `<p style="margin:0 0 10px;font-size:14px;color:#444;line-height:1.5;">"${r.comment}"</p>` : ''}
        ${r.photo_url ? `<img src="${r.photo_url}" alt="Review photo" style="width:100px;height:100px;border-radius:10px;object-fit:cover;border:2px solid #eee;cursor:pointer;" onclick="window.open('${r.photo_url}','_blank')">` : ''}`;
      list.appendChild(card);
    });

  } catch(e) {
    console.warn('[sellerReviews] Could not load:', e.message);
    if (empty) { empty.style.display = 'block'; empty.querySelector('p').textContent = 'Could not load reviews.'; }
  }
}

// ============================================================
// SELLER ACCOUNT SETTINGS (profile pic + name/email/phone)
// ============================================================
window.previewSellerProfilePic = function(input) {
  if (!input.files || !input.files[0]) return;
  const file = input.files[0];
  if (file.size > 10 * 1024 * 1024) { alert('File too large. Max 10MB.'); return; }
  const reader = new FileReader();
  reader.onload = e => {
    const preview = document.getElementById('sellerProfilePicPreview');
    const placeholder = document.getElementById('sellerProfilePicPlaceholder');
    if (preview) { preview.src = e.target.result; preview.style.display = 'block'; }
    if (placeholder) placeholder.style.display = 'none';
  };
  reader.readAsDataURL(file);
};

window.toggleSellerField = function(fieldId) {
  const input = document.getElementById(fieldId);
  if (!input) return;
  if (input.hasAttribute('readonly')) {
    input.removeAttribute('readonly');
    input.focus();
    input.style.borderColor = '#c8a96e';
    const saveRow = document.getElementById('sellerAcctSaveRow');
    if (saveRow) saveRow.style.display = 'flex';
  } else {
    input.setAttribute('readonly', true);
    input.style.borderColor = '';
  }
};

window.saveSellerAccountSettings = async function() {
  const name  = document.getElementById('sellerAcctName')?.value.trim();
  const phone = document.getElementById('sellerAcctPhone')?.value.trim();
  if (!name) { alert('Business name cannot be empty.'); return; }

  const sellerId = await getSellerIdForCurrentUser();
  if (sellerId && window.db) {
    try {
      await window.db.from('sellers').update({ business_name: name, phone }).eq('id', sellerId);
    } catch(e) { console.warn('[sellerAcct] save failed:', e.message); }
  }

  ['sellerAcctName','sellerAcctPhone'].forEach(id => {
    const el = document.getElementById(id);
    if (el) { el.setAttribute('readonly', true); el.style.borderColor = ''; }
  });
  const saveRow = document.getElementById('sellerAcctSaveRow');
  if (saveRow) saveRow.style.display = 'none';
  showSuccess('Saved!', 'Account settings updated.', 'Got it');
};

window.cancelSellerAccountEdit = function() {
  ['sellerAcctName','sellerAcctEmail','sellerAcctPhone'].forEach(id => {
    const el = document.getElementById(id);
    if (el) { el.setAttribute('readonly', true); el.style.borderColor = ''; }
  });
  const saveRow = document.getElementById('sellerAcctSaveRow');
  if (saveRow) saveRow.style.display = 'none';
};

// Populate seller account settings fields when profile tab opens
async function loadSellerAccountSettings() {
  const user = window.authManager?.getCurrentUser();
  if (!user) return;
  const sellerId = await getSellerIdForCurrentUser();

  const nameEl  = document.getElementById('sellerAcctName');
  const emailEl = document.getElementById('sellerAcctEmail');
  const phoneEl = document.getElementById('sellerAcctPhone');

  if (emailEl) emailEl.value = user.email || '';

  if (sellerId && window.db) {
    try {
      const { data } = await window.db
        .from('sellers').select('business_name, phone').eq('id', sellerId).single();
      if (data) {
        if (nameEl)  nameEl.value  = data.business_name || user.name || '';
        if (phoneEl) phoneEl.value = data.phone || '';
      }
    } catch(e) { /* fallback to user data */
      if (nameEl) nameEl.value = user.name || '';
    }
  } else {
    if (nameEl) nameEl.value = user.name || '';
  }
}

// Add pop-in animation keyframe once
(function() {
  if (!document.getElementById('rwAnimStyle')) {
    const s = document.createElement('style');
    s.id = 'rwAnimStyle';
    s.textContent = '@keyframes rwPopIn{from{transform:scale(.9);opacity:0}to{transform:scale(1);opacity:1}}';
    document.head.appendChild(s);
  }
})();


// ============================================================
// UPDATE BUYER ORDERS BADGE
// ============================================================

async function updateBuyerOrdersBadge() {
  const currentUser = authManager?.getCurrentUser();
  if (!currentUser) return;

  try {
    // Count total orders for this buyer
    const { count: totalOrders } = await db
      .from('orders')
      .select('*', { count: 'exact', head: true })
      .eq('buyer_email', currentUser.email);

    // Update badge
    const badge = document.getElementById('buyerOrdersCount');
    if (badge) {
      if (totalOrders > 0) {
        badge.textContent = totalOrders > 99 ? '99+' : totalOrders;
        badge.style.display = 'inline-block';
      } else {
        badge.style.display = 'none';
      }
    }

    console.log('[dashboard] Buyer orders badge updated:', totalOrders);
  } catch (error) {
    console.error('[dashboard] updateBuyerOrdersBadge:', error);
  }
}

// Call this after loading buyer orders
document.addEventListener('DOMContentLoaded', () => {
  // Update badge when page loads
  setTimeout(() => {
    if (typeof updateBuyerOrdersBadge === 'function') {
      updateBuyerOrdersBadge();
    }
  }, 500);
});

// Also update badge when orders tab is clicked
document.addEventListener('click', (e) => {
  if (e.target?.closest('[data-tab="buyer-orders"]')) {
    setTimeout(() => {
      if (typeof updateBuyerOrdersBadge === 'function') {
        updateBuyerOrdersBadge();
      }
    }, 100);
  }
});


// ============================================================
// ORDER DETAILS MODAL FUNCTION - ADDED TO DASHBOARD.JS
// ============================================================

async function openOrderDetailsModal(orderId) {
  console.log('[orderDetailsModal] ✅ FUNCTION CALLED from dashboard.js with orderId:', orderId);
  
  const modal = document.getElementById('orderDetailsModal');
  const content = document.getElementById('orderDetailsContent');
  
  if (!modal || !content) {
    console.error('[orderDetailsModal] ❌ Modal or content element not found');
    return;
  }
  
  content.innerHTML = '<p style="text-align:center;color:#999;">Loading order details...</p>';
  modal.style.display = 'block';
  
  try {
    const { data: order, error } = await db
      .from('orders')
      .select('*, products(id, name, image_url)')
      .eq('id', orderId)
      .single();
    
    if (error || !order) {
      console.error('[orderDetailsModal] Error loading order:', error);
      content.innerHTML = '<p style="color:#e74c3c;">Could not load order details.</p>';
      return;
    }
    
    const product = order.products;
    const lsTracking = JSON.parse(localStorage.getItem(`rewear_tracking_${order.id}`) || '{}');
    const courierName = order.courier_name || lsTracking.courier_name || null;
    const trackingNumber = order.tracking_number || lsTracking.tracking_number || null;
    
    const paymentBadge = {
      pending:   '<span style="background:#fff3cd;color:#856404;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">⏳ Awaiting Payment</span>',
      submitted: '<span style="background:#cce5ff;color:#004085;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">📤 Payment Submitted</span>',
      verified:  '<span style="background:#d4edda;color:#155724;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">✅ Payment Verified</span>',
      rejected:  '<span style="background:#f8d7da;color:#721c24;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;">❌ Payment Rejected</span>'
    }[order.payment_status || 'pending'] || '';
    
    let html = `
      <div style="margin-bottom:20px;">
        <h3 style="margin:0 0 12px;font-size:16px;font-weight:700;">Order ${order.id.slice(0, 8).toUpperCase()}</h3>
        <p style="margin:0;color:#999;font-size:13px;">Placed on ${new Date(order.created_at).toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' })}</p>
      </div>
      
      <div style="background:#f9f9f9;border-radius:12px;padding:16px;margin-bottom:16px;">
        <div style="display:flex;gap:12px;margin-bottom:12px;">
          ${product?.image_url ? `<img src="${product.image_url}" alt="${product?.name}" style="width:80px;height:80px;object-fit:cover;border-radius:8px;">` : '<div style="width:80px;height:80px;background:#eee;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:24px;">📦</div>'}
          <div style="flex:1;">
            <h4 style="margin:0 0 4px;font-size:15px;font-weight:700;">${product?.name || 'Product'}</h4>
            <p style="margin:0 0 4px;color:#666;font-size:13px;">Size: ${order.size_selected || '—'}</p>
            <p style="margin:0;color:#666;font-size:13px;">Quantity: ${order.quantity || 1}</p>
          </div>
        </div>
        <div style="border-top:1px solid #e0e0e0;padding-top:12px;text-align:right;">
          <p style="margin:0;font-size:14px;font-weight:700;color:#1a1a2e;">Total: ₱${parseFloat(order.total_price || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
        </div>
      </div>
      
      <div style="background:#f9f9f9;border-radius:12px;padding:16px;margin-bottom:16px;">
        <h4 style="margin:0 0 12px;font-size:14px;font-weight:700;">Order Information</h4>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:13px;">
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Status</p>
            <p style="margin:0;color:#1a1a2e;font-weight:600;">${order.status.replace(/_/g, ' ').toUpperCase()}</p>
          </div>
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Payment</p>
            <p style="margin:0;">${paymentBadge}</p>
          </div>
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Buyer Name</p>
            <p style="margin:0;color:#1a1a2e;">${order.buyer_name || '—'}</p>
          </div>
          <div>
            <p style="margin:0 0 4px;color:#999;font-weight:600;">Buyer Email</p>
            <p style="margin:0;color:#1a1a2e;font-size:12px;">${order.buyer_email || '—'}</p>
          </div>
        </div>
        
        ${order.delivery_address ? `
        <div style="margin-top:12px;padding-top:12px;border-top:1px solid #e0e0e0;">
          <p style="margin:0 0 4px;color:#999;font-weight:600;font-size:13px;">Delivery Address</p>
          <p style="margin:0;color:#1a1a2e;font-size:13px;">${order.delivery_address}</p>
        </div>` : ''}
        
        ${order.payment_reference ? `
        <div style="margin-top:12px;padding-top:12px;border-top:1px solid #e0e0e0;">
          <p style="margin:0 0 4px;color:#999;font-weight:600;font-size:13px;">Payment Reference</p>
          <p style="margin:0;color:#c8a96e;font-weight:700;font-size:13px;">${order.payment_reference}</p>
        </div>` : ''}
      </div>
      
      ${courierName || trackingNumber ? `
      <div style="background:#f0f9f0;border-radius:12px;padding:16px;margin-bottom:16px;">
        <h4 style="margin:0 0 12px;font-size:14px;font-weight:700;">📦 Tracking Information</h4>
        <div style="font-size:13px;">
          ${courierName ? `<p style="margin:0 0 8px;"><strong>Courier:</strong> ${courierName}</p>` : ''}
          ${trackingNumber ? `<p style="margin:0;"><strong>Tracking #:</strong> <span style="color:#c8a96e;font-weight:700;">${trackingNumber}</span></p>` : ''}
        </div>
      </div>` : ''}
    `;
    
    content.innerHTML = html;
    console.log('[orderDetailsModal] ✅ Modal content updated successfully');
    
  } catch (error) {
    console.error('[orderDetailsModal] ❌ Error:', error);
    content.innerHTML = '<p style="color:#e74c3c;">Error loading order details. Please try again.</p>';
  }
}

function closeOrderDetailsModal() {
  console.log('[orderDetailsModal] Closing modal');
  const modal = document.getElementById('orderDetailsModal');
  if (modal) modal.style.display = 'none';
}
