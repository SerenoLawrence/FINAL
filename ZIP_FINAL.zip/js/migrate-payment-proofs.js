// ============================================================
// migrate-payment-proofs.js — Migrate base64 payment proofs to Storage
// Requirement 1.6.6: Migrate Existing Payment Proofs
// ============================================================

/**
 * Migration script to convert base64 data URLs to Supabase Storage files
 * Run this script once after setting up Supabase Storage
 */

const PaymentProofMigration = {
  /**
   * Migrate all payment proofs from base64 to Storage
   * @returns {Promise<{success: boolean, migrated: number, failed: number, errors: Array}>}
   */
  async migrateAll() {
    console.log('[migration] Starting payment proof migration...');
    
    const results = {
      success: true,
      migrated: 0,
      failed: 0,
      errors: []
    };

    try {
      // Migrate listing fees
      const listingFeesResult = await this.migrateListingFees();
      results.migrated += listingFeesResult.migrated;
      results.failed += listingFeesResult.failed;
      results.errors.push(...listingFeesResult.errors);

      // Migrate orders
      const ordersResult = await this.migrateOrders();
      results.migrated += ordersResult.migrated;
      results.failed += ordersResult.failed;
      results.errors.push(...ordersResult.errors);

      console.log('[migration] Migration complete:', results);
      
      return results;

    } catch (error) {
      console.error('[migration] Migration failed:', error);
      results.success = false;
      results.errors.push({ type: 'general', error: error.message });
      return results;
    }
  },

  /**
   * Migrate listing fee payment proofs
   * @returns {Promise<{migrated: number, failed: number, errors: Array}>}
   */
  async migrateListingFees() {
    console.log('[migration] Migrating listing fee payment proofs...');
    
    const results = {
      migrated: 0,
      failed: 0,
      errors: []
    };

    try {
      // Get all listing fees with base64 data URLs
      const { data: fees, error } = await db
        .from('listing_fees')
        .select('id, seller_id, payment_proof_url')
        .like('payment_proof_url', 'data:image%');

      if (error) {
        console.error('[migration] Error fetching listing fees:', error);
        results.errors.push({ type: 'fetch', table: 'listing_fees', error: error.message });
        return results;
      }

      if (!fees || fees.length === 0) {
        console.log('[migration] No listing fees to migrate');
        return results;
      }

      console.log(`[migration] Found ${fees.length} listing fees to migrate`);

      // Migrate each fee
      for (const fee of fees) {
        try {
          const result = await this.migrateRecord(
            fee.id,
            fee.seller_id,
            fee.payment_proof_url,
            'listing_fees',
            'listing_fee'
          );

          if (result.success) {
            results.migrated++;
          } else {
            results.failed++;
            results.errors.push({
              type: 'migrate',
              table: 'listing_fees',
              id: fee.id,
              error: result.error
            });
          }
        } catch (error) {
          results.failed++;
          results.errors.push({
            type: 'migrate',
            table: 'listing_fees',
            id: fee.id,
            error: error.message
          });
        }
      }

      console.log(`[migration] Listing fees migration: ${results.migrated} migrated, ${results.failed} failed`);
      
      return results;

    } catch (error) {
      console.error('[migration] Listing fees migration error:', error);
      results.errors.push({ type: 'general', table: 'listing_fees', error: error.message });
      return results;
    }
  },

  /**
   * Migrate order payment proofs
   * @returns {Promise<{migrated: number, failed: number, errors: Array}>}
   */
  async migrateOrders() {
    console.log('[migration] Migrating order payment proofs...');
    
    const results = {
      migrated: 0,
      failed: 0,
      errors: []
    };

    try {
      // Get all orders with base64 data URLs
      const { data: orders, error } = await db
        .from('orders')
        .select('id, buyer_id, payment_proof_url')
        .like('payment_proof_url', 'data:image%');

      if (error) {
        console.error('[migration] Error fetching orders:', error);
        results.errors.push({ type: 'fetch', table: 'orders', error: error.message });
        return results;
      }

      if (!orders || orders.length === 0) {
        console.log('[migration] No orders to migrate');
        return results;
      }

      console.log(`[migration] Found ${orders.length} orders to migrate`);

      // Migrate each order
      for (const order of orders) {
        try {
          const result = await this.migrateRecord(
            order.id,
            order.buyer_id,
            order.payment_proof_url,
            'orders',
            'order'
          );

          if (result.success) {
            results.migrated++;
          } else {
            results.failed++;
            results.errors.push({
              type: 'migrate',
              table: 'orders',
              id: order.id,
              error: result.error
            });
          }
        } catch (error) {
          results.failed++;
          results.errors.push({
            type: 'migrate',
            table: 'orders',
            id: order.id,
            error: error.message
          });
        }
      }

      console.log(`[migration] Orders migration: ${results.migrated} migrated, ${results.failed} failed`);
      
      return results;

    } catch (error) {
      console.error('[migration] Orders migration error:', error);
      results.errors.push({ type: 'general', table: 'orders', error: error.message });
      return results;
    }
  },

  /**
   * Migrate a single record
   * @param {string} recordId - Record ID
   * @param {string} userId - User ID
   * @param {string} base64Url - Base64 data URL
   * @param {string} tableName - Table name ('listing_fees' or 'orders')
   * @param {string} type - Type for filename ('listing_fee' or 'order')
   * @returns {Promise<{success: boolean, url: string|null, error: string|null}>}
   */
  async migrateRecord(recordId, userId, base64Url, tableName, type) {
    try {
      console.log(`[migration] Migrating ${tableName} record ${recordId}...`);

      // Convert base64 to blob
      const blob = await this.base64ToBlob(base64Url);
      if (!blob) {
        return { success: false, url: null, error: 'Failed to convert base64 to blob' };
      }

      // Create File object
      const file = new File([blob], `payment_proof.${blob.type.split('/')[1]}`, {
        type: blob.type
      });

      // Upload to Storage
      const uploadResult = await FileUpload.uploadPaymentProof(file, userId, type);
      
      if (!uploadResult.success) {
        return { success: false, url: null, error: uploadResult.error };
      }

      // Update database record
      const { error: updateError } = await db
        .from(tableName)
        .update({ payment_proof_url: uploadResult.url })
        .eq('id', recordId);

      if (updateError) {
        // Try to delete uploaded file since DB update failed
        await FileUpload.deletePaymentProof(uploadResult.url);
        return { success: false, url: null, error: updateError.message };
      }

      console.log(`[migration] Successfully migrated ${tableName} record ${recordId}`);
      
      return { success: true, url: uploadResult.url, error: null };

    } catch (error) {
      console.error(`[migration] Error migrating ${tableName} record ${recordId}:`, error);
      return { success: false, url: null, error: error.message };
    }
  },

  /**
   * Convert base64 data URL to Blob
   * @param {string} dataUrl - Base64 data URL
   * @returns {Promise<Blob|null>}
   */
  async base64ToBlob(dataUrl) {
    try {
      // Extract base64 data and mime type
      const matches = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
      if (!matches || matches.length !== 3) {
        console.error('[migration] Invalid data URL format');
        return null;
      }

      const mimeType = matches[1];
      const base64Data = matches[2];

      // Convert base64 to binary
      const binaryString = atob(base64Data);
      const bytes = new Uint8Array(binaryString.length);
      
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Create blob
      return new Blob([bytes], { type: mimeType });

    } catch (error) {
      console.error('[migration] Error converting base64 to blob:', error);
      return null;
    }
  },

  /**
   * Verify migration results
   * @returns {Promise<{base64Count: number, storageCount: number}>}
   */
  async verifyMigration() {
    try {
      // Count base64 records
      const { count: listingFeesBase64 } = await db
        .from('listing_fees')
        .select('*', { count: 'exact', head: true })
        .like('payment_proof_url', 'data:image%');

      const { count: ordersBase64 } = await db
        .from('orders')
        .select('*', { count: 'exact', head: true })
        .like('payment_proof_url', 'data:image%');

      // Count storage records
      const { count: listingFeesStorage } = await db
        .from('listing_fees')
        .select('*', { count: 'exact', head: true })
        .like('payment_proof_url', '%storage%payment-proofs%');

      const { count: ordersStorage } = await db
        .from('orders')
        .select('*', { count: 'exact', head: true })
        .like('payment_proof_url', '%storage%payment-proofs%');

      const results = {
        base64Count: (listingFeesBase64 || 0) + (ordersBase64 || 0),
        storageCount: (listingFeesStorage || 0) + (ordersStorage || 0)
      };

      console.log('[migration] Verification results:', results);
      
      return results;

    } catch (error) {
      console.error('[migration] Verification error:', error);
      return { base64Count: -1, storageCount: -1 };
    }
  },

  /**
   * Generate migration report
   * @returns {Promise<string>} HTML report
   */
  async generateReport() {
    const verification = await this.verifyMigration();
    
    const report = `
      <div style="padding:20px;background:#f8f9fa;border-radius:8px;font-family:monospace;">
        <h3 style="margin:0 0 16px;color:#2c3e50;">Payment Proof Migration Report</h3>
        <table style="width:100%;border-collapse:collapse;">
          <tr style="border-bottom:1px solid #dee2e6;">
            <td style="padding:8px;font-weight:600;">Base64 Records Remaining:</td>
            <td style="padding:8px;color:${verification.base64Count > 0 ? '#e74c3c' : '#27ae60'};">
              ${verification.base64Count}
            </td>
          </tr>
          <tr style="border-bottom:1px solid #dee2e6;">
            <td style="padding:8px;font-weight:600;">Storage Records:</td>
            <td style="padding:8px;color:#27ae60;">${verification.storageCount}</td>
          </tr>
          <tr>
            <td style="padding:8px;font-weight:600;">Migration Status:</td>
            <td style="padding:8px;color:${verification.base64Count === 0 ? '#27ae60' : '#f39c12'};">
              ${verification.base64Count === 0 ? '✅ Complete' : '⚠️ Incomplete'}
            </td>
          </tr>
        </table>
      </div>`;
    
    return report;
  }
};

// Make globally available
window.PaymentProofMigration = PaymentProofMigration;

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
  module.exports = PaymentProofMigration;
}

// Auto-run migration if URL parameter is present
if (window.location.search.includes('migrate=payment-proofs')) {
  document.addEventListener('DOMContentLoaded', async () => {
    console.log('[migration] Auto-running migration from URL parameter...');
    
    showLoadingModal('Migrating Payment Proofs', 'This may take a few minutes...');
    
    const results = await PaymentProofMigration.migrateAll();
    
    hideLoadingModal();
    
    if (results.success && results.failed === 0) {
      showSuccess(
        'Migration Complete!',
        `Successfully migrated ${results.migrated} payment proofs to Supabase Storage.`
      );
    } else {
      showError(
        'Migration Completed with Errors',
        `Migrated: ${results.migrated}, Failed: ${results.failed}. Check console for details.`
      );
      console.error('[migration] Migration errors:', results.errors);
    }
    
    // Show report
    const report = await PaymentProofMigration.generateReport();
    document.body.insertAdjacentHTML('beforeend', report);
  });
}
