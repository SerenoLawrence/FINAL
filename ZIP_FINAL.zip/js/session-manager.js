// ============================================================
// session-manager.js — Session Management and Timeout
// Handles session timeouts, automatic logout, and session refresh
// Requirement 1.1.5: Implement Session Management
// ============================================================

class SessionManager {
  constructor() {
    this.REGULAR_USER_TIMEOUT = 30 * 60 * 1000; // 30 minutes in milliseconds
    this.ADMIN_USER_TIMEOUT = 15 * 60 * 1000; // 15 minutes in milliseconds
    this.WARNING_BEFORE_EXPIRY = 5 * 60 * 1000; // 5 minutes warning
    this.CHECK_INTERVAL = 60 * 1000; // Check every minute
    
    this.lastActivityTime = Date.now();
    this.sessionCheckInterval = null;
    this.warningShown = false;
    this.isAdmin = false;
    
    this.init();
  }

  init() {
    console.log('[session-manager] Initializing session manager...');
    
    // Check if user is admin
    this.checkUserRole();
    
    // Set up activity listeners
    this.setupActivityListeners();
    
    // Start session checking
    this.startSessionChecking();
    
    // Check Supabase session on init
    this.checkSupabaseSession();
  }

  checkUserRole() {
    const userType = sessionStorage.getItem('rewear_user_type');
    this.isAdmin = userType === 'admin';
    console.log('[session-manager] User role:', this.isAdmin ? 'Admin' : 'Regular');
  }

  getSessionTimeout() {
    return this.isAdmin ? this.ADMIN_USER_TIMEOUT : this.REGULAR_USER_TIMEOUT;
  }

  setupActivityListeners() {
    // Track user activity
    const activityEvents = ['mousedown', 'keydown', 'scroll', 'touchstart', 'click'];
    
    activityEvents.forEach(event => {
      document.addEventListener(event, () => {
        this.updateLastActivity();
      }, { passive: true });
    });
    
    console.log('[session-manager] Activity listeners set up');
  }

  updateLastActivity() {
    this.lastActivityTime = Date.now();
    this.warningShown = false; // Reset warning flag on activity
    
    // Store last activity time for admin users
    if (this.isAdmin) {
      localStorage.setItem('admin_last_activity', this.lastActivityTime.toString());
    }
  }

  startSessionChecking() {
    // Check session every minute
    this.sessionCheckInterval = setInterval(() => {
      this.checkSession();
    }, this.CHECK_INTERVAL);
    
    console.log('[session-manager] Session checking started');
  }

  stopSessionChecking() {
    if (this.sessionCheckInterval) {
      clearInterval(this.sessionCheckInterval);
      this.sessionCheckInterval = null;
    }
  }

  async checkSession() {
    const now = Date.now();
    const timeSinceLastActivity = now - this.lastActivityTime;
    const sessionTimeout = this.getSessionTimeout();
    const timeUntilExpiry = sessionTimeout - timeSinceLastActivity;
    
    // console.log('[session-manager] Session check:', {
    //   timeSinceLastActivity: Math.floor(timeSinceLastActivity / 1000) + 's',
    //   timeUntilExpiry: Math.floor(timeUntilExpiry / 1000) + 's',
    //   isAdmin: this.isAdmin
    // });
    
    // Show warning 5 minutes before expiry
    if (timeUntilExpiry <= this.WARNING_BEFORE_EXPIRY && timeUntilExpiry > 0 && !this.warningShown) {
      this.showExpiryWarning(Math.floor(timeUntilExpiry / 1000 / 60));
      this.warningShown = true;
    }
    
    // Session expired
    if (timeSinceLastActivity >= sessionTimeout) {
      console.log('[session-manager] Session expired due to inactivity');
      await this.handleSessionExpiry();
    }
    
    // Also check Supabase session
    await this.checkSupabaseSession();
  }

  async checkSupabaseSession() {
    try {
      const { data: { session }, error } = await db.auth.getSession();
      
      if (error) {
        console.error('[session-manager] Error checking Supabase session:', error);
        return;
      }
      
      if (!session) {
        console.log('[session-manager] No active Supabase session');
        await this.handleSessionExpiry();
      }
    } catch (error) {
      console.error('[session-manager] Failed to check Supabase session:', error);
    }
  }

  showExpiryWarning(minutesRemaining) {
    console.log('[session-manager] Showing session expiry warning:', minutesRemaining, 'minutes remaining');
    
    // Create warning notification
    const warningDiv = document.createElement('div');
    warningDiv.id = 'session-expiry-warning';
    warningDiv.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #ff9800;
      color: white;
      padding: 16px 24px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      z-index: 10000;
      max-width: 400px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    `;
    
    warningDiv.innerHTML = `
      <div style="display: flex; align-items: center; gap: 12px;">
        <div style="font-size: 24px;">⏰</div>
        <div>
          <div style="font-weight: 600; margin-bottom: 4px;">Session Expiring Soon</div>
          <div style="font-size: 14px; opacity: 0.9;">
            Your session will expire in ${minutesRemaining} minute${minutesRemaining !== 1 ? 's' : ''} due to inactivity.
          </div>
          <button id="extend-session-btn" style="
            margin-top: 8px;
            background: white;
            color: #ff9800;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            font-size: 13px;
          ">Stay Logged In</button>
        </div>
        <button id="close-warning-btn" style="
          background: none;
          border: none;
          color: white;
          font-size: 20px;
          cursor: pointer;
          padding: 0;
          width: 24px;
          height: 24px;
          display: flex;
          align-items: center;
          justify-content: center;
        ">×</button>
      </div>
    `;
    
    document.body.appendChild(warningDiv);
    
    // Handle extend session button
    document.getElementById('extend-session-btn').addEventListener('click', () => {
      this.updateLastActivity();
      this.refreshSession();
      warningDiv.remove();
    });
    
    // Handle close button
    document.getElementById('close-warning-btn').addEventListener('click', () => {
      warningDiv.remove();
    });
    
    // Auto-remove after 30 seconds
    setTimeout(() => {
      if (document.getElementById('session-expiry-warning')) {
        warningDiv.remove();
      }
    }, 30000);
  }

  async refreshSession() {
    try {
      console.log('[session-manager] Refreshing Supabase session...');
      const { data, error } = await db.auth.refreshSession();
      
      if (error) {
        console.error('[session-manager] Failed to refresh session:', error);
        return false;
      }
      
      console.log('[session-manager] Session refreshed successfully');
      this.updateLastActivity();
      return true;
    } catch (error) {
      console.error('[session-manager] Error refreshing session:', error);
      return false;
    }
  }

  async handleSessionExpiry() {
    console.log('[session-manager] Handling session expiry...');
    
    // Stop checking
    this.stopSessionChecking();
    
    // Sign out from Supabase
    try {
      await db.auth.signOut();
    } catch (error) {
      console.error('[session-manager] Error signing out:', error);
    }
    
    // Clear local auth state
    if (window.authManager) {
      window.authManager.clearAuthState();
    }
    
    // Show expiry message
    sessionStorage.setItem('rewear_login_message', 'Your session has expired due to inactivity. Please log in again.');
    
    // Redirect to login
    const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
    window.location.href = prefix + 'login.html';
  }

  async implementAutomaticRedirect() {
    // This method is called when session expires
    await this.handleSessionExpiry();
  }

  destroy() {
    this.stopSessionChecking();
    console.log('[session-manager] Session manager destroyed');
  }
}

// ---- GLOBAL INSTANCE ----
let sessionManager = null;

// Initialize session manager when user is authenticated
document.addEventListener('DOMContentLoaded', () => {
  // Check if user is logged in
  const currentUser = localStorage.getItem('rewear_current_user');
  
  if (currentUser) {
    console.log('[session-manager] User is logged in, starting session manager');
    sessionManager = new SessionManager();
    window.sessionManager = sessionManager;
  } else {
    console.log('[session-manager] No user logged in, session manager not started');
  }
});

// Listen for auth state changes
document.addEventListener('authStateChanged', () => {
  const currentUser = localStorage.getItem('rewear_current_user');
  
  if (currentUser && !sessionManager) {
    // User just logged in, start session manager
    console.log('[session-manager] User logged in, starting session manager');
    sessionManager = new SessionManager();
    window.sessionManager = sessionManager;
  } else if (!currentUser && sessionManager) {
    // User logged out, destroy session manager
    console.log('[session-manager] User logged out, destroying session manager');
    sessionManager.destroy();
    sessionManager = null;
    window.sessionManager = null;
  }
});

console.log('[session-manager] Session Manager loaded');
