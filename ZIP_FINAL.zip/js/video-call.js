/**
 * Video/Voice Call Module for REWEAR Marketplace
 * Integrates PeerJS video calling into buyer and seller dashboards
 * Messenger-like interface for seamless communication
 */

import { supabase } from './api/supabase.js';

class VideoCallManager {
  constructor() {
    this.peer = null;
    this.localStream = null;
    this.currentCall = null;
    this.isMuted = false;
    this.isCamOff = false;
    this.isMinimized = false;
    this.currentChatId = null;
    this.currentUserId = null;
    this.currentUserName = '';
    this.remoteUserName = '';
  }

  /**
   * Initialize video call system
   */
  async init(userId, userName) {
    this.currentUserId = userId;
    this.currentUserName = userName;
    
    // Create call UI container if it doesn't exist
    if (!document.getElementById('video-call-container')) {
      this.createCallUI();
    }

    // Listen for incoming calls
    this.setupIncomingCallListener();
  }

  /**
   * Create the video call UI (messenger-like floating window)
   */
  createCallUI() {
    const callHTML = `
      <!-- Video Call Container (Messenger-like) -->
      <div id="video-call-container" class="video-call-hidden">
        <!-- Incoming Call Modal -->
        <div id="incoming-call-modal" class="incoming-call-modal hidden">
          <div class="incoming-call-content">
            <div class="caller-avatar">
              <span class="avatar-icon">👤</span>
            </div>
            <h3 id="caller-name">Someone</h3>
            <p class="call-type">
              <span id="call-type-icon">📹</span>
              <span id="call-type-text">Video Call</span>
            </p>
            <div class="incoming-call-actions">
              <button class="btn-decline" id="decline-call-btn">
                <span>❌</span>
                <span>Decline</span>
              </button>
              <button class="btn-accept" id="accept-call-btn">
                <span>✅</span>
                <span>Accept</span>
              </button>
            </div>
          </div>
        </div>

        <!-- Active Call Window -->
        <div id="active-call-window" class="active-call-window hidden">
          <!-- Call Header -->
          <div class="call-window-header">
            <div class="call-info">
              <div class="status-indicator">
                <span class="status-dot" id="call-status-dot"></span>
                <span class="status-text" id="call-status-text">Connecting...</span>
              </div>
              <div class="remote-user-name" id="remote-user-name">User</div>
              <div class="call-duration" id="call-duration">00:00</div>
            </div>
            <div class="call-header-actions">
              <button class="btn-minimize" id="minimize-call-btn" title="Minimize">
                <span>➖</span>
              </button>
              <button class="btn-maximize hidden" id="maximize-call-btn" title="Maximize">
                <span>⬆️</span>
              </button>
            </div>
          </div>

          <!-- Video Container -->
          <div class="video-container" id="video-container">
            <!-- Remote Video (Main) -->
            <div class="remote-video-wrapper">
              <video id="remote-video" autoplay playsinline></video>
              <div class="remote-placeholder" id="remote-placeholder">
                <div class="placeholder-avatar">👤</div>
                <p>Connecting...</p>
                <div class="connecting-spinner"></div>
              </div>
            </div>

            <!-- Local Video (PiP) -->
            <div class="local-video-wrapper" id="local-video-wrapper">
              <video id="local-video" autoplay playsinline muted></video>
            </div>
          </div>

          <!-- Call Controls -->
          <div class="call-controls">
            <button class="control-btn" id="toggle-mic-btn" title="Mute/Unmute">
              <span class="icon">🎤</span>
              <span class="label">Mic</span>
            </button>
            <button class="control-btn" id="toggle-cam-btn" title="Camera On/Off">
              <span class="icon">📷</span>
              <span class="label">Camera</span>
            </button>
            <button class="control-btn btn-end-call" id="end-call-btn" title="End Call">
              <span class="icon">📞</span>
              <span class="label">End</span>
            </button>
            <button class="control-btn" id="toggle-screen-btn" title="Share Screen">
              <span class="icon">🖥️</span>
              <span class="label">Screen</span>
            </button>
          </div>
        </div>

        <!-- Minimized Call Indicator -->
        <div id="minimized-call-indicator" class="minimized-call-indicator hidden">
          <div class="minimized-content">
            <div class="minimized-video">
              <video id="minimized-remote-video" autoplay playsinline></video>
            </div>
            <div class="minimized-info">
              <span class="minimized-name" id="minimized-user-name">User</span>
              <span class="minimized-duration" id="minimized-duration">00:00</span>
            </div>
            <button class="btn-restore" id="restore-call-btn">
              <span>⬆️</span>
            </button>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', callHTML);
    this.attachEventListeners();
  }

  /**
   * Attach event listeners to call UI elements
   */
  attachEventListeners() {
    // Incoming call actions
    document.getElementById('accept-call-btn')?.addEventListener('click', () => this.acceptIncomingCall());
    document.getElementById('decline-call-btn')?.addEventListener('click', () => this.declineIncomingCall());

    // Call controls
    document.getElementById('toggle-mic-btn')?.addEventListener('click', () => this.toggleMic());
    document.getElementById('toggle-cam-btn')?.addEventListener('click', () => this.toggleCamera());
    document.getElementById('end-call-btn')?.addEventListener('click', () => this.endCall());
    document.getElementById('toggle-screen-btn')?.addEventListener('click', () => this.toggleScreenShare());

    // Window controls
    document.getElementById('minimize-call-btn')?.addEventListener('click', () => this.minimizeCall());
    document.getElementById('maximize-call-btn')?.addEventListener('click', () => this.maximizeCall());
    document.getElementById('restore-call-btn')?.addEventListener('click', () => this.restoreCall());

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
      if (!this.currentCall) return;
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

      switch (e.key.toLowerCase()) {
        case 'm': this.toggleMic(); break;
        case 'v': this.toggleCamera(); break;
      }
    });
  }

  /**
   * Start a video call with another user
   */
  async startCall(chatId, remoteUserId, remoteUserName, callType = 'video') {
    try {
      this.currentChatId = chatId;
      this.remoteUserName = remoteUserName;

      // Get local media stream
      await this.getLocalStream(callType === 'video');

      // Initialize PeerJS
      const myPeerId = `${this.currentUserId}-${Date.now()}`;
      await this.initPeer(myPeerId);

      // Send call invitation via database
      await this.sendCallInvitation(chatId, remoteUserId, myPeerId, callType);

      // Show call window
      this.showCallWindow();
      this.updateCallStatus('connecting', 'Calling...');

      // Wait for remote peer to accept (timeout after 60 seconds)
      this.callTimeout = setTimeout(() => {
        if (!this.currentCall) {
          this.showToast('❌ Call not answered');
          this.endCall();
        }
      }, 60000);

    } catch (error) {
      console.error('Error starting call:', error);
      this.showToast('❌ Failed to start call');
      this.endCall();
    }
  }

  /**
   * Initialize PeerJS connection
   */
  initPeer(peerId) {
    return new Promise((resolve, reject) => {
      this.peer = new Peer(peerId, {
        debug: 1
      });

      this.peer.on('open', (id) => {
        console.log('[PeerJS] Connected with ID:', id);
        resolve(this.peer);
      });

      this.peer.on('call', (incomingCall) => {
        console.log('[PeerJS] Incoming call from:', incomingCall.peer);
        this.handleIncomingCall(incomingCall);
      });

      this.peer.on('error', (err) => {
        console.error('[PeerJS] Error:', err);
        this.showToast(`⚠️ Connection error: ${err.type}`);
        reject(err);
      });

      this.peer.on('disconnected', () => {
        console.log('[PeerJS] Disconnected');
        this.updateCallStatus('disconnected', 'Disconnected');
      });
    });
  }

  /**
   * Get local media stream (camera + microphone)
   */
  async getLocalStream(includeVideo = true) {
    try {
      const constraints = {
        audio: true,
        video: includeVideo ? {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user'
        } : false
      };

      this.localStream = await navigator.mediaDevices.getUserMedia(constraints);
      
      const localVideo = document.getElementById('local-video');
      if (localVideo) {
        localVideo.srcObject = this.localStream;
      }

      return this.localStream;
    } catch (error) {
      console.error('Media access denied:', error);
      this.showToast('❌ Camera/microphone access denied');
      throw error;
    }
  }

  /**
   * Send call invitation to remote user via database
   */
  async sendCallInvitation(chatId, remoteUserId, peerId, callType) {
    try {
      const { error } = await supabase
        .from('call_invitations')
        .insert({
          chat_id: chatId,
          caller_id: this.currentUserId,
          callee_id: remoteUserId,
          peer_id: peerId,
          call_type: callType,
          status: 'pending',
          created_at: new Date().toISOString()
        });

      if (error) throw error;
    } catch (error) {
      console.error('Error sending call invitation:', error);
      throw error;
    }
  }

  /**
   * Listen for incoming call invitations
   */
  setupIncomingCallListener() {
    // Subscribe to call_invitations table for this user
    const subscription = supabase
      .channel('call_invitations')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'call_invitations',
        filter: `callee_id=eq.${this.currentUserId}`
      }, (payload) => {
        this.handleCallInvitation(payload.new);
      })
      .subscribe();
  }

  /**
   * Handle incoming call invitation
   */
  async handleCallInvitation(invitation) {
    if (invitation.status !== 'pending') return;

    // Get caller information
    const { data: caller } = await supabase
      .from('users')
      .select('name')
      .eq('id', invitation.caller_id)
      .single();

    this.remoteUserName = caller?.name || 'Someone';
    this.currentChatId = invitation.chat_id;
    this.remotePeerId = invitation.peer_id;
    this.callInvitationId = invitation.id;

    // Show incoming call modal
    this.showIncomingCallModal(invitation.call_type);
  }

  /**
   * Show incoming call modal
   */
  showIncomingCallModal(callType) {
    const modal = document.getElementById('incoming-call-modal');
    const callerName = document.getElementById('caller-name');
    const callTypeIcon = document.getElementById('call-type-icon');
    const callTypeText = document.getElementById('call-type-text');

    callerName.textContent = this.remoteUserName;
    callTypeIcon.textContent = callType === 'video' ? '📹' : '📞';
    callTypeText.textContent = callType === 'video' ? 'Video Call' : 'Voice Call';

    modal.classList.remove('hidden');
    document.getElementById('video-call-container').classList.remove('video-call-hidden');

    // Play ringtone (optional)
    this.playRingtone();
  }

  /**
   * Accept incoming call
   */
  async acceptIncomingCall() {
    try {
      // Hide incoming call modal
      document.getElementById('incoming-call-modal').classList.add('hidden');

      // Update invitation status
      await supabase
        .from('call_invitations')
        .update({ status: 'accepted' })
        .eq('id', this.callInvitationId);

      // Get local media stream
      await this.getLocalStream(true);

      // Initialize PeerJS
      const myPeerId = `${this.currentUserId}-${Date.now()}`;
      await this.initPeer(myPeerId);

      // Call the remote peer
      const call = this.peer.call(this.remotePeerId, this.localStream);
      this.handleCall(call);

      // Show call window
      this.showCallWindow();
      this.updateCallStatus('connecting', 'Connecting...');

      this.stopRingtone();
    } catch (error) {
      console.error('Error accepting call:', error);
      this.showToast('❌ Failed to accept call');
      this.endCall();
    }
  }

  /**
   * Decline incoming call
   */
  async declineIncomingCall() {
    // Update invitation status
    await supabase
      .from('call_invitations')
      .update({ status: 'declined' })
      .eq('id', this.callInvitationId);

    // Hide modal
    document.getElementById('incoming-call-modal').classList.add('hidden');
    document.getElementById('video-call-container').classList.add('video-call-hidden');

    this.stopRingtone();
    this.showToast('📞 Call declined');
  }

  /**
   * Handle incoming WebRTC call
   */
  handleIncomingCall(incomingCall) {
    // Answer with local stream
    incomingCall.answer(this.localStream);
    this.handleCall(incomingCall);
  }

  /**
   * Handle active call (both incoming and outgoing)
   */
  handleCall(call) {
    this.currentCall = call;
    this.startCallDuration();

    call.on('stream', (remoteStream) => {
      console.log('[WebRTC] Received remote stream');
      const remoteVideo = document.getElementById('remote-video');
      const remotePlaceholder = document.getElementById('remote-placeholder');

      if (remoteVideo) {
        remoteVideo.srcObject = remoteStream;
        remotePlaceholder.classList.add('hidden');
      }

      this.updateCallStatus('connected', 'Connected');
      clearTimeout(this.callTimeout);
    });

    call.on('close', () => {
      console.log('[WebRTC] Call closed');
      this.endCall();
      this.showToast('📡 Call ended');
    });

    call.on('error', (err) => {
      console.error('[WebRTC] Call error:', err);
      this.showToast('⚠️ Call error occurred');
      this.endCall();
    });
  }

  /**
   * Toggle microphone
   */
  toggleMic() {
    if (!this.localStream) return;

    this.isMuted = !this.isMuted;
    this.localStream.getAudioTracks().forEach(track => {
      track.enabled = !this.isMuted;
    });

    const micBtn = document.getElementById('toggle-mic-btn');
    const icon = micBtn.querySelector('.icon');
    
    icon.textContent = this.isMuted ? '🔇' : '🎤';
    micBtn.classList.toggle('muted', this.isMuted);

    this.showToast(this.isMuted ? '🔇 Microphone muted' : '🎤 Microphone on');
  }

  /**
   * Toggle camera
   */
  toggleCamera() {
    if (!this.localStream) return;

    this.isCamOff = !this.isCamOff;
    this.localStream.getVideoTracks().forEach(track => {
      track.enabled = !this.isCamOff;
    });

    const camBtn = document.getElementById('toggle-cam-btn');
    const icon = camBtn.querySelector('.icon');
    
    icon.textContent = this.isCamOff ? '📕' : '📷';
    camBtn.classList.toggle('camera-off', this.isCamOff);

    this.showToast(this.isCamOff ? '📕 Camera off' : '📷 Camera on');
  }

  /**
   * Toggle screen share
   */
  async toggleScreenShare() {
    try {
      if (this.isScreenSharing) {
        // Stop screen sharing, return to camera
        await this.getLocalStream(true);
        this.isScreenSharing = false;
        this.showToast('🖥️ Screen sharing stopped');
      } else {
        // Start screen sharing
        const screenStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: false
        });

        // Replace video track in the call
        const videoTrack = screenStream.getVideoTracks()[0];
        const sender = this.currentCall.peerConnection
          .getSenders()
          .find(s => s.track?.kind === 'video');

        if (sender) {
          sender.replaceTrack(videoTrack);
        }

        // Update local video
        document.getElementById('local-video').srcObject = screenStream;

        this.isScreenSharing = true;
        this.showToast('🖥️ Screen sharing started');

        // Listen for screen share stop
        videoTrack.onended = () => {
          this.toggleScreenShare();
        };
      }
    } catch (error) {
      console.error('Screen share error:', error);
      this.showToast('❌ Screen sharing failed');
    }
  }

  /**
   * End call
   */
  endCall() {
    // Close call
    if (this.currentCall) {
      this.currentCall.close();
      this.currentCall = null;
    }

    // Stop local stream
    if (this.localStream) {
      this.localStream.getTracks().forEach(track => track.stop());
      this.localStream = null;
    }

    // Destroy peer
    if (this.peer) {
      this.peer.destroy();
      this.peer = null;
    }

    // Stop call duration timer
    this.stopCallDuration();

    // Hide call window
    this.hideCallWindow();

    // Reset state
    this.isMuted = false;
    this.isCamOff = false;
    this.isScreenSharing = false;
    this.isMinimized = false;

    this.showToast('📞 Call ended');
  }

  /**
   * Minimize call window
   */
  minimizeCall() {
    this.isMinimized = true;
    document.getElementById('active-call-window').classList.add('hidden');
    document.getElementById('minimized-call-indicator').classList.remove('hidden');
    
    // Clone remote video to minimized view
    const remoteVideo = document.getElementById('remote-video');
    const minimizedVideo = document.getElementById('minimized-remote-video');
    if (remoteVideo.srcObject) {
      minimizedVideo.srcObject = remoteVideo.srcObject;
    }
  }

  /**
   * Restore call window from minimized state
   */
  restoreCall() {
    this.isMinimized = false;
    document.getElementById('minimized-call-indicator').classList.add('hidden');
    document.getElementById('active-call-window').classList.remove('hidden');
  }

  /**
   * Maximize call window
   */
  maximizeCall() {
    document.getElementById('active-call-window').classList.remove('minimized');
    document.getElementById('minimize-call-btn').classList.remove('hidden');
    document.getElementById('maximize-call-btn').classList.add('hidden');
  }

  /**
   * Show call window
   */
  showCallWindow() {
    document.getElementById('video-call-container').classList.remove('video-call-hidden');
    document.getElementById('active-call-window').classList.remove('hidden');
    document.getElementById('remote-user-name').textContent = this.remoteUserName;
  }

  /**
   * Hide call window
   */
  hideCallWindow() {
    document.getElementById('active-call-window').classList.add('hidden');
    document.getElementById('minimized-call-indicator').classList.add('hidden');
    document.getElementById('video-call-container').classList.add('video-call-hidden');
  }

  /**
   * Update call status indicator
   */
  updateCallStatus(status, text) {
    const statusDot = document.getElementById('call-status-dot');
    const statusText = document.getElementById('call-status-text');

    statusDot.className = `status-dot status-${status}`;
    statusText.textContent = text;
  }

  /**
   * Start call duration timer
   */
  startCallDuration() {
    this.callStartTime = Date.now();
    this.callDurationInterval = setInterval(() => {
      const duration = Math.floor((Date.now() - this.callStartTime) / 1000);
      const minutes = Math.floor(duration / 60).toString().padStart(2, '0');
      const seconds = (duration % 60).toString().padStart(2, '0');
      const timeString = `${minutes}:${seconds}`;

      document.getElementById('call-duration').textContent = timeString;
      document.getElementById('minimized-duration').textContent = timeString;
    }, 1000);
  }

  /**
   * Stop call duration timer
   */
  stopCallDuration() {
    if (this.callDurationInterval) {
      clearInterval(this.callDurationInterval);
      this.callDurationInterval = null;
    }
  }

  /**
   * Play ringtone
   */
  playRingtone() {
    // Implement ringtone audio if needed
    console.log('Playing ringtone...');
  }

  /**
   * Stop ringtone
   */
  stopRingtone() {
    // Implement ringtone stop if needed
    console.log('Stopping ringtone...');
  }

  /**
   * Show toast notification
   */
  showToast(message, duration = 3000) {
    // Create toast if it doesn't exist
    let toast = document.getElementById('video-call-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'video-call-toast';
      toast.className = 'video-call-toast';
      document.body.appendChild(toast);
    }

    toast.textContent = message;
    toast.classList.add('show');

    setTimeout(() => {
      toast.classList.remove('show');
    }, duration);
  }
}

// Export singleton instance
export const videoCallManager = new VideoCallManager();
