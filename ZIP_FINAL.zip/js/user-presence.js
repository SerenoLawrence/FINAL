/**
 * User Presence Manager
 * Tracks online/offline status of users in real-time
 */

class UserPresenceManager {
  constructor() {
    this.currentUserId = null;
    this.presenceSubscription = null;
    this.heartbeatInterval = null;
    this.isOnline = true;
  }

  /**
   * Initialize presence tracking
   */
  async init(userId) {
    this.currentUserId = userId;
    
    // Set user as online
    await this.setOnline();
    
    // Subscribe to presence changes
    this.subscribeToPresence();
    
    // Send heartbeat every 30 seconds
    this.startHeartbeat();
    
    // Handle page visibility changes
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.setOffline();
      } else {
        this.setOnline();
      }
    });
    
    // Handle page unload
    window.addEventListener('beforeunload', () => {
      this.setOffline();
    });
  }

  /**
   * Set user as online
   */
  async setOnline() {
    try {
      this.isOnline = true;
      
      const { error } = await db
        .from('user_presence')
        .upsert({
          user_id: this.currentUserId,
          is_online: true,
          last_seen: new Date().toISOString()
        }, {
          onConflict: 'user_id'
        });

      if (error) throw error;
      
      // Update UI
      this.updatePresenceUI(true);
    } catch (error) {
      console.error('[presence] Error setting online:', error);
    }
  }

  /**
   * Set user as offline
   */
  async setOffline() {
    try {
      this.isOnline = false;
      
      const { error } = await db
        .from('user_presence')
        .update({
          is_online: false,
          last_seen: new Date().toISOString()
        })
        .eq('user_id', this.currentUserId);

      if (error) throw error;
      
      // Update UI
      this.updatePresenceUI(false);
    } catch (error) {
      console.error('[presence] Error setting offline:', error);
    }
  }

  /**
   * Start heartbeat to keep user online
   */
  startHeartbeat() {
    this.heartbeatInterval = setInterval(async () => {
      if (this.isOnline) {
        try {
          await db
            .from('user_presence')
            .update({ last_seen: new Date().toISOString() })
            .eq('user_id', this.currentUserId);
        } catch (error) {
          console.warn('[presence] Heartbeat failed:', error);
        }
      }
    }, 30000); // Every 30 seconds
  }

  /**
   * Subscribe to presence changes
   */
  subscribeToPresence() {
    if (this.presenceSubscription) {
      this.presenceSubscription.unsubscribe();
    }

    this.presenceSubscription = db
      .channel('user_presence_changes')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'user_presence'
      }, (payload) => {
        this.handlePresenceChange(payload);
      })
      .subscribe();
  }

  /**
   * Handle presence change
   */
  handlePresenceChange(payload) {
    const userId = payload.new?.user_id || payload.old?.user_id;
    const isOnline = payload.new?.is_online;

    // Update UI for this user
    this.updateUserPresenceUI(userId, isOnline);
  }

  /**
   * Update presence UI for current user
   */
  updatePresenceUI(isOnline) {
    const statusElements = document.querySelectorAll('[data-presence-status]');
    statusElements.forEach(el => {
      if (isOnline) {
        el.classList.add('online');
        el.classList.remove('offline');
        el.textContent = '🟢 Online';
      } else {
        el.classList.add('offline');
        el.classList.remove('online');
        el.textContent = '⚫ Offline';
      }
    });
  }

  /**
   * Update presence UI for specific user
   */
  updateUserPresenceUI(userId, isOnline) {
    const userElements = document.querySelectorAll(`[data-user-id="${userId}"][data-presence-indicator]`);
    userElements.forEach(el => {
      if (isOnline) {
        el.classList.add('online');
        el.classList.remove('offline');
        el.innerHTML = '🟢';
      } else {
        el.classList.add('offline');
        el.classList.remove('online');
        el.innerHTML = '⚫';
      }
    });
  }

  /**
   * Get user presence status
   */
  async getUserPresence(userId) {
    try {
      const { data, error } = await db
        .from('user_presence')
        .select('is_online, last_seen')
        .eq('user_id', userId)
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('[presence] Error getting user presence:', error);
      return null;
    }
  }

  /**
   * Cleanup
   */
  destroy() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }
    if (this.presenceSubscription) {
      this.presenceSubscription.unsubscribe();
    }
  }
}

// Create global instance
window.userPresenceManager = new UserPresenceManager();

console.log('[presence] User presence manager loaded');
