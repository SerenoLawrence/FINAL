// ============================================================
// cart.js — Shopping Cart Management
// ============================================================

class ShoppingCart {
  constructor() {
    this.storageKey = 'rewear_cart';
    this.items = this.loadCart();
  }

  // Load cart from localStorage
  loadCart() {
    try {
      const stored = localStorage.getItem(this.storageKey);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('[cart] Error loading cart:', error);
      return [];
    }
  }

  // Save cart to localStorage
  saveCart() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.items));
      this.updateCartBadge();
    } catch (error) {
      console.error('[cart] Error saving cart:', error);
    }
  }

  // Add item to cart
  addItem(product) {
    const existingIndex = this.items.findIndex(
      item => item.id === product.id && item.size === product.size
    );

    if (existingIndex > -1) {
      // Update quantity if item already exists
      this.items[existingIndex].quantity += product.quantity || 1;
    } else {
      // Add new item
      this.items.push({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        size: product.size,
        quantity: product.quantity || 1,
        seller_id: product.seller_id
      });
    }

    this.saveCart();
    console.log('[cart] Item added:', product);
  }

  // Remove item from cart
  removeItem(productId, size) {
    this.items = this.items.filter(
      item => !(item.id === productId && item.size === size)
    );
    this.saveCart();
    console.log('[cart] Item removed:', productId, size);
  }

  // Update item quantity
  updateQuantity(productId, size, quantity) {
    const item = this.items.find(
      item => item.id === productId && item.size === size
    );
    
    if (item) {
      item.quantity = Math.max(1, quantity);
      this.saveCart();
      console.log('[cart] Quantity updated:', productId, quantity);
    }
  }

  // Get all items
  getItems() {
    return this.items;
  }

  // Get item count
  getItemCount() {
    return this.items.reduce((total, item) => total + item.quantity, 0);
  }

  // Get cart total
  getTotal() {
    return this.items.reduce((total, item) => total + (item.price * item.quantity), 0);
  }

  // Clear cart
  clearCart() {
    this.items = [];
    this.saveCart();
    console.log('[cart] Cart cleared');
  }

  // Update cart badge in UI
  updateCartBadge() {
    const badges = document.querySelectorAll('.cart-badge, .cart-count');
    const count = this.getItemCount();
    
    badges.forEach(badge => {
      badge.textContent = count;
      badge.style.display = count > 0 ? 'flex' : 'none';
    });
  }
}

// Initialize cart
window.cart = new ShoppingCart();

// Update badge on page load
document.addEventListener('DOMContentLoaded', () => {
  if (window.cart) {
    window.cart.updateCartBadge();
  }
});

console.log('[cart] Shopping cart initialized');
