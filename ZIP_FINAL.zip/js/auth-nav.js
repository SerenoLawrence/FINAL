// ============================================================
// auth-nav.js — Universal Navigation Auth State Handler
// Used on all pages to update navigation based on auth state
// ============================================================

function initAuthNavigation() {
  const updateNavigation = () => {
    // Ensure authManager is available
    if (!window.authManager) {
      setTimeout(updateNavigation, 100);
      return;
    }

    const authNav = document.getElementById('authNav');
    const userNav = document.getElementById('userNav');
    const userGreeting = document.getElementById('userGreeting');
    const dashboardBtn = document.getElementById('userDashboardBtn');
    const mobileDashboardLink = document.getElementById('mobileDashboardLink');
    
    // Check if we're on the dashboard page (more comprehensive check)
    const isDashboardPage = window.location.pathname.includes('dashboard') || 
                           window.location.href.includes('dashboard.html');
    
    if (window.authManager.isAuthenticated()) {
      const user = window.authManager.getCurrentUser();
      const userType = window.authManager.getUserType();
      
      // Show user navigation
      if (authNav) authNav.classList.add('hidden');
      if (userNav) userNav.classList.remove('hidden');
      
      // Show mobile dashboard link ONLY if NOT on dashboard page
      if (mobileDashboardLink) {
        if (isDashboardPage) {
          // Force hide with multiple methods
          mobileDashboardLink.classList.add('hidden');
          mobileDashboardLink.style.display = 'none';
          mobileDashboardLink.style.visibility = 'hidden';
          // Disable the link completely
          mobileDashboardLink.onclick = (e) => {
            e.preventDefault();
            return false;
          };
        } else {
          mobileDashboardLink.classList.remove('hidden');
          mobileDashboardLink.style.display = '';
          mobileDashboardLink.style.visibility = '';
          // Re-enable the link
          mobileDashboardLink.onclick = null;
        }
      }
      
      // Update greeting
      if (userGreeting) {
        userGreeting.textContent = `Hi, ${user.name || user.email.split('@')[0]}!`;
      }
      
      // Set dashboard link — always goes to unified dashboard
      if (dashboardBtn) {
        dashboardBtn.onclick = () => {
          const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
          window.location.href = prefix + 'dashboard.html';
        };
      }
    } else {
      // Show auth navigation
      if (authNav) authNav.classList.remove('hidden');
      if (userNav) userNav.classList.add('hidden');
      
      // Hide mobile dashboard link
      if (mobileDashboardLink) {
        mobileDashboardLink.classList.add('hidden');
        mobileDashboardLink.style.display = 'none';
      }
    }
  };

  // Initialize immediately and on auth state changes
  updateNavigation();
  
  // Listen for auth state changes (custom event)
  document.addEventListener('authStateChanged', updateNavigation);
  
  // Also update on page load and visibility change
  window.addEventListener('load', updateNavigation);
  document.addEventListener('visibilitychange', updateNavigation);
}

// Auto-initialize on DOM ready
document.addEventListener('DOMContentLoaded', initAuthNavigation);

// Also initialize immediately if DOM is already ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initAuthNavigation);
} else {
  initAuthNavigation();
}

// ============================================================
// DASHBOARD NAVIGATION HELPER (prevents loops)
// ============================================================
function navigateToDashboard(event) {
  if (event) {
    event.preventDefault();
    event.stopPropagation();
  }
  
  // Check if already on dashboard
  if (window.location.pathname.includes('dashboard') || 
      window.location.href.includes('dashboard.html')) {
    console.log('[Navigation] Already on dashboard, ignoring click');
    return false;
  }
  
  // Navigate to dashboard
  const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
  console.log('[Navigation] Navigating to dashboard');
  window.location.href = prefix + 'dashboard.html';
  return false;
}

// Make function globally available
window.navigateToDashboard = navigateToDashboard;