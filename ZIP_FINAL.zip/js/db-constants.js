// ============================================================
// db-constants.js — Database table and column name constants
// Requirement 1.8.4: Create Data Mapping Layer
// ============================================================

/**
 * Database table names
 * Use these constants instead of hardcoded strings to prevent typos
 */
const TABLES = {
  // Core tables
  PRODUCTS: 'products',
  SELLERS: 'sellers',
  SELLER_APPLICATIONS: 'seller_applications',
  ORDERS: 'orders',
  LISTING_FEES: 'listing_fees',
  TRANSACTIONS: 'transactions',
  
  // Communication
  CHATS: 'chats',
  MESSAGES: 'messages',
  NOTIFICATIONS: 'notifications',
  
  // Reviews and feedback
  REVIEWS: 'reviews',
  REPORTS: 'reports',
  
  // User data
  WISHLISTS: 'wishlists',
  
  // Platform data
  EARNINGS: 'earnings',
  MARKETPLACE_ACTIVITY_LOGS: 'marketplace_activity_logs',
  ADMIN_REVIEWS: 'admin_reviews',
  
  // Content
  BLOG_POSTS: 'blog_posts',
  NEWSLETTER_SUBSCRIBERS: 'newsletter_subscribers',
  CONTACT_MESSAGES: 'contact_messages',
  
  // Legacy
  ADMIN_SESSIONS: 'admin_sessions'
};

/**
 * Database column names by table
 * Use these constants for type-safe column references
 */
const COLUMNS = {
  // Common columns (present in most tables)
  COMMON: {
    ID: 'id',
    CREATED_AT: 'created_at',
    UPDATED_AT: 'updated_at'
  },
  
  // Products table
  PRODUCTS: {
    ID: 'id',
    SELLER_ID: 'seller_id',
    NAME: 'name',
    DESCRIPTION: 'description',
    PRICE: 'price',
    ORIGINAL_PRICE: 'original_price',
    CATEGORY: 'category',
    SUBCATEGORY: 'subcategory',
    CONDITION: 'condition',
    SIZE: 'size',
    SIZES: 'sizes',
    COLOR: 'color',
    BRAND: 'brand',
    MATERIAL: 'material',
    IMAGES: 'images',
    IMAGE_URL: 'image_url',
    STATUS: 'status',
    REJECTION_REASON: 'rejection_reason',
    VIEWS: 'views',
    FAVORITES: 'favorites',
    IN_STOCK: 'in_stock',
    IS_FEATURED: 'is_featured',
    LISTING_FEE_ID: 'listing_fee_id',
    APPROVED_AT: 'approved_at',
    APPROVED_BY: 'approved_by',
    SOLD_AT: 'sold_at',
    CREATED_AT: 'created_at',
    UPDATED_AT: 'updated_at',
    SUGGESTED_PRICE: 'suggested_price',
    RATING: 'rating'
  },
  
  // Sellers table
  SELLERS: {
    ID: 'id',
    USER_ID: 'user_id',
    BUSINESS_NAME: 'business_name',
    EMAIL: 'email',
    PHONE: 'phone',
    ADDRESS: 'address',
    BUSINESS_DESCRIPTION: 'business_description',
    VERIFIED: 'verified',
    VERIFIED_AT: 'verified_at',
    VERIFICATION_LEVEL: 'verification_level',
    TOTAL_SALES: 'total_sales',
    TOTAL_EARNINGS: 'total_earnings',
    RATING: 'rating',
    TOTAL_REVIEWS: 'total_reviews',
    ACTIVE_LISTINGS: 'active_listings',
    GCASH_NUMBER: 'gcash_number',
    GCASH_NAME: 'gcash_name',
    GCASH_QR_URL: 'gcash_qr_url',
    REJECTION_REASON: 'rejection_reason',
    DESCRIPTION: 'description',
    CREATED_AT: 'created_at',
    UPDATED_AT: 'updated_at'
  },
  
  // Seller Applications table
  SELLER_APPLICATIONS: {
    ID: 'id',
    USER_ID: 'user_id',
    BUSINESS_NAME: 'business_name',
    EMAIL: 'email',
    PHONE: 'phone',
    ADDRESS: 'address',
    BUSINESS_DESCRIPTION: 'business_description',
    YEARS_IN_BUSINESS: 'years_in_business',
    SOCIAL_MEDIA_LINKS: 'social_media_links',
    STATUS: 'status',
    REJECTION_REASON: 'rejection_reason',
    SUBMITTED_AT: 'submitted_at',
    REVIEWED_AT: 'reviewed_at',
    REVIEWED_BY: 'reviewed_by',
    CREATED_AT: 'created_at'
  },
  
  // Orders table
  ORDERS: {
    ID: 'id',
    BUYER_ID: 'buyer_id',
    BUYER_NAME: 'buyer_name',
    BUYER_EMAIL: 'buyer_email',
    BUYER_PHONE: 'buyer_phone',
    PRODUCT_ID: 'product_id',
    SELLER_ID: 'seller_id',
    QUANTITY: 'quantity',
    SIZE_SELECTED: 'size_selected',
    COLOR_SELECTED: 'color_selected',
    UNIT_PRICE: 'unit_price',
    TOTAL_PRICE: 'total_price',
    SHIPPING_ADDRESS: 'shipping_address',
    DELIVERY_ADDRESS: 'delivery_address',
    DELIVERY_METHOD: 'delivery_method',
    MEETUP_LOCATION: 'meetup_location',
    DELIVERY_FEE: 'delivery_fee',
    PAYMENT_METHOD: 'payment_method',
    PAYMENT_STATUS: 'payment_status',
    PAYMENT_PROOF_URL: 'payment_proof_url',
    PAYMENT_REFERENCE: 'payment_reference',
    PAYMENT_REJECTED_REASON: 'payment_rejected_reason',
    STATUS: 'status',
    TRANSACTION_ID: 'transaction_id',
    TRACKING_NUMBER: 'tracking_number',
    COURIER_NAME: 'courier_name',
    CONFIRMED_AT: 'confirmed_at',
    DELIVERED_AT: 'delivered_at',
    RECEIVED_AT: 'received_at',
    NOTES: 'notes',
    CREATED_AT: 'created_at',
    UPDATED_AT: 'updated_at'
  },
  
  // Listing Fees table
  LISTING_FEES: {
    ID: 'id',
    SELLER_ID: 'seller_id',
    TIER: 'tier',
    AMOUNT_PAID: 'amount_paid',
    PAYMENT_METHOD: 'payment_method',
    PAYMENT_REF: 'payment_ref',
    PROOF_URL: 'proof_url',
    STATUS: 'status',
    REJECTION_REASON: 'rejection_reason',
    MAX_LISTINGS: 'max_listings',
    LISTINGS_USED: 'listings_used',
    PAID_AT: 'paid_at',
    VERIFIED_AT: 'verified_at',
    VERIFIED_BY: 'verified_by',
    EXPIRES_AT: 'expires_at',
    CREATED_AT: 'created_at'
  },
  
  // Messages table
  MESSAGES: {
    ID: 'id',
    SELLER_ID: 'seller_id',
    BUYER_NAME: 'buyer_name',
    BUYER_EMAIL: 'buyer_email',
    PRODUCT_ID: 'product_id',
    MESSAGE: 'message',
    REPLY: 'reply',
    THREAD: 'thread',
    ACCEPTED: 'accepted',
    REJECTED: 'rejected',
    IS_READ: 'is_read',
    CREATED_AT: 'created_at',
    REPLIED_AT: 'replied_at'
  },
  
  // Reviews table
  REVIEWS: {
    ID: 'id',
    ORDER_ID: 'order_id',
    REVIEWER_ID: 'reviewer_id',
    REVIEWED_ID: 'reviewed_id',
    REVIEW_TYPE: 'review_type',
    RATING: 'rating',
    COMMENT: 'comment',
    RESPONSE: 'response',
    STATUS: 'status',
    CREATED_AT: 'created_at'
  },
  
  // Notifications table
  NOTIFICATIONS: {
    ID: 'id',
    USER_ID: 'user_id',
    NOTIFICATION_TYPE: 'notification_type',
    TITLE: 'title',
    MESSAGE: 'message',
    DATA: 'data',
    READ: 'read',
    READ_AT: 'read_at',
    CREATED_AT: 'created_at'
  },
  
  // Transactions table
  TRANSACTIONS: {
    ID: 'id',
    ORDER_ID: 'order_id',
    SELLER_ID: 'seller_id',
    GROSS_AMOUNT: 'gross_amount',
    COMMISSION_RATE: 'commission_rate',
    COMMISSION_AMOUNT: 'commission_amount',
    SELLER_PAYOUT: 'seller_payout',
    STATUS: 'status',
    RELEASED_AT: 'released_at',
    CREATED_AT: 'created_at'
  },
  
  // Earnings table
  EARNINGS: {
    ID: 'id',
    SOURCE: 'source',
    REFERENCE_ID: 'reference_id',
    AMOUNT: 'amount',
    RECORDED_AT: 'recorded_at'
  },
  
  // Wishlists table
  WISHLISTS: {
    ID: 'id',
    USER_ID: 'user_id',
    PRODUCT_ID: 'product_id',
    ADDED_AT: 'added_at'
  },
  
  // Newsletter Subscribers table
  NEWSLETTER_SUBSCRIBERS: {
    ID: 'id',
    EMAIL: 'email',
    SUBSCRIBED_AT: 'subscribed_at'
  },
  
  // Contact Messages table
  CONTACT_MESSAGES: {
    ID: 'id',
    FIRST_NAME: 'first_name',
    LAST_NAME: 'last_name',
    EMAIL: 'email',
    PHONE: 'phone',
    SUBJECT: 'subject',
    MESSAGE: 'message',
    CREATED_AT: 'created_at'
  }
};

/**
 * Status values for different entities
 */
const STATUS = {
  // Product status
  PRODUCT: {
    DRAFT: 'draft',
    PENDING: 'pending',
    APPROVED: 'approved',
    REJECTED: 'rejected',
    SOLD: 'sold',
    ARCHIVED: 'archived'
  },
  
  // Order status
  ORDER: {
    PENDING: 'pending',
    CONFIRMED: 'confirmed',
    SHIPPED: 'shipped',
    DELIVERED: 'delivered',
    RECEIVED: 'received',
    CANCELLED: 'cancelled',
    REFUNDED: 'refunded'
  },
  
  // Payment status
  PAYMENT: {
    PENDING: 'pending',
    SUBMITTED: 'submitted',
    VERIFIED: 'verified',
    REJECTED: 'rejected'
  },
  
  // Seller application status
  SELLER_APPLICATION: {
    PENDING: 'pending',
    APPROVED: 'approved',
    REJECTED: 'rejected'
  },
  
  // Listing fee status
  LISTING_FEE: {
    PENDING_PAYMENT: 'pending_payment',
    PROOF_SUBMITTED: 'proof_submitted',
    VERIFIED: 'verified',
    REJECTED: 'rejected',
    ACTIVE: 'active',
    EXPIRED: 'expired'
  },
  
  // Transaction status
  TRANSACTION: {
    PENDING: 'pending',
    RELEASED: 'released',
    CANCELLED: 'cancelled'
  }
};

/**
 * Product categories
 */
const CATEGORIES = {
  TOPS_SHIRTS: 'tops_shirts',
  PANTS_JEANS: 'pants_jeans',
  JACKETS: 'jackets',
  SHOES: 'shoes',
  ACCESSORIES: 'accessories',
  DRESSES: 'dresses',
  SKIRTS: 'skirts',
  ACTIVEWEAR: 'activewear',
  LINGERIE: 'lingerie',
  SWIMWEAR: 'swimwear'
};

/**
 * Product conditions
 */
const CONDITIONS = {
  NEW: 'new',
  LIKE_NEW: 'like_new',
  GOOD: 'good',
  FAIR: 'fair',
  POOR: 'poor'
};

/**
 * Listing fee tiers
 */
const TIERS = {
  BASIC: 'basic',
  STANDARD: 'standard',
  PREMIUM: 'premium'
};

/**
 * Payment methods
 */
const PAYMENT_METHODS = {
  GCASH: 'gcash',
  CASH: 'cash',
  BANK_TRANSFER: 'bank_transfer',
  MANUAL: 'manual'
};

/**
 * Delivery methods
 */
const DELIVERY_METHODS = {
  MEETUP: 'meetup',
  DELIVERY: 'delivery',
  PICKUP: 'pickup'
};

/**
 * Notification types
 */
const NOTIFICATION_TYPES = {
  SELLER_APPLICATION_SUBMITTED: 'seller_application_submitted',
  SELLER_APPLICATION_APPROVED: 'seller_application_approved',
  SELLER_APPLICATION_REJECTED: 'seller_application_rejected',
  LISTING_SUBMITTED: 'listing_submitted',
  LISTING_APPROVED: 'listing_approved',
  LISTING_REJECTED: 'listing_rejected',
  PAYMENT_SUBMITTED: 'payment_submitted',
  PAYMENT_VERIFIED: 'payment_verified',
  PAYMENT_REJECTED: 'payment_rejected',
  NEW_ORDER: 'new_order',
  ORDER_CONFIRMED: 'order_confirmed',
  ORDER_SHIPPED: 'order_shipped',
  ORDER_DELIVERED: 'order_delivered',
  ORDER_CANCELLED: 'order_cancelled',
  NEW_MESSAGE: 'new_message',
  NEW_OFFER: 'new_offer',
  OFFER_ACCEPTED: 'offer_accepted',
  OFFER_REJECTED: 'offer_rejected',
  PAYOUT_RELEASED: 'payout_released',
  SYSTEM_ALERT: 'system_alert'
};

/**
 * Review types
 */
const REVIEW_TYPES = {
  BUYER_TO_SELLER: 'buyer_to_seller',
  SELLER_TO_BUYER: 'seller_to_buyer'
};

/**
 * Helper function to get all columns for a table
 * @param {string} tableName - Table name from TABLES constant
 * @returns {string[]} Array of column names
 */
function getTableColumns(tableName) {
  const tableKey = Object.keys(TABLES).find(key => TABLES[key] === tableName);
  if (!tableKey || !COLUMNS[tableKey]) {
    return [];
  }
  return Object.values(COLUMNS[tableKey]);
}

/**
 * Helper function to build SELECT clause with all columns
 * @param {string} tableName - Table name from TABLES constant
 * @returns {string} Comma-separated column names for SELECT
 */
function selectAllColumns(tableName) {
  return getTableColumns(tableName).join(', ');
}

// ============================================================
// USAGE EXAMPLES
// ============================================================

/*
// Example 1: Use table constants
import { TABLES, COLUMNS, STATUS } from './db-constants.js';

const { data } = await db
  .from(TABLES.PRODUCTS)
  .select('*')
  .eq(COLUMNS.PRODUCTS.STATUS, STATUS.PRODUCT.APPROVED)
  .eq(COLUMNS.PRODUCTS.IN_STOCK, true);

// Example 2: Use column constants for type safety
const { data: seller } = await db
  .from(TABLES.SELLERS)
  .select(`
    ${COLUMNS.SELLERS.ID},
    ${COLUMNS.SELLERS.BUSINESS_NAME},
    ${COLUMNS.SELLERS.VERIFIED}
  `)
  .eq(COLUMNS.SELLERS.ID, sellerId)
  .single();

// Example 3: Use status constants
await db
  .from(TABLES.ORDERS)
  .update({ [COLUMNS.ORDERS.STATUS]: STATUS.ORDER.CONFIRMED })
  .eq(COLUMNS.ORDERS.ID, orderId);

// Example 4: Use category constants
const { data: jackets } = await db
  .from(TABLES.PRODUCTS)
  .select('*')
  .eq(COLUMNS.PRODUCTS.CATEGORY, CATEGORIES.JACKETS);
*/


// Make constants available globally for non-module scripts
if (typeof window !== 'undefined') {
  window.TABLES = TABLES;
  window.COLUMNS = COLUMNS;
  window.STATUS = STATUS;
  window.CATEGORIES = CATEGORIES;
  window.CONDITIONS = CONDITIONS;
  window.TIERS = TIERS;
  window.PAYMENT_METHODS = PAYMENT_METHODS;
  window.DELIVERY_METHODS = DELIVERY_METHODS;
  window.NOTIFICATION_TYPES = NOTIFICATION_TYPES;
  window.REVIEW_TYPES = REVIEW_TYPES;
  window.getTableColumns = getTableColumns;
  window.selectAllColumns = selectAllColumns;
}
