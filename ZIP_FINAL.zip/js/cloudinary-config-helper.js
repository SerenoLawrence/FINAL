/**
 * Cloudinary Configuration Helper
 * Allows dynamic configuration of Cloudinary cloud name
 * 
 * Usage:
 * 1. Call setCloudinaryConfig('your-cloud-name') before uploading
 * 2. Or set in localStorage: localStorage.setItem('cloudinary_cloud_name', 'your-cloud-name')
 */

class CloudinaryConfigHelper {
  constructor() {
    this.cloudName = this.loadCloudName();
  }

  /**
   * Load cloud name from localStorage or use default
   */
  loadCloudName() {
    // Try to get from localStorage first
    const stored = localStorage.getItem('cloudinary_cloud_name');
    if (stored) {
      console.log('[Cloudinary] Using cloud name from localStorage:', stored);
      return stored;
    }

    // Fall back to hardcoded value (update this)
    const hardcoded = 'YOUR_CLOUD_NAME';
    if (hardcoded !== 'YOUR_CLOUD_NAME') {
      console.log('[Cloudinary] Using hardcoded cloud name:', hardcoded);
      return hardcoded;
    }

    console.warn('[Cloudinary] No cloud name configured. Please set it using setCloudinaryConfig()');
    return null;
  }

  /**
   * Set cloud name and save to localStorage
   */
  setCloudName(cloudName) {
    if (!cloudName || cloudName.trim() === '') {
      console.error('[Cloudinary] Invalid cloud name');
      return false;
    }

    this.cloudName = cloudName.trim();
    localStorage.setItem('cloudinary_cloud_name', this.cloudName);
    console.log('[Cloudinary] Cloud name set to:', this.cloudName);
    return true;
  }

  /**
   * Get the upload URL
   */
  getUploadUrl() {
    if (!this.cloudName || this.cloudName === 'YOUR_CLOUD_NAME') {
      throw new Error('Cloudinary cloud name not configured. Please call setCloudName() first.');
    }
    return `https://api.cloudinary.com/v1_1/${this.cloudName}/image/upload`;
  }

  /**
   * Get the upload preset name
   */
  getUploadPreset() {
    return 'rewear_verifications';
  }

  /**
   * Validate cloud name format
   */
  isValidCloudName(cloudName) {
    // Cloud names are typically alphanumeric with hyphens
    return /^[a-zA-Z0-9_-]+$/.test(cloudName);
  }

  /**
   * Show configuration UI
   */
  showConfigUI() {
    const modal = document.createElement('div');
    modal.id = 'cloudinary-config-modal';
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0,0,0,0.7);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 10000;
    `;

    modal.innerHTML = `
      <div style="
        background: #1a1a2e;
        border: 1px solid #c8a96e;
        border-radius: 12px;
        padding: 30px;
        max-width: 500px;
        color: #fff;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      ">
        <h2 style="margin: 0 0 20px 0; color: #c8a96e;">Configure Cloudinary</h2>
        
        <p style="margin: 0 0 15px 0; color: #b0b0b0; font-size: 14px;">
          Enter your Cloudinary Cloud Name to enable image uploads.
        </p>

        <p style="margin: 0 0 15px 0; color: #999; font-size: 12px;">
          Don't have one? Sign up free at <strong>cloudinary.com</strong>
        </p>

        <input 
          type="text" 
          id="cloudinary-input" 
          placeholder="Enter your cloud name (e.g., abc123def)"
          style="
            width: 100%;
            padding: 12px;
            border: 1px solid #c8a96e;
            border-radius: 6px;
            background: #0e0e10;
            color: #fff;
            font-size: 14px;
            box-sizing: border-box;
            margin-bottom: 20px;
          "
        />

        <div style="display: flex; gap: 10px;">
          <button id="cloudinary-save" style="
            flex: 1;
            padding: 12px;
            background: #c8a96e;
            color: #0e0e10;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            font-size: 14px;
          ">Save</button>
          
          <button id="cloudinary-cancel" style="
            flex: 1;
            padding: 12px;
            background: #333;
            color: #fff;
            border: 1px solid #555;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            font-size: 14px;
          ">Cancel</button>
        </div>

        <p style="margin: 15px 0 0 0; color: #999; font-size: 12px;">
          Your cloud name is stored locally in your browser.
        </p>
      </div>
    `;

    document.body.appendChild(modal);

    const input = document.getElementById('cloudinary-input');
    const saveBtn = document.getElementById('cloudinary-save');
    const cancelBtn = document.getElementById('cloudinary-cancel');

    input.value = this.cloudName || '';
    input.focus();

    saveBtn.addEventListener('click', () => {
      const cloudName = input.value.trim();
      if (!cloudName) {
        alert('Please enter a cloud name');
        return;
      }
      if (!this.isValidCloudName(cloudName)) {
        alert('Invalid cloud name format');
        return;
      }
      this.setCloudName(cloudName);
      modal.remove();
      alert('Cloudinary configured successfully!');
    });

    cancelBtn.addEventListener('click', () => {
      modal.remove();
    });

    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        saveBtn.click();
      }
    });
  }

  /**
   * Check if configured
   */
  isConfigured() {
    return this.cloudName && this.cloudName !== 'YOUR_CLOUD_NAME';
  }

  /**
   * Get status
   */
  getStatus() {
    return {
      configured: this.isConfigured(),
      cloudName: this.cloudName,
      uploadUrl: this.isConfigured() ? this.getUploadUrl() : null
    };
  }
}

// Create global instance
window.cloudinaryConfig = new CloudinaryConfigHelper();

// Log status on page load
document.addEventListener('DOMContentLoaded', () => {
  const status = window.cloudinaryConfig.getStatus();
  console.log('[Cloudinary Config]', status);
  
  if (!status.configured) {
    console.warn('[Cloudinary] Not configured. Call window.cloudinaryConfig.showConfigUI() to configure.');
  }
});
