/**
 * Video Call Initiator
 * Allows sellers to initiate video calls with buyers
 */

class VideoCallInitiator {
  constructor() {
    this.currentUserId = null;
    this.currentUserRole = null;
  }

  /**
   * Initialize video call initiator
   */
  async init(userId, userRole) {
    this.currentUserId = userId;
    this.currentUserRole = userRole;
    
    // Create video call button UI
    this.createVideoCallButtons();
  }

  /**
   * Create video call buttons in chat/order interfaces
   */
  createVideoCallButtons() {
    // This will be called from chat.js and order-tracking.js
    // to add video call buttons to their interfaces
  }

  /**
   * Initiate a video call from seller to buyer
   */
  async initiateCall(buyerId, buyerName, orderId = null, chatId = null) {
    try {
      // Check if buyer is online
      const buyerPresence = await window.userPresenceManager?.getUserPresence(buyerId);
      
      if (!buyerPresence?.is_online) {
        this.showNotification('Buyer is currently offline', 'warning');
        return false;
      }

      // Generate room ID
      const roomId = this.generateRoomId();
      
      // Get current user info
      const currentUser = window.authManager?.getCurrentUser();
      const sellerName = currentUser?.name || 'Seller';

      // Create call invitation in database
      const { data: invitation, error: inviteError } = await db
        .from('video_call_invitations')
        .insert({
          caller_id: this.currentUserId,
          caller_name: sellerName,
          caller_role: 'seller',
          callee_id: buyerId,
          callee_name: buyerName,
          callee_role: 'buyer',
          room_id: roomId,
          order_id: orderId,
          chat_id: chatId,
          status: 'pending',
          created_at: new Date().toISOString()
        })
        .select()
        .single();

      if (inviteError) throw inviteError;

      // Send notification to buyer
      await this.sendCallNotification(buyerId, buyerName, sellerName, roomId, invitation.id);

      // Open video call page for seller (as host)
      this.openVideoCallPage(roomId, sellerName, 'host');

      return true;
    } catch (error) {
      console.error('[video-call-initiator] Error initiating call:', error);
      this.showNotification('Failed to initiate call: ' + error.message, 'error');
      return false;
    }
  }

  /**
   * Send call notification to buyer
   */
  async sendCallNotification(buyerId, buyerName, sellerName, roomId, invitationId) {
    try {
      // Create notification
      await db.from('notifications').insert({
        user_id: buyerId,
        notification_type: 'incoming_video_call',
        title: `📹 Incoming Video Call`,
        message: `${sellerName} is calling you`,
        data: {
          invitation_id: invitationId,
          room_id: roomId,
          caller_id: this.currentUserId,
          caller_name: sellerName
        },
        is_read: false,
        created_at: new Date().toISOString()
      });

      // Also send real-time notification via Supabase
      await this.sendRealtimeNotification(buyerId, {
        type: 'incoming_call',
        room_id: roomId,
        caller_name: sellerName,
        invitation_id: invitationId
      });
    } catch (error) {
      console.error('[video-call-initiator] Error sending notification:', error);
    }
  }

  /**
   * Send real-time notification via Supabase
   */
  async sendRealtimeNotification(userId, data) {
    try {
      await db
        .channel(`user_notifications:${userId}`)
        .send({
          type: 'broadcast',
          event: 'incoming_call',
          payload: data
        });
    } catch (error) {
      console.warn('[video-call-initiator] Real-time notification failed:', error);
    }
  }

  /**
   * Accept incoming call (buyer side)
   */
  async acceptCall(invitationId, roomId, callerName) {
    try {
      // Update invitation status
      const { error } = await db
        .from('video_call_invitations')
        .update({ status: 'accepted' })
        .eq('id', invitationId);

      if (error) throw error;

      // Get current user info
      const currentUser = window.authManager?.getCurrentUser();
      const buyerName = currentUser?.name || 'Buyer';

      // Open video call page for buyer (as joiner)
      this.openVideoCallPage(roomId, buyerName, 'join');

      return true;
    } catch (error) {
      console.error('[video-call-initiator] Error accepting call:', error);
      this.showNotification('Failed to accept call: ' + error.message, 'error');
      return false;
    }
  }

  /**
   * Decline incoming call
   */
  async declineCall(invitationId) {
    try {
      const { error } = await db
        .from('video_call_invitations')
        .update({ status: 'declined' })
        .eq('id', invitationId);

      if (error) throw error;

      this.showNotification('Call declined', 'info');
      return true;
    } catch (error) {
      console.error('[video-call-initiator] Error declining call:', error);
      return false;
    }
  }

  /**
   * Open video call page
   */
  openVideoCallPage(roomId, userName, mode) {
    const url = new URL('peer.html', window.location.origin);
    url.searchParams.set('room', roomId);
    url.searchParams.set('mode', mode);
    url.searchParams.set('name', encodeURIComponent(userName));
    
    // Open in new window or tab
    window.open(url.toString(), 'video-call', 'width=1280,height=720,resizable=yes');
  }

  /**
   * Generate room ID
   */
  generateRoomId() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let id = '';
    for (let i = 0; i < 8; i++) {
      id += chars[Math.floor(Math.random() * chars.length)];
    }
    return id;
  }

  /**
   * Show notification
   */
  showNotification(message, type = 'info') {
    // Use existing toast system
    if (window.showToast) {
      window.showToast(message, type);
    } else {
      alert(message);
    }
  }

  /**
   * Log call to database
   */
  async logCall(invitationId, duration, status) {
    try {
      await db.from('call_logs').insert({
        invitation_id: invitationId,
        duration_seconds: duration,
        status: status,
        created_at: new Date().toISOString()
      });
    } catch (error) {
      console.warn('[video-call-initiator] Error logging call:', error);
    }
  }
}

// Create global instance
window.videoCallInitiator = new VideoCallInitiator();

console.log('[video-call-initiator] Video call initiator loaded');
