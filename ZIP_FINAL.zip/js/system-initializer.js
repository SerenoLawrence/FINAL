/**
 * System Initializer
 * Initializes all system components in the correct order
 */

class SystemInitializer {
  constructor() {
    this.isInitialized = false;
    this.initPromise = null;
  }

  /**
   * Initialize all systems
   */
  async initialize() {
    if (this.isInitialized) return;
    if (this.initPromise) return this.initPromise;

    this.initPromise = this._doInitialize();
    return this.initPromise;
  }

  /**
   * Do initialization
   */
  async _doInitialize() {
    try {
      console.log('[system-initializer] Starting system initialization...');

      // Wait for auth to be ready
      await this.waitForAuth();
      const user = window.authManager?.getCurrentUser();
      if (!user) {
        console.warn('[system-initializer] No authenticated user');
        return;
      }

      console.log('[system-initializer] User authenticated:', user.id);

      // Get user role
      const userRole = await this.getUserRole(user.id);
      console.log('[system-initializer] User role:', userRole);

      // Initialize notification center
      if (window.notificationCenter) {
        await window.notificationCenter.init(user.id);
        console.log('[system-initializer] Notification center initialized');
      }

      // Initialize presence manager
      if (window.userPresenceManager) {
        await window.userPresenceManager.init(user.id);
        console.log('[system-initializer] Presence manager initialized');
      }

      // Initialize incoming call handler
      if (window.incomingCallHandler) {
        await window.incomingCallHandler.init(user.id);
        console.log('[system-initializer] Incoming call handler initialized');
      }

      // Initialize video call initiator
      if (window.videoCallInitiator) {
        await window.videoCallInitiator.init(user.id, userRole);
        console.log('[system-initializer] Video call initiator initialized');
      }

      // Initialize dashboard video call integration
      if (window.dashboardVideoCallIntegration) {
        await window.dashboardVideoCallIntegration.init(user.id, userRole);
        console.log('[system-initializer] Dashboard video call integration initialized');
      }

      this.isInitialized = true;
      console.log('[system-initializer] System initialization complete');

      // Emit initialization complete event
      window.dispatchEvent(new CustomEvent('systemInitialized', {
        detail: { userId: user.id, userRole }
      }));

    } catch (error) {
      console.error('[system-initializer] Initialization error:', error);
      throw error;
    }
  }

  /**
   * Wait for auth to be ready
   */
  async waitForAuth() {
    let waited = 0;
    while (!window.authManager?.isInitialized && waited < 10000) {
      await new Promise(r => setTimeout(r, 200));
      waited += 200;
    }

    if (!window.authManager?.isInitialized) {
      throw new Error('Auth manager not initialized');
    }
  }

  /**
   * Get user role
   */
  async getUserRole(userId) {
    try {
      // Check if user is seller
      const { data: seller, error: sellerError } = await db
        .from('sellers')
        .select('id')
        .eq('user_id', userId)
        .single();

      if (!sellerError && seller) {
        return 'seller';
      }

      // Otherwise, user is buyer
      return 'buyer';
    } catch (error) {
      console.warn('[system-initializer] Error getting user role:', error);
      return 'buyer'; // Default to buyer
    }
  }

  /**
   * Check if system is initialized
   */
  isReady() {
    return this.isInitialized;
  }
}

// Create global instance
window.systemInitializer = new SystemInitializer();

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.systemInitializer.initialize().catch(error => {
      console.error('[system-initializer] Failed to initialize:', error);
    });
  });
} else {
  window.systemInitializer.initialize().catch(error => {
    console.error('[system-initializer] Failed to initialize:', error);
  });
}

console.log('[system-initializer] System initializer loaded');
