// ============================================================
// mobile-header.js — Mobile Header Functionality for All Pages
// ============================================================

(function() {
    const mobileHeader = document.querySelector('.mobile-dashboard-header');
    const navbar = document.querySelector('.navbar');
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const navMenu = document.getElementById('navMenu');
    
    // Toggle between mobile header and desktop navbar
    function checkMobile() {
        if (window.innerWidth <= 767) {
            if (mobileHeader) mobileHeader.style.display = 'flex';
            if (navbar) navbar.style.display = 'none';
        } else {
            if (mobileHeader) mobileHeader.style.display = 'none';
            if (navbar) navbar.style.display = 'block';
        }
    }
    
    // Initialize on load
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    // Hamburger menu toggle
    if (mobileMenuBtn && navMenu) {
        mobileMenuBtn.addEventListener('click', () => {
            navMenu.classList.toggle('mobile-open');
        });
    }
    
    // Messages button
    const mobileMessagesBtn = document.getElementById('mobileMessagesBtn');
    if (mobileMessagesBtn) {
        mobileMessagesBtn.addEventListener('click', () => {
            // Detect if we're in pages/ folder or root
            const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
            window.location.href = prefix + 'dashboard.html#messages';
        });
    }
    
    // Notifications button
    const mobileNotificationsBtn = document.getElementById('mobileNotificationsBtn');
    if (mobileNotificationsBtn) {
        mobileNotificationsBtn.addEventListener('click', () => {
            alert('Notifications feature coming soon!');
        });
    }
    
    // Profile button
    const mobileProfileBtn = document.getElementById('mobileProfileBtn');
    if (mobileProfileBtn) {
        mobileProfileBtn.addEventListener('click', () => {
            // Detect if we're in pages/ folder or root
            const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
            window.location.href = prefix + 'dashboard.html#profile';
        });
    }
    
    console.log('[Mobile Header] Initialized');
})();
