// ============================================================
// checkout.js — Checkout Page Logic
// ============================================================

let currentUser = null;
let uploadedReceiptUrl = null;
let checkoutItems = [];

// Load order summary
async function loadOrderSummary() {
  const orderItemsEl = document.getElementById('orderItems');
  
  // Check if Supabase is ready
  if (!window.db) {
    console.error('[checkout] Supabase not initialized');
    alert('System not ready. Please refresh the page.');
    return;
  }  
  // Check if coming from direct product link (URL params)
  const urlParams = new URLSearchParams(window.location.search);
  const productId = urlParams.get('productId');
  const size = urlParams.get('size');
  
  if (productId && size) {
    // Direct purchase from product page
    try {
      console.log('[checkout] Loading product:', productId);
      console.log('[checkout] Size:', size);
      
      // Try to fetch the product
      const { data: product, error } = await db
        .from('products')
        .select('*')
        .eq('id', productId)
        .limit(1)
        .then(r => ({ data: r.data?.[0] || null, error: r.error }));
      
      if (error) {
        console.error('[checkout] Database error:', error);
        throw new Error(`Database error: ${error.message}`);
      }
      
      if (!product) {
        console.error('[checkout] Product not found in database');
        throw new Error('Product not found in database');
      }
      
      console.log('[checkout] Product loaded:', product);
      
      checkoutItems = [{
        id: product.id,
        name: product.name,
        price: parseFloat(product.price),
        image: product.image_url,
        size: size,
        quantity: 1,
        seller_id: product.seller_id
      }];
      
      console.log('[checkout] Direct purchase loaded:', product.name);
    } catch (error) {
      console.error('[checkout] Error loading product:', error);
      alert('Unable to load product. Please try again or contact support.\n\nError: ' + error.message);
      // Don't redirect immediately, let user see the error
      setTimeout(() => {
        location.href = 'shop.html';
      }, 3000);
      return;
    }
  } else if (window.cart && window.cart.getItems().length > 0) {
    // Purchase from cart
    checkoutItems = window.cart.getItems();
    console.log('[checkout] Cart purchase:', checkoutItems.length, 'items');
  } else {
    // No items
    console.log('[checkout] No items found');
    alert('Your cart is empty!');
    location.href = 'shop.html';
    return;
  }
  
  // Render items
  orderItemsEl.innerHTML = checkoutItems.map(item => `
    <div class="order-item">
      <img src="${item.image || 'https://via.placeholder.com/60'}" alt="${item.name}">
      <div class="order-item-details">
        <h4>${item.name}</h4>
        <p>Size: ${item.size} | Qty: ${item.quantity}</p>
        <p style="font-weight: 600; color: #c8a96e;">₱${(item.price * item.quantity).toFixed(2)}</p>
      </div>
    </div>
  `).join('');
  
  // Update summary — no fixed shipping, arranged via chat
  const subtotal = checkoutItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const total    = subtotal;
  
  document.getElementById('summarySubtotal').textContent = `₱${subtotal.toFixed(2)}`;
  // summaryShipping is already set to "Via chat with seller" in HTML
  document.getElementById('summaryTotal').textContent = `₱${total.toFixed(2)}`;
  
  console.log('[checkout] Order summary loaded successfully');
}

// Select payment method (GCash only)
function selectPayment(method) {
  document.querySelectorAll('.payment-method').forEach(el => {
    el.classList.remove('selected');
  });
  
  const radio = document.getElementById(`payment${method.charAt(0).toUpperCase() + method.slice(1)}`);
  if (radio) {
    radio.checked = true;
    radio.closest('.payment-method').classList.add('selected');
  }
  
  // Receipt upload is always required
  const receiptInput = document.getElementById('receiptFile');
  if (receiptInput) receiptInput.required = true;
}

// Handle receipt file selection
function handleReceiptFileSelect(e) {
  const file = e.target.files[0];
  if (!file) return;
  showReceiptPreview(file);
}

// Show receipt preview in drop zone
function showReceiptPreview(file) {
  const dropIcon = document.getElementById('receiptDropIcon');
  const dropPreview = document.getElementById('receiptDropPreview');
  const previewImg = document.getElementById('receiptPreviewImg');
  const fileName = document.getElementById('receiptFileName');
  const fileSize = document.getElementById('receiptFileSize');

  const reader = new FileReader();
  reader.onload = (event) => {
    previewImg.src = event.target.result;
    dropIcon.style.display = 'none';
    dropPreview.style.display = 'flex';
  };
  reader.readAsDataURL(file);

  fileName.textContent = file.name;
  fileSize.textContent = (file.size / 1024).toFixed(1) + ' KB';
}

// Remove selected receipt
function removeReceipt(e) {
  e.stopPropagation(); // Don't trigger the drop zone click
  document.getElementById('receiptFile').value = '';
  document.getElementById('receiptDropIcon').style.display = 'flex';
  document.getElementById('receiptDropPreview').style.display = 'none';
}

// Setup drag & drop on the receipt zone
function setupReceiptDropZone() {
  const zone = document.getElementById('receiptDropZone');
  const input = document.getElementById('receiptFile');
  if (!zone || !input) return;

  zone.addEventListener('dragover', (e) => {
    e.preventDefault();
    zone.classList.add('drag-over');
  });

  zone.addEventListener('dragleave', () => {
    zone.classList.remove('drag-over');
  });

  zone.addEventListener('drop', (e) => {
    e.preventDefault();
    zone.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
      // Set the file on the input
      const dt = new DataTransfer();
      dt.items.add(file);
      input.files = dt.files;
      showReceiptPreview(file);
    }
  });
}

// Upload receipt to Cloudinary
async function uploadReceipt(file, orderId) {
  const progressSection = document.getElementById('receiptUploadProgress');
  const progressBar = document.getElementById('receiptProgressBar');
  const progressText = document.getElementById('receiptProgressText');
  
  try {
    // Show progress
    progressSection.style.display = 'block';
    progressBar.style.width = '30%';
    progressText.textContent = 'Uploading receipt...';
    
    // Upload using helper function
    const receiptUrl = await window.uploadPaymentReceipt(file, orderId);
    
    // Complete
    progressBar.style.width = '100%';
    progressText.textContent = 'Upload complete!';
    
    console.log('[checkout] Receipt uploaded:', receiptUrl);
    return receiptUrl;
    
  } catch (error) {
    console.error('[checkout] Receipt upload failed:', error);
    progressText.textContent = 'Upload failed: ' + error.message;
    progressText.style.color = '#dc3545';
    throw error;
  }
}

// Load user data if logged in
async function loadUserData() {
  try {
    const { data: { user } } = await db.auth.getUser();
    
    if (user) {
      currentUser = user;
      
      // Try to get buyer data
      const { data: buyer } = await db
        .from('buyers')
        .select('*')
        .eq('email', user.email)
        .single();
      
      if (buyer) {
        // Pre-fill form
        document.getElementById('fullName').value = buyer.name || '';
        document.getElementById('email').value = buyer.email || '';
        document.getElementById('phone').value = buyer.phone || '';
      } else {
        // Just fill email
        document.getElementById('email').value = user.email || '';
      }
    }
  } catch (error) {
    console.log('[checkout] User not logged in or error:', error.message);
  }
}

// Handle form submission
async function handleCheckout(e) {
  e.preventDefault();
  
  const submitBtn = e.target.querySelector('button[type="submit"]');
  submitBtn.disabled = true;
  submitBtn.textContent = 'Processing...';
  
  try {
    // Get form data
    const formData = new FormData(e.target);
    const shippingInfo = {
      fullName:            formData.get('fullName'),
      email:               formData.get('email'),
      phone:               formData.get('phone'),
      notes:               formData.get('notes'),
      delivery_preference: formData.get('deliveryPreference') || 'meetup',
      delivery_address:    formData.get('deliveryAddress') || null
    };
    
    const paymentMethod = formData.get('payment');
    const items    = checkoutItems;
    const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const total    = subtotal; // No fixed shipping — arranged via chat
    
    // Handle receipt upload (required for all payments)
    const receiptFile = document.getElementById('receiptFile').files[0];
    
    if (!receiptFile) {
      alert('Please upload a payment receipt');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Place Order';
      return;
    }
    
    // Upload receipt first (use temporary order ID)
    const tempOrderId = `temp_${Date.now()}`;
    submitBtn.textContent = 'Uploading receipt...';
    const receiptUrl = await uploadReceipt(receiptFile, tempOrderId);
    console.log('[checkout] Receipt uploaded successfully:', receiptUrl);
    
    // Get or create buyer user_id
    let buyerUserId = null;
    if (currentUser) {
      buyerUserId = currentUser.id;
    }
    
    // Create orders for each item
    submitBtn.textContent = 'Creating orders...';
    const orderPromises = items.map(async (item) => {
      const orderData = {
        product_id: item.id,
        seller_id: item.seller_id,
        buyer_user_id: buyerUserId,
        buyer_name: shippingInfo.fullName,
        buyer_email: shippingInfo.email,
        size_selected: item.size,
        quantity: item.quantity,
        total_price: item.price * item.quantity,
        status: 'pending'
        // Note: payment_method and payment_receipt_url are not in the orders table schema
        // Receipt is uploaded to Cloudinary and can be stored separately if needed
        // Payment method: ${paymentMethod}
        // Receipt URL: ${receiptUrl}
      };
      
      const { data, error } = await db
        .from('orders')
        .insert([orderData])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    });
    
    const orders = await Promise.all(orderPromises);
    
    console.log('[checkout] Orders created:', orders);
    
    // Clear cart if items came from cart
    const urlParams = new URLSearchParams(window.location.search);
    if (!urlParams.get('productId') && window.cart) {
      window.cart.clearCart();
    }
    
    // Redirect to confirmation page with order IDs
    const orderIds = orders.map(o => o.id).join(',');
    location.href = `order-confirmation.html?orders=${orderIds}`;
    
  } catch (error) {
    console.error('[checkout] Error:', error);
    alert('Failed to place order: ' + error.message);
    submitBtn.disabled = false;
    submitBtn.textContent = 'Place Order';
  }
}

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
  await loadOrderSummary();
  await loadUserData();
  
  // Add form submit handler
  document.getElementById('checkoutForm').addEventListener('submit', handleCheckout);
  
  // Add receipt file input handler
  const receiptInput = document.getElementById('receiptFile');
  if (receiptInput) {
    receiptInput.addEventListener('change', handleReceiptFileSelect);
  }
  
  // Setup drag & drop
  setupReceiptDropZone();
  
  // Set default payment method
  selectPayment('gcash');
});

console.log('[checkout] Checkout page initialized');
