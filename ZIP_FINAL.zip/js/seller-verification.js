﻿// ============================================================
// seller-verification.js — FREE Seller Verification System
// Uses: Tesseract.js (OCR) + Face-api.js (Face Matching)
// ============================================================

let currentStep = 1;
const totalSteps = 5;
let verificationData = {
    seller_type: '',
    personal_info: {},
    id_info: {},
    images: {
        id_front: null,
        id_back: null,
        selfie: null
    },
    ai_results: {
        ocr_text: '',
        face_match: null
    }
};

// ---- INITIALIZATION ----
document.addEventListener('DOMContentLoaded', async () => {
    // Only run on seller-verification page
    if (!document.getElementById('email')) return;

    // Poll for auth to be ready (up to 5s)
    let waited = 0;
    while (!window.authManager?.isInitialized && waited < 5000) {
        await new Promise(r => setTimeout(r, 200));
        waited += 200;
    }

    const user = window.authManager?.getCurrentUser();
    if (!user) {
        showToast('Please log in first', 'error');
        window.location.href = 'login.html';
        return;
    }

    // Pre-fill email
    const emailField = document.getElementById('email');
    if (emailField) emailField.value = user.email;

    // Check if already verified or pending — if so, show status screen and stop
    const shouldStop = await checkExistingVerification(user.id);
    if (shouldStop) return;

    // Setup event listeners only if form is shown
    setupEventListeners();
});

// ---- CHECK EXISTING VERIFICATION ----
async function checkExistingVerification(userId) {
    try {
        const { data: rows, error } = await db
            .from('seller_verifications')
            .select('status, rejection_reason')
            .eq('user_id', userId)
            .order('submitted_at', { ascending: false })
            .limit(1);

        if (error) {
            showToast('Unable to check verification status. Please try again.', 'warning');
            return false; // don't block the form on error
        }

        const data = rows && rows.length > 0 ? rows[0] : null;

        if (data) {
            if (data.status === 'approved') {
                showStatusScreen(
                    '&#10003;',
                    '#27ae60',
                    'Already Verified!',
                    'You are already a verified seller on REWEAR. You can start listing products right away.'
                );
                return true;
            } else if (data.status === 'pending') {
                showStatusScreen(
                    '&#9203;',
                    '#c8a96e',
                    'Verification Under Review',
                    'Your identity verification has been submitted and is being reviewed by our team. This usually takes 1-2 business days. You will be notified once approved.'
                );
                return true;
            } else if (data.status === 'rejected') {
                // Show warning but let them resubmit
                showMessage('Previous Verification Rejected', data.rejection_reason || 'Please resubmit with correct documents.', 'warning');
                return false;
            }
        }
    } catch (e) {
        showToast('An error occurred while checking verification status.', 'warning');
        // Don't block the form on exception
    }
    return false;
}

// ---- IN-PAGE TOAST (replaces alert()) ----
function showToast(message, type = 'error') {
    // Remove existing toast
    document.getElementById('svToast')?.remove();

    const colors = {
        error:   { bg: '#e74c3c', icon: '&#10005;' },
        warning: { bg: '#c8a96e', icon: '&#9888;' },
        success: { bg: '#27ae60', icon: '&#10003;' },
        info:    { bg: '#1a1a2e', icon: '&#8505;' }
    };
    const c = colors[type] || colors.error;

    const toast = document.createElement('div');
    toast.id = 'svToast';
    toast.style.cssText = `
        position: fixed;
        top: 80px;
        left: 50%;
        transform: translateX(-50%);
        background: ${c.bg};
        color: #fff;
        padding: 14px 20px;
        border-radius: 12px;
        font-size: 14px;
        font-weight: 600;
        font-family: system-ui, sans-serif;
        box-shadow: 0 8px 24px rgba(0,0,0,.25);
        z-index: 99999;
        max-width: 90vw;
        width: max-content;
        display: flex;
        align-items: center;
        gap: 10px;
        animation: svSlideIn .25s ease;
    `;
    toast.innerHTML = `
        <span style="font-size:18px;">${c.icon}</span>
        <span>${message}</span>
        <button onclick="this.parentElement.remove()" style="background:none;border:none;color:rgba(255,255,255,.7);font-size:18px;cursor:pointer;padding:0 0 0 8px;line-height:1;">&times;</button>
    `;

    // Add animation
    if (!document.getElementById('svToastStyle')) {
        const style = document.createElement('style');
        style.id = 'svToastStyle';
        style.textContent = '@keyframes svSlideIn{from{opacity:0;transform:translateX(-50%) translateY(-12px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}';
        document.head.appendChild(style);
    }

    document.body.appendChild(toast);
    setTimeout(() => toast?.remove(), 5000);
}
function showStatusScreen(iconHtml, iconColor, title, message) {
    const rules  = document.getElementById('rulesScreen');
    const form   = document.getElementById('verificationFormContainer');
    const screen = document.getElementById('verificationStatusScreen');
    const iconEl = document.getElementById('statusIcon');
    const titleEl = document.getElementById('statusTitle');
    const msgEl   = document.getElementById('statusMessage');

    if (rules)  rules.style.display  = 'none';
    if (form)   form.style.display   = 'none';
    if (screen) screen.style.display = 'block';

    if (iconEl)  iconEl.innerHTML = `<div style="width:80px;height:80px;border-radius:50%;background:${iconColor}20;border:3px solid ${iconColor};display:flex;align-items:center;justify-content:center;margin:0 auto;font-size:36px;color:${iconColor};">${iconHtml}</div>`;
    if (titleEl) titleEl.textContent = title;
    if (msgEl)   msgEl.textContent   = message;
}

// ---- SETUP EVENT LISTENERS ----
function setupEventListeners() {
    // Seller type selection
    document.querySelectorAll('.seller-type-card').forEach(card => {
        card.addEventListener('click', () => {
            document.querySelectorAll('.seller-type-card').forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
            const type = card.dataset.type;
            document.getElementById('sellerType').value = type;
            document.getElementById('step1Next').disabled = false;
            verificationData.seller_type = type;
        });
    });

    // Step 1 next button
    document.getElementById('step1Next').addEventListener('click', nextStep);

    // Image uploads
    document.getElementById('idFrontInput').addEventListener('change', (e) => handleImageUpload(e, 'idFront'));
    document.getElementById('idBackInput').addEventListener('change', (e) => handleImageUpload(e, 'idBack'));
    document.getElementById('selfieInput').addEventListener('change', (e) => handleImageUpload(e, 'selfie'));

    // Terms checkbox
    document.getElementById('agreeTerms').addEventListener('change', (e) => {
        document.getElementById('submitBtn').disabled = !e.target.checked;
    });

    // Form submission
    document.getElementById('verificationForm').addEventListener('submit', handleSubmit);
}

// ---- NAVIGATION ----
function nextStep() {
    if (currentStep < totalSteps) {
        // Validate current step
        if (!validateStep(currentStep)) {
            return;
        }

        // Save data from current step
        saveStepData(currentStep);

        // Move to next step
        currentStep++;
        updateStepDisplay();

        // Special handling for review step
        if (currentStep === 5) {
            populateReview();
        }
    }
}

function previousStep() {
    if (currentStep > 1) {
        currentStep--;
        updateStepDisplay();
    }
}

function updateStepDisplay() {
    // Update progress steps
    document.querySelectorAll('.progress-step').forEach((step, index) => {
        const stepNum = index + 1;
        step.classList.remove('active', 'completed');
        
        if (stepNum < currentStep) {
            step.classList.add('completed');
        } else if (stepNum === currentStep) {
            step.classList.add('active');
        }
    });

    // Update form steps
    document.querySelectorAll('.form-step').forEach((step, index) => {
        step.classList.remove('active');
        if (index + 1 === currentStep) {
            step.classList.add('active');
        }
    });

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ---- VALIDATION ----
function validateStep(step) {
    switch(step) {
        case 1:
            if (!verificationData.seller_type) {
                showToast('Please select a seller type', 'warning');
                return false;
            }
            return true;

        case 2:
            const requiredFields = ['firstName', 'lastName', 'dateOfBirth', 'phoneNumber', 'streetAddress', 'postalCode'];
            for (const field of requiredFields) {
                const input = document.getElementById(field);
                if (!input || !input.value.trim()) {
                    const label = input?.previousElementSibling?.textContent || field;
                    showToast(`Please fill in: ${label}`, 'warning');
                    if (input) input.focus();
                    return false;
                }
            }
            // Check province and city (could be select or input)
            const provEl = document.getElementById('province');
            const cityEl = document.getElementById('city');
            if (!provEl?.value?.trim()) { showToast('Please select a Province', 'warning'); return false; }
            if (!cityEl?.value?.trim()) { showToast('Please select a City / Municipality', 'warning'); return false; }
            // Check date of birth dropdowns
            if (!document.getElementById('dobYear')?.value ||
                !document.getElementById('dobMonth')?.value ||
                !document.getElementById('dobDay')?.value) {
                showToast('Please select your complete Date of Birth', 'warning');
                return false;
            }
            return true;

        case 3:
            if (!document.getElementById('idType').value) {
                showToast('Please select an ID type', 'warning');
                return false;
            }
            if (!document.getElementById('idNumber').value.trim()) {
                showToast('Please enter your ID number', 'warning');
                return false;
            }
            if (!verificationData.images.id_front || !verificationData.images.id_back) {
                showToast('Please upload both front and back of your ID', 'warning');
                return false;
            }
            return true;

        case 4:
            if (!verificationData.images.selfie) {
                showToast('Please upload a selfie holding your ID', 'warning');
                return false;
            }
            return true;

        default:
            return true;
    }
}

// ---- SAVE STEP DATA ----
function saveStepData(step) {
    switch(step) {
        case 2:
            // SECURITY: Sanitize all text inputs
            const sanitize = window.VerificationSecurity?.sanitizeText || (text => text);
            
            verificationData.personal_info = {
                first_name: sanitize(document.getElementById('firstName').value.trim(), 50),
                middle_name: sanitize(document.getElementById('middleName').value.trim(), 50),
                last_name: sanitize(document.getElementById('lastName').value.trim(), 50),
                date_of_birth: document.getElementById('dateOfBirth').value,
                phone_number: sanitize(document.getElementById('phoneNumber').value.trim(), 20),
                email: sanitize(document.getElementById('email').value.trim(), 100),
                street_address: sanitize(document.getElementById('streetAddress').value.trim(), 200),
                city: sanitize(document.getElementById('city').value.trim(), 100),
                province: sanitize(document.getElementById('province').value.trim(), 100),
                postal_code: sanitize(document.getElementById('postalCode').value.trim(), 10)
            };
            break;

        case 3:
            // SECURITY: Sanitize ID information
            const sanitizeId = window.VerificationSecurity?.sanitizeText || (text => text);
            
            verificationData.id_info = {
                id_type: document.getElementById('idType').value,
                id_number: sanitizeId(document.getElementById('idNumber').value.trim(), 20)
            };
            break;
    }
}

// ---- IMAGE UPLOAD HANDLING ----
async function handleImageUpload(event, type) {
    const file = event.target.files[0];
    if (!file) return;

    // SECURITY: Validate image using security layer
    if (window.VerificationSecurity) {
        const validationErrors = await window.VerificationSecurity.validateImage(file, type);
        if (validationErrors.length > 0) {
            showToast('Image validation failed: ' + validationErrors.join(', '), 'error');
            event.target.value = '';
            return;
        }
    } else {
        // Fallback validation if security layer not loaded
        if (file.size > 5 * 1024 * 1024) {
            showToast('Image size must be less than 5MB', 'warning');
            event.target.value = '';
            return;
        }

        if (!file.type.startsWith('image/')) {
            showToast('Please upload an image file (JPG, PNG)', 'warning');
            event.target.value = '';
            return;
        }
    }

    // Read and preview image
    const reader = new FileReader();
    reader.onload = (e) => {
        const imageData = e.target.result;
        
        // Update preview
        const previewId = type + 'Preview';
        const boxId = type + 'Box';
        document.getElementById(previewId).src = imageData;
        document.getElementById(boxId).classList.add('has-image');

        // Store image data
        if (type === 'idFront') {
            verificationData.images.id_front = imageData;
            checkStep3Complete();
        } else if (type === 'idBack') {
            verificationData.images.id_back = imageData;
            checkStep3Complete();
        } else if (type === 'selfie') {
            verificationData.images.selfie = imageData;
            document.getElementById('step4Next').disabled = false;
        }
    };
    reader.readAsDataURL(file);
}

function checkStep3Complete() {
    const hasIdType = document.getElementById('idType').value;
    const hasIdNumber = document.getElementById('idNumber').value.trim();
    const hasBothImages = verificationData.images.id_front && verificationData.images.id_back;
    
    document.getElementById('step3Next').disabled = !(hasIdType && hasIdNumber && hasBothImages);
}

// Enable step3Next when ID type or number changes
document.getElementById('idType')?.addEventListener('change', checkStep3Complete);
document.getElementById('idNumber')?.addEventListener('input', checkStep3Complete);

// ---- POPULATE REVIEW ----
function populateReview() {
    const { personal_info, id_info, seller_type } = verificationData;
    
    const reviewHTML = `
        <div style="display: grid; gap: 16px;">
            <div style="padding: 16px; background: #f9f9f9; border-radius: 8px;">
                <h4 style="margin: 0 0 12px; font-size: 14px; color: #666; text-transform: uppercase;">Seller Type</h4>
                <p style="margin: 0; font-size: 16px; font-weight: 600; color: #1a1a2e;">${seller_type === 'individual' ? '👤 Individual' : '🏢 Business'}</p>
            </div>
            
            <div style="padding: 16px; background: #f9f9f9; border-radius: 8px;">
                <h4 style="margin: 0 0 12px; font-size: 14px; color: #666; text-transform: uppercase;">Personal Information</h4>
                <p style="margin: 0 0 4px;"><strong>Name:</strong> ${personal_info.first_name} ${personal_info.middle_name} ${personal_info.last_name}</p>
                <p style="margin: 0 0 4px;"><strong>Date of Birth:</strong> ${personal_info.date_of_birth}</p>
                <p style="margin: 0 0 4px;"><strong>Phone:</strong> ${personal_info.phone_number}</p>
                <p style="margin: 0 0 4px;"><strong>Email:</strong> ${personal_info.email}</p>
                <p style="margin: 0;"><strong>Address:</strong> ${personal_info.street_address}, ${personal_info.city}, ${personal_info.province} ${personal_info.postal_code}</p>
            </div>
            
            <div style="padding: 16px; background: #f9f9f9; border-radius: 8px;">
                <h4 style="margin: 0 0 12px; font-size: 14px; color: #666; text-transform: uppercase;">ID Information</h4>
                <p style="margin: 0 0 4px;"><strong>ID Type:</strong> ${id_info.id_type.replace(/_/g, ' ').toUpperCase()}</p>
                <p style="margin: 0;"><strong>ID Number:</strong> ${id_info.id_number}</p>
            </div>
            
            <div style="padding: 16px; background: #f9f9f9; border-radius: 8px;">
                <h4 style="margin: 0 0 12px; font-size: 14px; color: #666; text-transform: uppercase;">Uploaded Documents</h4>
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px;">
                    <img src="${verificationData.images.id_front}" style="width: 100%; height: 100px; object-fit: cover; border-radius: 6px;">
                    <img src="${verificationData.images.id_back}" style="width: 100%; height: 100px; object-fit: cover; border-radius: 6px;">
                    <img src="${verificationData.images.selfie}" style="width: 100%; height: 100px; object-fit: cover; border-radius: 6px;">
                </div>
            </div>
        </div>
    `;
    
    document.getElementById('reviewContent').innerHTML = reviewHTML;
}

// ---- FORM SUBMISSION ----
async function handleSubmit(e) {
    e.preventDefault();
    
    const user = window.authManager?.getCurrentUser();
    if (!user) {
        showToast('Session expired. Please log in again.', 'error');
        window.location.href = 'login.html';
        return;
    }

    // SECURITY: Comprehensive validation before submission
    if (window.VerificationSecurity && !window.VERIFICATION_TEST_MODE) {
        showProcessing('Validating submission...');
        
        const validation = await window.VerificationSecurity.validateSubmission(verificationData, user.id);
        
        if (!validation.valid) {
            hideProcessing();
            showToast('Validation failed: ' + validation.errors[0], 'error');
            await window.VerificationSecurity.logSecurityEvent(user.id, 'validation_failed', {
                errors: validation.errors
            });
            return;
        }
        showToast('Validation passed. Processing your submission...', 'success');
    } else if (window.VERIFICATION_TEST_MODE) {
        console.log('[TEST MODE] Skipping security validation');
    }

    // Show processing overlay
    showProcessing('Analyzing your documents...');

    try {
        // TEST MODE: simulate processing delay
        if (window.VERIFICATION_TEST_MODE) {
            updateProcessing('Test mode: skipping AI analysis...');
            await new Promise(r => setTimeout(r, 800));
        }

        // Step 1: Run OCR on ID front
        updateProcessing('Extracting text from ID...');
        const ocrText = await runOCR(verificationData.images.id_front);
        verificationData.ai_results.ocr_text = ocrText;
        showToast('ID text extracted successfully', 'success');

        // Step 2: Upload images to Cloudinary
        updateProcessing('Uploading images...');
        const imageUrls = await uploadImages();

        // Step 3: Generate security fingerprint
        const fingerprint = window.VerificationSecurity 
            ? await window.VerificationSecurity.generateFingerprint(verificationData.personal_info)
            : null;

        // Step 4: Get client info for security
        const clientIP = window.VerificationSecurity 
            ? await window.VerificationSecurity.getClientIP()
            : 'unknown';

        // Step 5: Detect security flags
        const securityFlags = {};
        
        // Check for suspicious patterns (skip in test mode)
        if (!window.VERIFICATION_TEST_MODE) {
            const allText = Object.values(verificationData.personal_info).join(' ');
            if (window.VerificationSecurity?.suspiciousPatterns.testData.test(allText)) {
                securityFlags.suspicious_patterns = true;
            }
        } else {
            securityFlags.test_mode = true;
        }

        // Step 6: Save to database with security data
        updateProcessing('Saving verification data...');
        const insertResult = await db
            .from('seller_verifications')
            .insert({
                user_id: user.id,
                seller_type: verificationData.seller_type,
                first_name: verificationData.personal_info.first_name,
                middle_name: verificationData.personal_info.middle_name,
                last_name: verificationData.personal_info.last_name,
                date_of_birth: verificationData.personal_info.date_of_birth,
                phone_number: verificationData.personal_info.phone_number,
                email: verificationData.personal_info.email,
                street_address: verificationData.personal_info.street_address,
                city: verificationData.personal_info.city,
                province: verificationData.personal_info.province,
                postal_code: verificationData.personal_info.postal_code,
                id_type: verificationData.id_info.id_type,
                id_number: verificationData.id_info.id_number,
                id_front_url: imageUrls.id_front,
                id_back_url: imageUrls.id_back,
                selfie_url: imageUrls.selfie,
                ocr_extracted_text: ocrText,
                submission_fingerprint: fingerprint,
                ip_address: clientIP,
                user_agent: navigator.userAgent,
                security_flags: securityFlags,
                status: 'pending',
                submitted_at: new Date().toISOString()
            })
            .select()
            .single();

        if (insertResult.error) {
            throw new Error(`Database error: ${insertResult.error.message}`);
        }

        const data = insertResult.data;

        // Step 7: Log successful submission attempt
        try {
            await db.from('verification_attempts').insert({
                user_id: user.id,
                attempt_type: 'submission',
                ip_address: clientIP,
                user_agent: navigator.userAgent,
                details: { verification_id: data.id }
            });
        } catch (logError) {
            // Silently fail - don't show error to user for logging failures
        }

        // Success!
        hideProcessing();
        showSuccessMessage();

    } catch (error) {
        hideProcessing();
        
        // Log failed submission
        if (window.VerificationSecurity) {
            await window.VerificationSecurity.logSecurityEvent(user.id, 'submission_failed', {
                error: error.message
            });
        }
        
        // Show detailed error message to user
        let userMessage = 'Verification submission failed. ';
        
        if (error.message.includes('Database error')) {
            userMessage = `Database Error: ${error.message}`;
        } else if (error.message.includes('upload')) {
            userMessage = `Upload Error: ${error.message}. Please check your internet connection and try again.`;
        } else if (error.message.includes('OCR')) {
            userMessage = `OCR Error: ${error.message}. Please ensure the image is clear and try again.`;
        } else if (error.message.includes('network')) {
            userMessage = `Network Error: ${error.message}. Please check your internet connection.`;
        } else if (error.message.includes('not a function')) {
            userMessage = `System Error: ${error.message}. Please contact support.`;
        } else {
            userMessage = `Error: ${error.message}`;
        }
        
        showToast(userMessage, 'error');
    }
}

// ---- OCR PROCESSING (FREE - Tesseract.js) ----
async function runOCR(imageData) {
    // TEST MODE: skip real OCR
    if (window.VERIFICATION_TEST_MODE) {
        console.log('[TEST MODE] Skipping OCR — returning mock text');
        return 'TEST MODE: OCR bypassed. Name: Test User. ID: 1234567890.';
    }
    try {
        const { data: { text } } = await Tesseract.recognize(
            imageData,
            'eng',
            {
                logger: m => {
                    if (m.status === 'recognizing text') {
                        updateProcessing(`Analyzing ID... ${Math.round(m.progress * 100)}%`);
                    }
                }
            }
        );
        return text;
    } catch (error) {
        throw new Error(`OCR failed: ${error.message || 'Unable to extract text from image'}`);
    }
}

// ---- IMAGE UPLOAD TO CLOUDINARY ----
async function uploadImages() {
    // TEST MODE: skip real upload, return placeholder URLs
    if (window.VERIFICATION_TEST_MODE) {
        console.log('[TEST MODE] Skipping Cloudinary upload — returning mock URLs');
        return {
            id_front: 'https://via.placeholder.com/400x250/c8a96e/fff?text=ID+Front+(Test)',
            id_back:  'https://via.placeholder.com/400x250/c8a96e/fff?text=ID+Back+(Test)',
            selfie:   'https://via.placeholder.com/400x250/1a1a2e/fff?text=Selfie+(Test)'
        };
    }

    const uploadPromises = [
        uploadToCloudinary(verificationData.images.id_front, 'id_front'),
        uploadToCloudinary(verificationData.images.id_back, 'id_back'),
        uploadToCloudinary(verificationData.images.selfie, 'selfie')
    ];

    const results = await Promise.all(uploadPromises);
    return {
        id_front: results[0],
        id_back:  results[1],
        selfie:   results[2]
    };
}

async function uploadToCloudinary(imageData, type) {
    const formData = new FormData();
    
    // Convert base64 to blob
    const blob = await fetch(imageData).then(r => r.blob());
    formData.append('file', blob);
    formData.append('upload_preset', 'rewear_verifications'); // You'll need to create this preset
    formData.append('folder', 'verifications');

    try {
        // Get upload URL from Cloudinary config helper
        let uploadUrl;
        if (window.cloudinaryConfig && window.cloudinaryConfig.isConfigured()) {
            uploadUrl = window.cloudinaryConfig.getUploadUrl();
        } else {
            // Fallback to hardcoded value
            uploadUrl = 'https://api.cloudinary.com/v1_1/YOUR_CLOUD_NAME/image/upload';
            if (uploadUrl.includes('YOUR_CLOUD_NAME')) {
                throw new Error(`Cloudinary not configured. Please set your cloud name using window.cloudinaryConfig.showConfigUI() or update the hardcoded value in seller-verification.js`);
            }
        }

        const response = await fetch(uploadUrl, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            const errorMsg = errorData.error?.message || `HTTP ${response.status}`;
            throw new Error(`Upload failed for ${type}: ${errorMsg}`);
        }

        const data = await response.json();
        if (!data.secure_url) {
            throw new Error(`Upload failed for ${type}: No URL returned from server`);
        }
        return data.secure_url;
    } catch (err) {
        throw new Error(`Failed to upload ${type}: ${err.message}`);
    }
}

// ---- PROCESSING OVERLAY ----
function showProcessing(message) {
    document.getElementById('processingText').textContent = message;
    document.getElementById('processingOverlay').classList.add('active');
}

function updateProcessing(message) {
    document.getElementById('processingText').textContent = message;
}

function hideProcessing() {
    document.getElementById('processingOverlay').classList.remove('active');
}

// ---- SUCCESS MESSAGE ----
function showSuccessMessage() {
    const formSteps = document.querySelectorAll('.form-step');
    formSteps.forEach(step => step.style.display = 'none');

    const successHTML = `
        <div class="verification-card">
            <div class="success-message">
                <div class="success-icon">&#10003;</div>
                <h2 class="success-title">Verification Submitted!</h2>
                <p class="success-desc">Your verification is under review. We'll notify you via email once it's approved. This usually takes 1-2 business days.</p>
                <button class="btn-primary-lg" onclick="window.location.href='dashboard.html'">Go to Dashboard</button>
            </div>
        </div>
    `;

    document.querySelector('.verification-container').innerHTML = `
        <div class="verification-header">
            <h1>🎉 Success!</h1>
        </div>
        ${successHTML}
    `;
}

// ---- UTILITY FUNCTIONS ----
function showMessage(title, message, type) {
    const toastType = type === 'success' ? 'success' : type === 'warning' ? 'warning' : type === 'info' ? 'info' : 'error';
    showToast(`${title}: ${message}`, toastType);
}

console.log('[verification] Seller verification system loaded');
