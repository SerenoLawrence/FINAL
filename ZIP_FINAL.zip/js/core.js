// ============================================================
// core.js — Shared utilities loaded on every page
// ============================================================

// ---- MODAL SYSTEM ----
const CONFETTI_COLORS = ['#111111','#c8a96e','#e8d5b0','#6b6460','#d4a843','#8b7355','#f0e6d3'];

function spawnConfetti(container) {
  for (let i = 0; i < 38; i++) {
    const piece = document.createElement('div');
    piece.className = 'confetti-piece';
    const size = Math.random() * 8 + 5;
    piece.style.cssText = `
      background:${CONFETTI_COLORS[Math.floor(Math.random()*CONFETTI_COLORS.length)]};
      width:${size}px; height:${size}px;
      left:${Math.random()*100}%; top:-10px;
      border-radius:${Math.random()>.5?'50%':'2px'};
      animation-duration:${Math.random()*1.2+1}s;
      animation-delay:${Math.random()*0.6}s;
    `;
    container.appendChild(piece);
  }
}

let activeModal = null;

function showModal({ type = 'success', title, message, btnText = 'Got it', onClose }) {
  if (activeModal) closeModal(activeModal, true);
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  const iconMap = { success: '✓', error: '✕', loading: '' };
  const iconClass = type === 'success' ? 'success-icon' : type === 'error' ? 'error-icon' : 'loading-icon';
  overlay.innerHTML = `
    <div class="modal-card">
      <div class="modal-confetti-area" id="modalConfettiArea">
        <div class="modal-icon-wrap ${iconClass}">
          ${type === 'loading' ? '<div class="modal-spinner"></div>' : `<span>${iconMap[type]}</span>`}
        </div>
      </div>
      <div class="modal-body">
        <h3 class="modal-title">${title}</h3>
        <p class="modal-message">${message}</p>
      </div>
      ${type !== 'loading' ? `<div class="modal-footer"><button class="modal-btn btn-dark" id="modalBtn" style="pointer-events:auto;cursor:pointer;position:relative;z-index:10001;">${btnText}</button></div>` : ''}
    </div>`;

  // Always append to body directly so nothing blocks it
  document.body.appendChild(overlay);
  // Force styles to ensure clickability
  overlay.style.cssText = 'position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;padding:24px;background:rgba(17,17,17,0.55);backdrop-filter:blur(6px);pointer-events:auto;';

  activeModal = overlay;
  if (type === 'success') spawnConfetti(overlay.querySelector('#modalConfettiArea'));

  const btn = overlay.querySelector('#modalBtn');
  if (btn) {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      closeModal(overlay);
      if (onClose) onClose();
    });
  }

  // Click outside to close
  if (type !== 'loading') {
    overlay.addEventListener('click', e => {
      if (e.target === overlay) {
        closeModal(overlay);
        if (onClose) onClose();
      }
    });
  }
  return overlay;
}

function closeModal(overlay, instant = false) {
  if (!overlay || !overlay.parentNode) return;
  if (instant) { overlay.remove(); if (activeModal === overlay) activeModal = null; return; }
  overlay.classList.add('modal-out');
  overlay.addEventListener('animationend', () => { overlay.remove(); if (activeModal === overlay) activeModal = null; }, { once: true });
}

function showSuccess(title, message, btnText = 'Got it, Thanks!') { return showModal({ type: 'success', title, message, btnText }); }
function showError(title, message, btnText = 'Try Again') { return showModal({ type: 'error', title, message, btnText }); }
function showLoadingModal(title = 'Loading…', message = 'Please wait.') { return showModal({ type: 'loading', title, message }); }
function hideLoadingModal() { if (activeModal) closeModal(activeModal); }


// ---- HELPERS ----
function starsFromRating(r) { const f = Math.round(r); return '★'.repeat(f) + '☆'.repeat(5 - f); }
function formatPrice(p) { return '₱' + parseFloat(p).toFixed(2); }
function formatPHP(amount) {
  return new Intl.NumberFormat('en-PH', {
    style: 'currency',
    currency: 'PHP',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount).replace(/^PHP\s?/, '₱');
}
function formatDate(d) { return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }); }


// ---- ERROR BOUNDARIES & RETRY LOGIC ----

/**
 * Execute an async function with timeout and retry capability
 * @param {Function} fn - Async function to execute
 * @param {Object} options - { timeoutMs, containerId, fallbackHTML, retryable }
 * @returns {Promise}
 */
async function executeWithFallback(fn, options = {}) {
  const {
    timeoutMs = 10000,
    containerId = null,
    fallbackHTML = '<p class="dash-empty">Could not load data.</p>',
    retryable = true
  } = options;

  const container = containerId ? document.getElementById(containerId) : null;

  const timeoutPromise = new Promise((_, reject) =>
    setTimeout(() => reject(new Error('Request timeout')), timeoutMs)
  );

  try {
    await Promise.race([fn(), timeoutPromise]);
  } catch (error) {
    console.error('[executeWithFallback] Error:', error.message);
    
    if (container) {
      const retryBtn = retryable
        ? `<button class="btn-secondary" onclick="location.reload()" style="margin-top:12px;">Retry</button>`
        : '';
      
      container.innerHTML = `
        <div style="text-align:center;padding:24px;">
          <p class="dash-empty" style="color:#c0392b;">⚠ ${error.message || 'Something went wrong'}</p>
          ${retryBtn}
        </div>`;
    }
    
    throw error;
  }
}

/**
 * Show a retry-able error message
 * @param {string} title
 * @param {string} message
 * @param {Function} retryFn - Function to call on retry
 */
function showRetryableError(title, message, retryFn) {
  showModal({
    type: 'error',
    title,
    message: `${message}<br><br><small style="color:#666;">This might be a temporary issue.</small>`,
    btnText: 'Retry',
    onClose: retryFn
  });
}


// ---- MOBILE MENU ----
const mobileMenuToggle = document.getElementById('mobileMenuToggle');
const navMenu = document.getElementById('navMenu');
if (mobileMenuToggle && navMenu) {
  mobileMenuToggle.addEventListener('click', () => {
    navMenu.classList.toggle('mobile-open');
    mobileMenuToggle.classList.toggle('is-active');
  });
}


// ---- SMOOTH SCROLL ----
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const href = this.getAttribute('href');
    if (!href || href === '#') return;
    const target = document.querySelector(href);
    if (!target) return;
    e.preventDefault();
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
});


// ---- STATS COUNTER ----
const statObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting || entry.target.classList.contains('animated')) return;
    const el = entry.target.querySelector('.stat-number');
    if (!el) return;
    const original = el.dataset.original || el.textContent.trim();
    el.dataset.original = original;
    const isK = original.includes('K'), isPercent = original.includes('%');
    const end = isK ? parseFloat(original) * 1000 : parseInt(original, 10);
    let startTs = null;
    const step = ts => {
      if (!startTs) startTs = ts;
      const progress = Math.min((ts - startTs) / 1600, 1);
      const value = Math.floor(progress * end);
      el.textContent = isK ? `${(value/1000).toFixed(1)}K+` : isPercent ? `${value}%` : `${value}`;
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
    entry.target.classList.add('animated');
  });
}, { threshold: 0.35 });
document.querySelectorAll('.stat-card').forEach(card => statObserver.observe(card));


// ---- NEWSLETTER ----
document.querySelectorAll('.newsletter-form').forEach(formWrap => {
  const input = formWrap.querySelector('.newsletter-input');
  const button = formWrap.querySelector('button');
  if (!input || !button) return;
  const submit = async () => {
    const email = input.value.trim();
    if (!email) { input.focus(); showError('Email Required', 'Please enter your email address.'); return; }
    button.disabled = true;
    showLoadingModal('Subscribing…', 'Adding you to our newsletter.');
    const { error } = await db.from('newsletter_subscribers').insert({ email });
    hideLoadingModal(); button.disabled = false;
    if (error) {
      if (error.code === '23505') showError('Already Subscribed', `${email} is already on our list.`, 'Got it');
      else showError('Something Went Wrong', 'Please try again.');
    } else { showSuccess("You're Subscribed!", `Updates coming to ${email}.`); input.value = ''; }
  };
  button.addEventListener('click', submit);
  input.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); submit(); } });
});


// ---- INQUIRY MODAL SYSTEM (Consolidated) ----
/**
 * Open inquiry modal for messaging a seller
 * @param {string} sid - Seller ID
 * @param {string} sellerName - Seller's display name
 * @param {string} productId - Optional product ID
 */
window.openInquiryModal = function(sid, sellerName, productId) {
  // Remove any existing inquiry overlay
  document.getElementById('inquiryOverlay')?.remove();
  
  const currentUser = window.authManager?.getCurrentUser();
  const overlay = document.createElement('div');
  overlay.id = 'inquiryOverlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;';
  
  overlay.innerHTML = `
    <div style="background:#fff;border-radius:16px;padding:28px;max-width:440px;width:100%;box-shadow:0 20px 60px rgba(0,0,0,0.3);">
      <h3 style="margin:0 0 4px;font-size:18px;">Send Message</h3>
      <p style="color:#888;font-size:13px;margin:0 0 20px;">to ${sellerName}</p>
      
      <div style="margin-bottom:12px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Your Name</label>
        <input id="inquiryName" type="text" value="${currentUser?.name || ''}" placeholder="Your name"
          style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
      </div>
      
      <div style="margin-bottom:12px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Your Email</label>
        <input id="inquiryEmail" type="email" value="${currentUser?.email || ''}" placeholder="you@email.com"
          style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;box-sizing:border-box;">
      </div>
      
      <div style="margin-bottom:20px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:4px;">Message</label>
        <textarea id="inquiryMessage" rows="4" placeholder="Ask about a product, availability, or anything else…"
          style="width:100%;padding:10px 12px;border:1.5px solid #e0e0e0;border-radius:8px;font-size:14px;resize:vertical;box-sizing:border-box;font-family:inherit;"></textarea>
      </div>
      
      <div style="display:flex;gap:10px;">
        <button onclick="submitInquiry('${sid}','${productId || ''}')"
          style="flex:1;padding:12px;background:#1a1a2e;color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:700;cursor:pointer;">
          Send Message
        </button>
        <button onclick="document.getElementById('inquiryOverlay').remove()"
          style="padding:12px 18px;background:#f5f5f5;color:#333;border:none;border-radius:8px;font-size:14px;cursor:pointer;">
          Cancel
        </button>
      </div>
    </div>`;
  
  document.body.appendChild(overlay);
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
};

/**
 * Submit inquiry message to seller
 * @param {string} sid - Seller ID
 * @param {string} productId - Optional product ID
 */
window.submitInquiry = async function(sid, productId) {
  const name    = document.getElementById('inquiryName')?.value.trim();
  const email   = document.getElementById('inquiryEmail')?.value.trim();
  const message = document.getElementById('inquiryMessage')?.value.trim();
  
  if (!name || !email || !message) {
    showError('Missing Information', 'Please fill in all fields.');
    return;
  }
  
  try {
    const payload = {
      seller_id: sid || null,
      buyer_name: name,
      buyer_email: email,
      message
    };
    
    if (productId) payload.product_id = productId;
    
    const { error } = await window.db.from('messages').insert(payload);
    if (error) throw error;
    
    document.getElementById('inquiryOverlay')?.remove();
    
    // Determine correct path for dashboard link
    const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
    showSuccess(
      'Message Sent!',
      `Your inquiry has been sent. <a href="${prefix}dashboard.html#buyer-messages" style="color:#c8a96e;font-weight:600;">View in Messages →</a>`,
      'Got it'
    );
  } catch (err) {
    console.error('[submitInquiry]', err);
    showError('Could Not Send', 'Please check your connection and try again.');
  }
};


// ---- QUICK CHAT MODAL SYSTEM (Consolidated) ----
/**
 * Open quick chat modal with pre-filled questions
 * @param {string} sid - Seller ID
 * @param {string} sellerName - Seller's display name
 * @param {string} productId - Product ID
 * @param {string} productName - Product name
 */
window.openQuickChatModal = function(sid, sellerName, productId, productName) {
  const currentUser = window.authManager?.getCurrentUser();
  const overlay = document.createElement('div');
  overlay.id = 'quickChatOverlay';
  overlay.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.6);z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;';
  
  overlay.innerHTML = `
    <div style="background:#fff;border-radius:16px;padding:32px;max-width:500px;width:100%;box-shadow:0 12px 48px rgba(0,0,0,0.3);max-height:90vh;overflow-y:auto;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
        <div>
          <h3 style="margin:0 0 4px;font-size:20px;">Chat with Seller</h3>
          <p style="color:#888;font-size:14px;margin:0;">${sellerName}</p>
        </div>
        <button onclick="document.getElementById('quickChatOverlay').remove()"
          style="width:32px;height:32px;border:none;background:#f5f5f5;border-radius:50%;cursor:pointer;font-size:18px;color:#666;">
          ×
        </button>
      </div>

      <div style="background:#f9f9f9;padding:12px;border-radius:10px;margin-bottom:16px;">
        <div style="font-size:13px;color:#666;margin-bottom:4px;">About:</div>
        <div style="font-weight:600;font-size:14px;">${productName}</div>
      </div>

      <div style="margin-bottom:16px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:8px;">Quick Questions:</label>
        <div style="display:flex;flex-direction:column;gap:6px;">
          <button onclick="document.getElementById('quickChatMessage').value='Is this item still available?'"
            style="padding:10px 14px;background:#fff;border:1px solid #ddd;border-radius:8px;text-align:left;cursor:pointer;font-size:13px;transition:all 0.2s;"
            onmouseover="this.style.borderColor='#c8a96e';this.style.background='#fdf8f0';"
            onmouseout="this.style.borderColor='#ddd';this.style.background='#fff';">
            💬 Is this item still available?
          </button>
          <button onclick="document.getElementById('quickChatMessage').value='Can you provide more details about the condition?'"
            style="padding:10px 14px;background:#fff;border:1px solid #ddd;border-radius:8px;text-align:left;cursor:pointer;font-size:13px;transition:all 0.2s;"
            onmouseover="this.style.borderColor='#c8a96e';this.style.background='#fdf8f0';"
            onmouseout="this.style.borderColor='#ddd';this.style.background='#fff';">
            🔍 Can you provide more details about the condition?
          </button>
          <button onclick="document.getElementById('quickChatMessage').value='Do you offer shipping? What are the rates?'"
            style="padding:10px 14px;background:#fff;border:1px solid #ddd;border-radius:8px;text-align:left;cursor:pointer;font-size:13px;transition:all 0.2s;"
            onmouseover="this.style.borderColor='#c8a96e';this.style.background='#fdf8f0';"
            onmouseout="this.style.borderColor='#ddd';this.style.background='#fff';">
            📦 Do you offer shipping? What are the rates?
          </button>
          <button onclick="document.getElementById('quickChatMessage').value='Can I see more photos of this item?'"
            style="padding:10px 14px;background:#fff;border:1px solid #ddd;border-radius:8px;text-align:left;cursor:pointer;font-size:13px;transition:all 0.2s;"
            onmouseover="this.style.borderColor='#c8a96e';this.style.background='#fdf8f0';"
            onmouseout="this.style.borderColor='#ddd';this.style.background='#fff';">
            📸 Can I see more photos of this item?
          </button>
          <button onclick="document.getElementById('quickChatMessage').value='Is the price negotiable?'"
            style="padding:10px 14px;background:#fff;border:1px solid #ddd;border-radius:8px;text-align:left;cursor:pointer;font-size:13px;transition:all 0.2s;"
            onmouseover="this.style.borderColor='#c8a96e';this.style.background='#fdf8f0';"
            onmouseout="this.style.borderColor='#ddd';this.style.background='#fff';">
            💰 Is the price negotiable?
          </button>
        </div>
      </div>

      <div style="margin-bottom:12px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:6px;">Your Name</label>
        <input id="quickChatName" type="text" value="${currentUser?.name || ''}" placeholder="Your name"
          style="width:100%;padding:10px 12px;border:1px solid #ddd;border-radius:8px;font-size:14px;box-sizing:border-box;">
      </div>

      <div style="margin-bottom:12px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:6px;">Your Email</label>
        <input id="quickChatEmail" type="email" value="${currentUser?.email || ''}" placeholder="your@email.com"
          style="width:100%;padding:10px 12px;border:1px solid #ddd;border-radius:8px;font-size:14px;box-sizing:border-box;">
      </div>

      <div style="margin-bottom:20px;">
        <label style="font-size:13px;font-weight:600;display:block;margin-bottom:6px;">Your Message</label>
        <textarea id="quickChatMessage" rows="4" placeholder="Type your question or select from quick questions above..."
          style="width:100%;padding:10px 12px;border:1px solid #ddd;border-radius:8px;font-size:14px;resize:vertical;box-sizing:border-box;"></textarea>
      </div>

      <div style="display:flex;gap:12px;">
        <button onclick="submitQuickChat('${sid}', '${productId}')"
          style="flex:1;padding:14px;background:#c8a96e;color:#fff;border:none;border-radius:10px;font-size:15px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/>
          </svg>
          Send Message
        </button>
        <button onclick="document.getElementById('quickChatOverlay').remove()"
          style="padding:14px 24px;background:#f5f5f5;color:#333;border:none;border-radius:10px;font-size:15px;font-weight:600;cursor:pointer;">
          Cancel
        </button>
      </div>

      <div style="margin-top:16px;padding:12px;background:#e8f5e9;border-radius:8px;font-size:12px;color:#155724;">
        💡 <strong>Tip:</strong> The seller will receive your message and reply in their dashboard. You can check replies in your <strong>Buyer Dashboard → Messages</strong>.
      </div>
    </div>
  `;
  
  document.body.appendChild(overlay);
  
  // Close on overlay click
  overlay.addEventListener('click', (e) => {
    if (e.target.id === 'quickChatOverlay') {
      overlay.remove();
    }
  });
};

/**
 * Submit quick chat message to seller
 * @param {string} sid - Seller ID
 * @param {string} productId - Product ID
 */
window.submitQuickChat = async function(sid, productId) {
  const name    = document.getElementById('quickChatName')?.value.trim();
  const email   = document.getElementById('quickChatEmail')?.value.trim();
  const message = document.getElementById('quickChatMessage')?.value.trim();
  
  if (!name || !email || !message) {
    showError('Missing Information', 'Please fill in all fields.');
    return;
  }
  
  // Basic email validation
  if (!email.includes('@') || !email.includes('.')) {
    showError('Invalid Email', 'Please enter a valid email address.');
    return;
  }
  
  try {
    showLoadingModal('Sending...', 'Sending your message to the seller.');
    
    const payload = {
      seller_id: sid,
      buyer_name: name,
      buyer_email: email,
      message
    };
    
    if (productId) payload.product_id = productId;
    
    const { error } = await window.db.from('messages').insert(payload);
    if (error) throw error;
    
    hideLoadingModal();
    document.getElementById('quickChatOverlay')?.remove();
    
    const prefix = window.location.pathname.includes('/pages/') ? '' : 'pages/';
    showSuccess(
      'Message Sent! ✉️',
      `Your message has been sent to the seller. They will reply soon. <br><br><a href="${prefix}dashboard.html#buyer-messages" style="color:#c8a96e;font-weight:600;text-decoration:underline;">View in Messages →</a>`,
      'Got it'
    );
  } catch (err) {
    hideLoadingModal();
    console.error('[submitQuickChat]', err);
    showError('Failed to Send', 'Could not send message. Please try again.');
  }
};
