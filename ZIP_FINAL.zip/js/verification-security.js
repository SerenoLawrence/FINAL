// ============================================================
// verification-security.js — Security Layer for Verification System
// Protects against abuse, spam, and malicious submissions
// ============================================================

const VerificationSecurity = {
    // Rate limiting
    rateLimits: {
        submissions: new Map(), // userId -> { count, resetTime }
        maxSubmissionsPerDay: 3,
        cooldownMinutes: 60
    },

    // Image validation
    imageValidation: {
        maxSizeBytes: 5 * 1024 * 1024, // 5MB
        minSizeBytes: 10 * 1024, // 10KB (prevent tiny/fake images)
        allowedTypes: ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'],
        minWidth: 400,
        minHeight: 300,
        maxWidth: 8000,
        maxHeight: 8000
    },

    // Input sanitization patterns
    patterns: {
        name: /^[a-zA-Z\s\-\.ñÑ]{2,50}$/,
        phone: /^(\+63|0)[0-9]{10}$/,
        email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        postalCode: /^[0-9]{4}$/,
        idNumber: /^[A-Z0-9\-]{5,20}$/i
    },

    // Suspicious patterns to detect
    suspiciousPatterns: {
        repeatingChars: /(.)\1{4,}/, // aaaaa, 11111
        testData: /test|fake|dummy|sample|xxx/i,
        sqlInjection: /('|(--)|;|\/\*|\*\/|xp_|sp_|exec|execute|select|insert|update|delete|drop|create|alter)/i,
        xss: /<script|javascript:|onerror=|onload=/i
    },

    // Fingerprinting to detect duplicate submissions
    async generateFingerprint(data) {
        const str = JSON.stringify({
            name: data.first_name + data.last_name,
            dob: data.date_of_birth,
            id: data.id_number
        });
        
        // Simple hash function (in production, use crypto.subtle.digest)
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        return Math.abs(hash).toString(36);
    },

    // Check rate limiting
    async checkRateLimit(userId) {
        const now = Date.now();
        const userLimit = this.rateLimits.submissions.get(userId);

        if (!userLimit) {
            this.rateLimits.submissions.set(userId, {
                count: 1,
                resetTime: now + (24 * 60 * 60 * 1000) // 24 hours
            });
            return { allowed: true };
        }

        // Reset if time expired
        if (now > userLimit.resetTime) {
            this.rateLimits.submissions.set(userId, {
                count: 1,
                resetTime: now + (24 * 60 * 60 * 1000)
            });
            return { allowed: true };
        }

        // Check if exceeded
        if (userLimit.count >= this.rateLimits.maxSubmissionsPerDay) {
            const hoursLeft = Math.ceil((userLimit.resetTime - now) / (60 * 60 * 1000));
            return {
                allowed: false,
                reason: `Rate limit exceeded. You can submit ${this.rateLimits.maxSubmissionsPerDay} verifications per day. Try again in ${hoursLeft} hours.`
            };
        }

        // Increment count
        userLimit.count++;
        return { allowed: true };
    },

    // Validate image file
    async validateImage(file, type) {
        const errors = [];

        // Check file type
        if (!this.imageValidation.allowedTypes.includes(file.type)) {
            errors.push(`${type}: Invalid file type. Only JPEG, PNG, and WebP are allowed.`);
        }

        // Check file size
        if (file.size > this.imageValidation.maxSizeBytes) {
            errors.push(`${type}: File too large. Maximum size is 5MB.`);
        }

        if (file.size < this.imageValidation.minSizeBytes) {
            errors.push(`${type}: File too small. Minimum size is 10KB.`);
        }

        // Check image dimensions
        try {
            const dimensions = await this.getImageDimensions(file);
            
            if (dimensions.width < this.imageValidation.minWidth || 
                dimensions.height < this.imageValidation.minHeight) {
                errors.push(`${type}: Image resolution too low. Minimum ${this.imageValidation.minWidth}x${this.imageValidation.minHeight}px required.`);
            }

            if (dimensions.width > this.imageValidation.maxWidth || 
                dimensions.height > this.imageValidation.maxHeight) {
                errors.push(`${type}: Image resolution too high. Maximum ${this.imageValidation.maxWidth}x${this.imageValidation.maxHeight}px allowed.`);
            }
        } catch (e) {
            errors.push(`${type}: Could not read image file. File may be corrupted.`);
        }

        return errors;
    },

    // Get image dimensions
    getImageDimensions(file) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            const url = URL.createObjectURL(file);
            
            img.onload = () => {
                URL.revokeObjectURL(url);
                resolve({ width: img.width, height: img.height });
            };
            
            img.onerror = () => {
                URL.revokeObjectURL(url);
                reject(new Error('Failed to load image'));
            };
            
            img.src = url;
        });
    },

    // Sanitize text input
    sanitizeText(text, maxLength = 100) {
        if (!text) return '';
        
        // Remove HTML tags
        text = text.replace(/<[^>]*>/g, '');
        
        // Remove special characters that could be used for injection
        text = text.replace(/[<>\"'`]/g, '');
        
        // Trim and limit length
        text = text.trim().substring(0, maxLength);
        
        return text;
    },

    // Validate personal information
    validatePersonalInfo(data) {
        const errors = [];

        // First name
        if (!this.patterns.name.test(data.first_name)) {
            errors.push('First name contains invalid characters or is too short/long (2-50 characters).');
        }

        // Last name
        if (!this.patterns.name.test(data.last_name)) {
            errors.push('Last name contains invalid characters or is too short/long (2-50 characters).');
        }

        // Middle name (optional)
        if (data.middle_name && !this.patterns.name.test(data.middle_name)) {
            errors.push('Middle name contains invalid characters.');
        }

        // Date of birth
        const dob = new Date(data.date_of_birth);
        const age = (Date.now() - dob.getTime()) / (365.25 * 24 * 60 * 60 * 1000);
        
        if (isNaN(dob.getTime())) {
            errors.push('Invalid date of birth.');
        } else if (age < 18) {
            errors.push('You must be at least 18 years old to become a seller.');
        } else if (age > 120) {
            errors.push('Invalid date of birth (too old).');
        }

        // Phone number
        if (!this.patterns.phone.test(data.phone_number)) {
            errors.push('Invalid Philippine phone number format. Use +639XXXXXXXXX or 09XXXXXXXXX.');
        }

        // Email
        if (!this.patterns.email.test(data.email)) {
            errors.push('Invalid email address format.');
        }

        // Postal code
        if (!this.patterns.postalCode.test(data.postal_code)) {
            errors.push('Invalid postal code. Must be 4 digits.');
        }

        // Check for suspicious patterns
        const allText = Object.values(data).join(' ').toLowerCase();
        
        if (this.suspiciousPatterns.testData.test(allText)) {
            errors.push('Suspicious data detected. Please use real information.');
        }

        if (this.suspiciousPatterns.sqlInjection.test(allText)) {
            errors.push('Invalid characters detected in input.');
        }

        if (this.suspiciousPatterns.xss.test(allText)) {
            errors.push('Invalid characters detected in input.');
        }

        return errors;
    },

    // Validate ID information
    validateIdInfo(data) {
        const errors = [];

        // ID type
        const validIdTypes = ['national_id', 'drivers_license', 'passport', 'sss_id', 'umid', 'postal_id', 'voters_id'];
        if (!validIdTypes.includes(data.id_type)) {
            errors.push('Invalid ID type selected.');
        }

        // ID number
        if (!this.patterns.idNumber.test(data.id_number)) {
            errors.push('Invalid ID number format. Must be 5-20 alphanumeric characters.');
        }

        // Check for repeating characters
        if (this.suspiciousPatterns.repeatingChars.test(data.id_number)) {
            errors.push('ID number appears to be fake (repeating characters).');
        }

        return errors;
    },

    // Check for duplicate submission
    async checkDuplicateSubmission(userId, fingerprint) {
        try {
            // Check if user already has a pending or approved verification
            const { data, error } = await db
                .from('seller_verifications')
                .select('id, status, submitted_at')
                .eq('user_id', userId)
                .in('status', ['pending', 'approved'])
                .order('submitted_at', { ascending: false })
                .limit(1);

            if (error) throw error;

            if (data && data.length > 0) {
                const existing = data[0];
                if (existing.status === 'approved') {
                    return {
                        isDuplicate: true,
                        reason: 'You are already a verified seller.'
                    };
                }
                if (existing.status === 'pending') {
                    const hoursSince = (Date.now() - new Date(existing.submitted_at).getTime()) / (60 * 60 * 1000);
                    if (hoursSince < 24) {
                        return {
                            isDuplicate: true,
                            reason: 'You already have a pending verification. Please wait for admin review.'
                        };
                    }
                }
            }

            return { isDuplicate: false };
        } catch (e) {
            console.error('[security] checkDuplicateSubmission error:', e);
            return { isDuplicate: false };
        }
    },

    // Log security event
    async logSecurityEvent(userId, eventType, details) {
        try {
            await db.from('audit_logs').insert({
                user_id: userId,
                action: `verification_security_${eventType}`,
                details: details,
                ip_address: await this.getClientIP(),
                user_agent: navigator.userAgent,
                created_at: new Date().toISOString()
            });
        } catch (e) {
            console.error('[security] Failed to log event:', e);
        }
    },

    // Get client IP (best effort)
    async getClientIP() {
        try {
            const response = await fetch('https://api.ipify.org?format=json');
            const data = await response.json();
            return data.ip;
        } catch (e) {
            return 'unknown';
        }
    },

    // Comprehensive validation before submission
    async validateSubmission(verificationData, userId) {
        const errors = [];

        // 1. Rate limiting
        const rateCheck = await this.checkRateLimit(userId);
        if (!rateCheck.allowed) {
            return { valid: false, errors: [rateCheck.reason] };
        }

        // 2. Check for duplicates
        const fingerprint = await this.generateFingerprint(verificationData.personal_info);
        const dupCheck = await this.checkDuplicateSubmission(userId, fingerprint);
        if (dupCheck.isDuplicate) {
            return { valid: false, errors: [dupCheck.reason] };
        }

        // 3. Validate personal information
        const personalErrors = this.validatePersonalInfo(verificationData.personal_info);
        errors.push(...personalErrors);

        // 4. Validate ID information
        const idErrors = this.validateIdInfo(verificationData.id_info);
        errors.push(...idErrors);

        // 5. Validate images (already done during upload, but double-check)
        if (!verificationData.images.id_front || !verificationData.images.id_back || !verificationData.images.selfie) {
            errors.push('All images are required (ID front, ID back, and selfie).');
        }

        // 6. Log validation attempt
        if (errors.length > 0) {
            await this.logSecurityEvent(userId, 'validation_failed', {
                errors: errors,
                fingerprint: fingerprint
            });
        }

        return {
            valid: errors.length === 0,
            errors: errors,
            fingerprint: fingerprint
        };
    }
};

// Export for use in seller-verification.js
window.VerificationSecurity = VerificationSecurity;

console.log('[security] Verification security layer loaded');
