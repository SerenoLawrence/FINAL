// ============================================================
// Cloudinary Helper Functions
// ============================================================
// Convenient functions for uploading different types of images
// ============================================================

/**
 * Upload product images
 * @param {File[]} files - Array of image files
 * @returns {Promise<string[]>} Array of image URLs
 */
async function uploadProductImages(files) {
  if (!window.cloudinaryUploader) {
    throw new Error('Cloudinary not configured');
  }
  
  const folder = window.CLOUDINARY_FOLDERS.products;
  const results = await window.cloudinaryUploader.uploadMultiple(files, folder, {
    tags: ['product', 'listing']
  });
  
  const failed = results.filter(r => !r.success);
  if (failed.length > 0) {
    throw new Error(`Failed to upload ${failed.length} image(s)`);
  }
  
  return results.map(r => r.url);
}

/**
 * Upload verification ID images
 * @param {File[]} files - Array of ID image files (front and back)
 * @param {string} sellerId - The seller's user ID
 * @returns {Promise<string[]>} Array of image URLs
 */
async function uploadVerificationIDs(files, sellerId) {
  if (!window.cloudinaryUploader) {
    throw new Error('Cloudinary not configured');
  }
  
  const folder = window.CLOUDINARY_FOLDERS.verification.ids;
  const results = await window.cloudinaryUploader.uploadMultiple(files, folder, {
    tags: ['verification', 'id', sellerId],
    publicId: `${sellerId}_id_${Date.now()}`
  });
  
  const failed = results.filter(r => !r.success);
  if (failed.length > 0) {
    throw new Error(`Failed to upload ${failed.length} ID image(s)`);
  }
  
  return results.map(r => r.url);
}

/**
 * Upload verification selfie
 * @param {File} file - Selfie image file
 * @param {string} sellerId - The seller's user ID
 * @returns {Promise<string>} Image URL
 */
async function uploadVerificationSelfie(file, sellerId) {
  if (!window.cloudinaryUploader) {
    throw new Error('Cloudinary not configured');
  }
  
  const folder = window.CLOUDINARY_FOLDERS.verification.selfies;
  const result = await window.cloudinaryUploader.uploadFile(file, folder, {
    tags: ['verification', 'selfie', sellerId],
    publicId: `${sellerId}_selfie_${Date.now()}`
  });
  
  if (!result.success) {
    throw new Error(result.error || 'Failed to upload selfie');
  }
  
  return result.url;
}

/**
 * Upload GCash QR code
 * @param {File} file - QR code image file
 * @param {string} sellerId - The seller's user ID
 * @returns {Promise<string>} Image URL
 */
async function uploadGCashQR(file, sellerId) {
  if (!window.cloudinaryUploader) {
    throw new Error('Cloudinary not configured');
  }
  
  const folder = window.CLOUDINARY_FOLDERS.payments.gcash;
  const result = await window.cloudinaryUploader.uploadFile(file, folder, {
    tags: ['payment', 'gcash', sellerId],
    publicId: `${sellerId}_gcash_qr`
  });
  
  if (!result.success) {
    throw new Error(result.error || 'Failed to upload GCash QR');
  }
  
  return result.url;
}

/**
 * Upload payment receipt
 * @param {File} file - Receipt image file
 * @param {string} orderId - The order ID
 * @returns {Promise<string>} Image URL
 */
async function uploadPaymentReceipt(file, orderId) {
  if (!window.cloudinaryUploader) {
    throw new Error('Cloudinary not configured');
  }
  
  const folder = window.CLOUDINARY_FOLDERS.payments.receipts;
  const result = await window.cloudinaryUploader.uploadFile(file, folder, {
    tags: ['payment', 'receipt', orderId],
    publicId: `receipt_${orderId}_${Date.now()}`
  });
  
  if (!result.success) {
    throw new Error(result.error || 'Failed to upload receipt');
  }
  
  return result.url;
}

/**
 * Upload profile picture
 * @param {File} file - Profile image file
 * @param {string} userId - The user's ID
 * @returns {Promise<string>} Image URL
 */
async function uploadProfilePicture(file, userId) {
  if (!window.cloudinaryUploader) {
    throw new Error('Cloudinary not configured');
  }
  
  const folder = window.CLOUDINARY_FOLDERS.profiles;
  const result = await window.cloudinaryUploader.uploadFile(file, folder, {
    tags: ['profile', userId],
    publicId: `${userId}_profile`,
    maxSize: 5 * 1024 * 1024 // 5MB max for profile pics
  });
  
  if (!result.success) {
    throw new Error(result.error || 'Failed to upload profile picture');
  }
  
  return result.url;
}

// Export functions
window.uploadProductImages = uploadProductImages;
window.uploadVerificationIDs = uploadVerificationIDs;
window.uploadVerificationSelfie = uploadVerificationSelfie;
window.uploadGCashQR = uploadGCashQR;
window.uploadPaymentReceipt = uploadPaymentReceipt;
window.uploadProfilePicture = uploadProfilePicture;

console.log('[cloudinary] Helper functions loaded');
