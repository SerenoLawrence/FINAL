-- ============================================================
-- REWEAR MASTER DATABASE SETUP
-- ONE FILE TO RULE THEM ALL
-- ============================================================
-- 
-- This combines:
-- 1. Your existing database (products, sellers, orders, etc.)
-- 2. NEW Security Verification System
-- 3. All RLS policies
-- 4. All indexes
--
-- SAFE TO RUN MULTIPLE TIMES
-- ============================================================

-- ============================================================
-- PART 1: CORE TABLES (Your Existing Database)
-- ============================================================

-- PRODUCTS TABLE
CREATE TABLE IF NOT EXISTS products (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name             TEXT NOT NULL,
    price            NUMERIC(10,2) NOT NULL,
    category         TEXT NOT NULL,
    image_url        TEXT,
    rating           NUMERIC(2,1) DEFAULT 5.0,
    in_stock         BOOLEAN DEFAULT TRUE,
    quantity         INT DEFAULT 1,
    status           TEXT DEFAULT 'approved',
    sizes            TEXT[] DEFAULT ARRAY['S','M','L'],
    suggested_price  NUMERIC(10,2),
    description      TEXT,
    rejection_reason TEXT,
    seller_id        UUID,
    listing_fee_id   UUID,
    created_at       TIMESTAMPTZ DEFAULT NOW()
);

-- BLOG POSTS TABLE
CREATE TABLE IF NOT EXISTS blog_posts (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title             TEXT NOT NULL,
    excerpt           TEXT,
    category          TEXT NOT NULL,
    image_url         TEXT,
    read_time_minutes INT DEFAULT 5,
    published_at      TIMESTAMPTZ DEFAULT NOW(),
    created_at        TIMESTAMPTZ DEFAULT NOW()
);

-- NEWSLETTER + CONTACT TABLES
CREATE TABLE IF NOT EXISTS newsletter_subscribers (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email         TEXT NOT NULL UNIQUE,
    subscribed_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS contact_messages (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    first_name TEXT NOT NULL,
    last_name  TEXT NOT NULL,
    email      TEXT NOT NULL,
    phone      TEXT,
    subject    TEXT NOT NULL,
    message    TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- SELLERS TABLE
CREATE TABLE IF NOT EXISTS sellers (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id          UUID,
    business_name    TEXT NOT NULL,
    email            TEXT NOT NULL UNIQUE,
    phone            TEXT,
    description      TEXT,
    verified         BOOLEAN DEFAULT FALSE,
    verified_at      TIMESTAMPTZ,
    rejection_reason TEXT,
    location         TEXT,
    store_name       TEXT,
    address          TEXT,
    updated_at       TIMESTAMPTZ,
    created_at       TIMESTAMPTZ DEFAULT NOW()
);

-- ORDERS TABLE
CREATE TABLE IF NOT EXISTS orders (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id     UUID REFERENCES products(id) ON DELETE SET NULL,
    seller_id      UUID,
    buyer_name     TEXT NOT NULL,
    buyer_email    TEXT NOT NULL,
    size_selected  TEXT,
    quantity       INT DEFAULT 1,
    total_price    NUMERIC(10,2),
    status         TEXT DEFAULT 'pending',
    transaction_id UUID,
    buyer_user_id  UUID,
    created_at     TIMESTAMPTZ DEFAULT NOW()
);

-- WISHLISTS TABLE
CREATE TABLE IF NOT EXISTS wishlists (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID NOT NULL,
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    added_at   TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (user_id, product_id)
);

-- REVIEWS TABLE (only allowed after order status = 'received')
CREATE TABLE IF NOT EXISTS reviews (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id     UUID REFERENCES orders(id) ON DELETE CASCADE,
    product_id   UUID REFERENCES products(id) ON DELETE CASCADE,
    seller_id    UUID,
    buyer_email  TEXT NOT NULL,
    rating       INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment      TEXT,
    photo_url    TEXT,
    type         TEXT GENERATED ALWAYS AS (
                     CASE WHEN rating >= 3 THEN 'positive' ELSE 'negative' END
                 ) STORED,
    created_at   TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (order_id)  -- one review per order only
);

-- RLS for reviews
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY "reviews_select_all" ON reviews
    FOR SELECT USING (true);

CREATE POLICY "reviews_insert_own" ON reviews
    FOR INSERT WITH CHECK (
        buyer_email = (SELECT email FROM auth.users WHERE id = auth.uid())
        AND
        EXISTS (
            SELECT 1 FROM orders
            WHERE orders.id = order_id
            AND orders.buyer_email = (SELECT email FROM auth.users WHERE id = auth.uid())
            AND orders.status = 'received'
        )
    );

-- Update product rating when review is added
CREATE OR REPLACE FUNCTION update_product_rating()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE products
    SET rating = (
        SELECT ROUND(AVG(rating)::numeric, 1)
        FROM reviews
        WHERE product_id = NEW.product_id
    )
    WHERE id = NEW.product_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_update_product_rating ON reviews;
CREATE TRIGGER trg_update_product_rating
    AFTER INSERT OR UPDATE ON reviews
    FOR EACH ROW EXECUTE FUNCTION update_product_rating();

-- ADMIN SESSIONS TABLE
CREATE TABLE IF NOT EXISTS admin_sessions (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    pin_hash   TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- LISTING FEES TABLE
CREATE TABLE IF NOT EXISTS listing_fees (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    seller_id      UUID NOT NULL REFERENCES sellers(id) ON DELETE CASCADE,
    tier           TEXT NOT NULL DEFAULT 'basic',
    amount_paid    NUMERIC(10,2) NOT NULL DEFAULT 0,
    max_listings   INT NOT NULL DEFAULT 5,
    listings_used  INT NOT NULL DEFAULT 0,
    status         TEXT NOT NULL DEFAULT 'active',
    paid_at        TIMESTAMPTZ DEFAULT NOW(),
    expires_at     TIMESTAMPTZ,
    payment_method TEXT,
    payment_ref    TEXT,
    created_at     TIMESTAMPTZ DEFAULT NOW()
);

-- TRANSACTIONS TABLE
CREATE TABLE IF NOT EXISTS transactions (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id          UUID REFERENCES orders(id) ON DELETE RESTRICT,
    seller_id         UUID REFERENCES sellers(id) ON DELETE RESTRICT,
    gross_amount      NUMERIC(10,2) NOT NULL,
    commission_rate   NUMERIC(4,3) NOT NULL,
    commission_amount NUMERIC(10,2) NOT NULL,
    seller_payout     NUMERIC(10,2) NOT NULL,
    status            TEXT NOT NULL DEFAULT 'pending',
    released_at       TIMESTAMPTZ,
    created_at        TIMESTAMPTZ DEFAULT NOW()
);

-- EARNINGS TABLE
CREATE TABLE IF NOT EXISTS earnings (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source       TEXT NOT NULL,
    reference_id UUID,
    amount       NUMERIC(10,2) NOT NULL,
    recorded_at  TIMESTAMPTZ DEFAULT NOW()
);

-- BUYERS TABLE
CREATE TABLE IF NOT EXISTS buyers (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name       TEXT NOT NULL,
    email      TEXT NOT NULL UNIQUE,
    phone      TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS buyer_addresses (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    buyer_id       UUID NOT NULL REFERENCES buyers(id) ON DELETE CASCADE,
    label          TEXT NOT NULL DEFAULT 'Home',
    street_address TEXT NOT NULL,
    city           TEXT NOT NULL,
    province       TEXT NOT NULL,
    postal_code    TEXT NOT NULL,
    country        TEXT NOT NULL DEFAULT 'Philippines',
    is_default     BOOLEAN NOT NULL DEFAULT FALSE,
    created_at     TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- PART 2: NEW SECURITY VERIFICATION SYSTEM
-- ============================================================

-- Drop old simple seller_verifications if it exists
DROP TABLE IF EXISTS seller_verifications CASCADE;

-- Create NEW comprehensive seller_verifications table
CREATE TABLE seller_verifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    
    -- Seller type
    seller_type TEXT NOT NULL CHECK (seller_type IN ('individual', 'business')),
    
    -- Personal information
    first_name TEXT NOT NULL,
    middle_name TEXT,
    last_name TEXT NOT NULL,
    date_of_birth DATE NOT NULL,
    phone_number TEXT NOT NULL,
    email TEXT NOT NULL,
    
    -- Address
    street_address TEXT NOT NULL,
    city TEXT NOT NULL,
    province TEXT NOT NULL,
    postal_code TEXT NOT NULL,
    
    -- ID information
    id_type TEXT NOT NULL CHECK (id_type IN (
        'national_id',
        'drivers_license',
        'passport',
        'sss_id',
        'umid',
        'postal_id',
        'voters_id'
    )),
    id_number TEXT NOT NULL,
    
    -- Uploaded images
    id_front_url TEXT NOT NULL,
    id_back_url TEXT NOT NULL,
    selfie_url TEXT NOT NULL,
    
    -- AI/OCR results
    ocr_extracted_text TEXT,
    face_match_score DECIMAL(5,2),
    face_match_result BOOLEAN,
    
    -- Security columns
    submission_fingerprint TEXT,
    ip_address TEXT,
    user_agent TEXT,
    security_flags JSONB DEFAULT '{}',
    risk_score INTEGER DEFAULT 0 CHECK (risk_score >= 0 AND risk_score <= 100),
    
    -- Verification status
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    rejection_reason TEXT,
    
    -- Admin review
    reviewed_by UUID REFERENCES auth.users(id),
    reviewed_at TIMESTAMP WITH TIME ZONE,
    
    -- Timestamps
    submitted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Constraints
    UNIQUE(user_id, submitted_at)
);

-- VERIFICATION ATTEMPTS TABLE (Rate Limiting)
CREATE TABLE IF NOT EXISTS verification_attempts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    attempt_type TEXT NOT NULL CHECK (attempt_type IN ('submission', 'validation_failed', 'rate_limited')),
    ip_address TEXT,
    user_agent TEXT,
    details JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    action TEXT NOT NULL,
    details JSONB,
    entity_type TEXT,
    entity_id UUID,
    ip_address TEXT,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================================
-- PART 3: INDEXES
-- ============================================================

-- Core tables indexes
CREATE INDEX IF NOT EXISTS idx_products_seller_status ON products(seller_id, status);
CREATE INDEX IF NOT EXISTS idx_products_category_stock ON products(category, in_stock);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_seller_status ON orders(seller_id, status);
CREATE INDEX IF NOT EXISTS idx_listing_fees_seller ON listing_fees(seller_id, status);
CREATE INDEX IF NOT EXISTS idx_transactions_seller ON transactions(seller_id, status);
CREATE INDEX IF NOT EXISTS idx_earnings_source ON earnings(source, recorded_at);

-- Verification system indexes
CREATE INDEX IF NOT EXISTS idx_seller_verifications_user_id ON seller_verifications(user_id);
CREATE INDEX IF NOT EXISTS idx_seller_verifications_status ON seller_verifications(status);
CREATE INDEX IF NOT EXISTS idx_seller_verifications_submitted_at ON seller_verifications(submitted_at DESC);
CREATE INDEX IF NOT EXISTS idx_seller_verifications_fingerprint ON seller_verifications(submission_fingerprint);
CREATE INDEX IF NOT EXISTS idx_seller_verifications_risk_score ON seller_verifications(risk_score DESC);
CREATE INDEX IF NOT EXISTS idx_verification_attempts_user_id ON verification_attempts(user_id);
CREATE INDEX IF NOT EXISTS idx_verification_attempts_created_at ON verification_attempts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_verification_attempts_type ON verification_attempts(attempt_type);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_entity ON audit_logs(entity_type, entity_id);

-- ============================================================
-- PART 4: ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================

-- Enable RLS on all tables
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE newsletter_subscribers ENABLE ROW LEVEL SECURITY;
ALTER TABLE contact_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE sellers ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE wishlists ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE listing_fees ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE earnings ENABLE ROW LEVEL SECURITY;
ALTER TABLE buyers ENABLE ROW LEVEL SECURITY;
ALTER TABLE buyer_addresses ENABLE ROW LEVEL SECURITY;
ALTER TABLE seller_verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE verification_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Drop all existing policies (clean slate)
DO $$ 
DECLARE
    r RECORD;
BEGIN
    FOR r IN (
        SELECT schemaname, tablename, policyname 
        FROM pg_policies 
        WHERE schemaname = 'public'
    ) LOOP
        EXECUTE 'DROP POLICY IF EXISTS "' || r.policyname || '" ON ' || r.schemaname || '.' || r.tablename;
    END LOOP;
END $$;

-- Products policies
CREATE POLICY "products_select_all" ON products FOR SELECT TO anon, authenticated USING (TRUE);
CREATE POLICY "products_insert_all" ON products FOR INSERT TO anon, authenticated WITH CHECK (TRUE);
CREATE POLICY "products_update_all" ON products FOR UPDATE TO anon, authenticated USING (TRUE) WITH CHECK (TRUE);
CREATE POLICY "products_delete_all" ON products FOR DELETE TO anon, authenticated USING (TRUE);

-- Blog posts policies
CREATE POLICY "blog_select_all" ON blog_posts FOR SELECT TO anon, authenticated USING (TRUE);

-- Newsletter policies
CREATE POLICY "newsletter_insert_all" ON newsletter_subscribers FOR INSERT TO anon, authenticated WITH CHECK (TRUE);
CREATE POLICY "newsletter_select_all" ON newsletter_subscribers FOR SELECT TO anon, authenticated USING (TRUE);

-- Contact messages policies
CREATE POLICY "contact_insert_all" ON contact_messages FOR INSERT TO anon, authenticated WITH CHECK (TRUE);

-- Sellers policies
CREATE POLICY "sellers_insert_all" ON sellers FOR INSERT TO anon, authenticated WITH CHECK (TRUE);
CREATE POLICY "sellers_select_all" ON sellers FOR SELECT TO anon, authenticated USING (TRUE);
CREATE POLICY "sellers_update_all" ON sellers FOR UPDATE TO anon, authenticated USING (TRUE) WITH CHECK (TRUE);

-- Orders policies
CREATE POLICY "orders_insert_all" ON orders FOR INSERT TO anon, authenticated WITH CHECK (TRUE);
CREATE POLICY "orders_select_all" ON orders FOR SELECT TO anon, authenticated USING (TRUE);
CREATE POLICY "orders_update_all" ON orders FOR UPDATE TO anon, authenticated USING (TRUE) WITH CHECK (TRUE);

-- Wishlists policies
CREATE POLICY "wishlists_all" ON wishlists FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Admin sessions policies
CREATE POLICY "admin_sessions_select_all" ON admin_sessions FOR SELECT TO anon, authenticated USING (TRUE);

-- Listing fees policies
CREATE POLICY "listing_fees_select_all" ON listing_fees FOR SELECT TO anon, authenticated USING (TRUE);
CREATE POLICY "listing_fees_insert_all" ON listing_fees FOR INSERT TO anon, authenticated WITH CHECK (TRUE);
CREATE POLICY "listing_fees_update_all" ON listing_fees FOR UPDATE TO anon, authenticated USING (TRUE) WITH CHECK (TRUE);

-- Transactions policies
CREATE POLICY "transactions_select_all" ON transactions FOR SELECT TO anon, authenticated USING (TRUE);
CREATE POLICY "transactions_insert_all" ON transactions FOR INSERT TO anon, authenticated WITH CHECK (TRUE);
CREATE POLICY "transactions_update_all" ON transactions FOR UPDATE TO anon, authenticated USING (TRUE) WITH CHECK (TRUE);

-- Earnings policies
CREATE POLICY "earnings_select_all" ON earnings FOR SELECT TO anon, authenticated USING (TRUE);
CREATE POLICY "earnings_insert_all" ON earnings FOR INSERT TO anon, authenticated WITH CHECK (TRUE);

-- Buyers policies
CREATE POLICY "buyers_all" ON buyers FOR ALL TO anon, authenticated USING (TRUE) WITH CHECK (TRUE);
CREATE POLICY "buyer_addresses_all" ON buyer_addresses FOR ALL TO anon, authenticated USING (TRUE) WITH CHECK (TRUE);

-- Seller verifications policies
CREATE POLICY "verifications_select_own" ON seller_verifications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "verifications_insert_own" ON seller_verifications FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "verifications_select_admin" ON seller_verifications FOR SELECT TO public USING (TRUE);
CREATE POLICY "verifications_update_admin" ON seller_verifications FOR UPDATE TO public USING (TRUE);

-- Verification attempts policies
CREATE POLICY "attempts_select_own" ON verification_attempts FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "attempts_insert_own" ON verification_attempts FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "attempts_select_admin" ON verification_attempts FOR SELECT TO public USING (TRUE);

-- Audit logs policies
CREATE POLICY "audit_select_all" ON audit_logs FOR SELECT TO public USING (TRUE);
CREATE POLICY "audit_insert_all" ON audit_logs FOR INSERT TO public WITH CHECK (TRUE);

-- ============================================================
-- PART 5: FUNCTIONS
-- ============================================================

-- Function: Check rate limiting
CREATE OR REPLACE FUNCTION check_verification_rate_limit(p_user_id UUID)
RETURNS TABLE (
    allowed BOOLEAN,
    attempts_today INTEGER,
    max_attempts INTEGER,
    next_allowed_at TIMESTAMP WITH TIME ZONE
) AS $$
DECLARE
    v_attempts_today INTEGER;
    v_max_attempts INTEGER := 3;
BEGIN
    SELECT COUNT(*) INTO v_attempts_today
    FROM verification_attempts
    WHERE user_id = p_user_id
    AND attempt_type = 'submission'
    AND created_at > NOW() - INTERVAL '24 hours';
    
    IF v_attempts_today >= v_max_attempts THEN
        SELECT created_at + INTERVAL '24 hours' INTO next_allowed_at
        FROM verification_attempts
        WHERE user_id = p_user_id
        AND attempt_type = 'submission'
        AND created_at > NOW() - INTERVAL '24 hours'
        ORDER BY created_at ASC
        LIMIT 1;
        
        RETURN QUERY SELECT FALSE, v_attempts_today, v_max_attempts, next_allowed_at;
    ELSE
        RETURN QUERY SELECT TRUE, v_attempts_today, v_max_attempts, NULL::TIMESTAMP WITH TIME ZONE;
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function: Detect duplicate submissions
CREATE OR REPLACE FUNCTION detect_duplicate_verification(
    p_user_id UUID,
    p_fingerprint TEXT
)
RETURNS TABLE (
    is_duplicate BOOLEAN,
    existing_status TEXT,
    existing_id UUID,
    submitted_at TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        TRUE as is_duplicate,
        sv.status,
        sv.id,
        sv.submitted_at
    FROM seller_verifications sv
    WHERE sv.user_id = p_user_id
    AND sv.submission_fingerprint = p_fingerprint
    AND sv.status IN ('pending', 'approved')
    ORDER BY sv.submitted_at DESC
    LIMIT 1;
    
    IF NOT FOUND THEN
        RETURN QUERY SELECT FALSE, NULL::TEXT, NULL::UUID, NULL::TIMESTAMP WITH TIME ZONE;
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function: Calculate risk score
CREATE OR REPLACE FUNCTION calculate_verification_risk_score(
    p_verification_id UUID
)
RETURNS INTEGER AS $$
DECLARE
    v_risk_score INTEGER := 0;
    v_verification RECORD;
    v_user_age_days INTEGER;
    v_previous_rejections INTEGER;
BEGIN
    SELECT * INTO v_verification
    FROM seller_verifications
    WHERE id = p_verification_id;
    
    IF NOT FOUND THEN
        RETURN 0;
    END IF;
    
    SELECT EXTRACT(DAY FROM NOW() - created_at)::INTEGER INTO v_user_age_days
    FROM auth.users WHERE id = v_verification.user_id;
    
    IF v_user_age_days < 7 THEN
        v_risk_score := v_risk_score + 20;
    END IF;
    
    SELECT COUNT(*) INTO v_previous_rejections
    FROM seller_verifications
    WHERE user_id = v_verification.user_id AND status = 'rejected';
    
    v_risk_score := v_risk_score + (v_previous_rejections * 15);
    
    IF v_verification.security_flags ? 'suspicious_patterns' THEN
        v_risk_score := v_risk_score + 25;
    END IF;
    
    IF v_verification.security_flags ? 'rapid_submissions' THEN
        v_risk_score := v_risk_score + 30;
    END IF;
    
    IF v_verification.security_flags ? 'low_quality_images' THEN
        v_risk_score := v_risk_score + 10;
    END IF;
    
    IF v_risk_score > 100 THEN
        v_risk_score := 100;
    END IF;
    
    UPDATE seller_verifications SET risk_score = v_risk_score WHERE id = p_verification_id;
    
    RETURN v_risk_score;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function: Handle verification approval
CREATE OR REPLACE FUNCTION handle_verification_approval()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'approved' AND (OLD.status IS NULL OR OLD.status != 'approved') THEN
        IF EXISTS (
            SELECT 1 FROM information_schema.tables 
            WHERE table_schema = 'public' AND table_name = 'sellers'
        ) THEN
            IF EXISTS (SELECT 1 FROM sellers WHERE user_id = NEW.user_id OR id = NEW.user_id) THEN
                UPDATE sellers
                SET 
                    verified = TRUE,
                    verified_at = NOW(),
                    business_name = COALESCE(business_name, NEW.first_name || ' ' || NEW.last_name),
                    email = NEW.email,
                    phone = COALESCE(phone, NEW.phone_number),
                    address = COALESCE(address, NEW.street_address || ', ' || NEW.city || ', ' || NEW.province || ' ' || NEW.postal_code),
                    updated_at = NOW()
                WHERE user_id = NEW.user_id OR id = NEW.user_id;
            ELSE
                INSERT INTO sellers (
                    id, user_id, business_name, email, phone, address,
                    verified, verified_at, description, created_at
                ) VALUES (
                    NEW.user_id, NEW.user_id,
                    NEW.first_name || ' ' || NEW.last_name,
                    NEW.email, NEW.phone_number,
                    NEW.street_address || ', ' || NEW.city || ', ' || NEW.province || ' ' || NEW.postal_code,
                    TRUE, NOW(), 'Verified seller on REWEAR', NOW()
                );
            END IF;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function: Update updated_at timestamp
CREATE OR REPLACE FUNCTION update_seller_verifications_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- PART 6: TRIGGERS
-- ============================================================

DROP TRIGGER IF EXISTS trigger_verification_approval ON seller_verifications;
CREATE TRIGGER trigger_verification_approval
    AFTER UPDATE ON seller_verifications
    FOR EACH ROW
    EXECUTE FUNCTION handle_verification_approval();

DROP TRIGGER IF EXISTS trigger_update_seller_verifications_timestamp ON seller_verifications;
CREATE TRIGGER trigger_update_seller_verifications_timestamp
    BEFORE UPDATE ON seller_verifications
    FOR EACH ROW
    EXECUTE FUNCTION update_seller_verifications_updated_at();

-- ============================================================
-- PART 7: VIEWS
-- ============================================================

CREATE OR REPLACE VIEW verification_fraud_alerts AS
SELECT 
    sv.id,
    sv.user_id,
    sv.first_name || ' ' || sv.last_name as full_name,
    sv.email,
    sv.status,
    sv.risk_score,
    sv.security_flags,
    sv.submitted_at,
    au.email as user_email,
    au.created_at as user_created_at,
    (SELECT COUNT(*) FROM seller_verifications sv2 
     WHERE sv2.user_id = sv.user_id AND sv2.status = 'rejected') as previous_rejections,
    (SELECT COUNT(*) FROM verification_attempts va 
     WHERE va.user_id = sv.user_id AND va.created_at > NOW() - INTERVAL '7 days') as attempts_last_7_days
FROM seller_verifications sv
JOIN auth.users au ON au.id = sv.user_id
WHERE sv.risk_score >= 50 OR sv.status = 'pending'
ORDER BY sv.risk_score DESC, sv.submitted_at DESC;

-- ============================================================
-- PART 8: PERMISSIONS
-- ============================================================

GRANT SELECT, INSERT ON seller_verifications TO authenticated, anon;
GRANT ALL ON seller_verifications TO service_role;
GRANT ALL ON verification_attempts TO authenticated, anon;
GRANT SELECT, INSERT ON audit_logs TO authenticated, anon;
GRANT SELECT ON verification_fraud_alerts TO authenticated, anon;
GRANT EXECUTE ON FUNCTION check_verification_rate_limit TO authenticated, anon;
GRANT EXECUTE ON FUNCTION detect_duplicate_verification TO authenticated, anon;
GRANT EXECUTE ON FUNCTION calculate_verification_risk_score TO authenticated, anon;

-- ============================================================
-- PART 9: SEED DATA (Only if tables are empty)
-- ============================================================

-- Seed admin PIN
INSERT INTO admin_sessions (pin_hash)
SELECT '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'
WHERE NOT EXISTS (SELECT 1 FROM admin_sessions LIMIT 1);

-- Seed sample sellers
INSERT INTO sellers (business_name, email, phone, description, verified)
SELECT * FROM (VALUES
    ('Maria Fashion Store', 'maria@example.com', '+63 912 345 6789', 'Selling pre-loved designer clothes', FALSE),
    ('Juan Thrift Shop', 'juan@example.com', '+63 917 234 5678', 'Affordable second-hand clothing', FALSE),
    ('Ana Vintage Closet', 'ana@example.com', '+63 918 345 6789', 'Curated vintage pieces', TRUE)
) AS v(business_name, email, phone, description, verified)
WHERE NOT EXISTS (SELECT 1 FROM sellers LIMIT 1);

-- ============================================================
-- SETUP COMPLETE!
-- ============================================================

SELECT '✅ DATABASE SETUP COMPLETE!' as status,
       '' as detail
UNION ALL
SELECT 'Tables Created' as status,
       COUNT(*)::TEXT || ' tables' as detail
FROM information_schema.tables 
WHERE table_schema = 'public'
UNION ALL
SELECT 'RLS Policies' as status,
       COUNT(*)::TEXT || ' policies' as detail
FROM pg_policies
WHERE schemaname = 'public'
UNION ALL
SELECT 'Functions' as status,
       COUNT(*)::TEXT || ' functions' as detail
FROM pg_proc p
JOIN pg_namespace n ON p.pronamespace = n.oid
WHERE n.nspname = 'public'
AND p.prokind = 'f'
UNION ALL
SELECT 'Triggers' as status,
       COUNT(*)::TEXT || ' triggers' as detail
FROM pg_trigger
WHERE tgname NOT LIKE 'pg_%';

-- ============================================================
-- MIGRATION: Add photo_url to reviews (run if table already exists)
-- ============================================================
ALTER TABLE reviews ADD COLUMN IF NOT EXISTS photo_url TEXT;
