-- ============================================================
-- REWEAR — COMPLETE DATABASE SETUP
-- Safe to run on existing databases (uses IF NOT EXISTS + ADD COLUMN IF NOT EXISTS)
-- Run this in Supabase SQL Editor
-- ============================================================

-- ============================================================
-- PART 1: CORE TABLES
-- ============================================================

CREATE TABLE IF NOT EXISTS products (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name             TEXT NOT NULL,
    price            NUMERIC(10,2) NOT NULL,
    category         TEXT NOT NULL,
    image_url        TEXT,
    rating           NUMERIC(2,1) DEFAULT 5.0,
    in_stock         BOOLEAN DEFAULT TRUE,
    quantity         INT DEFAULT 1,
    status           TEXT DEFAULT 'approved',
    sizes            TEXT[] DEFAULT ARRAY['S','M','L'],
    suggested_price  NUMERIC(10,2),
    description      TEXT,
    rejection_reason TEXT,
    seller_id        UUID,
    listing_fee_id   UUID,
    created_at       TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS sellers (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id          UUID,
    business_name    TEXT NOT NULL,
    email            TEXT NOT NULL UNIQUE,
    phone            TEXT,
    description      TEXT,
    verified         BOOLEAN DEFAULT FALSE,
    verified_at      TIMESTAMPTZ,
    rejection_reason TEXT,
    location         TEXT,
    store_name       TEXT,
    address          TEXT,
    avatar_url       TEXT,
    gcash_number     TEXT,
    gcash_name       TEXT,
    updated_at       TIMESTAMPTZ,
    created_at       TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id       UUID REFERENCES products(id) ON DELETE SET NULL,
    seller_id        UUID,
    buyer_name       TEXT NOT NULL,
    buyer_email      TEXT NOT NULL,
    buyer_phone      TEXT,
    size_selected    TEXT,
    quantity         INT DEFAULT 1,
    total_price      NUMERIC(10,2),
    status           TEXT DEFAULT 'pending',
    payment_status   TEXT DEFAULT 'pending',
    payment_reference TEXT,
    payment_receipt_url TEXT,
    payment_rejected_reason TEXT,
    shipping_info    JSONB,
    delivery_address TEXT,
    courier_name     TEXT,
    tracking_number  TEXT,
    transaction_id   UUID,
    buyer_user_id    UUID,
    confirmed_at     TIMESTAMPTZ,
    shipped_at       TIMESTAMPTZ,
    delivered_at     TIMESTAMPTZ,
    received_at      TIMESTAMPTZ,
    created_at       TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS reviews (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id     UUID REFERENCES orders(id) ON DELETE CASCADE,
    product_id   UUID REFERENCES products(id) ON DELETE CASCADE,
    seller_id    UUID,
    buyer_email  TEXT NOT NULL,
    rating       INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment      TEXT,
    photo_url    TEXT,
    type         TEXT GENERATED ALWAYS AS (
                     CASE WHEN rating >= 3 THEN 'positive' ELSE 'negative' END
                 ) STORED,
    created_at   TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (order_id)
);

CREATE TABLE IF NOT EXISTS messages (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    seller_id    UUID,
    buyer_name   TEXT NOT NULL,
    buyer_email  TEXT NOT NULL,
    product_id   UUID,
    message      TEXT NOT NULL,
    reply        TEXT,
    replied_at   TIMESTAMPTZ,
    accepted     BOOLEAN DEFAULT FALSE,
    accepted_at  TIMESTAMPTZ,
    rejected     BOOLEAN DEFAULT FALSE,
    rejected_reason TEXT,
    is_read      BOOLEAN DEFAULT FALSE,
    thread       JSONB DEFAULT '[]',
    updated_at   TIMESTAMPTZ DEFAULT NOW(),
    created_at   TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS listing_fees (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    seller_id      UUID NOT NULL REFERENCES sellers(id) ON DELETE CASCADE,
    tier           TEXT NOT NULL DEFAULT 'basic',
    amount_paid    NUMERIC(10,2) NOT NULL DEFAULT 0,
    max_listings   INT NOT NULL DEFAULT 5,
    listings_used  INT NOT NULL DEFAULT 0,
    status         TEXT NOT NULL DEFAULT 'active',
    proof_url      TEXT,
    paid_at        TIMESTAMPTZ DEFAULT NOW(),
    expires_at     TIMESTAMPTZ,
    payment_method TEXT,
    payment_ref    TEXT,
    created_at     TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS transactions (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id          UUID REFERENCES orders(id) ON DELETE RESTRICT,
    seller_id         UUID REFERENCES sellers(id) ON DELETE RESTRICT,
    gross_amount      NUMERIC(10,2) NOT NULL,
    commission_rate   NUMERIC(4,3) NOT NULL,
    commission_amount NUMERIC(10,2) NOT NULL,
    seller_payout     NUMERIC(10,2) NOT NULL,
    status            TEXT NOT NULL DEFAULT 'pending',
    released_at       TIMESTAMPTZ,
    created_at        TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS earnings (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source       TEXT NOT NULL,
    reference_id UUID,
    amount       NUMERIC(10,2) NOT NULL,
    recorded_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS buyers (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name       TEXT NOT NULL,
    email      TEXT NOT NULL UNIQUE,
    phone      TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS wishlists (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    UUID NOT NULL,
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    added_at   TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (user_id, product_id)
);

CREATE TABLE IF NOT EXISTS blog_posts (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title             TEXT NOT NULL,
    excerpt           TEXT,
    category          TEXT NOT NULL,
    image_url         TEXT,
    read_time_minutes INT DEFAULT 5,
    published_at      TIMESTAMPTZ DEFAULT NOW(),
    created_at        TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS newsletter_subscribers (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email         TEXT NOT NULL UNIQUE,
    subscribed_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS contact_messages (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    first_name TEXT NOT NULL,
    last_name  TEXT NOT NULL,
    email      TEXT NOT NULL,
    phone      TEXT,
    subject    TEXT NOT NULL,
    message    TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS admin_sessions (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    pin_hash   TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- PART 2: SELLER VERIFICATION SYSTEM
-- ============================================================

CREATE TABLE IF NOT EXISTS seller_verifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    seller_type TEXT NOT NULL CHECK (seller_type IN ('individual', 'business')),
    first_name TEXT NOT NULL,
    middle_name TEXT,
    last_name TEXT NOT NULL,
    date_of_birth DATE NOT NULL,
    phone_number TEXT NOT NULL,
    email TEXT NOT NULL,
    street_address TEXT NOT NULL,
    city TEXT NOT NULL,
    province TEXT NOT NULL,
    postal_code TEXT NOT NULL,
    id_type TEXT NOT NULL CHECK (id_type IN ('national_id','drivers_license','passport','sss_id','umid','postal_id','voters_id')),
    id_number TEXT NOT NULL,
    id_front_url TEXT NOT NULL,
    id_back_url TEXT NOT NULL,
    selfie_url TEXT NOT NULL,
    ocr_extracted_text TEXT,
    face_match_score DECIMAL(5,2),
    face_match_result BOOLEAN,
    submission_fingerprint TEXT,
    ip_address TEXT,
    user_agent TEXT,
    security_flags JSONB DEFAULT '{}',
    risk_score INTEGER DEFAULT 0 CHECK (risk_score >= 0 AND risk_score <= 100),
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    rejection_reason TEXT,
    reviewed_by UUID REFERENCES auth.users(id),
    reviewed_at TIMESTAMPTZ,
    submitted_at TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, submitted_at)
);

CREATE TABLE IF NOT EXISTS verification_attempts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    attempt_type TEXT NOT NULL CHECK (attempt_type IN ('submission', 'validation_failed', 'rate_limited')),
    ip_address TEXT,
    user_agent TEXT,
    details JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    action TEXT NOT NULL,
    details JSONB,
    entity_type TEXT,
    entity_id UUID,
    ip_address TEXT,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- PART 3: MIGRATIONS (add columns to existing tables safely)
-- ============================================================

-- reviews: add photo_url if missing
ALTER TABLE reviews ADD COLUMN IF NOT EXISTS photo_url TEXT;

-- sellers: add avatar_url, gcash columns if missing
ALTER TABLE sellers ADD COLUMN IF NOT EXISTS avatar_url TEXT;
ALTER TABLE sellers ADD COLUMN IF NOT EXISTS gcash_number TEXT;
ALTER TABLE sellers ADD COLUMN IF NOT EXISTS gcash_name TEXT;

-- orders: add all new columns if missing
ALTER TABLE orders ADD COLUMN IF NOT EXISTS buyer_phone TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_status TEXT DEFAULT 'pending';
ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_reference TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_receipt_url TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_rejected_reason TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS shipping_info JSONB;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivery_address TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS courier_name TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS tracking_number TEXT;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS confirmed_at TIMESTAMPTZ;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS shipped_at TIMESTAMPTZ;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS delivered_at TIMESTAMPTZ;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS received_at TIMESTAMPTZ;

-- listing_fees: add proof_url if missing
ALTER TABLE listing_fees ADD COLUMN IF NOT EXISTS proof_url TEXT;

-- ============================================================
-- PART 4: AUTO-LINK ORPHANED PRODUCTS TO SELLERS
-- Links products with no seller_id to the seller with matching email
-- Also links by user_id if available
-- ============================================================

-- Link products to sellers via user_id match
UPDATE products p
SET seller_id = s.id
FROM sellers s
WHERE p.seller_id IS NULL
  AND s.user_id IS NOT NULL
  AND p.seller_id IS NULL;

-- If still unlinked and only one seller exists, assign to that seller
-- (useful for single-seller test setups)
DO $$
DECLARE
    v_seller_id UUID;
    v_seller_count INT;
BEGIN
    SELECT COUNT(*) INTO v_seller_count FROM sellers;
    IF v_seller_count = 1 THEN
        SELECT id INTO v_seller_id FROM sellers LIMIT 1;
        UPDATE products SET seller_id = v_seller_id WHERE seller_id IS NULL;
        RAISE NOTICE 'Linked all orphaned products to seller: %', v_seller_id;
    ELSE
        RAISE NOTICE 'Multiple sellers found. Manual linking required for orphaned products.';
    END IF;
END $$;

-- ============================================================
-- PART 5: INDEXES
-- ============================================================

CREATE INDEX IF NOT EXISTS idx_products_seller_status   ON products(seller_id, status);
CREATE INDEX IF NOT EXISTS idx_products_category_stock  ON products(category, in_stock);
CREATE INDEX IF NOT EXISTS idx_orders_status            ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_seller_status     ON orders(seller_id, status);
CREATE INDEX IF NOT EXISTS idx_orders_buyer_email       ON orders(buyer_email);
CREATE INDEX IF NOT EXISTS idx_reviews_seller           ON reviews(seller_id);
CREATE INDEX IF NOT EXISTS idx_reviews_product          ON reviews(product_id);
CREATE INDEX IF NOT EXISTS idx_reviews_buyer            ON reviews(buyer_email);
CREATE INDEX IF NOT EXISTS idx_listing_fees_seller      ON listing_fees(seller_id, status);
CREATE INDEX IF NOT EXISTS idx_transactions_seller      ON transactions(seller_id, status);
CREATE INDEX IF NOT EXISTS idx_earnings_source          ON earnings(source, recorded_at);
CREATE INDEX IF NOT EXISTS idx_seller_verifications_user   ON seller_verifications(user_id);
CREATE INDEX IF NOT EXISTS idx_seller_verifications_status ON seller_verifications(status);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user          ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action        ON audit_logs(action);

-- ============================================================
-- PART 6: ROW LEVEL SECURITY
-- ============================================================

ALTER TABLE products              ENABLE ROW LEVEL SECURITY;
ALTER TABLE sellers               ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders                ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews               ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages              ENABLE ROW LEVEL SECURITY;
ALTER TABLE listing_fees          ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions          ENABLE ROW LEVEL SECURITY;
ALTER TABLE earnings              ENABLE ROW LEVEL SECURITY;
ALTER TABLE buyers                ENABLE ROW LEVEL SECURITY;
ALTER TABLE wishlists             ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_posts            ENABLE ROW LEVEL SECURITY;
ALTER TABLE newsletter_subscribers ENABLE ROW LEVEL SECURITY;
ALTER TABLE contact_messages      ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_sessions        ENABLE ROW LEVEL SECURITY;
ALTER TABLE seller_verifications  ENABLE ROW LEVEL SECURITY;
ALTER TABLE verification_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs            ENABLE ROW LEVEL SECURITY;

-- Drop all existing policies (clean slate)
DO $$
DECLARE r RECORD;
BEGIN
    FOR r IN (SELECT schemaname, tablename, policyname FROM pg_policies WHERE schemaname = 'public') LOOP
        EXECUTE 'DROP POLICY IF EXISTS "' || r.policyname || '" ON ' || r.schemaname || '.' || r.tablename;
    END LOOP;
END $$;

-- Products
CREATE POLICY "products_select_all" ON products FOR SELECT TO anon, authenticated USING (TRUE);
CREATE POLICY "products_insert_all" ON products FOR INSERT TO anon, authenticated WITH CHECK (TRUE);
CREATE POLICY "products_update_all" ON products FOR UPDATE TO anon, authenticated USING (TRUE) WITH CHECK (TRUE);
CREATE POLICY "products_delete_all" ON products FOR DELETE TO anon, authenticated USING (TRUE);

-- Sellers
CREATE POLICY "sellers_select_all" ON sellers FOR SELECT TO anon, authenticated USING (TRUE);
CREATE POLICY "sellers_insert_all" ON sellers FOR INSERT TO anon, authenticated WITH CHECK (TRUE);
CREATE POLICY "sellers_update_all" ON sellers FOR UPDATE TO anon, authenticated USING (TRUE) WITH CHECK (TRUE);

-- Orders
CREATE POLICY "orders_select_all" ON orders FOR SELECT TO anon, authenticated USING (TRUE);
CREATE POLICY "orders_insert_all" ON orders FOR INSERT TO anon, authenticated WITH CHECK (TRUE);
CREATE POLICY "orders_update_all" ON orders FOR UPDATE TO anon, authenticated USING (TRUE) WITH CHECK (TRUE);

-- Reviews
CREATE POLICY "reviews_select_all" ON reviews FOR SELECT TO anon, authenticated USING (TRUE);
CREATE POLICY "reviews_insert_verified" ON reviews FOR INSERT TO authenticated WITH CHECK (
    buyer_email = (SELECT email FROM auth.users WHERE id = auth.uid())
    AND EXISTS (
        SELECT 1 FROM orders
        WHERE orders.id = order_id
          AND orders.buyer_email = (SELECT email FROM auth.users WHERE id = auth.uid())
          AND orders.status = 'received'
    )
);
-- Allow anon insert for local-auth users
CREATE POLICY "reviews_insert_anon" ON reviews FOR INSERT TO anon WITH CHECK (TRUE);

-- Messages
CREATE POLICY "messages_select_all" ON messages FOR SELECT TO anon, authenticated USING (TRUE);
CREATE POLICY "messages_insert_all" ON messages FOR INSERT TO anon, authenticated WITH CHECK (TRUE);
CREATE POLICY "messages_update_all" ON messages FOR UPDATE TO anon, authenticated USING (TRUE) WITH CHECK (TRUE);

-- Listing fees
CREATE POLICY "listing_fees_select_all" ON listing_fees FOR SELECT TO anon, authenticated USING (TRUE);
CREATE POLICY "listing_fees_insert_all" ON listing_fees FOR INSERT TO anon, authenticated WITH CHECK (TRUE);
CREATE POLICY "listing_fees_update_all" ON listing_fees FOR UPDATE TO anon, authenticated USING (TRUE) WITH CHECK (TRUE);

-- Transactions
CREATE POLICY "transactions_select_all" ON transactions FOR SELECT TO anon, authenticated USING (TRUE);
CREATE POLICY "transactions_insert_all" ON transactions FOR INSERT TO anon, authenticated WITH CHECK (TRUE);
CREATE POLICY "transactions_update_all" ON transactions FOR UPDATE TO anon, authenticated USING (TRUE) WITH CHECK (TRUE);

-- Earnings
CREATE POLICY "earnings_select_all" ON earnings FOR SELECT TO anon, authenticated USING (TRUE);
CREATE POLICY "earnings_insert_all" ON earnings FOR INSERT TO anon, authenticated WITH CHECK (TRUE);

-- Buyers
CREATE POLICY "buyers_all" ON buyers FOR ALL TO anon, authenticated USING (TRUE) WITH CHECK (TRUE);

-- Wishlists
CREATE POLICY "wishlists_all" ON wishlists FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Blog
CREATE POLICY "blog_select_all" ON blog_posts FOR SELECT TO anon, authenticated USING (TRUE);

-- Newsletter
CREATE POLICY "newsletter_insert_all" ON newsletter_subscribers FOR INSERT TO anon, authenticated WITH CHECK (TRUE);
CREATE POLICY "newsletter_select_all" ON newsletter_subscribers FOR SELECT TO anon, authenticated USING (TRUE);

-- Contact
CREATE POLICY "contact_insert_all" ON contact_messages FOR INSERT TO anon, authenticated WITH CHECK (TRUE);

-- Admin sessions
CREATE POLICY "admin_sessions_select_all" ON admin_sessions FOR SELECT TO anon, authenticated USING (TRUE);

-- Seller verifications
CREATE POLICY "verifications_select_own"  ON seller_verifications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "verifications_insert_own"  ON seller_verifications FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "verifications_select_all"  ON seller_verifications FOR SELECT TO public USING (TRUE);
CREATE POLICY "verifications_update_all"  ON seller_verifications FOR UPDATE TO public USING (TRUE);

-- Verification attempts
CREATE POLICY "attempts_select_own"  ON verification_attempts FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "attempts_insert_own"  ON verification_attempts FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "attempts_select_all"  ON verification_attempts FOR SELECT TO public USING (TRUE);

-- Audit logs
CREATE POLICY "audit_select_all" ON audit_logs FOR SELECT TO public USING (TRUE);
CREATE POLICY "audit_insert_all" ON audit_logs FOR INSERT TO public WITH CHECK (TRUE);

-- ============================================================
-- PART 7: FUNCTIONS & TRIGGERS
-- ============================================================

-- Auto-update product rating when review is added
CREATE OR REPLACE FUNCTION update_product_rating()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE products
    SET rating = (
        SELECT ROUND(AVG(rating)::numeric, 1)
        FROM reviews WHERE product_id = NEW.product_id
    )
    WHERE id = NEW.product_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_update_product_rating ON reviews;
CREATE TRIGGER trg_update_product_rating
    AFTER INSERT OR UPDATE ON reviews
    FOR EACH ROW EXECUTE FUNCTION update_product_rating();

-- Auto-approve seller when verification is approved
CREATE OR REPLACE FUNCTION handle_verification_approval()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'approved' AND (OLD.status IS NULL OR OLD.status != 'approved') THEN
        IF EXISTS (SELECT 1 FROM sellers WHERE user_id = NEW.user_id OR id = NEW.user_id) THEN
            UPDATE sellers SET
                verified = TRUE,
                verified_at = NOW(),
                business_name = COALESCE(business_name, NEW.first_name || ' ' || NEW.last_name),
                email = NEW.email,
                phone = COALESCE(phone, NEW.phone_number),
                updated_at = NOW()
            WHERE user_id = NEW.user_id OR id = NEW.user_id;
        ELSE
            INSERT INTO sellers (id, user_id, business_name, email, phone, verified, verified_at, created_at)
            VALUES (NEW.user_id, NEW.user_id, NEW.first_name || ' ' || NEW.last_name,
                    NEW.email, NEW.phone_number, TRUE, NOW(), NOW());
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS trigger_verification_approval ON seller_verifications;
CREATE TRIGGER trigger_verification_approval
    AFTER UPDATE ON seller_verifications
    FOR EACH ROW EXECUTE FUNCTION handle_verification_approval();

-- Auto-update updated_at on seller_verifications
CREATE OR REPLACE FUNCTION update_seller_verifications_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_update_seller_verifications_timestamp ON seller_verifications;
CREATE TRIGGER trigger_update_seller_verifications_timestamp
    BEFORE UPDATE ON seller_verifications
    FOR EACH ROW EXECUTE FUNCTION update_seller_verifications_updated_at();

-- ============================================================
-- PART 8: PERMISSIONS
-- ============================================================

GRANT SELECT, INSERT ON seller_verifications TO authenticated, anon;
GRANT ALL ON seller_verifications TO service_role;
GRANT ALL ON verification_attempts TO authenticated, anon;
GRANT SELECT, INSERT ON audit_logs TO authenticated, anon;

-- ============================================================
-- PART 9: SEED DATA (only if tables are empty)
-- ============================================================

-- Admin PIN (default: 1234)
INSERT INTO admin_sessions (pin_hash)
SELECT '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4'
WHERE NOT EXISTS (SELECT 1 FROM admin_sessions LIMIT 1);

-- ============================================================
-- DONE — Check results below
-- ============================================================

SELECT
    'Tables'   AS type, COUNT(*)::TEXT AS count FROM information_schema.tables   WHERE table_schema = 'public'
UNION ALL SELECT
    'Policies' AS type, COUNT(*)::TEXT FROM pg_policies WHERE schemaname = 'public'
UNION ALL SELECT
    'Triggers' AS type, COUNT(*)::TEXT FROM pg_trigger WHERE tgname NOT LIKE 'pg_%'
UNION ALL SELECT
    'Products without seller_id' AS type, COUNT(*)::TEXT FROM products WHERE seller_id IS NULL
UNION ALL SELECT
    'Total products' AS type, COUNT(*)::TEXT FROM products
UNION ALL SELECT
    'Total sellers' AS type, COUNT(*)::TEXT FROM sellers;
