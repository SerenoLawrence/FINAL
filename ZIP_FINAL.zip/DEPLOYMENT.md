# REWEAR Deployment Guide

Complete guide for deploying REWEAR to production.

## Pre-Deployment Checklist

- [ ] All environment variables configured
- [ ] Supabase database initialized
- [ ] Cloudinary account set up
- [ ] SSL certificate ready
- [ ] Domain name configured
- [ ] Email service configured
- [ ] Payment gateway configured (if applicable)

## Environment Setup

### 1. Supabase Configuration

```javascript
// api/supabase.js
const SUPABASE_URL = 'https://your-project.supabase.co'
const SUPABASE_KEY = 'your-anon-key'
```

### 2. Cloudinary Configuration

```javascript
// api/cloudinary-config.js
const CLOUDINARY_CLOUD_NAME = 'your-cloud-name'
const CLOUDINARY_UPLOAD_PRESET = 'your-upload-preset'
```

### 3. Database Initialization

```bash
# Connect to Supabase
# Run the SQL setup script:
# database/REWEAR_FULL_SETUP.sql
```

## Deployment Options

### Option 1: Netlify (Recommended)

1. **Connect Repository**
   - Go to netlify.com
   - Click "New site from Git"
   - Select your GitHub repository

2. **Configure Build**
   - Build command: (leave empty - static site)
   - Publish directory: `yoww-main`

3. **Environment Variables**
   - Go to Site settings → Build & deploy → Environment
   - Add:
     ```
     SUPABASE_URL=your-url
     SUPABASE_KEY=your-key
     CLOUDINARY_CLOUD_NAME=your-name
     CLOUDINARY_UPLOAD_PRESET=your-preset
     ```

4. **Deploy**
   - Push to main branch
   - Netlify auto-deploys

### Option 2: Vercel

1. **Import Project**
   - Go to vercel.com
   - Click "New Project"
   - Import from GitHub

2. **Configure**
   - Root directory: `yoww-main`
   - Framework: Other (static)

3. **Environment Variables**
   - Add same variables as Netlify

4. **Deploy**
   - Click Deploy

### Option 3: Custom Server (VPS/Dedicated)

1. **Upload Files**
   ```bash
   scp -r yoww-main/ user@server:/var/www/
   ```

2. **Configure Web Server (Nginx)**
   ```nginx
   server {
       listen 443 ssl http2;
       server_name yourdomain.com;
       
       ssl_certificate /path/to/cert.pem;
       ssl_certificate_key /path/to/key.pem;
       
       root /var/www/yoww-main;
       index index.html;
       
       location / {
           try_files $uri $uri/ /index.html;
       }
       
       # Cache static assets
       location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
           expires 1y;
           add_header Cache-Control "public, immutable";
       }
   }
   ```

3. **Enable HTTPS**
   ```bash
   certbot certonly --nginx -d yourdomain.com
   ```

4. **Restart Web Server**
   ```bash
   sudo systemctl restart nginx
   ```

### Option 4: Docker

1. **Create Dockerfile**
   ```dockerfile
   FROM nginx:alpine
   COPY yoww-main /usr/share/nginx/html
   COPY nginx.conf /etc/nginx/conf.d/default.conf
   EXPOSE 80
   CMD ["nginx", "-g", "daemon off;"]
   ```

2. **Build Image**
   ```bash
   docker build -t rewear:latest .
   ```

3. **Run Container**
   ```bash
   docker run -p 80:80 rewear:latest
   ```

## Post-Deployment

### 1. Verify Deployment
- [ ] Site loads without errors
- [ ] All pages accessible
- [ ] Images loading correctly
- [ ] Database connection working
- [ ] Authentication functional

### 2. Test Features
- [ ] User registration
- [ ] Product browsing
- [ ] Shopping cart
- [ ] Checkout process
- [ ] Order creation
- [ ] Messaging system
- [ ] Admin panel

### 3. Performance Optimization
- [ ] Enable gzip compression
- [ ] Set up CDN for static assets
- [ ] Configure caching headers
- [ ] Minify CSS/JS
- [ ] Optimize images

### 4. Security Hardening
- [ ] Enable HTTPS/SSL
- [ ] Set security headers
- [ ] Configure CORS properly
- [ ] Enable rate limiting
- [ ] Set up WAF rules

### 5. Monitoring Setup
- [ ] Error tracking (Sentry)
- [ ] Performance monitoring (New Relic)
- [ ] Uptime monitoring
- [ ] Log aggregation
- [ ] Alert configuration

## Database Backup

### Automated Backups
```bash
# Supabase handles automatic backups
# Access via: Dashboard → Backups
```

### Manual Backup
```bash
# Export database
pg_dump -h db.supabase.co -U postgres -d postgres > backup.sql

# Restore database
psql -h db.supabase.co -U postgres -d postgres < backup.sql
```

## Scaling

### Database Scaling
- Monitor connection count
- Upgrade Supabase plan if needed
- Optimize slow queries
- Add indexes for frequently queried columns

### Application Scaling
- Use CDN for static assets
- Enable caching
- Optimize API calls
- Consider load balancing

## Troubleshooting

### Site Not Loading
1. Check DNS configuration
2. Verify SSL certificate
3. Check web server logs
4. Verify file permissions

### Database Connection Issues
1. Check Supabase status
2. Verify connection string
3. Check firewall rules
4. Review RLS policies

### Image Upload Failures
1. Verify Cloudinary credentials
2. Check upload preset
3. Review file size limits
4. Check CORS settings

### Performance Issues
1. Enable caching
2. Optimize images
3. Minify assets
4. Use CDN
5. Check database queries

## Rollback Procedure

### If Deployment Fails
1. **Netlify/Vercel**: Revert to previous deployment
2. **Custom Server**: Restore from backup
3. **Docker**: Roll back to previous image

```bash
# Docker rollback
docker run -p 80:80 rewear:previous-tag
```

## Maintenance

### Regular Tasks
- [ ] Monitor error logs
- [ ] Check performance metrics
- [ ] Update dependencies
- [ ] Review security logs
- [ ] Backup database
- [ ] Test disaster recovery

### Monthly
- [ ] Review analytics
- [ ] Check for updates
- [ ] Audit user accounts
- [ ] Review payment transactions

### Quarterly
- [ ] Security audit
- [ ] Performance review
- [ ] Capacity planning
- [ ] Disaster recovery drill

## Support & Resources

- **Supabase Docs**: https://supabase.com/docs
- **Cloudinary Docs**: https://cloudinary.com/documentation
- **Netlify Docs**: https://docs.netlify.com
- **Nginx Docs**: https://nginx.org/en/docs/

## Emergency Contacts

- Supabase Support: support@supabase.io
- Cloudinary Support: support@cloudinary.com
- Hosting Provider Support: (your provider)
