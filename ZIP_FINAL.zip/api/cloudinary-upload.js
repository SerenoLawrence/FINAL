// ============================================================
// Cloudinary Upload Helper
// ============================================================
// Handles image uploads to Cloudinary with organized folders
// ============================================================

class CloudinaryUploader {
  constructor() {
    this.config = window.CLOUDINARY_CONFIG;
    this.folders = window.CLOUDINARY_FOLDERS;
    
    if (!this.config || !this.config.cloudName) {
      console.error('[cloudinary] Configuration not loaded! Make sure cloudinary-config.js is included first.');
    }
  }

  /**
   * Upload a single file to Cloudinary
   * @param {File} file - The file to upload
   * @param {string} folder - The folder path (use CLOUDINARY_FOLDERS constants)
   * @param {object} options - Additional upload options
   * @returns {Promise<object>} Upload result with secure_url
   */
  async uploadFile(file, folder, options = {}) {
    try {
      // Validate file
      if (!file || !(file instanceof File)) {
        throw new Error('Invalid file provided');
      }

      // Validate file type
      if (!file.type.startsWith('image/')) {
        throw new Error('Only image files are allowed');
      }

      // Validate file size (max 10MB)
      const maxSize = options.maxSize || 10 * 1024 * 1024; // 10MB default
      if (file.size > maxSize) {
        throw new Error(`File size exceeds ${maxSize / 1024 / 1024}MB limit`);
      }

      // Create form data
      const formData = new FormData();
      formData.append('file', file);
      formData.append('upload_preset', this.config.uploadPreset);
      
      // Add folder if provided
      if (folder) {
        formData.append('folder', folder);
      }

      // Add custom public_id if provided
      if (options.publicId) {
        formData.append('public_id', options.publicId);
      }

      // Add tags if provided
      if (options.tags && Array.isArray(options.tags)) {
        formData.append('tags', options.tags.join(','));
      }

      // Upload to Cloudinary
      const uploadUrl = `https://api.cloudinary.com/v1_1/${this.config.cloudName}/image/upload`;
      
      console.log('[cloudinary] Uploading to:', uploadUrl);
      console.log('[cloudinary] Using preset:', this.config.uploadPreset);
      console.log('[cloudinary] File size:', file.size, 'bytes');
      
      const response = await fetch(uploadUrl, {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('[cloudinary] Upload failed:', response.status, errorText);
        
        let errorMessage = 'Upload failed';
        try {
          const errorJson = JSON.parse(errorText);
          errorMessage = errorJson.error?.message || errorMessage;
        } catch (e) {
          errorMessage = errorText || errorMessage;
        }
        
        throw new Error(errorMessage);
      }

      const result = await response.json();
      
      console.log('[cloudinary] Upload successful:', result.secure_url);
      
      return {
        success: true,
        url: result.secure_url,
        publicId: result.public_id,
        width: result.width,
        height: result.height,
        format: result.format,
        bytes: result.bytes,
        thumbnail: this.getThumbnailUrl(result.public_id, 200, 200),
      };

    } catch (error) {
      console.error('[cloudinary] Upload error:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Upload multiple files
   * @param {File[]} files - Array of files to upload
   * @param {string} folder - The folder path
   * @param {object} options - Additional upload options
   * @returns {Promise<object[]>} Array of upload results
   */
  async uploadMultiple(files, folder, options = {}) {
    const uploads = files.map(file => this.uploadFile(file, folder, options));
    return Promise.all(uploads);
  }

  /**
   * Generate a thumbnail URL from a Cloudinary public_id
   * @param {string} publicId - The Cloudinary public_id
   * @param {number} width - Thumbnail width
   * @param {number} height - Thumbnail height
   * @returns {string} Thumbnail URL
   */
  getThumbnailUrl(publicId, width = 200, height = 200) {
    return `https://res.cloudinary.com/${this.config.cloudName}/image/upload/c_fill,w_${width},h_${height}/${publicId}`;
  }

  /**
   * Generate an optimized image URL
   * @param {string} publicId - The Cloudinary public_id
   * @param {object} transformations - Transformation options
   * @returns {string} Optimized image URL
   */
  getOptimizedUrl(publicId, transformations = {}) {
    const {
      width = 800,
      height = 600,
      crop = 'fill',
      quality = 'auto',
      format = 'auto'
    } = transformations;

    return `https://res.cloudinary.com/${this.config.cloudName}/image/upload/c_${crop},w_${width},h_${height},q_${quality},f_${format}/${publicId}`;
  }

  /**
   * Delete an image from Cloudinary (requires backend API)
   * Note: This requires server-side implementation with API secret
   * @param {string} publicId - The Cloudinary public_id to delete
   */
  async deleteImage(publicId) {
    console.warn('[cloudinary] Delete operation requires backend API with authentication');
    // This would need to be implemented on your backend
    // because it requires the API secret which should never be exposed to the client
    return {
      success: false,
      error: 'Delete operation must be implemented on backend'
    };
  }
}

// Initialize and export
window.CloudinaryUploader = CloudinaryUploader;
window.cloudinaryUploader = new CloudinaryUploader();

console.log('[cloudinary] Uploader initialized');
