// ============================================================
// Cloudinary Configuration
// ============================================================
// IMPORTANT: Replace these with your actual Cloudinary credentials
// Get them from: https://cloudinary.com/console
// ============================================================

const CLOUDINARY_CONFIG = {
  cloudName: 'divivr6jo',              // Your cloud name
  uploadPreset: 'rewear_uploads',      // The preset you'll create
  apiKey: '982683389468518',           // Your API key
};

// Folder structure for organized storage
const CLOUDINARY_FOLDERS = {
  products: 'rewear/products',              // Product listings
  verification: {
    ids: 'rewear/verification/ids',         // Government IDs
    selfies: 'rewear/verification/selfies', // Selfie with ID
  },
  payments: {
    gcash: 'rewear/payments/gcash',         // GCash QR codes
    receipts: 'rewear/payments/receipts',   // Payment receipts
  },
  profiles: 'rewear/profiles',              // Profile pictures
};

// Export configuration
window.CLOUDINARY_CONFIG = CLOUDINARY_CONFIG;
window.CLOUDINARY_FOLDERS = CLOUDINARY_FOLDERS;

console.log('[cloudinary] Configuration loaded');
