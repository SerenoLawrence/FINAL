# REWEAR - Sustainable Fashion Marketplace

A modern, full-featured e-commerce platform for buying and selling pre-loved fashion items.

## 🚀 Quick Start

### Prerequisites
- Node.js or Python (for local server)
- Modern web browser
- Supabase account (for backend)
- Cloudinary account (for image hosting)

### Local Development

```bash
# Start local server on port 5500
python -m http.server 5500 --directory yoww-main

# Or with Node.js
npx http-server yoww-main -p 5500
```

Visit: `http://127.0.0.1:5500/yoww-main/`

## 📋 Features

### Buyer Features
- **Browse Products** - Shop pre-loved fashion items
- **Order Management** - View order history with full preview
  - Product image, name, price, size, quantity
  - Order status and payment information
  - Delivery address and tracking
- **Order Actions**
  - 🔍 Track orders in real-time
  - ✕ Cancel pending orders
  - ✓ Confirm receipt when delivered
  - ⭐ Leave reviews for received items
  - 💬 Chat with sellers about orders
- **Wishlist** - Save favorite items
- **Messaging** - Direct communication with sellers
- **Account Management** - Profile, addresses, payment methods

### Seller Features
- **Product Listings** - Add and manage inventory
- **Order Management** - View and process buyer orders
- **Seller Dashboard** - Sales analytics and statistics
- **Verification** - Identity verification for trust
- **Messaging** - Communicate with buyers
- **Earnings** - Track sales and payouts

### Admin Features
- **User Management** - Manage buyers and sellers
- **Order Monitoring** - Track all transactions
- **Payment Verification** - Approve/reject payment proofs
- **Security Monitoring** - Audit logs and activity tracking

## 🏗️ Project Structure

```
yoww-main/
├── index.html              # Main landing page
├── pages/                  # All page templates
│   ├── dashboard.html      # Main dashboard (buyer/seller)
│   ├── shop.html           # Product listing
│   ├── product.html        # Product details
│   ├── checkout.html       # Checkout flow
│   └── ...
├── js/                     # JavaScript modules
│   ├── auth.js             # Authentication
│   ├── dashboard-buyer.js  # Buyer dashboard logic
│   ├── dashboard-seller.js # Seller dashboard logic
│   ├── cart.js             # Shopping cart
│   ├── checkout.js         # Checkout logic
│   └── ...
├── css/                    # Stylesheets
│   ├── style.css           # Main styles
│   ├── dashboard.css       # Dashboard styles
│   ├── responsive.css      # Mobile responsive
│   └── ...
├── api/                    # Backend integrations
│   ├── supabase.js         # Database client
│   ├── cloudinary-config.js # Image hosting
│   └── ...
└── database/               # SQL schemas
    └── REWEAR_FULL_SETUP.sql
```

## 🔧 Configuration

### Environment Variables
Create `.env` file or update in `api/supabase.js`:

```javascript
const SUPABASE_URL = 'your-supabase-url'
const SUPABASE_KEY = 'your-supabase-key'
```

### Cloudinary Setup
Update in `api/cloudinary-config.js`:

```javascript
const CLOUDINARY_CLOUD_NAME = 'your-cloud-name'
const CLOUDINARY_UPLOAD_PRESET = 'your-preset'
```

## 📱 Key Pages

| Page | Path | Purpose |
|------|------|---------|
| Dashboard | `/pages/dashboard.html` | Main buyer/seller hub |
| Shop | `/pages/shop.html` | Browse products |
| Product | `/pages/product.html` | Product details |
| Checkout | `/pages/checkout.html` | Purchase flow |
| Order Tracking | `/pages/order-tracking.html` | Track shipments |
| Seller Verification | `/pages/seller-verification.html` | Become a seller |

## 💾 Database

### Main Tables
- **users** - User accounts and profiles
- **products** - Inventory listings
- **orders** - Purchase transactions
- **reviews** - Product and seller reviews
- **messages** - User conversations
- **sellers** - Seller profiles and verification

See `database/REWEAR_FULL_SETUP.sql` for complete schema.

## 🔐 Security

- Row-Level Security (RLS) on all tables
- Email verification for accounts
- Payment proof verification
- Seller identity verification
- Audit logging for admin actions
- Secure password hashing

## 📊 Order Workflow

```
Pending → Confirmed → Shipped → Delivered → Received → Complete
   ↓
 Cancelled
```

**Payment Status**: Pending → Submitted → Verified → Complete

## 🎨 UI/UX

- **Responsive Design** - Mobile, tablet, desktop
- **Dark Mode Support** - Modern color scheme
- **Accessibility** - WCAG compliant
- **PWA Ready** - Offline support, installable
- **Real-time Updates** - WebSocket subscriptions

## 🚀 Deployment

### Netlify
1. Connect GitHub repository
2. Set build command: (static site, no build needed)
3. Set publish directory: `yoww-main`
4. Add environment variables in Netlify UI
5. Deploy

### Vercel
1. Import project from GitHub
2. Set root directory: `yoww-main`
3. Add environment variables
4. Deploy

### Custom Server
1. Upload `yoww-main` folder to server
2. Configure web server to serve static files
3. Set up SSL certificate
4. Configure environment variables

## 🐛 Troubleshooting

### Orders not loading
- Check browser console for errors
- Verify Supabase connection
- Check RLS policies on orders table

### Images not displaying
- Verify Cloudinary configuration
- Check image URLs in database
- Ensure CORS is enabled

### Authentication issues
- Clear browser cache and cookies
- Check Supabase auth configuration
- Verify email verification settings

## 📞 Support

For issues or questions:
1. Check console for error messages
2. Review database logs in Supabase
3. Check network requests in browser DevTools
4. Review audit logs in admin panel

## 📝 License

All rights reserved. REWEAR © 2024

## 🔄 Recent Updates

- ✅ Order preview with full details (no click needed)
- ✅ Cancel order functionality for pending orders
- ✅ Chat with seller feature
- ✅ Real-time order tracking
- ✅ Payment verification system
- ✅ Seller verification workflow
